if (not LPH_OBFUSCATED) then
      LPH_ENCNUM = function(toEncrypt, ...)
          assert(type(toEncrypt) == "number" and #{...} == 0, "LPH_ENCNUM only accepts a single constant double or integer as an argument.")
          return toEncrypt
      end
      LPH_NUMENC = LPH_ENCNUM
  
      LPH_ENCSTR = function(toEncrypt, ...)
          assert(type(toEncrypt) == "string" and #{...} == 0, "LPH_ENCSTR only accepts a single constant string as an argument.")
          return toEncrypt
      end
      LPH_STRENC = LPH_ENCSTR
  
      LPH_ENCFUNC = function(toEncrypt, encKey, decKey, ...)
          assert(type(toEncrypt) == "function" and type(encKey) == "string" and #{...} == 0, "LPH_ENCFUNC accepts a constant function, constant string, and string variable as arguments.")
          return toEncrypt
      end
      LPH_FUNCENC = LPH_ENCFUNC
  
      LPH_JIT = function(f, ...)
          assert(type(f) == "function" and #{...} == 0, "LPH_JIT only accepts a single constant function as an argument.")
          return f
      end
      LPH_JIT_MAX = LPH_JIT
  
      LPH_NO_VIRTUALIZE = function(f, ...)
          assert(type(f) == "function" and #{...} == 0, "LPH_NO_VIRTUALIZE only accepts a single constant function as an argument.")
          return f
      end
  
      LPH_NO_UPVALUES = function(f, ...)
          assert(type(setfenv) == "function", "LPH_NO_UPVALUES can only be used on Lua versions with getfenv & setfenv")
          assert(type(f) == "function" and #{...} == 0, "LPH_NO_UPVALUES only accepts a single constant function as an argument.")
          return f
      end
  
      LPH_CRASH = function(...)
          assert(#{...} == 0, "LPH_CRASH does not accept any arguments.")
      end
  end
  
  local cheat = { GameName = 'None', Modules = { }, Globals = { } }

  local Players = game:GetService("Players")
  local Http = game:GetService("HttpService")
  local UIS = game:GetService("UserInputService")
  local Run = game:GetService("RunService")
  local Tween = game:GetService("TweenService")

  cheat.ac = { ok = false, watch = true }
  local function log(tag, msg)
      if not cheat.ac.watch then
          return
      end
      if cheat.debugWrite then
          cheat.debugWrite("log", tostring(tag), tostring(msg))
      end
  end
  cheat.log = log

  local debugSession = { active = false, lines = {}, startedAt = 0, connections = {} }
  cheat.debugSession = debugSession

  local function shortBytes(text)
      text = tostring(text)
      if text:match("^[%w%s%p]*$") then
          return text
      end
      local hex = {}
      for index = 1, math.min(#text, 6) do
          hex[#hex + 1] = string.format("%02x", text:byte(index))
      end
      return "#" .. table.concat(hex)
  end

  local function describe(value, depth)
      depth = depth or 0
      local kind = typeof(value)
      if kind == "Vector3" then
          return string.format("V3(%.2f, %.2f, %.2f)", value.X, value.Y, value.Z)
      elseif kind == "CFrame" then
          local position, look = value.Position, value.LookVector
          return string.format("CF(%.2f, %.2f, %.2f | look %.3f, %.3f, %.3f)", position.X, position.Y, position.Z, look.X, look.Y, look.Z)
      elseif kind == "Instance" then
          local parentName = value.Parent and shortBytes(value.Parent.Name) or "nil"
          return "<" .. value.ClassName .. " " .. parentName .. "/" .. shortBytes(value.Name) .. ">"
      elseif kind == "EnumItem" then
          return tostring(value)
      elseif kind == "number" then
          return string.format("%.4f", value)
      elseif kind == "string" then
          return "\"" .. shortBytes(value) .. "\""
      elseif kind == "function" then
          return "fn"
      elseif kind == "table" then
          if depth >= 3 then
              return "{...}"
          end
          local parts = {}
          local count = 0
          for key, item in pairs(value) do
              count = count + 1
              if count > 24 then
                  parts[#parts + 1] = "..."
                  break
              end
              parts[#parts + 1] = tostring(type(key) == "string" and shortBytes(key) or key) .. "=" .. describe(item, depth + 1)
          end
          return "{" .. table.concat(parts, ", ") .. "}"
      end
      return tostring(value)
  end

  local function debugWrite(tag, ...)
      if not debugSession.active then
          return
      end
      local pieces = {}
      for index = 1, select("#", ...) do
          local item = select(index, ...)
          pieces[#pieces + 1] = type(item) == "string" and item or describe(item)
      end
      local lines = debugSession.lines
      if #lines >= 30000 then
          return
      end
      lines[#lines + 1] = string.format("[%8.3f] %-10s %s", os.clock() - debugSession.startedAt, tag, table.concat(pieces, " "))
  end
  cheat.debugWrite = debugWrite
  cheat.describe = describe
  local function fatal(msg)
      pcall(function()
          game:GetService("StarterGui"):SetCore("SendNotification", { Title = "dihhaxx", Text = "Unsupported executor", Duration = 8 })
      end)
      local player = Players.LocalPlayer
      if player then
          player:Kick("Connection closed")
      end
  end
  cheat.fatal = fatal
  cheat.watch = function(fn, msg)
      return function(...)
          local results = table.pack(pcall(fn, ...))
          if not results[1] then
              log("error", tostring(msg) .. ": " .. tostring(results[2]))
              return
          end
          return table.unpack(results, 2, results.n)
      end
  end
  do
      local need = { checkcaller = "function", hookfunction = "function", gethui = "function",
          islclosure = "function", getcallingscript = "function", getgc = "function" }
      for gname, gtype in pairs(need) do
          if type(rawget(_G or getgenv(), gname)) ~= gtype and type(rawget(getgenv(), gname)) ~= gtype then
              fatal("executor function unavailable: " .. gname)
              return
          end
      end
      local lp0 = Players.LocalPlayer
      if typeof(lp0) ~= "Instance" then
          fatal("no local player yet")
          return
      end
  end

  local function guardClosures()
      local scripts = Players.LocalPlayer and Players.LocalPlayer:FindFirstChild("PlayerScripts")
      local guard = scripts and scripts:FindFirstChild("FallenGuard")
      if not guard then
          return nil
      end
      local count = 0
      if getgc and islclosure then
          for _, fn in getgc(false) do
              if type(fn) == "function" and islclosure(fn)
                  and not (isexecutorclosure and isexecutorclosure(fn)) then
                  local okSrc, source = pcall(debug.info, fn, "s")
                  if okSrc and tostring(source):find("FallenGuard", 1, true) then
                      count = count + 1
                  end
              end
          end
      end
      return count
  end
  cheat.guardClosures = guardClosures

  do
      local tries = 0
      local function attempt()
          local count = guardClosures()
          if count then
              cheat.ac.ok = true
              return
          end
          tries = tries + 1
          if tries < 10 then
              task.delay(0.4 + math.random() * 0.3, attempt)
          end
      end
      task.spawn(attempt)
      task.spawn(function()
          while true do
              task.wait(30)
              if not cheat.ac.ok and guardClosures() then
                  cheat.ac.ok = true
              end
          end
      end)
  end

  local fetch do
      local repo = "sad-ddot/kota-main"
      local key = "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"
      local function req(opts)
          if syn and type(syn.request) == "function" then return syn.request(opts) end
          if type(request) == "function" then return request(opts) end
          if type(http_request) == "function" then return http_request(opts) end
          if http and type(http.request) == "function" then return http.request(opts) end
          return nil
      end
      fetch = function(path)
          local url = "https://api.github.com/repos/" .. repo .. "/contents/" .. path .. "?ref=main"
          local last = "no http"
          for _, scheme in ipairs({ "Bearer ", "token " }) do
              local ok, res = pcall(req, {
                  Url = url,
                  Method = "GET",
                  Headers = {
                      Authorization = scheme .. key,
                      Accept = "application/vnd.github.raw",
                      ["User-Agent"] = "roblox",
                  },
              })
              if ok and res then
                  local code = res.StatusCode or res.Status
                  if code == 200 and type(res.Body) == "string" and #res.Body > 100 then
                      return res.Body
                  end
                  last = "http " .. tostring(code)
                  if code ~= 401 and code ~= 403 then break end
              elseif not ok then
                  last = tostring(res)
              end
          end
          error("fetch failed: " .. path .. " (" .. last .. ")")
      end
  end

  local libLink = "https://raw.githubusercontent.com/sad-ddot/fun/refs/heads/main/uis.lua"
  local ok_net, libSource = pcall(function() return game:HttpGet(libLink) end)
  local ok_load, libChunk = false, nil
  if ok_net and type(libSource) == "string" then
      ok_load, libChunk = pcall(loadstring, libSource)
  end
  if not ok_load or type(libChunk) ~= "function" then
      fatal("library fetch failed")
      return
  end
  local ok_lib, lib_ret = pcall(libChunk)
  if not ok_lib or typeof(lib_ret) ~= "table" then
      fatal("library build failed")
      return
  end
  local Library = lib_ret
  local flags = Library.Flags
  local apply_equip_aim
  local clearLos
  local Window = Library:Window({
      Title = "dihhaxx",
  })
  local Watermark = Library:Watermark({
      Name = "dihhaxx",
  })
  local KeybindList = Library:KeybindList({Name = "Keybinds"})
  local InvViewer = Library:InventoryViewer()
  local TargetHUD = Library:TargetIndicator()
  local PlayerList = Library:Playerlist({Name = "Player List"})
  Watermark:SetVisibility(true)
  KeybindList:SetVisibility(false)
  InvViewer:SetVisibility(false)
  TargetHUD:SetVisibility(false)
  PlayerList:SetVisibility(false)

  local rosterAdded = {}
  local function syncRoster()
      local list = game:GetService("Players"):GetPlayers()
      for i = 1, #list do
          local plr = list[i]
          if not rosterAdded[plr] then
              rosterAdded[plr] = true
              pcall(function() PlayerList:Add(plr) end)
          end
      end
  end
  syncRoster()
  game:GetService("Players").PlayerAdded:Connect(function(plr)
      if not rosterAdded[plr] then
          rosterAdded[plr] = true
          pcall(function() PlayerList:Add(plr) end)
      end
  end)
  game:GetService("Players").PlayerRemoving:Connect(function(plr)
      rosterAdded[plr] = nil
      pcall(function() PlayerList:Remove(plr) end)
  end)

  local indLines = nil
  local indTarget = nil
  local function indSetLine(which, text, color)
      if indLines == nil then
          indLines = {
              weapon = TargetHUD:AddItem(""),
              status = TargetHUD:AddItem(""),
              texts = { weapon = "", dist = "" },
          }
          pcall(function()
              indLines.weapon.Instance.LayoutOrder = 1
              indLines.status.Instance.LayoutOrder = 2
          end)
      end
      if which == "weapon" or which == "dist" then
          indLines.texts[which] = text
          local weaponText, distanceText = indLines.texts.weapon, indLines.texts.dist
          text = (distanceText ~= "" and weaponText ~= "") and (weaponText .. " - " .. distanceText) or (weaponText .. distanceText)
          which = "weapon"
      end
      local entry = indLines[which]
      if entry ~= nil and entry.Instance ~= nil then
          pcall(function()
              entry.Instance.Text = text
              entry.Instance.Visible = true
              entry.Instance.TextTransparency = 0
          end)
          if color ~= nil then
              pcall(function()
                  entry.Instance.TextColor3 = color
              end)
          end
      end
  end


  local previewTicks = { inventory = 0, targetHud = 0 }

  local function keepOnScreen(widget)
      local ok, position, size = pcall(function()
          return widget:GetBounds()
      end)
      if not ok or typeof(position) ~= "Vector2" then
          return
      end
      local viewport = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1920, 1080)
      local outside = position.X < 0 or position.Y < 0
          or position.X + size.X > viewport.X
          or position.Y + size.Y > viewport.Y
      if outside then
          local x = math.clamp(position.X, 8, math.max(viewport.X - size.X - 8, 8))
          local y = math.clamp(position.Y, 8, math.max(viewport.Y - size.Y - 8, 8))
          widget:SetPosition(UDim2.fromOffset(x, y))
      end
  end

  do
      local localPlayer = Players.LocalPlayer
      local inventoryPreviewShown = false
      local targetPreviewShown = false

      Run.RenderStepped:Connect(function()
          local menuOpen = Library.WindowOpenState ~= false
          local now = os.clock()

          local inventoryLoopAlive = now - previewTicks.inventory < 0.5
          if not inventoryLoopAlive then
              local showInventory = menuOpen and flags.ArmorBarEnabled == true
              InvViewer:SetVisibility(showInventory)
              if showInventory and not inventoryPreviewShown then
                  inventoryPreviewShown = true
                  keepOnScreen(InvViewer)
                  local held = {}
                  local character = localPlayer.Character
                  if character then
                      for _, child in ipairs(character:GetChildren()) do
                          if child:IsA("Model") and child.Name ~= "Hair" and child.Name ~= "HolsterModel" and not child.Name:match("^Armor_") then
                              held[#held + 1] = { Name = child.Name:match("^(.-)/") or child.Name }
                          end
                      end
                  end
                  InvViewer:SetTarget(localPlayer.Name .. " (preview)")
                  InvViewer:SetSummary("")
                  InvViewer:SetSections({
                      { Name = "Holding Weapon", Entries = held },
                      { Name = "Armor", Entries = {} },
                  })
              elseif not showInventory then
                  inventoryPreviewShown = false
              end
          end

          local targetLoopAlive = now - previewTicks.targetHud < 0.5
          if not targetLoopAlive then
              local showTarget = menuOpen and flags.TargetHUDEnabled == true
              TargetHUD:SetVisibility(showTarget)
              if showTarget and not targetPreviewShown then
                  targetPreviewShown = true
                  keepOnScreen(TargetHUD)
                  indTarget = localPlayer
                  task.spawn(function()
                      pcall(function()
                          TargetHUD:SetTarget(localPlayer)
                      end)
                  end)
                  indSetLine("weapon", "WPN Preview")
                  indSetLine("dist", "0.0 m")
                  indSetLine("status", "Visible - Head", Color3.fromRGB(80, 255, 120))
              elseif not showTarget then
                  targetPreviewShown = false
              end
          end
      end)
  end

  local function flagColor(v, fallback)
      fallback = fallback or Color3.fromRGB(255, 255, 255)
      if typeof(v) == "Color3" then
          return v, 0
      end
      if type(v) == "table" then
          local c = v.Color
          if typeof(c) == "Color3" then
              local a = v.Alpha
              if type(a) ~= "number" then
                  a = v.Transparency
              end
              if type(a) ~= "number" then
                  a = 0
              end
              return c, a
          end
      end
      return fallback, 0
  end


  local removalFlags = {
      ["No Recoil"] = "NoRecoil",
      ["No Spread"] = "NoSpread",
      ["No Sway"] = "NoSway",
      ["No Bob"] = "NoBob",
      ["No VM Recoil"] = "NoVMRecoil",
      ["No Muzzle Flash"] = "NoMuzzleFlash",
      ["No Fall Damage"] = "NoFall",
  }
  local function isRemoved(name)
      if flags.Removals ~= true then return false end
      local key = removalFlags[name]
      if not key then return false end
      return flags[key] == true
  end
  local function syncRemovals()
      if getgenv().bobSwitch then getgenv().bobSwitch(isRemoved("No Bob")) end
      if getgenv().kickSwitch then getgenv().kickSwitch(isRemoved("No VM Recoil")) end
      if getgenv().flashSwitch then getgenv().flashSwitch(isRemoved("No Muzzle Flash")) end
  end


  local function bindOn(state, flag)
      if state ~= true then
          return false
      end
      if not flag then
          return true
      end
      local kb = flags[flag]
      if type(kb) ~= "table" then
          return true
      end
      local key = kb.Key
      if type(key) ~= "string" or key == "" or key == "None" then
          return true
      end
      if kb.Mode == "Always" then
          return true
      end
      return kb.Toggled == true
  end

  local CombatPage = Window:Page({Name = "Combat"})
  local GunModsTab
  local VisualsPage = Window:Page({Name = "Visuals"})
  local MiscPage = Window:Page({Name = "Misc"})
  local MiscMain = MiscPage:SubPage({Name = "Main"})
  
  local Players, Debris, workspace, GuiService, Run, RS, UIS, Lighting, Http = game:GetService('Players'), game:GetService('Debris'), game:GetService('Workspace'), game:GetService('GuiService'), game:GetService('RunService'), game:GetService('ReplicatedStorage'), game:GetService('UserInputService'), game:GetService('Lighting'), game:GetService('HttpService')
  
  cheat.Globals.HitSoundNames = {}
  cheat.Globals.HitSoundIds = {}
  cheat.Globals.DesyncParts = {}
  cheat.Globals.DesyncedPositions = {}
  
  cheat.Globals.LastManip = tick()
  cheat.Globals.LastAutoReload = tick()
  local hitsounds
  do
        hitsounds = {
          ["SitNNDog"] = [[SUQzBAAAAAABAFRYWFgAAAASAAADbWFqb3JfYnJhbmQAbXA0MgBUWFhYAAAAEQAAA21pbm9yX3ZlcnNpb24AMABUWFhYAAAAHAAAA2NvbXBhdGlibGVfYnJhbmRzAGlzb21tcDQyAFRTU0UAAAAPAAADTGF2ZjYwLjE2LjEwMAAAAAAAAAAAAAAA//tQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAABhAACZyAACAgUICw4QFBcaHSAjJSksLjE0Njk8P0FERkhLTVBSVFdXWVxeYGNlaGpsb3F0d3p9gIOGioyQkpaanZ+hpKaprK6usbS2ubu+wMPGyMrO0NLV19rc3+Hj5ujr7vDz9fj6/f8AAAAATGF2YzYwLjMxAAAAAAAAAAAAAAAAJAJAAAAAAAAAmchFe2Q9AAAAAAAAAAAAAAAAAAAAAP/7EGQAD/AAAGkAAAAIAAANIAAAAQAAAf4AAAAgAAA/wAAABBFSICwf/8QHPWD6vB8CA/EAIOWD/UCDuu/o1QQBA5EZ8oCDhAcgh/+X93//0neIdlVkUmZldd/dZI5Q0AVksfaEoyDm//sQZCIP8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEMSXO3scb9/JHnudxilFS10LNKtDorFxUTRoHv39sPPkocH64TTtaZXbEgRA6MSP5OLZAHm6Wp+w6IhoRioRyq8lEM6T/+5BkRAjwAAB/gAAACAAAD/AAAAEFnAEC1AAAAAAAP8KAAARo0NIoWPcxAtiT37oPl0yUf3/sNtadr8nKqhXooWFofg2XsLREECZ2ZmZmZWNGL83+eylHPiILSb/d/KabGw0K0O7szqzMy366SyIJMgAQOGRhIRf4MBp1VgAEIqWK2NEQEAUPgIQgICKsJACWpIgWWXYmzUBEK7L4isUqa5FRG6BQjGPTLYIKyzCCdHNREPDUyKJ1Jy8qBIqiMVzbUvfKYGhi+SK4UVBx5NgYR4G3QqBp73S1nbL4Plq20zANOY6QMKAoCGSbrOUHmvpm/daW/amkQjIQcGAK5HnAMKOguIrCOHoSH8RBBBqwLDC0hdAMLZxDCyAQELEUrYk5msJ0JiWAqEoO+UHtgYVUg6gYm0Fy3Dbe1M2tctYYqahC5hhNhk0hx1z/MEZMhH5Bph3fz7/2fJmTVgKDDoZUi17r2GK2f/0f/0VJuqqaiVkcRAtJwKsYdbHigUPjxQxAoSooJGvlUcIBhc0WDGEGNcCgUYEhHT7Zi8AGIjRXncX/+5Bk7AAEx0xGfmGAAAAAD/DAAAAhGUMV+cyAAAAAP8MAAAD+q0hsdFIYXc/lSkVhTG+r29fXOnasjq5TsCEL+rn41pRAINdKyIf1kUvOU7LM3Kl+8cUkr3BeU7nA7CftJswXFbphsgoVIkm9WJGO4aVD5laiVHS9LqxqZTIcPMfxgoM4jJRKAspWlOq5CoJ8IItzJRkZttG93ac39csdvtr122PPPC0watH8C8L08GBPrGoM+dtmKaguLVwgt42CFXlXNwq2OJAWjdGhN04UDkPPcU1xz48M0RsopSaKYhFZaZIxaAGipeoOICghZDR7oxGGrP7qWts7xpJ9ZQBgQzxbT9VNFMpG8/TtbI/Rx2H+1trEqnFXoQdVFLU3GOBdJryqYmSFCnhQnF43wrWb9K5uZmxcMjFCP9WLuC8mkbDpbYO3kq8yrKhbD3fr6ja1UVocxgG9IiU00JlIptsVROUsGCr1zO11VMOPoMTKMNI6YoEPaAI8re27a6aZzJ+zNF/YNgyo14gpnVjsQCYgpQzd3KuHf7WIj89wcQXynWL/+6Bk2YD2l17If2ngCgAAD/DgAAEZ9ZEh7LzV6AAANIAAAAQgzFKDjwDeA6AV6X2XUX1bOHLMCKgiixwqxkE/FwFvVieVCNZ1Oj0AXsxy2JA91c7hFiV6OLykymlb8qk5YTLDPAIOF4z4iQohWSkAOrZEsuKjTidkoIAS9QKRYw+jjuyPig8ym4XwUJk2zimKFZGir1RSRgqORGiymMTMMDQrKG2gbJk+f+/8UNM7u29TXwbXv+G5WSl0rqvf1PV2GNzanX2Eu7fSWYwuxKQbmqmodVklRAtO1WV6aF4ZyGGCggIHERJkHPjNhGGKVp3iEGhuFgCcA8BkLBE1lMZQ19r8bedz3+eKDzmZGEuqqR6MUZ6nKhLGqVeicrKERS+wzGNMkQSlOsycNFkRRpu6qM5GLwZXDLnVqZ2FHx4ThEsvyKhSXfMU1tNSrUy7VJ2JRtclE1v5U42ORhEiYnqWXDVVENLiwK41zRNU8HF6gU6faRLsVC6PRW3g6ZacHw9FLJEIiyyRsO4orkmmFDTRcRTpVSydC2sfKjNMYOVrs9us1NVHwxl5mZlWWNxoDY3HldgovMwrTllQ6JJhw05BA0EEwCFQ5EwgxREkFsJRKnnFaQhg9y7YyxpPZkGblzrd4pLlLZA8ym5XSgfdMkSpeJ1CoNKN4fBONiUeh8F5kUFhwLgaDq+bjkP/+5Bk+wD12GZKey9L2gAADSAAAAEa4Zkf7T0V6AAANIAAAATaolsn3dDccWy7YnFpDPUx+lahUl1qNeo+q3KdZYqx+Nc16/2Y6XTnQcRE8zTe2rOnR3bHSOV7ztI3fuCSCS5aYS5QpDFpj0q4h5dllfElo9YuwtGLhxDitjl13m8iQLvM2qaGtlaAuH17/LAgIMZMKYcgFlBixABOjSMzo4HRjGhGWUyWqE0aAQfBsEKZQShqxZabOpLR4PtDj+zTuwl/nCgXOmZhDFp/pY7shma0idSl1jTuFTMyqL3hcVl8Iby2yOLiArMl5fjcPy2odjhodJ7L22K01YmHp5lUqxeJ9Vb+GB6ZIaZQVdVr1Dy+BcYDxCPoVPHQpEYexwbNEJVenztcB0RHKHHUa45Sj6X5TWbiFMFPpmrWnW7v6ip3HJatA0f0Tf//////+lTsp0IaqpuZhVjaIAtOHIWTGiARhoMaLBfMeRTKLJqhM0s40DHDe9OcCiw6osCEBWEjBZFjSRjHqTNEM6kXzZOtCEwni7tZ4p5UtTt6fKfjMDL/+5Bk8ID2FGZG+0xF4gAAD/AAAAEY1Z0l7TEc4CYAY0AAAAA0KlSVZ0axRm9mfK18YrlPW6eXUG7YtK9CoDHAZocOFWz2mWRgbns8tsRoMdhRWUPw/Y29RPD/OhGyplFs0p7OTtDWQ+EJMpLm+cykMErlalGM3hbEOJomWrNIrlkxmVQRYkd56eSPqLj+lHCDq+X0CHmkOtrPqX35dW1iSs77d66pBgbpqSLLsEP9AgQICocFBNCRbSDJBRVVVMKrLXED1YgaCQDwQKgk4xTwpMawoKXGiHMJDwKjszyG1JoZKMRpDU2QYVqMdH4ccZzcDTwiFWT1TNT1qczCwcBpIUbBb1KQonxoq3SXiqOifUUN09UioV0arnDeRNM0RhVnkUrY31Z3022qeI2PoWlbSCk3TyOr4G4CcbUTBTrY/N1may8IYhDISogxdYxM1RAGEfI6WYvRFoxXoUpmt9VzktEL4/VLJeP7O/rUucPW+1aVi6vNCiP/XGNajfeo2aXx5c7v7/+R9Hmg0ejwQJ/yCyOZIHAUMCcCgkEADf//////+6Bk5YHmtGbH+3l42A+mmPEAovBaDZkf7eXhKGCbY4wCj8DUo21FCKuqqoZ3W0QJgexRYCzw1QEyapWAxYwzRoaHioQOVCgUxowGAAUYV+3ZACrC6GorSNKZI5DlPiwB0IkrpVrqbktH2eZoMjKci8xsCrUMFPqyy+0NqPUhpM7nDc1xhuRSkUcNLMUFLrC8rF9RtiNeP21UvI6GTmq0acY8RhUM6/pWK1zinoaK5WnFCUccaplMV44uSZJQWyAe7GvkOKwvhM3jUSU8C/Haq5nBiq7ZrUDD4xleVmLZm+1684x3VFnIUKI3OO67JIdnUDanROmljUVNVwhmj14AYB///////9Q4tWNVVTVQ7WSVg/nGYt8cpeVgAgSYQGYIyCjJgA4NDJnJFBw4QhACAIhM8giARRjKpYKUDS2b1sk26K/ZqaRoURRHp8iHQNS+oWn5JMk5JH8jMtOLjE9MFp4bLo2gWKqHE2BgrAdK4dMiWYLg8K6kXQWuytUl70F9mCNlWWYKOTLcfra5Wq11fzt0c6ZmRqrNHzouWuOLTL4VsFKqy1UmfiKzSMT2qNVW9qz1E7RusUd8bsbEbBs/MX6BTjtwxVx6yhd3dneXfX5kBM5K5TJRdrCAxa7oBAyaYBNyW7AUGtLkUMhV6+bBkamHsJdWXNKdFrLp5x99X2h6VyWCadqUXpb/+5Bk8QD2t2dIe09NeAuACSIAAAAX4Ysf7TDVyAAAP8AAAARHAe3BZSFBplQDO2BsDpl9sCZeutrTPoWxBMRmUWIo0eZJAszlD09nR26SQSjsrp8KsruVL9NQQzct38s5mM3oC+VWnxVfBL6qdrctwBBEqJgsrInOmkFFKdHBWReooGalj2BUt2RJGMipC70KfUhHXtRZ1mqRXDZE8yNzbBw6DrpOMzRHLfKmTGboXlkRFMGZsAnoIU5iaeJnu5AjPKDZqZkeBkCkgoyNMMIQKRZik5QXLcFmBJWSCBCZOWMAgEs0uucgFYQMRxYuw2iGAYNEAot5KHIfiGKz7wSUClhGUoJwcAUxZwtRVRStAbKUw32kF9rYhDpbJGIYw2IwiIbsMDLtKGIZsYLaNqhzkcMpKK1F9GDoGNMWFR6cy6tycZZWljYWVAM79Xs/w/nhjEWUkpVIN0vpoJo5zkJMMklZdxAT6PAxg/DMJafw+WYh6eXxNi/BBQ6U2wo4Zx8KNRqJifuwfTHKA8C4IRJmiEHg40LISWVoHFZPZpftpPb/+6Bk3oD2nmNF+1gfOgAADSAAAAEeWXkZ7TzeqAAANIAAAARcsKjQiJgHCJDKila5qZh/ZGgLTIQfDA8Gw4AzCsVyqKBpRGhuQQY8e55lAAjHK0G0lE5kRAxkaOCzLhFyFvUcUW1Uke2nMOZG1hmFGme8BbBQNrigxbRpBXGqOUghXn4Xs3Uam4DacqjZVWk0AyjulQsyVAg2w50qaapY0aiYSGn4lIcRy0hw0C3xX6xGuuV05N7SjNKRwwzRV9j1ApuG8gOZ+l2J4zq9QIwq36ufF+Mg2DGQ5PL6wriWKdOMdGxRNqQVSkQqSM59U5g9vpLqJR89n9qNm5Y0LE9MVvq72mKVzf7rq0/r921uJi9Y+qyfUkEnBoJ2eGmsbZsC5QHHQMB05QIIHC65oImeCgBYnMJEC45lwGtBcyRUOtggZ0kilap1oDL2/UVfxrssf6ea9D8pfVrtPFmVPu3rrP7JIJn2uuLhGIMuy0AAiOMVMqHq45leT04lPNKpYULcrUros2IkJmVrS1pWFZrkhtcNG5cnJmYfGYMSIcno6/DZUybgGcfzTBYh8j0qqzGyzsNWo/mVPjaYbOdYoS9kblDGQ6bFe0riB1ATUY/rjR9AXCiLl4szGh4J+jFVM5L6agPIuZmZpZSNTV7YsLJjUClBgdtE6yuDYjzVtxAgNixFu63yINT0LMn/+5Bk7gD3SGZH+7p5+gAADSAAAAEZQU8V7bx7CAAANIAAAAR/LdVjDBbME/YClzQnacyQqaRIENy6MNCMf97oUxoXHc2M7FApFmMJ9PDfv5YigQjTI809grZ1wJcJBNLLSeE1oDkW5Kn2HQrCR4eFEjB0FsQgvgi5zNqMZFQ8T7HDcnJzuJlEbJWpQptV6NBrfw4lHDRkEQu48rmqy8sMieRzbneeCMDgw8mNMHbhmerij9i78KQmIjl+o/c3cdr/id7RCihyce9A2zty8/btkfm4qRALAjE02EFXIcxoIQZuIQ9QC48EyBYobEUBSCHZUDHXkSTnkz4U0xsz+q9ZnMNmbVEoadKrOEn6uZlOiDtO1It50Gw9Q48FWYhsGL3ggoGmm1oqi+nAnzlUY/51vUBfgRk48XLe8erT1ZbbPH6UndJldnVhjhqtw1R7rzQmVUuNlhnO+L1W2dimG2TAFIjqqQZBkKFR8LqE9qyTufzkCF/UmsmqhUU9zfrIx8igbTeklTr2EYwlFVJmeum7PGMrUR4ptuZWSQW1uHZrZGT/+6Bk0wD2a2RIe081egAADSAAAAEaFZsn7T01oAAANIAAAAQNjRh0oTLEzBuBQGeHieZyIQhhFK/0VBqKZ1wZIQrCMcBkBKDwP8e5uMaRVJcTNirsvQwVKrEC6XJpGOplQsQEqpzfO+DBOtXItQrhjxsWVDmc76pg4ISlTcE+TkigNSSTw6vyIGAklZ2BpUw7f41i/XXD1DXVMYjpYxq5WSiuZBxCDJsnh0oK7hZMRrPhDHQyKSId8NCoRBHD1Qhrzx17PuTrGPtKm4maRnz7LWMrYo9fZTz8Myv6PGYdXMV2nUzeerFWOawwR5fFpArSYd2tjaA3HGKr0E5mEylZ4H4Ldq8OfJMSjVmMyPNiZVwjuywgBRZVVUrnTxL0abSEG4gD/NBzZ3hkuTgepoFoeUZvHkomNXrpnUpznOnMv4kI5g5FI3qtdrDG/fp45hXHjIuTwnikOzexLQ4mGblxxFEdksS40SVefNJXmEO65A4yoRshunWnAmoTI/FknIZVKo91LpwBnn2rGpxKzIvdtI9OmHzVzDrC2xjyHD79p5w/fv+ZnvZZ3XbTtKwQz6uLnfYY1hh6FYqQeQbXyFpLXJAvzIUh/wwjCxu3YLzBsKcJHJiIMYMwgUFMcODNx0zkjMrSzEQkFC5lZCXwYInxDhUCzAAQEAYyFv27ECO5DEARxwIIgS5Dbtz/+5Bk9wD2jmNI+09jegAADSAAAAEZiZUl7T2RaAAANIAAAASN/84Gt3M6aXx1rcKh+bryCHG0TpUAlEhidZvbVSVFKoqJ0SGOgvORNCZBXvEq9h7vrx2khIBPU2gHRZRu8nMnZ+cMK16RSjb4vLqlY1IDIiBwPDxEHYqFU9L5DJhXaVQ+s+nxpTn/rFMQLP5GNInJyDPF+IbEzM1zL/e6lM6cPVMzfXSl2gEcmdCaMksDYyrEtQaYQVmXHMnaMKpRmOOvNoDTbMKFBgIOSIzmXCkpYoWhxwaOJCrzjKvSsI3FZaa8NQmHH/i9VwYFfqLSStE5p0rUH0tenWEbxu9aVRxd8noIF+ql4jg5ke73IgAIXPwmbyFAzq5iOGhJiuibOj15HGWkI6FJ/iHaLH4ykQ4zFovuwe2VkMpmNzwowqR2TvDzpaOhd7+L2i2+sm/XIv/5s3fP1NXGwpiAXbnD7YYemKXOmtoNeruJAGImZGrSkB3ByoZiMhUPMhGiAEMHVz718FH5mxgRGiJpgYuaiNpBq5TCC40Fh008DbAXhSj/+5Bk5oD2qmFKe2w3OgAADSAAAAEYNY0n7TB86AAANIAAAARVUJgIwkLKwB4C5LKF3Oc8sZhqHnxZ1dpeS6/TvlLMYzfZ8YyumbhMDy6MrNZgYOAtMfx6FGkqiIYiNHhkvYZESYDlUcl0qn6anltmGKd5LEvCguDLS7a51gtjMm82jQJpDlDWA+MitZ7u42vd8oJH0VDDobWBQKorFU2qiIsSopdQW1cNlb/CF+n//9ngjYGXvCJHZ6hqTTY+qZQPA36BmpAKLSlWQmDuYpCCBJrggKJIJDKRJPpdIyQDzH4wMDgFJQwutztLcEAWMAAYwIAiYMGQSOZfHY0D4DcNQcKi0OG7HZe6j6Ow+6r6Oo3CG6KI44SmregaE8oK0BGIVmZNKbtPfYCgzBmSdcsSTPrDbTysLbn79JHAYOW9WlE1WuTFLnajUPSGBL8Llc5emJvC/PSmx9+tXjr+5LQbnDxhCBKBWu/8Wi0unK8B1s4lGnFa3DdHVnLlFWf6AYxFaF7ZbBFXlTClyz4Li2QM6i3ixcSmUWZTHVkMH5wOrEb/+6Bk2YD2uGJK+28fqgAADSAAAAEc6Zkprmi16AAANIAAAAQpRBiGSTYVZKoMXJWXAEBiA2/AdC4OsAzgzZpOpZoZhMvH4lmDkidU4bEKpWYT6fQYZIyBnq71gwERMGAadjjSNJMcJVyqdCuCIhBCxqGmWc38Qi1fbWobf6rT/qVvFOrCssnbA8AJQChcbjEWflypFrHKo/Dw2+26XDco+1HntnFxJh9ditXmZ7tqmu2Y/E78C1639bopBWYWJJNNyvOPF7NHlvLO7WiUOzcpqy/5RdlUtsUk3E5XMcvY4//ftXiZ/0HpUNghsAACUuwAAGDCI3jGo7TBUzAoEYyBZh0Nxv7NZpCHRjJ2CjsIbDMZM87BPbszXSEEhFg0JwAEiJYcZIJAHXZ41IYAjCQ4J9M+c8uSBgxrFQiEBECidOXOCmGxO1K57ubpvavRi4VFGAInFbmSZGoKD1kuUXhQnOQTH6rty2/albiwfalk1X3KLFZ4xIGVBwQXXk4kzr8Lv7s/+7HabkuryCAUDWiwKSDAADT5TkLXtKgv78vl7LI/Um4s7luXuo5lRkCpH5pYMj0Q7e1ynXHmnf+xiUBkBVs/wAgcDZZMKUQmGDeOrG7OY27JuEImFjQYMDRhkfgQKmDAaFNyfRaJ8sYa0EhA2Kh5IUHOqIKaQjHMMBg5rDmhkRjhssSdye3/+5Bk7QD110lM+zzQmAAADSAAAAEaPRkrru9GoAAANIAAAASNA0OOPPhpUSoUEqxIUAw4kdqlt81iChuH4ea0gDEQ6Zq4Gv1YdDqExOGLrdUK3Ur5bxh19MdZ63H9YbhkQAphogCkIHDEUv87U7/P7hrPX/81Py2muyx2qlI9Lt27+EdjsAxbKloYzOuRdge7eg13ViTotFVH0JTdZ9xCMcFICCQXAPCwDhtDgHEQVExXAoFDEEXzBZRQ6ezC4EDAAHhULzBgBWfGBr9mvcQFZsAoDHLjTWQKMrYyU5pqmJibVyFIoIt/T0D1jOs3fkTUIYawQpFYjT7H4vGYB6WT6OSIhx0AxTDWsg3sBBoPai1C4adKEMqvdljY0OtNqgsZyl97dbCwtdWECjIkQvNhALEmBzF65Kodsvu7Hd6yx7fs36fGUPurm3hD8MV5Qsyu8DgQxLXrZfCq0pjPvrFI3MZ0edy4ixzk1fFiqq1ghgIYKcBYsAxgIgMDgQAzEoEQVBwzMMEEIlxmgBmGAMDS2YkBaJ5giNmOCKaQBWCrC4j/+5Bk5QD2RkLNezzZOAAADSAAAAEZlRk17udxIAAANIAAAATTzYrKJhsQILa4jJHDVnYr3GNq3qLHUFI76atGl4DCgcq2nJVr15l3otH5coyIxDVtCToCgDTizk62Mt2HCUB6iNtkYJCV3R2Nvo8mbxuNjTyvB+EV0KYOn6aHFSJ0WZ3LO5dry/9Y61jzmtYW4g81qbg68zhRGhkbcordgxmsshyknmVqnh6Rxv7eH8q8oq1CVBAQZQBAuDRCcwIQBAyYWkCgSYWXGNShr4AacczxhRWBBUYBjlHQMhxABiAmckQhpiqSbmDCwU0lwklwxLMKFAgygfm5eKAphJsNCLqcpospWMBkTy1SZu2jS9uERQRhYgNehDF4oz0EdkQGQgGQaUmSpoCFmh3bDst0EIHBlf52DINS4d61y5l6cQH85gciaOp+1/1nf35/7TMzVbB81QjIBrzFjHNAXU6Yj/CpQ9KQbxYCmWovv/prTdxgqgQACAARzg0g4HaDLgQFwHhxuEp2ZzznnCGhMmUUGHEDDoPRgJoKhQqXEZIElTL/+5Bk2ID2FkbPe5nbagAADSAAAAEXnRM77bH+YAAANIAAAATNTphJmeljSzADAQVZtF8Nv8nqiC02JxOSORIOdyqxuipZTZ23cCozh7AUUCxtIIKGjABz5nwpSNeG9gCu+TsSlaD5Bzkne1dIWSAcGsfzCh2rt+OuV/fp19mmT3d09E5TquE0aRILBMFKsKh/LbB8KCgEsLi/lKxQnvZnsFoCACEACW8HjKjRk14Q5EtQYylo5BtCwFgzLK2HGANCCEYEUoE2pekCDDHyTx/k6pDKpYn+YcsY0svxVZqwNImLQiwCtK40/9OweDv3MQwpg3udE+kdUaM4bMYBQkhQiAhdl5ssibsbmNBLPzCQFGxRYMKYfh98CyhgQYX1Tii7kMDBoCrMAgWtLLFELH6bje/P862GrjvN567tuj99er+E8hLsvjQ8ZD0GCBwISS4VBVgSyaCTlAJoY4rh8iSl7VR+KQs0skY4EAHO/9bPEbARAAgAsDqyxJcQIzPcHbCmw6qlwBYwdom4xgoBrmpcQWWsICpEw5c8BTNGUQEeLnL/+5Bk1wD1YUTPe09nCAAADSAAAAEZ2RU/7W36YAAANIAAAATfGgoHYdmCBuZDrEgAOMwHLtIQy1maYYCMI5W9yt22+YjSUjIwSDDDZjA6vS8hfROg1PsA+j+wAFqMOhNKpOP/MviNySMIHHAQUAIATGhHRhaUSY4EAF7wMZCgNJAsgrA48V5SRikh+d3vmt87lz+7/vNf/71zX8zt0lh7oGmpGtd5nFhqRQt5IjD0zKIrGdzrm0FbS3+b4TgAAZQDp8grBR5oB10X8EUMbqRiw0asIm6GRgZWa2NGXmBkY8YoQJUmMmoXNhoIUcLLhYuNQQhJvtNftKnHBHblTPl6JkEwqC0It08ikOViHH0bdpsqdtga1xEEAQzgjKghlQHYAb/ptPHH0DUjOONoQGEIlvSy9HMUCLUphItpEPakWgIXMzSGIxbjSyszxrzGnh/Pt/9/WL5/x8fE0FrYFk7KHUmC3qIo0NJcimqWRuwzsz9xY3Bx/ElCIBECAA7wDG0UHCIOCTNSIwY8MwLRKQMfAU7zMGA1gHVEwxxjLzcz9hP/+5Bk2AL2QUXN81vTggAADSAAAAEXfRU/7eXzQAAANIAAAAQYBxQFIg8MDQsunQxBmqCVZlpmWuDQFhV4zDcyYJJFyXbtu/CK83TVJHJpZLo4yNkjNE4HBDigAGnMF0hEIFBTDiDADOAOAFNMQGpZq7a0cCHB4CoLASQsx1D1o4iTlYqrSEL7M2wIk1N71tiif/7x8f//NvCy+T0U79HRDURjH6IqhSdY4Lhg9Wu6obES39FLRGAAiAHKAakAM9EYAYdKmquQFAjCwQdbAYMHBhxhJ8YiJqHmDh4kaiw/gtAMINNAu8raIjB8gHDLHTHXi3Z2oAbVS9ksIfl9Kst+cxhiAnYtPq6zjwqAC8adJEWLMkoKbBolA5AygTJDQkhCTWWEKMM8cjNYkdRQlKxWBpCo1xRtLM6wkjYD5PBXsURIN0S7exxP9Z/+f/r+2XiJSL9nJOLYEcbhJXMUCoXk8sxpaK/M+G5CLV34dSNAAAAABuAFEYCBLCAKknBAKQIoFGPQBlSjRTXTDZAUANCCHTDbJUjREeJCw1xTgrOgzwT/+5Bk1ID100RQ+3l8UgAADSAAAAEXCRVN7eXv4AAANIAAAAQ29DivECjq2NehplzkO1NQRGqsdldJNUOEIiNK1+Gk7V8lrwSYdS/YO4B2qQFKg4hRhYwgqkWkOgNWQytm7KVyKnX4kMscsCehg8djWFmUQbVpfp8ZnLHDC/z/1lz///3v90MYlduWuRD87JlH2IQJSp6ssnajgP3jWhyXyiUP9Q79IJxAAAEAXA2axMxOm4mFq5vwuNEUOmYnxpC0ZgMEAEZsAs1gowBMB7y0FvXpNRDEr0fjDAA4MyAy0DQIxpIIgNjcaEYelbKYIWW6sVgOKVrNG02kutNXU09PQWRL5R8IAPhw0GViGhcFLQNalyOGGkyGKg0RFEFZJdFgIWMAxTOneLJgQF/Qgwsi4FaMSlUdRo1zye32Kx2ibt8z0zMzM2268xyqcxYXlwPnjscgZCQIYkiSI5cFKwpn6VT1g5MBAAAAEjAPEsNAIcsykcNDrtKgA4jc+A8hDjDYDU6N2CTAcgWw9IgEGJFBAjGmpLCwZsRkpBpCLFnQMAH/+5Bk2YD1ukVR+3nBwAAADSAAAAEXlQ9BzeWVAAAANIAAAAQXVmvtdUupou/ONdy4ZrtwazRwE0xFJ2kqwSgEPQtMsQLIacIVGRyN4ZVkKeQJEW+L1qpNDUaUAS7QAqPLgTGtO+91W9YQgaAMjSaaPNRQTc3vqtz169pVg2QE5ouFt0U5IXHRoDplTIoBU8TD00ke+cioAQAEoGchplDqtgwJuMtMhk1FQAIzzByIQmhizUDh52yEaHOsaOCz7LjdBXvLAA0QEWFMRHQganAQAKCh1IaYC3ZIQSMO/KGuJq4tYXov7soS66jwYQERIk/jBGjJRxJyCghnjAC8purbGXQ8GKoKVg447ac6OYCGocVDxg8PClGUkw4VKn+Ufcq3Vh6jIEI9CTRXZvlnrfv//8K1JF9Nsr24JMLrPFbQKjIfHx0UgOAkg2Ki6iv10lEDEAAAGsAAEc0JWJGjrnWPBkpxQGCnjJoTlk1eNgMg2PGOFmxhE0fmaq8ChikqNQ8QmI5xUZAOot3YeQfeV9FyN9qURfCUOQ402y9vnI4FkEr/+5Bk3gL1eUTR+1hNQAAADSAAAAEXGRE/zekvyAAANIAAAAQlRLzNUJaVCYoIYyNAAggLHlwWVtSZM09p72lkIAnAKXSGOQlLiwqf3jNBMDItvOzaZpeCZrM/M82zUaFyY6WvL7onFxMw6XnjDw0vF4/MqCUoVEo0f97QjASAM6AedEDXwhWm3wG3JmUmGIsDxNxQu9B2ZDFmZvSSkmpEE0HcCQEhqM8QVZq1QCAABWaA0IGUmcoA5cRdhskNV4MjMtboxFTWDUB4EGYCFQJhMZ1DSGJhhjCVmSgaOoCW1ZLZnrKWcy5pgmwRs0irOUhHXL2LTesLLnazNGjZeLEKf7rvfv/8NbX3aUbXFMK6V46+FU3Kc006dp6iTIKO0qFQLa+hMZYjbUrkxkcxMQAAHsAMqjFVDKStYY5KBZBo34kEa6cKQAnYwQP3B7YcJpA8KXLsLQv+3Zy7EXV3esuIgdI0bFXyKVsmqyh/aW2+8Vp2tvNPvIHaQWZEl3FnuWYtpQVgtSQEwDeOo01ShMxqPTpOByV8eLBf/P9WOSO9rrX/+5Bk6IL1TkTR+1ljcAAADSAAAAEV1RVJ7WHt4AAANIAAAARZ7PsRaZ+dWxvwTpnUqYlYYqy4vIkJ+nGxWNTZCZigO1CXNxbT+1KyUltYVGETAPIARJAYwACo6wMy5kz807qIYCmbrhVqRDgIsNSCWcoqMoVikhaKHHYKgJHIl4x9rZfxA5s5dQJEn1AbWrdyD6au+GcwsLLZWFhF8kwwYoHCZUrCmFJhIFUT4ngFIwE+E8wogvLKhh1uNEfvStxiX/xV6HTUm7VZ9vY00mbfGvj2gMaQSRca+EsvHzE4narXFDlMMkTI4XE60JzBeN8dxEt1kVVWRFEEAD9QDMUPeQVGGwGXClRp0gAc2MQd0FwDNEALYiDg4mQaUxIQEZoXw53h/E6HpjkqMeKkBnn4eh6vVFFi5g+xzOR+s5+oa+ePBci3K1dFyeCvCZHcLkTbt07wJhlRcuTNI4OXbNiobVcrV+7LccdX1kCq/ufb4xKVl4KQbHy1egMD9Uemmx2YaPwYlIs1W1Mkghhysr8Uq8CLLs6ECQD9nBmhojbtKGr/+4Bk+oL1DERTe1h6+gAADSAAAAEUxQ9H7WHtoAAANIAAAAQrMgJMDLTSiqjBVst6YJMmgk4MCgcFd8xAiUpJOqu0t5LS0Yx7sdVM5DLTpkoeru9kxW8iynWfUCdU7b1k0l2u1crFGfhJy3Hc4UhKxFE+VDWdLCxsTWzy3rhwNrksuZxQig6BlJcS2vkfNY6u4XfUWx1wJn1kBIkKdAvUhETBiFEwXRNNBE49n/VpoThVE1IEgDXeDfJDkMTCuxMDOmXbHISGRKghgRBE6wU2UvTLJiAkOfh4WapouIpY8TUptyEipSxO02dpTNIm1HC323Vz1D0TiMG2H1oX9m5c41O68Nx+B25KZpdIjSl8nZgWcHsEEIySLT3KP2gv5j2pMagWQsPzzuGX5SlbVosq2XU3VZfQokKxHKk/CcHm0N5vRVQcMeEfjmmlhcTWy1Q7JmABbj0cdAJbMrKauBzycAqsADJDLTpcsK5T6f/7cGT7APTnRdD7L2PqAAANIAAAARNlET/tPTGgAAA0gAAABATVjzAoV2KhMsCAB0tQZMCPKU5C0y6S5yhtMsh3n0GBTeuUj61BXyhrTazLX8v15VF6s3eiEO526RrUShio9tBjSv44r7lUunongXCYpbaS3ibGWYBfyfrbUpFtlm7a3aREZ9FUUAnFaiMlu2KhDE0kmG66MMwMnkYhW55UQ0WHxMZkArcCVUmgPHMG1bnJuuCyT+LARHdVQUUBfk4NGTCl8ktiS9iRhqo9uco6HBlFTG/AEYhECgFJJC7DmMoUy08EKzSeNrWuvMyWkLcK1pnfwm88cXUiNizObw3oEBecH6v0aSaemmK6LiPw1lAx1eIeT2CwwkqqJLSsOq1e9TZTkdofqWPVWVrhdsD2A9Z11bsb27P/+5Bk6YD1RUdOe0x/KAAADSAAAAEVIR877T08KAAANIAAAASqtx47xulTWo2mFDT5UbGdbpQqxXtT1ul1bK6rGBkiHAiynxmBHYDnEGyEEZN8vAhpGtXjE8ihAKuIe4t/RLMYkPAgDAIiHiyRicWAAOCF7P4/blLwf2BFBGELqU9FIjROQ09gj/TMBv2SvLEIhj0KA8XlghqggaUox6ZPHwpBooOj1dVYPBy0pNB1SrTlcqPmHinyFEvPdW+qSRsJiqQ9+Fdx6tqSm1rX0Q14nNIELik7SAIlqUBL3UE/WlQLSPVNorY8bsR4EKYKsAWxeXeVppEQZQNRGMidrgcOpg8MBQhmOAlAJgELApIDQeHjUc9eYKKxiAQmaOs9VUifgtVc1D26GEoBWZ92BCHCl4FiQM5MkUSHRoVTQuKwFSrNe+mmYPpEd2wPsQDKHs5TPBxEVdZikOx0i2BchzzFsQ1C3F845U5wNqwxeVseYnvqEwSTsjxCoMu21jRL1dPXqohQonpaHZ9HiMsBCGTtSXORC1Kqz+H4f74hjxSQW+L/+4Bk/wD1N0ZOe1h56AAADSAAAAEVXR857TH3YAAANIAAAAQzwlJDhv94pT634os/OrdJmMpIILqamIBAXlcD0UbOnpeB2AHKAqLGjnYFAzMEA6j+OhERIDMUHRJ7acYkLpyTiWw0FsHiQryeSJsBzHYUwtBaBonQuUS989o0Gi4Vr2RTIWELOlBFaVkJe8zQDwwEIGSwTTmLhFURssXaJBaJtyAPiIzSGa+fYPVj6JDiksmS38+u9nQv3QoUg4FNI0Ha4fAGFIKSkAohgQENwd21ChS4oq8abQGv9iaakWMiNVQowbyuDqwI5o3EYsZOZjVWCBc5ojQSL9gnYy3k4S0BFOiuKhoDX8NU7VCJdDSWn6TpBtdCzJyB9OyBCWmeLvTNKtrSSYGdicCAIegJ1Jc42o+ywl/OxCl5u3jwWDwrQnzE9ExXUZU4presvstay9YYNmGrdnHxXOvq9a3vpwdqmVExn0e7QT1OnP/7gGT6gPXxSM37mXr4AAANIAAAARUNEzntvZEgAAA0gAAABAbxXSrGPjMZcN67InshIS7KsO5yFzucGyYkIqPmXOHNBmiMHhcHWIKNmNaGKfiQxfYIDm9ECUZqzJp5dyuZUN1RluJMpmE7joT4vV0b1mdmkmzNDOVg9oGyYk9YUy5M2xqt05JjbPJCnklJfj1tqJAqOdRKF44w4dhl855CPztHqRyvd2c+vcrEzA3do8WJ4icGBFwqgoAsJBWAjR/GwVnpmJ6h24Od6sHVgqWENUQnAXSeDpDBEJ+TWi034pMRGwYig5VLICEeM7HkQhUGJQseBCECWYyBvKARgbQEIUpThXswH9CGVBqSQ8TEbYCxA8BwYETSr6KzJwdpG1w3r15XyFLTGfqqcaufxbVn7nmKM0DWMBxmwrv1JxdapGYUJa2cretuz4LNsRoS36Gr/HB2seUsFsmkkYHycvYcpkTrS63TMzMvRf+u//uAZOuA9N9Ez3t5eUgAAA0gAAABE3kPQe09kagAADSAAAAEFlrZHVhsCVTwPwzAXAsHDvrgks8SzCVGqzOINAIXcEoSEiqPLBwKxUfWeF/0kULiTEhMUZTckVIqjTDIFuIo6U6sODyHBpCUVH6ZVh7sSOVx1nirUuhB4KCZCJ4nlxi8Svl6sL6W4JCElT5rsMCWO3NUjZCQ93ieeBS+K7tqta7eUtKtv1PGU6lWnKymbDnU5eQk5MmZXoJhPluc8SLpCAs9imf6FWOJVmdTC0MUvgDxBAQUzNQTMAvMQcHIpjUjUhIoaMwXLAagRNHEesDTvAiKvBSl2jqRB8FVCkQ9FGIaJIjnKSz7DqPPpyR79UMKFprCwkFE5vTARLMjnMsaGn3dvrv/yXsfAtp0p8fxPjz0uWisaE3w9rC4PpVskWLnOfm+sbrCvFc29tu7fKVVQYJAkMPJ4ijNFwWzkqiHPs8hfnF5JiNtIPL/+4Bk9AD09klO+29kaAAADSAAAAEUsRM77WXjoAAANIAAAAQ5Sm5kPssuyIpiAIIZVAfQNkmLqgmdw7gi9hPMCWRFUdYGWBKArGKsBhGQsKLyXJ2GQXVCSoZzlcFg3sDUgODzcCPCzX5YlEiB/J40GknJzCTHEW3CujUOovpuLhhca7/gesFfBzDKIeQZVLlpiPcv42XHEZKKtlbHOd9Eg7gb1LGewknmVwg431c+SSydjhDZWEuQvVc2E6b3ytVLPlJp+aFGjSbWJOLwiTvvAKp1molFZAkUNm4IQZo5BsyCwYLYAx5k4GWkKlmskBtSxEtgWICABIhRVpgdBAQLJLnbdEMY9DRQJfjrBWo2duVbyT/x2OIvrpHNje5JdsZ0sW6RaV6VoeVjvkeRtY+aQdMYal0kz+j5mgzSPp8RdOty1vWDS38XcDLVbcZrcXUbGFzDb0nNCUxY1Ec7OLCYhSIqdXm02I9XK9CFpv/7gGT2APU/Rs37WHqoAAANIAAAARUJHy/s4eigAAA0gAAABDBQRmT3Sty7oiqQTKGNYGxXDoA2JA7uM0QoYICTMmeiNWAUhkWXhB4Tu4KiMC09lYk9IBeAQBgB8JW3eBrD/run1fRVx2kw5BaMWHMFkcZymHp4LCUYldDfLwhiUDIwwWC0Rz90qqu3cXlMqi4QhICM8SdVMdxHqTHVzJbfOjlOsPuQ2FjtndjPmZsqN1i48KS46s8fKF8cJeIB22JXpMP5ZqXwb/1rILo1yWRWZAbELJgN6GU1MrGIgxiT5h1wJbMbEOzXc0YDEi2SFiZ4PFDUBNojO6rLW4kLUU7xHFuOZ0p3yJP1ZXEdTv1WrE8hSG2jNqFGkzN7EijkB/CKmCQeQ8E8Nd65wo8bLLIywiVGWW5QnlJTERmY36GpaJk5UtVPzMcIxVbBkhPYr+RhVMG/dOznmZlQ06OqPLUwVs5Xw9S+mDST62q7//uAZPIA9QVFzHtZeGAAAA0gAAABFF0VKe1hiYAAADSAAAAEIcr36krHie+Yy4uOVj/9tTJa+E9U7qymGybaWBuTKb5nghxwhak2RIafGnbCgQzCkqHy5zzIMBc4YsIqNIaAfon6SXCUQ0kcV4q3RikPNYq3I3nRkIWd5PVSwmSyNsF4wJ3qQ+S+qoyjRs/Q7vFpkurlxeKQITgdCKAEBYBoQ1UbKl4nohxeMjRON2hY6JAgJdSXb1xZDMWGhIYSEvGUCZrROy9CVMg60YiqNsxihqGU7ZbUL1SI8y/+MoyqF3lmVVMZEigYDotn0AYYw5UAATRBTSNwVLIlhnEpiy5QAabAxgCJMJROf1Egao/iDK+ATEqXGUwcIaYpjnYS5+iD0Q8npTKF4kkjR05HctpiITdCKDqQSxCYKRehmxIqXkJ+B0pmBYFJkJxNR0K549Wpm68kdQh3vEXWol1n3MZ1+iGhLXSwSDKp0mP/+4Bk9ID1l0jJ+1h5ygAADSAAAAEVLTcj7T0viAAANIAAAATUu3iMEgJBSOwLHyooByNZqc+0dJNOVFb0WI/IwpHoon9Xupsru6aZVDkTbAoPeNlgzkbx4C/BgwIFP0NN46kxCeLcCMIx4S/A1YRoC4Yy3NYrjO+tWINLiTauRGISYmK9ipOGZcHMahC5YDWp+fEkdqOkMuLVITPkwtEIjoLI1GDx+hNIZKWLx6JIkE4rFaNAWHdVkRRNiM2cRNvrWX47r3Dg/fUJC8JCIc0aih+LyoH5kNTJXNklDMfUFOVDg1fLilW5Vy8zWds2fZv1Lv6nF1Vay5mId28ljCwAGCwQYKHGANM0zS6QWlFQTfiM8QgAL9J/kpbPU5UKk9WWp6rpj7MXAeFlSqbmvNB7Unmpos/bNRbdDXF5Wgjsgm46kldupBIN+BoqIZpqYc3xzLCQvvFeT9XYdCQPRIO1K+OW8RqrSylqvVVXYv/7kGTqgPWAScb7T2PSAAANIAAAARW1Jx/s4YzIAAA0gAAABLbvWWs1bq48ouyKl06hlKSClpcMSkfl4yVDB0S2uXtsIdHvpMsoRpMjbWFrsDi61xJmWmGZUcSZAgEOiEIRAQ0AVQRBF2SJBm468aEjIk8jLHYcUwGO6BPgcBBB0k+SqFEbQpcKFnspmD1TACnCGghCaiK0pWpWCq+gtLExJUJkJVza5clW8vHw+IBvGsLwaJwNpC1TfZQV7npFFtS9KovPrWIIYIzlhte1Vo5vzZXayVpg6mNlKeJQICc6UvLBLE6C7y7Nns1qfipjs7qnbZzhZjqIl6ZVXytoCA5q17gEYE7r+aGltNIcEiyYBWAzki+oOKW4VQVMZFDytjJHCaPLHbaA2KQTkUYOIxC9rAVN12wHA/H5ustI5BysjE6OthV0OG+j3lcjkVyHURZst5+BtGQvbVYGzYpEZBAQ42wLpWQtoSpxoZFLaM7uC221NXG1kiMRzYUkLM8WMSiLBZH5IR8uiFSyFuRG9pqX6CNdRJZd7UVHNVMzLs0bbf/7gGT6APU6Ucj7LB3iAAANIAAAARQ1NRvsvY0IAAA0gAAABIMBxjDWjIgzBDC75oyABuAYiAQYsqHT2OAhigqIgGx9OoQl2HMMRKF6Gy6P1sFtF2ON+xuR2JF+nWxzjpSGspxJL1H+0kmzlhx1SxzyxJ36gZ2xqcF5qrAWu4sEJ2ldxDWZGJsUD+AxoYyt0PJ5k1ZWtJ4t5IU2Xsjm51gun9X7TlXK49VlEq+E2MsQuRf12h8zAyO38OK/vP4mIvSpoGRX9faXddWZiZmZVkjTZBgOIHUzoCzFIOAIiGACIQGyBY4lcG5EDQOBAKCJPsFRPkPWhpDB5lAc2issgyMSV0K8DRR0XOtMimERjAcIY1iELR/NphIaRavWnakQCoW0I0jw/QiAoDUmLlb5bjHkG47DgdiUPSVcsrd+X+fbQkRZdt8axxh7jNeVT3UmnMDJoJcC4yPqQOr1Y9BSSh+jZNFAyJBZHFNQ4cts//uAZPoA9RtJR3svTaAAAA0gAAABFZklHe1h5QgAADSAAAAErzgB4h9lLS5Mf17mamod0dbaIoO8VQMNmeBRhZWXnd1FN/gJAMwYkAwRtechNOR5QNaSyFwl+wImGySXw02HJ5GIlkMS3j03Do9VFQ2Hw/E/jmMrNGhmlLz8A4EQrCSn9apJiKAmPHQ6nsVykev+W/OW4WlkxNKTUxeUJK4fROHL2Q7ceNlCdcfzXz4rX2O5+kSGVSZGT0knF1sV6s7Fk5xx2TXZ7v3pd6FwdsUqaamqqHZNLGgaDrqCYUWxBbFFBJSUzMgGECrYgBmCAIRAYOtF/0I2TQ2z1bYOAClkDiEULRhGPJbBMLh9GgYGNDY4Q2RLCkQB8IgfkWMtmp+ZjSJZaKxJKZiPqUnD+Tkj9zqO6LT+JIkXrj47QF66X4VLDiGqZLKKkdI3tlY+209q9bRYXTapswOJuXFAlRnVCwPsrD9Ic43Zd97/+4Bk9gD1akjG+5hh8gAADSAAAAEUXT8f7eGDwAAANIAAAAS0tXvvHfrRsa1cHftnNRM08M1caQEBw061gMQL1AIQMnEvXnUQMQBcTUzB0QhVGvdTorEWTFHITngZa2B3X2ilMx2CXUH40EUGqABo0Pz8MzKxYqfrQbGCx5kfBAUlUlE8yibRFhk4sbRWZXNHfXJdPLCGwZlYll8/d2NfG7DZor1Ty7mWsv6rikqPmjLCNcspKJZVeYm5JoYozkSVqZIuVF70OO/Nxi7bGKUb0tfqFqpqqYm4hWlsRCoHLSQwkAT5VM0NFJGxgGKGxLEYyCXhERCAaANLZGkS27TpNUbMwSD1/yNrz+LGV47LiUBImphJK0l4viUY2cGYeHZ2FwN3oGFCJAOXDgdnUN8rsrF13Fh5RUfzdfvRZVnLXd1n3ViF6qtlkHzFlOclIUr0eTsRNpx9fJYUi1ISebguUxKQiygHp2nU4mHvU//7gGTyAPU7S0f7WGByAAANIAAAARR9Gx3tYYXIAAA0gAAABLbsdIbf5NnDQ7xDIbbUQDBzgvk7iG4M+a6VRIdZU/SvlNBENP1FtHAMIPBupWIqrsLSjgcLYc6hbnE/Tjjq1TndcvafcyfPUucBw7LxqGyK1SLChdtL9Usp/uFWprbYZ3aO4g6hK9hgrBpmQoF9mSvUVXVI31SJomGpdfKxqymrGuXncCE+fRsobjZ/pynaEleSQtD8cT+Epqlp9RW2T2j1Iq6OydQ3UlOsgr9mTlv1OnmJh4VeqQw/x1FcRJDQHgYAKCIREMiWIZD6hk6q4GYDGzSUjehcJetLN6FVnDY87DNh/hEghgIoVzcK3y3sSGlIbi4yLygzXt8rMxxuTx/WM9o/CxYgD47wk0Ni4UPQblU6O6Gad1vUUfvqDL3E8BEKZ0dE3e1Nc+XLZULV9warl5WVYwdIBKC14yWDAwODFYqYk/LmRreb//uAZPCA9PVHx/tYYXIAAA0gAAABFSkbGew9kYgAADSAAAAEt1F8e2md7tzctqCczUzMOzOxtgwHpAxISVNEAvoYoJhXmaERACQpMsqk3kIQGI/KqMVQBNzZtAcysKxxys1UnLhxz/lfXcfmEylymPPNFpFFJsai2f8ZAmZgRJatfK5tthSRy4sEZefElMwlYPELmPLz5aKh0ZkkeDhY9YlLVzRi88is5CcsIa2t164zSsLCC7a6G+XB6iTHhlxsO645KcbYhkxDTu+r6tfcyn3PnaZQbXYBFWiKmZZ1SRtIGA5O8WcyUZB5kgIAnTBCAZQwxQyBFUj0BgBEwtLVQdjqmSHj2xx7obZO7jpwXNzj9xGPTDHYoQoxYiMjcPSyI4FT4mPKXlOiSJpXBw1jJBKNmSXGmXIRaKp+hryC42Vkh8uJK5k/YPtMhKiHzjz4Sc+9KxiVh5j/VhXWySKPMvtH5TPHnh0JqeMFEEz/+4Bk8QD1IUpGc1hh0gAADSAAAAEVJUcd7LB5QAAANIAAAAQbHhBZKaGxJ2o3MZdlXctHrjBeu7nmJmYqHU622SIAPnIig0EKDA8zLOAI+HTwqghKjMHFAhjXYMIIQpmqVt0V2xliMrlLFGzklslxiAJYrBgHISjc4jRlN4s9c0LwhgybEdGqdgdPCuFEiKkBrDAXxLH8eDo5D9DYKsUOuLzVGjc1SW5aXHrZ162bRGRyQNK0SwkNnJ6uXobpDWL3D13VB0fnC4G5JSn0aEWjwfES5W2edHl6tK+X45d0t/TWr7Kqh3eZqHZI22gIDpcQs06YXAGUtLfhuZhoW2Mok+SoA5oAAn8YK19GFU7PkWFVHIXa8g+F+AzDsch+4DIGhwquN9C46voQqxsZB2JbBPOE5aSKVpUKp2tPF5HJpfB5SPCl0urBkfnUa4zP1lLsx+ODfuNN84cPdr7Ne55jlJlq8hw+fsl+GSGPJ//7gGTugPVKScb7WGHyAAANIAAAARVdKxvtYYdIAAA/wAAABAuKAlGB6ecEVjtUwuL0M/ee48DLouKuc0rYmpZeJioZVtaZv85dsLgUlXPe1/marVcpfcOgtQdUHXlpdEvsjo6bmwllz8pn2DsUlkWmYOBoIZeCIqHA8FsojicLCifmQlGiRCHQsCeSJ/FUBbhOFS924eGhPoen/qUYgqPHgS3nUNKaxrTtc/dlfEfLLfMXrocZg+yl1xxvj19xXUyWq2fJfQ0K75NLfK7ntJbZ2/tt2vA+paxEEn1YiImIVVccaBgM3yY4Y4UxZnhjxqVIgHKGt3UGQaQFNPHCxCBWzHXeU7xaE3zWW2i7WFsJKQ7DsDww1unlVtrs1blFSZrsElNLJodjjqRm1WlDhL7aVELTaR+hf6xGG8XkJCothXIcnjRAP1RPXI4DpdEvVswiWVFxorskssykUctLFj68tpm2n3HTs/OzMcFx//uAZOiB9RpIxvt4YPAAAA/wAAABE40lHe1hg8AAAD/AAAAEsU4oSuPoQrVpVLKc9VI8Pq31wpUvQ4vqRlVXn4dVmZlpdVOWNoCA5bkWWiQtCMDBEuhCWMCULAsGGmVNXL6rFAQweAbBAhjiFwRbCvJIinZOlEtq5XmA9YWs3kLPsyC9sitRb8f4kqLjJ0v0VQowozdP2IzKVqWX6uZ2FeKsgDAnspSo+Trk5o9F4qhLak8XerOE5DM7Hp6vsbK2F38xeJKsRrSShqGMLzmLka98Qx+VPFYRDxFpqYp3EAktur+yfhrDiRi3Nnt/cQsqiIqJmFZJImQIDAGzokRYCCgyplyjpY0CSbAAQOZh4VODEBFiYamgOfWeSHlvo/KKNIZUAiXgjK0ZMEax8WEooOExBHAS1h6FBIESqgmB6Oxu8oDh1eyllk9LnYOBYEp11acuhaAskFytVGPSyhOFpacYgnbThEftGudvRZT/+5Bk7QD1dFXG+0wfMAAAD/AAAAEVtSkb7T2NyAAAP8AAAAQ+NGHNfLCdxus66IhmlOy6+bDImksuxlalcgXVf7bLcpaO/QcdYePh4aICYk/qSamoiWZbImQajjumyETAQJTfnE8WuApcYoKBl5EDaUYAW3FlYCNoKlmBACfx0WSmaIuO4fCGgCdGo5P5OAkR3vKnqmWIyF3PhUHcpVlPq/Z0KAqUEblpRxrr54hOHJupSIBYHfoVBYL79kqyYz66WB9d8DVj3VbCuNIcrTNweDxNH/lhUVW29KaGviFSEZjufkdYcB2pEMeBGEEf9Mqvs2+bFfm4u+Yr2pes2mYEKEZ/em7pT3PqG8qamHUr9WQeDhixGk0soM4BDJRQBEgXJyZDBggYmDwRC0qjCAQwYKHAJOhdwAvVBRApGBCDpE6FgOs642k6vN0yELZdBcbxT/TyscYhfPFdrxRAtUKQoehDyftx+Kyh9mmYQgB/PJS6XD2VbSVsXFxstnxpW9HYvWMoSxsviMhU1xlU8qZsnu+Zr0M8WvHd7xoyZVNTnlr/+4Bk/QD1WEzG+1hh0AAAD/AAAAEWyUUd7T2RAAAANIAAAARIHtBQhAsQm5RPfTJmVde+v7z7SXysjFQ1kc2LeomHujiBYOAQV6GAAJiZUwg6VHEBSOrAFaTNA9QYwUVBgsZWggAHMtBgcCg0mNJEVCAxmMlMUTTHykw88OsXjpbkztBJCgs0JCDgtffSOOI/pc9Ot2mKRRmCSTBUAbL2WAIbW1zwMy5lyg7E2j3aS1HFNH9NBGZuLDLX2JF3BEwmYsR9WFIqnE5ARrYCYg2YpKWgULjp3JoIeoAg4igZYkJUEJzClCpeC/GNSD8Sg4yVixl3GArSlQtBlA2qhAFtGcpWosINYpHI+QkAD4UwkgAwDEIMTEW4OyZUwbwdS2LVjvrKl4Y7YyAKDdUwxUEDRgKExjAuZwVo9lDCasC6jc0J8t42VGn0AIyXsaiBKGaAyJVEhEAJp3AhSD6y2ZYLcduR9e1gDQGeIvhcGP/7kGTwgPWMTMl7b2PiAAANIAAAARxdGyXt4fVIAAA0gAAABHGkCIUvEl2rsZFLyITUH02mZFwE6oml4mg0yxMBYZyUoRoFNNrDX07FQoD2cKDvuhxSeX6TXqZJ4llV8rBlQtCekWmO2BNR0VbRYBaL5mg0qBFRvSY1pRhum+abyyNAgANGE3bThhZeWnBcadixhCSRhDA4oQClzDLNU1SwA3CVA1aCSUxk/iEEzWTeQDkAMIBLg4gkJDoHhkVTv/+7eIp++9mUUShIBgaZELMaiAEMuEcGOEFTMoAgqaAYFzRpiBlySgCTrMkbi4yPKK7PaDBIHsB8D/Istw9COcHK8wqaKUqDoZ3kPJOx6CEH+IeaToIkek+lWkRCULjxiVFjK8HSTaC5IagyxJ4xyhBvItXNhTkZGckyCjFKFTLecNK9TYGANaFBwogCgHFBIY1KygwAQAIVSWJmCSNblrDAbRiSYLpFDJdwzTzIWoQBIhgPmItl/AwUwgEFE91KxRFJo031lgZuSihI8OBmE6IbXWihmMWO/NyHZS9QAAAMV//7oGTkgfdgSUv7eMnqAAANIAAAARoxFS/tPzGIAAA0gAAABAZaa+saWIZECYgiYAWcQmaImZYeKGjIkkLmbKXFppa8InYFg1oKEhtJ5TLompcXrojKgU54MxwNy5KgMt1CQonK5P2GoFeLiqZnzVPFcozdtqV6OTz47k8zRqoc5HqqGtQniqkcGdEGJIRM2LCb2TzdXgZIOmI/CMhXA8MIBUInCJQVVEVBogLBjX6TIJVkyvwUAbDByNGpETAMcZUDTBoIDBhARllQ+DvTXAAAoEaBsxxsiI0ykjMIDWC7wwawYAjN3edv7umYIzsQBw7qMG/aHLA4AuqQEw0cIBiomOCI0jKSKygUuXYLuFwGBqDxq9AECpjtedyHGDuFLHSiutTa/JfVZekO1N3H3i1obpkw9Lx/J6c7jKg+dhUUsguB98eDB6nEsrn5ZRhIPhyMJIz5Sxn5YUsjiEsjxcMwpAHD3qGVC/jFmklEjTFH0TRlsUKAYDFizPTBohAAMnHMs5ABoyUEx4hmIMCGGMGCEHMbBJYGg06CoVNocMiKNnBESg0ps2DJrxj1hykRiTJixILHAoW3WBYlUr/+6XpUTasAAATaBF8IqAK+JJBBDHZpqTJqgIJGQhcMvqhQYjisDGEtGnQMIZ6o/6zigDPHdaqpsVA3VVJTMMoVwwUuGuUuSk6rI0WH1f/7kGT4gfZ4RUz7T8vwAAANIAAAARp1FTHss1iIAAA0gAAABI7jWmmxbNfCODfpxrHdlyHqgnCgUpXNTJoyi52Qu3Q5yaw4EMvOwFpE/Gnnbgvl5nIWc/D5u5CRkBYa8gKL8AQFTJAaYB4KLByRhEEIDSlD07YADiwAeZoZadEEacMkFNcta56DJiyoBkEMsN1UASkASZhmjQlBkUDDinadMBZsrbdzH/uzHtCFogADADllbDUKzIADNmSwmFQBKqASMzoo2JYDC1sAkIQlA5MEEi6LlNba2lu7jRmlrpdp4X2eSnl3aV/36axN08ogxucVor7wSdsLYoXMN1kDyy/s3LOQQzSlk+TtQqfQal7sJUMhW+n+vF6Y05KRboyBSsRh1GwIGXWIRZMFT7LSjJQIBIfBggxxsyAUaGAJCbYmYtGBpogOp9G8BJ8nETkAE0So15M4zJCQcM6KmzXQTVlAslMe/OY3MtZHD84c3NbFjGVkzBUNQKBoQBtOIi8zwhEZWMKxiLMNGgceg4cNGKAEBIJHlnrPXVU/38iGQQcAAP/7oGTlgPaKRU77WMngAAANIAAAAR4tHTnta3PoAAA0gAAABAHfiJMHuIDERaQydzcFBYJ9mBzRRwgBCCy5iZAoIuZChcyAqISDB0GVS1sFM+sZr00FwWzSjaS47jPuxtg1tpEpl0w+tepGGaQxErs5GH6u3H/eN22XQ9KW1fxeEpe+w3d4ajR5tgSGXYGJh6y2CQ8DBqMpdpJpgrAkpy1wKPmLBmDLjx8OFjRYCETFihJyudZIseVQMIwGpJjFIs9NejKzgIKA5+aFCCEot2GKxk6oaQQmmFBhpuYskGqFpvI6ZBBGLvxABkJUba2Dg8a8gnEjxlQmZcckgIUAl7qflbCsgiQAABwG7Uh0MG2CYQYxWhwMYoDrIdzFVZwpiCR3TZm3qXDP2OI9tcjDsxVlebJ5E4r9qyAtE0/SJjyE9P3ZE5c6Oz4vE45AecCGOKYhDSPTAHCoWh6K6px38hxuM2jSnNAC1Gcrrn48sicYSrCqd6hgEnyFwQQGKoMMUEJBC5AQLDCJKYAsAAyZJnkhIfCztuBsR5tSRsQhhgpswRvTh2kA4EMwkALJB42hoEDjoGBJ6aMobyACpwH+mBnHZwmaUm/Wmtpig0aemLWgbIbyaFThxS4VCGXHLVk5mpVP+pdHIQEAAAmckiQMgULMg5IiSs4qkAIoSUGJIjzedQQjAQCjRQUCRf/7kGT3APcfRk1zOtzwAAANIAAAARwNFzXss1TAAAA0gAAABK+ZcwmzOQ6X1oY3H1i1n+n+9lb3Q7KmeshlziQNlJ6Ziz/uTBcbYmu+B1DWExhonujHX6YIyaZXXjHKJ/G4L5ZInCjOgncKDUwSZMMwLmgBIzRxJNE1GMQmFuhMGmO4cEUjzpjHGmEyUiSLMmHFpmx6YaLgI8CMhKkysqMHCjEjow5AGCI0ZPNRJgsqCMLMmSDTIcwYrMyMjCqwqo5yyiaK0nrOJjEIMpJjTUb8unBDpiBCbEVmUmZghYYUVmvghnhEbsGmDk6SEsf/ZUKaEoB4WK2TMrjVTDkeNgc4aTBUMQkJKW0dJA6KZp5nCqyuiuhoCAQty05mjit2Sui7Z4FZbF6aBNNFjT2tIicANYl6u4rKY1F4jBO3hyfSRyqIQzD8NSKpEm1cht777PhQK/g6C4bYm+ygTZCIhLnUjTcx4GkopogyDAxf5I2UOwShVLAwWOAkYkJ48FBQExwsMjBcEHADLFkqR6QZNKPLhEZEIwtyHfTYJBxKc0iDlv/7oGTTAfeRRUxzWdxyAAANIAAAARxtGTXNZ0MAAAA0gAAABICECNQZ0gLhzXjDDzQsMOGbDipm15tyJN5O8mMIOAJEzrILiDImjsGTaBi5z6yzFW/+2WQSEoAADgxK7Ro4JaNNEAEjLxQFtMenNMVLUhQ0ZEAl2iYGAIUAQeL94pet3YY6MCtdYKw554dgu9HHlikCwxHl3Kla1A6grazk7Lar60rSZZGX5f91HyeyhbgnM77qPnBLauykaLBdFeDnOdKF4sRZwkO+6iiyWuqYPWKnNYmpQw8i3S1pcwRqL3mMi6xqxhywQpASEQwBGpMqAChow4pkZgxhpxxZMQsQINGnhgS4E2mZ8nYqHSvGLVnfIgAQCuAUYnHKm9YEDkyzIHbDFNjjPDDFDqMDqkTSpTxhB6INEEvYpZGfTn/2ZLuyfgd4WHUBRYAipozJqToteYglwa8OuozhIZBg4kmVQhgNYBpzdUK2auG/ap1kOLDiddunOzwcC4cCGSxFFBeRKGxpXHJWI7LQjk4BDMbymrlH7RSUDE6O3hDMDUD1tqPyUOjKDGqMVmH/f97JhgEdgCGHRTQT3jCAqIKLsRauo6AAtdD1iKOaY4cGLvmCCIWGBDgIkj0YMEhSOqTAGn2N+ZMcOAWQ0RAKqzFxiI8JIjFHgAIBEMOTFzAgkPIgwW1PNby7vIZjIv/7oGTbAfdNRkz7WNRyAAANIAAAARi9Fz/NM1UAAAA0gAAABIgADg4qQQxkBQwUFQxuCQz8TlFN6QKKn5QaXQzwAlEA6WZQRAIVFYeylZq9lJujIGvuo159WPRqGJiU9fSQNneJrz/S+ApmAZ2ZktiUWH/txC/chmXy3KVTsZvVK05L32j8NSqkeWJOizjCBX3cBdymbM1PqxoysPtU8IbnYWMWiTPT0U1QlLwTocFRAyQUmaCxxntMmaZAYDHwhCmeTmAFABAZguYKkY0MEGgMKN2tEUU2Y0wK4HvjhNjmHDBITcgjpsj0pBsqblgaOsf28cpQAuxFWWHpw5s7tj+x4Z7togADfIwTCYCTB8RCIIgqFo6EwFDUw1BEyaZQ4JXEyTAkwkDoLHocCLNTxhtnWqNasrUsV1clagCDZphmGmPHsInZp3IDXexeq7U/jVfRUkQXYLWaBw6fx2shZpHU3lsL6kk4rYT1XvaK2OpC9eu1Cf07E03W2qaWLBQ58joqiXbAhWV0zK5VPbPn3fWzdlexTpkc4LZaOzQZOqjOHkURrM8RkLcPUjozPJ8RtlzHSsh0JQExoAHDU2cwqAQwrA0wSCoxJGMOB0xpeU4BN0yUF40ODkxBAoweB0GAIYIAsYQD0ZdDOY/ho11Pd17kcf0KgoYgB6gqzp46BmY4cdmwRys+kiiw9v/7kGT2APb6RdB7udDYAAANIAAAARZVF1Hu5euAAAA0gAAABMQim7CZJRgFl+Vc9upaGMEmpH5R3DVR3JbFqWnoIcfctWknBgBTLvPATAOVj1C1ffQoK5wh199gMYx8QzFD5feb7RdDBAzVDMni0drwfNxIJLp4Yg64OoipzKx0FEQmrVlFDfAAAAAAAAAGJ4dBAWmDosBcJgKFoYKQgAEKLSevBUcsEAYuAg4jwiAPGNCcZASgsk0JTb0z7mAw6YvGphkTmoCGYXAyxG/MMEQyocDOBuMdBw9muTvzKC4PMCCQxqDXdMJjsyaSzKxEEYJMEhcDEMwQBAwPGLDMZqPhvu+myGYDUWaxT5m8mmTx+YwAhjaCauRDUoIhYxgQMUGDKDIw4BNyhDYp8/8GN0ODKCgSPDHTk113ErczuJNTBB0bMRBzGSExUNHg8CEhMaFUNDBO1BiQjTI4k2kOlXIlzsvZ8X8ZKw5ZkYoIhbhUDdg6ftP4ziLspHQhJ9yWltRi6ry0COKcb+syRwUmsCvIu+BgQWDoZRnZkiGt+Wcq///7oGTrgPXjRFL7uWTAAAANIAAAASMdFzfO82vAAAA0gAAABKEkVjMAByA1S03gYxLcykYVBmCWmBEmuImrCNHFoBbQBBTKZAuTMMEDCzzv3BwCDhw19UvWdryd1IAIHRdfCI4hHtINUWMmJMaIL7NyXYJBEV0uAuADBxQERVGkYCEGJAhIELHhCcMIOLXLlZA3BoCuV4p/M3RnZ8LfCzQNSUVAUxjEpELUMZSIHGG1g0U0AocOHHiEUoOHQVRv3LXQbZo99ym6vHLG0lr8cfysxrqTMz8y7N6lI2Ih2pLEZwiPzguMnFQWBmXlpar3mYAAAAAAAB/5CmKQiYBERkY0g0FmKzyZiF4OHpiIAkg3MUmEFMIy4QwELVKwE8zvBZjWwEgpmGAQgWOMaNJBOQCYCcm2xwyZgFiUyLYIQenKjZko0GLpnwGZwHgIPMeChJDMEGw59NFGh1YKpKagkGOxAY2GdXYgaTYCEFfJhCQJCQsjAQEEjMeDF9DQOLEiMpkQs2xkhqBgoxk2FkIx88Q1MVKFaDMCsKoBixoZ6VEhmYSAmCBJjQkTApb5BdnrvuNZtTkelUbhFKoQ+8OufNPtIfiH95+Oe7lezTZwqNvE4cfQkNyb1fIsBKOL1bEyaSL3QpTOdmXV/IoEIhAAAAA3qOMCHASHmDNxqS6bmhAF7MWQEABpseZUaf/7kGTzgPZZRVPzWWagAAANIAAAAR8pFT/OY2zAAAA0gAAABCMvSFQYHKJjQLPEJy/Cky7peWLKUJFl3VijgltqDJ5pKrbEFjyg9NAr7Rbw3i0LZJZqwBeIiUQ5iU5hHnqAEdhJhxBmCoCRCLNMwCHl+ICMw+DVoJWsQf9HhXpdVqiJqpWPrpSsecmBXa6wYcFgXFFAVsq6C4bB3QppXhhY/DVy2zltIPzzktzD9Vub7bl05SUlZpDuRSpK0H3/nur7UKo+O8kY+q6XfgyKdxkICAAAABwcFYiRa7BkD4aaUGJgoFJTWygy7HPrlAEQmgi5ihaYIOkgUAgUCAQyDF4FvCQSAAd0RAHweVBQIIjAQ9TFJgwsQDgRUBjZQFWUwJJM/SjHQYzQdMKCzGh8xohCC4xcAIi40JRMDEjGwox8fNzbgSfmMHoEJDdKs18IMGMwoEGHKJphuYsbDxWIjAxNEMeAjCQksGgXWAKBoSh4sMKAXrSzvs0BgOvBQIVDTCAxdTKC/wQoDA8CjYVGDFDkyINhlpUM7oXeaK2FRgOIA//7sGTPgvZmRdHzeMtQAAANIAAAASRNKTv1vYAoAAA0goAABABc6DGAx6+y2HGvRmHmZszQHCgSpYFAQuKYqOhYDHAgcFzNDIwg0U6MiXAEHAEIMlBwajGMiRe8xYWHR0ypDBgUAggxYlDh399/v0kssYGSKt6nJ5jYfFVBIgQmdsWZ+ADB5wM+O8ZPxkJKmEA+bLZ5h+DgJpjg5BQcB1IO0LMVKgKBpjYYmKw6ZXVpxUKAJVMfEgcLkg8aFpmyBJEOMRMBGQAADQAIh0y0MMUDDFA4VBkbVNlIAUBLwNNRaMGGRIQSCXugUtEhBVcrDt6Cg8OC00U54JAw2OD4Qjlu0tC/4YANmbuzuSodSqEsZsugLDIYRBAEkSzlNEqBisw0MNekfC8ICAVBh4EeN1HjYOZsbP6BgkhApc9ICDcufcgV/2SrLUZ3lcjjSqqTheRbsZsVIUrEIwBOtWxkRZmMIJJDr///8tkOAD9QieqX9f/o9gUHMZARoEfWU1yWbxQ75S3IugOQgDI2Gj9ABi9omICAHOoxsejEZIMOhUww/DF4zM4y40iCAAEDMgAJvMYlKhxEKmbQUHG0LAQ0Ac3EkLlTRBxgYZkFGgYHMQoIURYDA0cx0qiTAATNHjPGSh6KqjXHAUaMeZGhZEuBRZ0U3jKGzUADlrjHjDbsl4RgFIR0CHHG8e5LxmDEwcKMq6M6dQAiQ12R0I8imDUZeOA1YAYJFhatMMw2YUCl868vf6gmzEjAgQkRA8xDTDpcmaWbvNzdhj17UeT1HRxQHMCYDCaLFydwZSoCrVIUWV0WrGNtlsDWksksQALCBIqMZTcv//ugZP6ACE1N035zYBIAAA0gwAAAINkzRfnNEAAAADSDAAAA5d//RwEgb/rr7z///Lco2JJsG7XO+EdZlQBAKtAEdkvWm8cE6YpWZxgMogsJJRpgEpmg5KGIB4OOt0CgkdCooCuDzIKwjfOUJaPi8DaYOk6UkF6IAClJ8cDGeTa3Qk4q0GmznHaoD6OVUj0IBadKR0highzOTCdMqWKUsLIo1heRKBUqXTTChayiT8a0ilm7XtnP1jXYGq0kOaaJaFmBBrZegx3KEmEKQ0gi0+RSubH6pVsQ5ThY3N5Gq1U/rikOYgABYGg3XCFWYGwzgarkQ4x64wBoxYcFHgxCYyBCzH5QosxDEogtkDPJU9MnelolmPtYlDL18t6FggQKJkNsVKCQ8x4ZCsGg409dy/ktAxQVAXrLKuKl0LuPwE0iBhhKSeD1kJBljpB/JUtXw4hZMpAlhpFidJ5ThfKMk7uHHR8jlf0r6ZpFevo3zeSFvwIMWfs1Nrnq5KF8ZThSSeUx+yxo5eVacDfDevYWmq/YR3d1AAAGQAU7BVAKKAC5ilgAkZjGyhkgyTShYzUDbvG1Qi8Rko+z67kFHjZorCxpV4/XDioHNhLoEDLaES0Rlou6UONWF8jmScRmDqcBOCFD5OtHExdLpvKJ1GXZOjNeJk9ivPhdHXAisg/4MFRF2QRmNRUPzhUm//uQZOkA9T9FT39p4AAAAA0g4AABFgUTMc1h68gAADSAAAAER/8VJmteodRreU3rVLc4fVvmbXrqD27GfwwULBWLYi0XlgT3EFu8OOfutYnJhDAlvwD4Mk8UsAxcPVTABiypgpoD0PXKbhgCTsiZk1gxlWNFllLtYq7srU2d8lNEIHB2sHoInwkilxYCTA7D2Th+qwbqAyKY3fU6hrUiCQGUErhqQjg6GwUqLJ2oX0h4m/W3QCCGE8ZSW5lvzecdSsLrQ+setrcBKstgsg2QWigY+IliafGZERouFDC1Y0dR3i0qXLtKqZcgQA5eByHGgFibhgtyarIVINSU5EjHIE1zLNMdkYFLzltEjnqJKLKdYth2HWzkosu1lgW1MUJwl4N9DEexzQVuIpVlDi4kbDgMwc49CkQpWaS7gwNbMyvj2S455hc1cuEkeqMnamNAQGyxioYeJEnWX6Ir4da2zi0OPpWpZyYZYMsOR7NVnoyItFMbjDRS2fqHSN5bjiVZkO2CMc6vVDU5TUeesafNo9fRZqi6y6rDVLkEAEpwZnCC//twZPuA9RRETXsvZGAAAA0gAAABEt0VP+1hh0gAADSAAAAEiTWDN0YNXIQycJgIAYDgIkMLpCWOKByiUFUHYF54dBWG+pZjYLg7JStnqfB+LbEMJMmmX18nEOV6rlY0wYxywFsR0YiiEnW2uOfCqwo1M3ZbTOXZhIINIuUJQJyHCVB9MsZJsTk2DOon66Yd/NfNbEWCzYmtFmh3hXtLGc3B1Jt7BazUUB1ow8qPkgoVHhQsjHHUr5yhRYO/jzRRnc9SV3z9bVo4aYNAQA2uBGCAUXTtzPPOgQ8K/yJJnaeDTcJGJctUMrENHPDD75lqhIuockW2BFIwAiKXsmkTqlgRfMsEZbx2HGqXEyYCgLgrlI25iKo30wCuZC/ECVp+KBDpsv0LABYugKUAQhGRLlKSAThUOziRRv/7kGTpAPWFSc57WXhoAAANIAAAARXBJTfuZeUgAAA0gAAABIp461YsKeAzPSYJcxVFLAl3TckbNr6hxXqy1x2RWUQtwYbQGd7Ll81tTfWHFodZB07Ko0/CgLv2nPg/jg8Gv1Lc9TGzxIhgCAEk4NJEUAKqwWRTKYhOk180BzYYijBxGhwMZQiADd7N1mUhgIiVbp2Tr9n5U0q7g/scae/D7S9qquK0qZEnPPW+SqIZytfTlQHViMbmeV7srpoi/JhoOgvDxd5f0o5MIZopWB/eB5dRDYPnFRbDlFd+2b/MXq54+QFOqGk4trEpcKjp4+1cqrYIhknLeFKaCEK8maIYPDc2SLJ6YgYJkxKS/0KYDl24zWUJtk4OyKJixZkdhHS4pdHGDmUuA5IHezPLTRKB5SfjAPOKSaJGBeZSDKk3CFwatDiTlIAHTFEtoWpEeZnqefQZhUZysQxCsJWuerIJS2Bm2ckj8hxid2AYCzsKAiNRm0ZgVuIAAPcXMcJWHaJCJqFaax8YUaNc21+qmRYmMBoQxcu0MiQ4jez+kS0aJf/7gGT4APWkRE37mnl4AAANIAAAARUlHTvtsfygAAA0gAAABNkHZqSJWBiVktGxgeuGsQT+MVsuxk8UFGZhU7yHk6maaA5tl7hDEJ7uDRihkhaowZ9N5jn9BU45QICgAGvN7CCrQwIk+f9HPUFkJYi1rNiwgNJgq0s3MY2MNMJjcFwVBSG/aawkq2mF97CYsSZ/AD8xiJVGdvtKIDiDwU9ixBsHVoYkRJlzKl5so1F5JpqjU4ca48z1u9UqyqVQA4ylKqCWaxXwL1AQLC0+UTkN0+W5Q+wVVZszTmyuRDT+xqadiAICp6sFU99/ZM79Iu8UaocgHYCIyBB1dLZXQDnEg0WC0yPLOFyxuR/SXLASVqcLa4unSRn6UA1z8WGs6MxgPJVXQcwaeO6WiA4skbG2KAE+YiYswvHEACWGg6boXBhZkBkBCDLpiTYwD1JJ+Z9BsWBQS7KhxfR1ZjFeEEyyljTGopT0jo0MefyH//uQZO2A9ZBFT/tZe3gAAA0gAAABGZkdP+3rBegAADSAAAAE4RWytsreys+qCMxIhs1aVsjCCsuhEAlvKeba+tamnojLq2GZLI0lECpZhRkGG0ESWmFzRwueJiYfVw2sXNEQrbM8WA52GGjEc3yJg6VxEnSrHG1xM4Ah0uQIhkOpcGMwIFQClsmAIkGGp7AoATBQK0VjDoxjVcrzkNFDMJATJBk5ulMdATHSw3ALODsziXVkyURiDUY6Sl2yACMBBzICgzRIEjxmCwoMCkzICkC7gUJseo1bTEwVCOUmBARi56ju1pbhkJqaVPHJNxnQUPBokPGZjbF39bQKvNZ1MyCIaRkDM3Xc0SHYlcTeWZ7F34k27Mlyh6bwlk9KpTVh5G9Pt7RZbBX7p6OKrCQI0yJoMAZCRDeo1oA23VRT6TJAV0V1OU4DAgDEWIShFQHbACY4LfmFJaNY6sjgoC1hguVUyea6LGsPw3neSCKIBjwoUgCACA4GmyslAIVD6ZRSrUQUGgSSzJGwOqnA/+IDXzpLhGakGUE4wwGRIPgk0h03//uQZOyA9YVE0XtJf5oAAA0gAAABHoUjPe7vC+gAADSAAAAEYuX1LAqMmDBPKBQSKTCpXNkGsMHraP2Y9ipbaoSQQEBpPOUxil7v8X8vk/JpQpCN1BD+N0JKDKZggEGCtDQBfiw44RFiTvtHHQJYjp0NCYWZRuvTagl1P/tPz94X8P33nMXQhNR4Ii3in7VabVPYjVISATNci25aExTaVyN6S9S9m84nWsWPs6GHKqpqsolJ8Ukk3BgZhyEOUZel5k64zZ///9WZrfLAoocAgAkSANvFc4xScA+zdVJs2gszk8YrK+No/f9pJtZmZQGcYQqw3ukWkIZWSZUHJ55cooWKDtqzXMcIf+K7JRkD8/2ld/Fsi36WWRcwaOduzjCBZTLYq0cGkJZFsVZ1RQ1boDCB2pyCmZ6kxZ3nPd/DJ/4qms4OnRcu8wm46ZcsCQVLfKvmVTzrtypqRXwrTpNKn9uCLAt1eMbTmv0MChQRCgAUoAzywMBLCACMdRjJ0e4YOUmxDo7KJxmiFxWTtgNcW8WGtIEJeUHcoZAKp5l3Suih//uQZNiA9sxIz/uaxTgAAA0gAAABE+ETTe0d/gAAADSAAAAEgQnCwOv0a6MgrWB1QoK//azze3iVqjcqiJrJJZulESQwTFvvtJjmnhmcpiQFWrWMcDVWm2pC03nuO//P/r/0ktq06E1i+WeDNHL9vcQ9ntpGUUm0kFE3xDgJ7e46RVO22ZB0XMVWmVWhISACBpAAgcGakasBlooa0QGpSUVJQc20rEfsGOZmhKa0JOmdG4WIpDg6xKV0IAoAULneLrgduoIICXcNWJSDB1qEyJEImP43JoOHQ9OWWtERp21jlgAOKZcvNpxBWK3TTlCB0QdFgHBpLDJAPwq5VUyZTG7RDAoDQRTJvr/O52////9av9rTUj3rcG34NdaGwgs/WhohM46yles+Jlt8+MUUNdSRyeSq0092JwA6ktvRGMTu6ZVOL0e9Yf/4T4///////////+cR3gkMADMogDQeAGhCQsFkoDQxla3QGMiZoR0QzAk1nENpsJU3A3oteSM5CpiNWyuI+tcaq3eziArFK96lAgXmpmRtfHpr32EaL12u//uQZNqA9PtEUft5fFAAAA/wAAABGBUjP+3rDegngGZAAAAAFzXme2GX/DOqtxwCr45NDlGQFLDcmoUdXNtczYtfuwwWDH9u3qsmyyzm5Rj+W+/qX3Kt6DYhZ+lmd3ZbMlA8kvSJtnShySx2VO3jefKl1EmDP160HDFVdeicKVgKsNTHtbW5GAAABR//1GFgzhQIYUohvwaCgFSWoG9zg1aUSwHQYxJRMgXLZipCOKAyvFZmaA0aIE8R0wGEs8Ubn7JsNS/akaAJJrWAiVFYmm1kYcRO2LJIDJg2P9WPzi0wShVNYC+Csjx1YBWBLVZ0wbyb1dTmrvXKiDLgF0Ik+z2/+0Fc616bv23V/MgfPfFKaayigOEpMW9+hSdLCz2oit4myqt7qp4OplIcEeEfhPJ9LsNgDj//qbRW4zruBhkBUVICsA4NkpTBUQqH5s5AYam1CsBEBsDXoSvjQikKEDMSKZj9abFC0I1hgDLwFoz1Xb+X6MPQjPkNqAEIbGPpvvNhisG0r4i5Kqje5YRJ036ppEFl4GQ3cUy0O1DJKNRV//uQZOQA5XVI0Xt5ZPgOqSnDAAKfE8UTSe3p6cAhJKaMAAp4ZoJqh0FWgawNJU0er3/Xa17/fp2txzeMWN3JA3heil3IhcTq9AIBDULYG1vzaPPaJ3nj5MFoO/Z2FjR54WXbnR2n///////////qDsgBCoAAAAAkBwBXhtArhEjk8pwzIowRsLuDOqxGcNihIkgVHGZEO25EjBB0WNP6wIcIm+Hp0Pu+0VS6s4xJFr8J8KDg+y6ZiiJdkFekL7NQjURjQZ69aiLNYrlVpYCp6BzA5zv38siSOeobafcXeq/+X/H1//FxDoc1ZLq2EukON0yYFlMF8oYPLsXKV7BVsLGMy1bW3DxFo0JMDeP1CXStxF6x1ckIPGMAFNm+Tg0czNAQjJRk4AaPKD0sQwjCqGYOZk0iMn5mROucBK8buU4wH09nxwgObV7t/ldz3KGVY5tIQkSrcoqLtvStgFPqMoS5QTbUxzfd+nGyytxWifSHgzMBXKsbapb++ul7rHb1ap/8ehYyGeYspgP3x7Lq9B0inojgWA6vJqUVvkZD0v11//uAZPCA9S5E0ft5fEgKYAkgAAAAFIkTP+1h8yAAAD/AAAAEY5RzmKV98rkNWFQDXysRD9PFfsqZBjNA50rgYponygGAFJiYQaAcmPIp8aeLBwsomFtIkAFaEaIOFUCV4YKBJnuk64jHb/ZJpERZ2hkY9ZQK7XrM0m7RYQV4daNz9NHMIINArrX5KIkgHywEhvt5KYE1KLsuhhDEA3BxWSRqQw8s6xX7+v//8/NfXMbUeMqJYK6etOJp1t7aAcL86YEX3s5vMqZ+uNuDxTubMrXNDhNm1hP1ZN5aevXze4ABBgMAAAA9sAAmOWSUGGDCqaCnDNY6ZWSMkjfowisWgBiY3AKB3zHQ5owK17kwFrhgyJjwK15s3lY0cMmbKtLAoqm2TYkooMSMCyljDmGvcjIYCUFgBe4VHmfKnbNkyJHFKszZF/WypuCgIFMH+eAxw88ZIBHGbkoEMbItyCKMoZ7Crtu9h///uA/FW1j/+4Bk6oD1E0TQe3hj+gAADSAAAAEUlRU/7eHt6AAANIAAAARcgN5ocjoiEGBDoiNaEQAWEkgZsylkpcZ9WGBYoDjKbTEzFmQEzQoa8ogl+ZEK+6ihgR5M2BSBkwyjNqtEI5JWIJUGiPGBHsKdMcIBzRS+YmILlxyTuScKKTUIQZ7QDbxzDADBnju7jez1SFkwvmMtsIlZyyQBHghUDmtlUQWOmzzO9lKCoca6yFFEdGmFAQKzJl4JHmIrApYqoZqMBrsQhuVJKzUqYASyBZYsxELomrg1u6tgiZWtWh4u4NFv68Blhmf4FB1Uwqaaco0FOo2FtESXulFyKZ58/85Ve///5u2mggEEs3dlzWxIZbN4wSVLigSCktDOgCoIky1cxhi1oOqmSQ8BTkwqfbBTHJHWHXQ9MCR+Br4FAppm8sMql6UKghcrDCCZY9ErdymW6Y1LOIZGQd7wDVxgLhaigVaTbYgFAYqNGcM4C//7kGTrgPcYRU37HNAYAAANIAAAARr9FUntYzYgAAA0gAAABEzEwQzodMRHhEVN52aS0NEAX6svSebuxd4Q5jsv49ILiprONHK1vLyYYBFt6bgiLeyfAti/vzSWkjyzhhOLWS0AgsM1vLAy32L1ACRGHK2+ktsZYc/8N6///7EqrPk/SLAwqcaTJemxXVXMvfq9ZftrGlp7qczDvUSOFvRDjdXKRLvWGc1T6CApGd1AAFdABPo4w0WNHQLD1CDiIOMQjjI2QgpEYQOaV0USHzf0qvC0LDn7JRzAaZHWeA8Kp6idEEog72zlEyKXn1UR8qSUgoOAbtoLRLSn64iESthMdYyCgnm3MiMiQ14baCDnpPsfBf3HaILFv/f/7Lr///H3iK+zOfiu1DjtFoG11i2DfhxIR/nVaqQCtRKnTBSvsqVToS9gs9LSyx73bAtHh2gAF3APpJCrBbIreMXbWkFDJmdRqQ0eMKeESkhajwGelI6MEgMKak/pnhLXL8cDl9ypsRHWC34usgmWxiD6FsVnKqpCmpJ8RhCIJnIVFnb7hP/7kGTMgPUOQ1X7eHvyAAANIAAAARQhE0/tZe3AAAA0gAAABKUSJZLKIcDwuvPlgExakpBZBLn5OIDf//sXkEjgxnNn2iyWKiepbWfxlIzuLgdqOokF0ONCmRUFOlGtUn7bcNhrhklp7CwSbMjAABuAGsCRuZqXEMnRThwRPsEDANVzYEkuiHIBi4qYMmhx3YqiMIMvB8n+boNZ0sSeMwHw6dj9sUxJqq+LYgMnF3ahskxT7gmSBWhS99nhKpByLv2pinsZMyNDLm5A2YWstQ+Qhk87sKfBohXi0yG3iHSJG/1rCx+////pmZmZk4oxcOVaV8ei36JMTew6HI/sXhKYY0BKZIVFgAQmKj0mp3q1OIqOA3HYKtUnCkiHYAAMDg4ag2TtKow1s+EBS0mBCCAaGU3xqQAGIlRCTa8HyHRpuTjNHUl5E9evCAjCHA5uu+LDBUMaUVnpghFmguEwgoRRWUDJ4oryWbkR0RSz38hswZ8vzDsbGGA0sXrGiEaaYM1mlkJkkcpjhDghoRhqYHDdqjBt/83MTImyNHpRbbGSlv/7gGTpgPTPRNV7TX8QAAANIAAAARXdD0ft5Y/IAAA0gAAABKKaPuOX9VYcz8S0Jz2EhkYsmHF//9vmJmdCIE/u0wgHN5NUDwSQyB0zMLNjaH3ETZMY3GHscDlKJyDJNf9x0jQfYPBsp0Y73beiqAUJO25bqE4sYqtLNNuQWYaIZiYqDohAxH9QxR+w2Ff1BGQJWgTlclEWQ4O8kZU0MCGikSmQ5MnlIDnHMia0/3/Lr/////t8+oLe05o5KW005b3jOwsKXa2LaeY5EeYSX64NJax81rXZInVIpRMIiboqtAQZJ1EQAAgODYgjd9DBFzqhh+uLyBggyJA2EwmcjU0w4ZkAG5VY6DERjY7fLHRTAIF3GsI8AQQuqVrYMQMHg8+4K7TJrkg4mj6SsiZWxYQAhA7M2qU3aWt0zsJZ0aGQhgiZpSiq7BgSkNuKqu4XiCoQMPS9yDGpF43pfOJ9T07u59rGr3/5rv8/8dUr//uAZOmC9ThEUntTfxgAAA0gAAABE8kPSe1l7eAAADSAAAAEnQ7KJHFaaGr80/1W48MORqnlTkOVR044DVB7euCmFFrOGWPN1Jby5BEGxGxGXeozPJO/9FgDm4kiBU+CA0EqJxAvEnzgpjAiccTmKDJq5eLBpgQWYoNBcgnL1hI5dUQgZMkT8/E+8SAZrTkuKp0y6bf8VGtGGMpA8KpoJa0ytIuQMofg7JfymQnBns4pg7ycMEs7aLD7F3fbZVGUT5wJA/O7XLT9Zmb72tfRlSuiOS8c0PjtZeWD6JaucaWF5BTCkApVPB7iub+vPT1ePbpZOy0dBEWWx5N1rwkfMf7u+oAGOhZUEAA1TgzQkESSVAAZ8zBmhPUKkhVVwQqLMMuDQQWAQvY58rLfiIfWfAiROeBW+dcvrRZUiwrwS66iwljDOlZ2ZPLi4LKC+VuFjhkS5HQM9XtSRyV3USZG5DAAxzU09aV4YGyEIQ7/+5Bk6wL2CURP+1vQiAAADSAAAAEVTRU97eGN4AAANIAAAAQqWYd3umvY4ewWjYpaxNM1V0/+cGK7nNZOrobr0as2Pjg7VOxeqJZgWz0ugUqJKUdQ4EcckISmWG6Us1KSCC9fLY8Q0DqipAAAZPgxyAxoKp7GBHOd0BAkETGYMMNCYWbKpjAILC4XB8m8i6kJeDiqMKxhcDnPS+zdVbGxu7I6zUGJwAw1U7T25smcVlNt5lksNurCr5FiNbY4wtXD+OzVLyW1PHCI+JZDQWxzHUaaxDJ61PcNzXI9tum5jJNIuI6nBCjBNiKwj8R8EjCfbj9hJ4z2o7TujnIc6gmUZBHZOz+JycTpdnoWFExykZi4oWonFPmifClQ40SAFuezc4LQEkWRte6xYSowBCQpNRAAdb4GjY3ZJUxO3TqQtWIgLGRMYQDdKJAIABcOArBbSc6iJbNVEzAVYjlGRw5VcpoKpKxsJyaIShzzBN882SCbBci2qsgLpcujZLbWz1fH5FhhwkrRVjAL65aE4SFrtY2qvZ6t/FkrFMemqyiQ1L//+5Bk84D1aUfOe3hjeAAADSAAAAEYjRc3rmHr4AAANIAAAARCWpjbUvEOzHqSkfEx45Dol+TVhCHyMp2RsuuEgS4FasslBM/8Kij+68xBpYuXsecl0QJwI0/c0AJm+AySGIA4XPMiQUyMGUzDBHMmw0WGGNzNME1EV+PCYYSpkJYLMdcU4BOT/TRdyKetx8FZZGjYJcnn0jRjMQnpz6gj4AfSFQ6DdfS1Q1PyxUNJg3yjKZou04aTykrFOwQ3se16uLecx2yMbMTx7tTuURbn2oo8kGs0OM9a4yyp6xIvY13aIuEgoWTOToOKB1iyoTMSAr5MQgkHbXO1HQPF7ghVgIR3uVZWAJW+DJkQGhMStOTIMi0ItJkCxlRxumaPZlRZnixhiYZGEBFP5WVAQEeG0KWQQ0hSjpRCmNJTD+HQ5v0MLug39VU/v08ReZC/E9e72Y8DURuI/cJRRZ5EU5uGROBEm3My+tW1OnSuT0ON4QyeTBirwazA1Ix+J6MyVOvLakhPRhIW3ztN7sQ5Go8Gp4b0KiKxVVcmLBEUl9YQkjT/+4Bk+QD1QUbN+49j6AAADSAAAAEVARU3rmXlIAAANIAAAATgmPh/GtYJ0+uQWHl7VUJIUa4MAETgwIwJrQbMwPTIWExgRMESDMykoLi8hgpCTEyFSQUfLmI2h+jiIKOMlh3oQdSealypmdubXYiyrhsCNK6VzfiBKCMYZJpWBTmArZN0K/csNgctH4T2BlmUTdHyx3gSXeYc4acM90pUo9SrPqMo7QmVdzx1GbKdOZPOUJqYYtnp/qZMvkWrlDBufjZq0Biw3NcRdptGUks8+71tv+YNGRRVfrEhFRFIRna2fmSETXNQMlyqoAB03DSI30pB1UaMDmnioPTyUvMIJAFqGukZoAMHOylhhikcjWmsihj6eaAIChJ6WpjuZiQx1IIQTAxcRgDAMDLFzygAAIMEbPEOCDIKGIViwgFIQCbQCGJAn6hnbZn5kGliFzWvNAMAAZGLATRlh6SkOUEGbGBGCQtUJhyi0x4OWv/7gGT1APVQRM57T2PoAAANIAAAARXxIzf1t4AgAAA0goAABAlCGtYvYBgS/G8MoSM8ebdUilaS6VDE39Xc/ydCdCo3VBUwucZRAVjCqJGBieEOptJFJ70CidChJXS1OOtVQUQeLuLGMgGLsMkqV2Do4J6AoQ2ZgLKcGwLDRJ130ka6dyy/f///zUmQUPZO7d////9n67EBsDdJ0gUICAACAAODB4XQcEphsIZlMSZ1YwRlGBIQgJmsM5hULRiqDYjAohBwoB8wYArc8sMXQceC4dLAZXkpxKgAvwu6BkbTWiTNmUmUHgKXDi74R1YRsKTbAX0MqpM+HHBYoEEgRiBieKdoqSM8WFgBQHStMmlBzNQMvwaOSdF6w4FCTJgjSHjJAFyQCXCYVArJUtVmvNALKW4Mucqlp52Kzctd1rLWVzLudKRv9DUYpJTDTJm2Z04TH2HLuUocFjjXG7vmmIwilhbOS16Zr8NxttFW//ugZOyACDJM0X5vRIAAAA0gwAAAHK0RPf3dACAAADSDgAAEDSjchOlpD8RFW3K9YjAYPcRA0uhoTXuZJAg5sA5GTjEIibCFyIZhHaPQ6BTFAkMCiIy2CzGZOMZAYz6TODgoEDkFgKeBybbo9mjCvyKhAgjagWtwue9kSpngSQk+FIwyetW3rcqaeHgNJabVgNoVFg/4haAcT8SQqZ2BMk2JKsqwnhYXuIeP///6Z9GWz6SfVIbxnrArFixHinesLGtFeioxmopVHme5iMJQltINHYTRL4Y+0KRyMbEMREOfFucgyPKiQAOUAEVTOWUGDl4CZo2AAoyU9ApqY2GDSAMBZisGRL11+yoMGoi4RXhoVanJpK3wAz8cgtYlkfLYtO/Joj8zmFZr8ttyQtxK6lASAEfpTMvqrBR1JCgpK4w7YyHeyB3oQ5yynrOgobHqs+/GH6w//32RYcPtFJpXBfNXPJvmlr/XGENsqDUXUJKvXVZ8rEFg5JsB8Uw5UH5caKpw+td+9283RVNqAB7AAXjMsrZkII52kDAQRcOiLN8ojJgTBnUJyDJPzTMbYUJE2phd9PUOuV/Z+YMgrUWdEQAGxE+qaCiEMTCc5Y3oK3sEWwWsaSphYMMvNY56BWvp4gHyNmYGygrUGgjqvoKv1qz3H/3fa/mmF047+N53afVZEhGq+XCaanBk//uAZOmA9VNEVnuZevgAAA0gAAABFI0VV+3pj+AAADSAAAAEN1Vn2hRCFqZhJCsSNEIIldkqpmy4duaeXW+SslBCJoAB3wACnGJAig5iR8GHtEPDxhBcZWKsQSpApIY1MJ2RF0gtwHDTM+vgiYpeq2AuweVWEpzL9b9T1LmDVdxj5hPbHqUR4s04FWBSGDtlo7B6Wnii7C2s2pgC60OAK8eEOAO8x8WjpvdcXmzv5vlPuvSlsZ+/jM9r4c67qbH/bFI+9EOcobgLM+Z5CA0bl0PRAgPYkSLV9l0kAABEABnQDlGMqJCioXeDVzkEgBg66OjxqiIXVMHATMh44fUGyRJNyCrsHURCHxxIrglkAkEgIlX1DAZGb2CZ1NbJRXtwwY3CaucABlr2z0AgEyBblZHxqcQtkhzaX6VbBFU/VmXAZ2Ga2wZah1oDeaUSrWt4pnDhW9IM91bv13j5//z96xFr8mxJFwkHGFE6EtH/+4Bk5oD07ETV+09l2AAADSAAAAETNRNV7eXs4AAANIAAAASGApanxHJkXAy4BGkpWsKL8lBCAABwADSAHMg2JHsaAhkUdhi6bYIEpg0gGNyHKUQhgXmO82YuC7GLIJERQbV4UBAMg4GzTOS1QGjQ80lO0cNjnItHy0q34rdUbpcbKUyz4vALxGwnH4LwBQVqJej8ljIrzYBrqXPch/LotjQkaY9RgJFAyVeuU3y4x3lXmqdPW+853/jXzNjPQvDXAN+DWYwlTaLZkcaKRCp7OYhMN7Yu+tekyvRWAgAAEAAewA2RmEKe2IkRRhIIA0LgBCRjhM4RQCmKgh7E4RVaer/AU1ImBVB+B3IIDkSVAMbBMzLXqV6NMT+GmjczzbrR824RWLAECNyB50SdiAwYO98AP4SHuZHI2wIaX01xVUWjlUsoXFrUnEtsbmMFRf+7sDwp8lophpn3ycvD85sXWuXD1lwLiqtweTxd6f/7gGTvAPUnRFL7eXtwAAANIAAAARSxEUnuZfMAAAA0gAAABE8m8BRqpE8DVSp8A5j6GSIAACgAGkANLnNUBFiR3LpNwcg0p00kQyU961jmAYGqYoAlALANrpKYRoSvBCBUIApDyxaqZpkwIl6GkNDIrPbPziwxMShjj4y6/cgNQJsr7NdPwWbTzWhST3SCoQJb6/DTWw7zgwY+gAFHZZRvtejDvOkpO1EICanZnuTK/IP7DE/jq1z+4fz68S3+NXOrOs9tU08zyE22uv65ko7Tx+jp8XZ7Rw8rbNS+XRLvPpUWPPJGAAAAAgAI0AxGwC/GxjEA7WMtgEPTTrTh1oSgQFKpkjbpisGYyDCVYNNMwFAFa6eIFB8yvAQQgEXnZeZOga30EsGMA+M0tOKisF+4kvIY7KpaDvWCUzITv4TqibBTTcW4sO4oNjYdFHSFTxbxpKwyK4JRatAsRQluLPKYsHEinYvNLFhpmNPu//uAZO4A9QBB0nt5Y/IAAA0gAAABFmEPSe1zCugAADSAAAAExbkIzjfLm5/D//mH1IF3+td7lSX+0sEQiS1YhKcM+PoyZ+pUgEt24CTkZM1ra7Hlv0MUqVLN6WTWOREAACbXBk56YCQI8mJthxoOl+BkY0xYNsI1Xo8mElB2Z/GXwA0xvzTTwkWj21UquRt0vAMBAmCbEgg+19ASZ8E88xLk1Z6tWUVkdDixhbky6qj4dNb13VUDNBWgL0XKBlEZu4CM6gNZ66YhBhwqAowre62s07AElYs19sCGDzV4AabT0Duz8a1yv3HvL3NXX7+3+Nfnx6nrYvo2a9SyhocTjT0rJivInPZYaqY7gBgDyXzjCQ7d1SgGAAAQABGuAg4mHQezgwSWzMIAR6BwJMelYDJNvSYTixYPIlQDGBP0RAIxIqgwbQ63EtaJLJTpPYREsHFCzPLlDtKX81rY/UWAk9y6hmoTlS7ExYlMkID/+5Bk6QL2CEXP+13KugAADSAAAAEW/QlD7fNKIAAANIAAAAQ9e1p9m6gYuDpt2DEIV/ksclne+BofWDkXJWSBILtxf9ni0br+3GDXXyoJk+fXXNNZxX9fkrb29Mx4m6P3k7Cbh5MCeJiKPdqHDWCn1uG9Q8daon8SOvo0nVHAAAEABG+DCKAoVoCqfGIhIlZ4IYIpKToR4NQkOEEMOBr/T4+OIgD8J/GClBwLUNiGOX51hARMJvcgFzN9oJXh+CuZPlKhGHkdHNjA5XVinfEoB8xTsTpl0dUTR6hy9K3gv/iIwVLJqyT09T4N3qbl8datZ/Gtrmuf/zn/y7hvu+65ELdLuWPPazhhfs1WzgOY+YfinrSl4Xfd25MAP0LmSRUAIAYAES4FCcxoFa0YAtgrETkCCo0I8CHVqSIpkKAfeXlAlDrfmdGrL6VuJnZkLJkob0QJIYN2r0SKA4blBEXDc3A3dcU5lF6KoORLHgVgjROSZDuq6JxMqggGS23pKIT8dmmWxcwAFGrI4jnZLuSJR+2AvqV1SHv6//zfd/j/tUn/+4Bk6wD1gkPQ+5l82AAADSAAAAEULQtJ7XNKIAAANIAAAARaLp+/jrpyXbeuFRa1UvvUA61XM+IMyLEy7nwro+zg1ABEcABtQDRhQxQKAwWalJD0i2ooFmLthn5WmCYSDGXIpy1ANBsPQAY1tEqBnJDLDgMaiYMRi2+i1BRMJ0zh9Ceu9sKoz8m1D1kW5KMWARsVD6wa5jxpzCCVrTmuhCYNObetYIFSDVOucHwFv2X1jevE///xi3/+cSatvZe37Cpi9vrJ4g7Q92dGpYJdLNzcJz7OCdVd6vFDAAAAFgAUoAeT5go1R8gGhmwYvejkISuZHGCCBFELKgxZvTAwIcx3SSuUCVhGdGcTizNrkvBwwPzNbskAoIGw1Arcisy60rgBr+EvuF3opDdwZNwI6bTxhuLBWYqxkosSZxyQsDCIV9Fdi5oxDclMHsLWrbJklaEH4rC+EPiJVuLXqWyNhMDUnba/+/5rf//Drf/7gGTmgPUGQ9J7eHzIAAANIAAAARMRD0vt6ezAAAA0gAAABNKKprj5Xs5inJV/ZVMt6l2irlbJiYh/s7Crom8dJEgJUfgBVIAwIZMDAFDQLAGohbRDFQI0IuDLRq8mMXHDs3oeB4QqYxINRbVXjSE4DQT1FtgjsRTBCbSUuQXe16HlUyUKG5U16MZcrqdzszMpuv92NEIt67Ln4QqaWJTg8IyeYgB6h6TbhkDyxII68a3T4YzTCL+ZT82nz5zyxvvb//OM7+f+8u80/JLHbnpf4LbKrmKI/ula4XDGzwpBHU2diGJFNPL5ECIDIDYAXtAIHhrRwYFOrhK5b96MFEOkpbZIILLz9Ix4TJ4mbeALBpmBCwMTOypyUSnSvSwFRpFKjkONIKAlinZA97w3zen4+AHJLSsQ/Uvd6WM8tsZbx+vbATgqmpwJgPGKyMB1Rdxd1XFEMYlUMcqmXMrC44zrdfmXXnvzDIyVn5YH//uAZO4A9XZDT/uae3IAAA0gAAABFQERS+3l8SAAADSAAAAEUkg+uRngKDii08Q2Wi+sOyyrHxSeiY2IQ9jmar2/QgdUQiFBA2sA1JcRA3xMPxOKYYqyg0Lg4oUzQoBLiQgAoZbRrYiCmCFsMlUFoMv4qzRTBtqhQiRBBjaNsnosKuVrNOrE+T06TLFsBzIUiz0X0So3ZOTRY4SdVM7WZwuSrXxJhDUbOyHlPFputfeLmKvrP8L////X+pycaPfhHkgDIxHVhauPl8R0mextlSnWOiT5YJwNhyT2dqFFVUQzEAgZIAIlAyOh8eIkSXSLiaUudsKbZ4ICwQqChY4h8iMu8KBEKCiEBtREE0anaiJiUNCwirPYruVOk06WuE/rXexJTJ7n9k1V0567Hn4HjUEXqxFwYkKHcuTxG6dKjLazwNIUlkTCo/s9i95NVHKiRiQ+DHXD6md4fN8d5XGdxlFZ+fpBUscq5QhmZn7/+4Bk5wD1FETR+09lwgAADSAAAAETSRFH7T2RwAAANIAAAAT5tl6hcWtkOZPQ8tyrFyJ1DXCd955k62+B0WSNnSNGVPg2TBjBghjY0tzNIERNEArAgYAxJZeYxFoNJZlMBu7SPWMSwzAZe43Ig4YvImeduyVlNLRkFIOnf2LPPGIpG3RhyI23QvuRH2IxWzKCoYpKYxoJfnZmWK1o0+0z2ZdaXQhyemB2r8SyIZikCrLxNogsXXKLVR2tC1rFJh+XHXveUqebfgVRtHbEMcSpaqKyISVKgcioJRpEic98SgzBUuvrcmxbKpC1kzg2NEBUmgqaTLvBgOeo0fIQKsDSPDB+DbixhyVgSRePoEJbvIJDvPBbvE3AC8oWWJ4pfmELqL9lZAFWtA9x8qRosSN+8a15aTBPVGTBFq98CGdR38aBmq4QSDlTivRrQ3wRwGH6QygCpKzbDUQ2J1RpEFMAQ6omhJIESNHLS58lZP/7gGTtAPVGRU57WHtqAAANIAAAARWRFTnuZY3gAAA0gAAABMpsxRFiTUx9kRkPQJrMEB6LQZJWzJlAJCU4FBGDqJcv8pZIxOiLDMgqFcDsMYEplQYMQWzNABjJnIEXXHjp4TIQQaMTLLFFIDdAApF2QA7oknHzJMbfgyF4HWlSIJAsPTpXpAbK4MgNym/dSrK4IduAoyu9XzWLeU81a1LMnluxwjqlQ1Eo2P3pLbhEIY8LbSrgskYbeeVfh8824rPyetlIpVxvpHlyE5n3gu8hl+xgkh4jmhdRiomGLxsPh2lWD8mNFB+kWURs5wctX/5s3WtnCpABZFZHrwzaTA2GCDFA9XMQE4HGhBcwMHjEQIChAMFh4w0KjDgEBApTyLKmLwuYLDZgAGkwIjQyI0JI8ADHorHCIhoZtFJwNugUhgkOmDUgfhAYlMeJobHybeMBdwQsMvVDuZv8ZjwRqZJxaZmTBccAhq/XYreg//uQZOaA9StDzPtPTTgAAA0gAAABFg0XNe3pi+gAADSAAAAEozRg6CmFAW/VCwePzwwAj24hewOIRHNAQz2wMkDvTnNBJ6PxIONNMs8RCJ4Sl3X0ma75ztxfERbKXjMpZvX4k0RlL7sZRyChYKjSLS3Ax673Om1RpDtbZkCGDQLO0kGBCQxlAMrXwFAB4gz30flURIQxz4gULGIAAcwnM6nEkWWuFVUIZKEFVpjVGhBdlADzVWJQ4zdUMdnx6fNaIOMlOI3M25AjE3pVDqZekIDCsTG1NSUi5io9znhZ+zGDkfgCkHRVMOFXQKFepF4YMbMmMKylKi40BkWGkvE8Tdn0qM5cGetv9DFLajchgu9GHtnOxOFRyalbcIZoYFcmvz+4/r9/jzPCmjriy2c1vneUsoplTNbhDRbHy+BWJW2xJOtcXymQignewBf6GhMN1W9ibqsobgu14F1ojDq4cb5x6Li2qrgYLEplYAl8kAisjJyACBZmLUZFDBx8ehppHuIY7Aa6CyxZS8UCMoKo1Zd7UFoMXlpbB9XciCHUBKNA//uQZPoA9+JFTvuazRgAAA0gAAABF4EXP+3rBMgAADSAAAAEl0BXIX9vjkDDZS8rgFmNYsRyD6Jqr1BCNFmZnVUjAjQbn4mqxTRkMkxjAHqHAnmWEwRdV/g7t4+b3f4bsRY82sfEK2GaJKyL8LMPC+T0/6v1armR4+Wz2ZosKGpnaRQ0ymBqSgy6C1ppaZZTnKADRQkRCC5vGxk0g8ANyvAi5URtGoOwgAMJfR2HqPkIVqsVRexQ6o6BnYWtltpiiY4sl8eTi5IZlMYZUJSl9u2wllWTo8AhDujmuSUquCx0QEB1KZi+oVU9HaKg4NpRWs3YGeH9b9MV8WJZZLsoTTO1zrLvP/r9Po/taz33Yle1wly2syV2dKoQhhdsz1pVvnWVA+c6qg9aXGViApkwCu0AAJYLGm8iCGLCT64BL0IBYOvHuAU+rwVATRWHSAHRqGxmAnlqtld2ehuoLFlucGQ5W9PQDfPJWMUAfKLh5U4ZSEMMaIV0e7bCdWYlyimKy6cz9F1LCT8vw4YrUqni3bev8/DfJZyWgg53FgYsPqe9//uQZNwA9QBEUXt5eXoAAA0gAAABE5ETSe1h66AAADSAAAAE7R6VeQaR60y1P0kkk9K+PtxPZsMZ0XJCmRXIFZcVc5Mq4TsSbNMW9VzVCsgFIngZuAKxg4MOTNTuUD2pTtEjKWz1UT9mjCTyQWFAJKcTLLPmBDNMRCRCRmCoyGjRfJ8qhjHMpXpRILwTdGAlmuGrS9JhTm8K+OlNJJjQCrXdmo7Y8SdpITthoiCxG4hiINNKLyuZS/axHex8Wmx3JyVirJaPyqxO47g7bZXkdgh0oo9eWfbkvH7EinKQUg9jzRy8voa4nM1Lqj2I5yO97pE3IYdbemhmQABwOg2CVaCRZiGJj5BqxBqUwiWm9HINBShxoHqThNqESwsGclDbCK6n3Th8qrfqNIcx031RmhIU4EiUTSums2TVVSDV52n4hyxPOo4bzLptgwlcwMM1lc5iwMp2qFPQm9CXj59bTyPulVhfamxXKLC5Yos8monePdVzJBvjNdZiJ6zmwsKFGAKM3GAcSpQ5sUzOaxMkMR8rnGiafEANjU/3Gy0bk6qh//uAZPwA9QdF0PtYeloAAA0gAAABFUEdO+3p42AAADSAAAAEITifAuooWvDEEnEKEJFGDkm9AOaLgCpyijUb77hREFrhfYUYTDpV8iA6EcEw1AWCzMxzroqDqMtXGMpHhPX8Y3Vkkr1CMPoTGwI5WwncB5DYDJXkc5moiIzck2KWRXq3E8ben8rDHzMyaUWCFWmYko8zHd6c4mX0HU2l3uW242Vy4mTMuzmfQEjQ9BY4yLdra88fTyv7P9jbROlyPVv7URWMaklnVmQTtT4BkAAiElGTAl43ItaclGAEMnQZQg6h1sIfvAkWx9MNrDfwAj+ySiaIk8rE8MHwtUrLn6uk0JTkmg1WXiDuy4DhODJEmMn3jKJElWAPRtwJlBeagAiBkRQ7NzEpmAEjdbjKQzbHJCJLxwI6w5sVTw/aWqJbZSY/yc6MV12LrYiVDcvQCKOUZieIJ0bXEw4IEbNDBiX1LW16c6CSAOzDnRb/+4Bk+wD1OUbM+1h6SAAADSAAAAEUzRkp7WHnSAAAP8AAAATf1kGP///////lxzvhhTp9MEHydJQ8NDMqLAm0VgewAI0kQmYKrAE+AR2AS8WGAYEgEQMTADAgo+iABUslRCJLkOrVCxW0pGRMKn46+zuQFcvvy7paGCWRSd+6tJNs8n7rPnbiD8yablTuxeUgdIpDCYSR9hY+NOSmiyW7AW4qnrrGFNKihvZd9cTmL308zhWN5Wl2n+WdAjPtiPCsuXJiatNl5f8slCqE6oTHSPKdy2GZYnch7JtXrznzSbwek1GrrzR0AvthO0QwAKGi0Ulv///+1OmW0P/8VLXD4cIR3VH61GVRqMB8VPfNVdbvzBeKWkllaJNoKg4yFrTjiNYa9oYEQaYgMHTWihIai2PQAVFaLaAAEEBQ40ykeKcDRiJtBjyXJvCmHeftHilLcXCMp0RlCjmEdSSZMiWBGp6maDpEykHwqwjESv/7kGT4gOVSScp7eGHiEeAJUQAAABW1QyPt4YvItKPkSAMzyUIQKHZ4cs48P8ND0xeKqymbT5pMLFLN6ncVr17VH+vV2crW1G7X+87nGB0bLVamA3fLCAVHyodXcgRN5alOYxKou64jWLABGHfNlWbJeaaRxhf////aKptNSU0SXmVzhNE1M6dPnpWQVy51nsfnGaNBC3LvDOsSdaNALHtsDooquMegJgIUEmLSmWhAUiraKCgFjLXvCmcQhm7piEUpQBwBJal5Z1OVSjil5NA9W5JI9DUCqHr8k0z1XyNarE/QmGsuMusnMxRXE9XtF0nFy1qVSkuZGNugnmh9VOr09KZfvdxuUlhg6QP9WYYmiRlFHuQskAElFwWKCuawqWfMNkRg+ZW9BUhis9vtbk+ExZ22LPv3jtwh///////LP//OyoBLVSlpeFVkRhOImA5seiJMUA4qDw8HMAFVCFDIvMsxQ1zDJQjThNaEA6n2bsuUCXLHnLb1nJTLZbHYSx0SlEvpyEyeE5IlH1KaGByJCCB01acUlpEevklfGOKm6f/7kGTrgOT9SUj7T2PAKskJEgDM8hSJGSPtPS/INgAlCAAAAocSsDYKisPJTQX0JcLj0tCTZq9eSqExfdJJzC+4dRr+8vExfFDGvWanNIj5pYjNV6AUCw6WFY/t0IgfGTjpcOS+euDosv+PS/sVNXUVurEM/ewV5eZV2S230qAF+4cjAwnMfJDJqbzFwd2ZYYkJCRAhIglK1kuhx7kTdwFIpBgmF3jKX53AEjlUnlsdYbqZZrGiUOyt5F44pMASFNSSQHBBLMRCI7hdAj+xoqiSppMEuTu2FvxFVMJcxt6xz9iVhu3BmOWaA7m+cQd/EOLLGyejC45i6vDpswDJHpFwQRVql9rqaM2vVlhVK+wOG+uqpdaO5C7eP/kqGJmololtvbQoCcnUHQnCBzNeFzPgsCKC2SeB6M8g7MjuDSl44+HjyUAdtF0OnCEkVgcCJUBbDgY0xEOhAR1O1Jl6wM4CgCXdK4mhnkOVKGlfBLnEQ9bcIS+deC2NOaWbVWvoXGTkRsa94w2JxJEsjL6XY16LVwkm9oq7YvbVKf+BNmRcU//7gGTrgPVeSkd7eWFiAAAP8AAAARStGx3tMfhIAAA0gAAABNKabHOijPhFiajXcCQOHxHyq50/ajm/c2ADx8VymcFGHzxwIiZmnZ1tz0JgIaJCaYhUnOrkeSi46mDwC3C7DSpAyAGmSVXYZAsQjpYDaGmErhiLbMRLqd7eWMpzMV0QlTEsD0k7ONxYzEDSSpMjOV5dAWw9J0pcYI1WdfSb5dPOi64amE3SfsLEhrALYZ6gKUyy/ptmPBUExgOCuP6RD51HV+uoisPTkyMyJoI6J8RA4JtGWjDQeaEY4FtAyRNqk5BAyMnwXBRcQto0o783c74oQ54/cypZiXiWZmlkSIgM9kQUmmXlYYpmYB5ioOFwNlAGKyYNBjCUAMohwao9QzCAkk4eYc2662ewaFSq2ug9rwP5cbaRTsOQTMtbl03A7QolYEIqMLh5EktF6ElEOAfxUGpPXhgsKh3BtL9xVuruWkqGyX3XTJtx//uQZOcA9T5GR3t4eVAAAA0gAAABFlEpHey9M4AAADSAAAAEl49XxrCdr9E6uKJO7RQ0yaOnRerRx1xdqhUuQ3LrI1ZThuOicGC913GtaWs7ku1XS906Si6ftw93WW61JRtggGJOdkJ3Qm4uEOo2oawZK2tKmWMoEmMwZMrAVQhIhpYdKVUxiQnKhyiQ45jSZs19asKtesJynSy9TGkaRpKJrcWKR7Vri4eQOouOntm11piZPTq3mVpJEIGwlE4QhGXEpUzRcu1hGINWru9a1joSiSe1r1rZZp7t7DonJYxxAKOq0vAeJxkeu15qOq2oi7OuTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//uAZPgA9VhJR3t4YnIAAA0gAAABEtkhD6y9jYAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=]],
              ["AmongUs"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAALQAAQmoACAgRERkZICAmJiYqKjExOTk/P0ZGRk5OVlZhYWlpaXFxeXmDg4uLkZGRl5efn6SkqampsLC4uMDAyMjQ0NDW1tvb4eHj4+Pk5Obm5+fp6ezs7O/v8vL19fj4+Pv7/Pz+/v//AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQE00EAAeAAAEJqNIAcEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7oMQAAAAAAf4AAAAg9pBjMGANEU0GAG5XRQRCgdPfyCe5+iFnCfQncnOIVdy+v8JC+IhUAET+PA/9weZ7+//Q8ePEB+GDvAGQAAzD/t8k+Aja81t2u31TTSByWsKmKeRIZAf5zNKmREEASCCgzZjBIRuqgpMConruArjiYHXzlBLoF4EqxEQBkBEOb8oGOOCQSoMYgwkjUIICTjJERRdEHDvEYQxpMFECJxmBGjCYaxzCGSegBAw6JaPBZBAYsssADwDxxd+GFsnqOnDygDB6lWVNoBRURi8EJTnQBszRPc+rK5ZGO0rvvvDc9elExGLMUfiQPS1uXTVJNw/PxiQPO7DFIYbSHY2ztt5SkO15a76RSG5+Zl8ex5Tz/cKenvX6KA7Uovfnqc/Hv1+0PM6SxT93ljf1h9P/57ttM/AEdaJj//bnk21t6UFTyfMVMSUKMyYEawoh0aj8qpvbovmKeFuYSIGZgzhNmBaHOZCoqpgGANGq3IZLVhioWAJOnOsscyFhg0PGUjgYILRmJAmlWCaPAZmkDBaUAayGPFMZOIxgEUmPCIYRHpjUAmDAeUDoiUCLQUDgFHYkHSwFAMABgDjIELbgei+Q7QCEZMnl4OeEUOJQQM4vaURANRIyCQHsIgUD1gLRmWBjI+gWqcRbgdAcRgFZxmFjFr7LqF1E0Gns4Rweq9Enff/7sMTbgB49VRevcyBNJLFice5hcPhwFvslbdwM1b02VTr7ZrKYmXzhp45OncjQhMRAj6lhmA6zg14kv9rytJcErSrKxPOkUeDCNEqOeuluylDBXTTnTZd57XbgCGHDa5SMAaZYygB3ZW/krmnYmWdsrppfUaxEXLd+FwmLNclkD3HUoY5KIDi+cdp4s7j/y2er2uynTSOTnRXb9q6mUoI+eSbgY7MRBDDSwRDAGjzUx0ahwgAMjMTEGAwx1OHIgFiGtRhqhwasSAIVZqYqPmPhpUEjQAtg+iRgayBGVF3BRRiYDiOC38+y92I2w5tUI2MobwCwONZvu79O4c9djEofhVEum7EAs3mbjX4S1RXEMXpSkYudIdp0VkzGXSYI96ITSUASYMPGYiRDZUi4OCpVrLCNhvLQcFgQ982CSCaHiuNG4tsioTEz56vSsiTCzISogFRFA2wu8yl8DsZxshhF1LmiUMQhTkvEPOOMQh+tt5lq9D1HtgO8R8MM12tqdK9PkgUKLYJp1w8aDnHmOM9VSmEkSgnDSS8w3Ifb8uDyI/V6HoeN8Z8W4wCqYkyo5EopMdOcBkwJGSAgYELgyCTFYDNbjEBDwEonUkPPFzCsB8Whojv2RCA1NJ0GhBZEDFI4MXBgSpGGRBCegOLcNA1TxLmdJxmcJ4PwlAMQADi5LA+hYSXjuLyzmPEeNCCjohWH+3To12nG5YhK08EcmTROyRQTTsKfWjxE2L+gXhCxwHoxN5xj7LoOY3Uur1tb2xH4uVejC9oWzxmu06gV22M31ELCSRrixkOMo8EKLguVwXKBd2klalH6XnaVwyPzwU90//ugxOyAIg2LPa3h8ePIMSn9zLz0WjkYytCMiubOvQFY4PlmLHivG2PVp3pzfKWLSKxtNYsry+bw5HrS4R9VCTRTYyIACgAZT8pQ66EOzp6QgYBjpZVSKa5b5azcmcoHONdZ07wehyCooRw8HgpVahyoFhaYsVNjt1taqD0ZypNs4WFnsOXHF05vb2sbWa01Q+lS5u6pp9RbLS5Ma2cmojR20tkvH2TxVxi2lxMNPKyVIs10bWPNJYWdra4qoheG49iVjetORhvY4AK2NWaDV1ZkfHZfW3z2YA3kCMGAzpSQBCIkzCSKDpUw4TNdGAYLhjGg49pQFCEQCCAwEJBIIjQlU3iUS7U0kmm3Z/VXagiFlNadJmKt2cMLGYvMOUiqXKFkOexGd3ADCf3jKo08+dBFE+48wxzIHhuOxeVyh6pRRp4ujBzYo1FozcjU3bg3HLurTcXsd7jv0/aenzsU8liUDXY/O0jtS9J1ZAhGwG7GXg3Qyt3nenZbnKrr8wmWym3fylVS079yJbqwz//WppNez//pLHM8+fafiFdN8opocFgUsCYBMCAIhFEohA1I54iMpORI0MMGTEAYwoWGgcxkJC4UBAoykBAwoSBgGJAuIAoVARwZ/PmcAzhG+YOsw2wmCDQCg7pqUucXHgF/6yObdGmZOyGBypvXlcaHAcWo0motTq1Ec3TV//uQxOWAEVGHV/WkACNXqKn/N4BJpgJSpOlicmXdLIOYe67d2hvJHYYhxpcBQPSydvYdVMmApUYxSBgOcRvXuztrFPIYZfykjcaepypDWdSCVj25G4EsToilO+892eiE7vliWzcanqeclv25Y3dk6v5BD7J+S+tLKS9UhV7U9j2xTzMCySXQ80HC1/ZqNs5XcEALLQPU0L+LFQHg5deZesuO52b2ye7LZq7cna0ana3MrXI7Zl8fjOXYtTz98Mq/u3QiD1H/RhBRksQUROgOgGBUvQ2S9TXQtj6wrJbzWr4KgiegCk4t0wzFg80qx5Ckh6MYOsoqBamt2S9FUqSShBKs0YocWLkixPcOPNZpSGuYn4j8pb73J4cVqpqdI49lIGXJsyapNQjvs8vfYteszLW6XdVbVOUPvyVi8mCLf/SHV9q63IdCBFBLAGDDgEjDglnTYEi2OFQBg6CtaYrvK2rmaSwV4BICRdAVKH0U0U7w6xSSZqe12i7UUMvZMQjRUYWX6U8RLarksXhOysOzoKWnhvY7X365LB9nOB8jKxQw//uQxPsAImGTafm8oAoQLS67sIABNIxMhkdL7Dh36pkc1VEuiNOGjnIwk846PvqgcrwrnYSm0MGLh2iZiFIpmUcCEHF6ahhnloahcQSAhAcKsSFp7KqtwnWtwI3zJVsEmlkVK0qKdZQzUiydMwRw71CVWpSmhgIZIiaVxg0lBD4PJoSlFZv1KcXfSZGUKZ9jYzQ1jZH7ZFSZiKrDKGX6zoU+Gq26wCM2cBIKgE6xtTVQzUuigolh1+bfVXabNKAlR3l5dGQUEW5JRQwpUv0EGQRLQQ7IxITYYXsj03y3Xatt7MgOQTAShrPqiMQeu5Y3NHnzh91PYnFw9NiJ22uSYzrpzJbVsecN2IpRvOObsTt3Mxbd1VtPTCJrq1uayf91Hzjr7S4avR1zXTHV3fwzddRXUVU3w1zZrqN3MxsSdLp/jbE7XXUVCtPQMod2zCuDZUAyW7E2k0U0TCiGXhnBQc1IWGBKeNSQQlAosqvDSkFMhEDMUhM9BAV05/Je7LTHmjJDAAjMHAEIB9UdWcmAAl9iZIg+qVScSUyodQ1FmsMI//tgxPWAEGGFb8wkb4obsWz5lI34fZRxKuPUL8w67a12cPK5E6uVeCfam78MxbDBb/Q5K2Tue3JpDLHEftE5QiHU043DrW4AgyUyyHqSG4fiUBRSSumzVmKiigb4PxMySXutLoVboKd+7UzCNVJ6epFY2hMHyaHukruplGZLQ3YZhrjs00ilFNYs0dNNYZT2oHosJt/4HZo9bjtfkcFyiXwqdy+rGcZizP/9t+rNeV0eMdcufuye1/15BH4u1uLwiGocltd/5/hHSaaHhoiEkyFhMptNEMmE1kk+TRHMhwzzWAmbeHEmD4BKQ5sgCMMMOoRnB1xCuiqAAphywOPgAGQPwwcD//uQxOiAETGFZfWFgAwpsup/NaAAApKILWoNLRCggzZZbZ1TSYKwzGnFfVoBa9HiVQEqql7K1rqdNnf1CN22Txx1ZqVKYw66MrjDM3GVPLn/iz6PjH3SuPbGpp2octssa0zCMNLyZo3WzAk7LHvlkU0//LjwuK6LtPM6EYeS+9EDxdo70zcNxRy5u5BzbWojBr7RupX7/8qxGzAU7WhpwM38hiakV5979rupilnvmaWS1KCG9vq3CMsyZ21p4akpuWv+Sw/JYU/8Xj8sW5JHzef/+arvrDs0/0alNnEYxMxREM6M5KwHDKBisXA/IdBcAhpyghuCgpMDEqhBCjEzt9ARJewwwDNFGMRhUjTTIYCNvA3CzwI+h6XMdgHJLcJRAZws4aA/LSUe21hStccBwVHmDOG0dYdsMCwNHOsCYa4a4mBq5a0r1OR72UPw/kGzULUZjkEuw4EEXG/euXvHAETd6GZ6u8sP5O3GaNyKrDFMVlOnFpW8k01rc6pquWAnad6QyeES94JxkkTgeAX4lFNDTSZWv187stjMqwprtmZp//ugxOSAIL2PXfmdAAwSsqx/M4BAcYfrc+UcqXZu3ZtSqKReDJa9kAwNGrcM001SwuCL8mnZ2zvPnz/Hfo7MYgNrMksQxGb859izyH6SWP5aciVxi7LKeZd3VVRBRDJTaTISUTkfuB1QMXDMDKSJnRIYBSgIMe3DAjGFLwpWHEKZIxhPrAGOQAkLBlxyaEBqfQVttdKyqNKbl7oszWQ0C82sKEtdZwqNwIq/7G3cZlKYEbs57jPzDjiM1eWUyEMgyGHIgwWBKsFvvFnVoVqy50Gwyh3Z17pVfg2hj0WWsj8wGAHhhrcFQc6nZuSv1F6ODrsmxhmflUm7Vlk86jOY1IvpIehi7TymdpYtlSzNLVgqVZ0lhIZ320mY9Bb9QXVd3cqxty6P50MxDHKB656AJFIo5Y1TXbUAyz/h6B4Dhima+/D8wVRYbvf7vReCMYCobsTjtXGU2MqpuYVCFEgtOYxjVRJzEwy4YhClomCJDR+TkbGztgbN7DyPaUqAIgvD00UFCy7kgQA8GHjBhhBD5ZZzQws8lHGjVfhmhZ6HDtTSm7a5gebB9Xe5rzHM8RXvdsMh5q4/4qVXTr4i+f7jjvtYp73tJl4+LKiLpOfGzVEiCwiJm4KkExGc7ap4UjRIkm3fUHRKAKGgRKFQ0YvQjlVLfvi+j7Lea0wJ0Q8kZgOyaYJmpKQNziUO//uQxNmAIAGVZ/mcAAIILG3/sIABM6Sa5e9pJJMpHnOPNQlat0W7a2amjVBNA+rLzVqxq3uVr2OtnEX21K5+a21br+2w5zafm0JW1x59VVObDnV3c/ue50TKQ35tRYoU6ObuK78TQL/upkS5uxMZComqJaKzWrHa/qetwamGYZKIxIFCBUyOnShkqoChBhRwOLgwQYoADQRf0LlzOiy8EFIBVqEoQy6om5uiwJ8HzDAFkDExK5gsnXYxeCGus4i4KaJCUMEguOvJpLDEF0T0fi9SpkDGzPxXcR32IU8Au6vWC2owXeiUDNbWrA67091YqszJ37ikQtPkw+KRumlNuBuW2gSF91iUHeSuDolZnMKS1Rwf3Kjv2WjRF4nSaxbjblxuarVb8V3Wt5y2rNyOvNU9FVqz24gzBYFH+CX7mq0ZlD/S11oKtxnOzGrnZuan98+5DGPJXXzfi7dzkGsPWfGmIyhHIOAkOxxsL9P1F53Gu7t2moNlUgQxTqLjmTsXsNwlzVMjjEDqzHXNV4DNhdJdyMBKIPZnHWBUgSYFggDe//uQxN6AELU1b/WFgAwcsuv/NYAAkaeAlukVCWClCEEBjm05ZEySKMUUzQxYzF2WMtZwrQ8C/4m+Cnkh3WqK7kTdUlGnuNCFFlh2sqDoYSp86NnMBwPlC7ceeR9qSjwe2MSqMOPDDTYk+0PN+wZ1ozaziz7PO6k9BtJGYXT0mVlrUlj1NLK1+LzdSktU+WNNVp7EXkEzPu9DNLXwr461qmn84vOy6xPchiryNRyrKasupLVLxy4ct0jXYOcaxam+0lzvwJK78llj2v5GdSyvbt/8hhyJw0976XpbXkMq5fiLh7uJIlM2NHNoMarXjuuMACLnmBHJmA6IMhQQUbukgBhBixhjH54mh2QxbYGikAJjUjhgK6IKXK6DCZHxsAcx4x5jDRUZeQkEWbLmNcaioUylEZtFOVTsTQkv7FIeaYylrUXb9zn+ZKknnA4YqH385LmuSicfSggac2yB6ViqazMeczBnEbppTLGvQ3KbliLbjrZ30htypAz2UPpMw5GPuXr93dBhIrUtuXGnLUnYOWlAjkuE4U09kojcxEaKrbkE//ugxN4AH1GVafmcAAQZMqz/NYAAUkMSl8qnoJo72d2idKK1rMUiLuSm3DL/yGXO0pTA9C70BSiedyvR/77U9I4VaxYj8OyCltWv952HtvGHfjjcIzZ3J7d+uumXabVkV0QlSjKkqjUDsLfCpUDCwCCNO2M7FAwwqDRQQZUiIhwABgoUQhTFkQQOAhcLBBGMgxFzFkbZI0vSgJLchlgduPCKWp7NuqBI113Va480hixaF3l1IOqUqaM2Z6yp6lMGcNfnGJOgzZMxQ1rbAo2/T6t9IYPaQ8jh27bS4S5METMLZNfdSQQ5HXlb2FRurJs1oyqG4Ii0qwpaDOVTdSllVPH5b2/GpZP4ZV9XbURtyX4xGpTy7uM+/scfWBO3IYprEYpI1O3ZPhd7T/YpK+crydq69UKgqTxmmq3Mb//8Sb6klFrKUzd+s+/bH+2j+Qy/8/WiksmcZHhS8+9/NaJVldnQ0AKL0cbbkkNhPgVHFzB03NEHjgCgWHzGhwZDjBiqYNiWiqBAwPGQMDHxh4MAmOGhgUzoj8JQaNdIuIDgAgQu0KSA7kGiCEUGgtYafBUnWI0xORMeGGdKov7HJXArI6WMwypy5uWqaGm5MOVqa9K5e7EOK6liyYw/0RSKkT9Lmgt2aWrF3AlsmlaxHTa1VX/G4fpY5Yd2fs0leG5dPX8ZdQ2KOQNSjDc4//ugxNgAH/mXY/msgAQjsqx/N5AAk2kSjcopqssiTtU0ei1SYmael7HKkpi/zk7S0kw+8af2App795RfCLS6S092mnYAgSjpZi9PT9aVV71//e1kLZHHpma2qeDKeV3otl+byzs7Wwz7Oymxdu3J6Wt1lERDUSEM1NLJMmx0xx0ybEzYoOGncYmK4GaLh1hmYhIGMpAMqZQaPDS0JkAxmios4LnF+XlJkEAihYgLJy4bCC2aDovRBkui66zHUZw4DlIyLutx1/WSsHYO3drjkDB1B0H0embTTO+OM5JRCGiYCIsccV+lA0t0b0KJKyGVOVGneiVLNQ1aqw5RO/arSlv40/TBnAfd2k1VNoezfmMxSIUUukT9Rehm5LTRCO0U7EYTMymMw7NW4lYorNfOxUsWM6fCarTeMRl0q1+MANxllLZm+yuMSmUtfZJOyqHeT0spoah+5z/f1uTnVZXNZ1N0tSY7/4Y3XRpoB+XX86sh32Z93ku6M6GonAoZVq5ndaFi8MT0WMYVMNSiWMThGM4ogABgGRacmQAKmaalmrLqGShAmMxSlQbDK0WjC4RDHQdx0JznpCwpOCBMmHNQxPxHM4LNBJDFZoiwWEp5Bsc47AGCQCCBIYHISsPDZhQQsIMUUMGLU6HjxkDIkjYwpJNwSHCEE2dDRqBCAFCQOYjQ4mFioJEkOEFn//vAxM4AIHWVW/msAAWzsun/O6AA4UkopqIQpiAahia63F1jIIzRkFPwEMBogsyXYRvTJiAsIX4rEpghGXUaa4S4HbMgMMmBXoY0iraXKLlpCr0gwMJxpiCqjVmtKAFQWm0X+YOnwg6jszswoMKCkRQsIAAUEiFDhUGYAAxhaDTHRYOyqGFIJgsna3F1mLBwy9V9jDdUTHKSEIQhEBMWHEQNSKqYtILpJEEgJVNoAYIS8QqLlsHcaWr0ZbATjTt7zAj1IOOXIdZmsHwVCl/vuiY7Mh8HAkQklUx2ysoHgaR6SQGWDAJmr7WF3/iYZ3lniXV0ijgkccsVaMiJxkTMjHQujBUONipjGRkwUpMABwMxlgjMZcguFjQsKBgsAGHhA4YiWIXuRyCqRMcLRhfkCCBdIZRG0BGuIg6YVPT2ZCrCXOW6ycFLgYtpqXqljVX1giTLZRRXYpg0xH9IteS5lYlkto9jSWI65LVXM4p2noqMsUybisVrMNS50Z+WQNhEn2dSs0iW16eljdR72UzHGvUr+x6U7fWIuTDrX3/k92pYr184GhxiUBQfLZdSQXJalb6WU1Zl6JTMvxSbp9X5+USyb1jet03alBIuaZU4Nqh3nrOlf2PRmxrnyxY795O/D9Ry4vb/D+e16dYEu59YIfrO9Eqst1MuzU6sJoRiyFUYRUKxIdEIgk1hIk0KBhQGAioypXHERINWAU7kGhMpma6Y8MBoUZGLAIqDhcBXoXK/tA5wYda9MqVqrZyI6rHDKgCAAFO0IvyxKJQPEplDRXrOVWMgZShbfuzjCmQtM49bWo9EJW19MQuxFUr8khnBs3HZcV3nzcCed3CPwQ8TM6ZSypZh2pGnax+dfmNRyKWpbYhWDNWQJzrpppG0xnEP1ZqHqsumubpKSrG5HKM5+tDEszUaQCkR4eLlqAM1T6ZCqV+7MDRC9EZZD1iT2sLmeNNMzEUeSV3a163/+6DE+IAhjZVf+byABAwyq38zgADz4u8Dw1odUaZylu3C+oEr2Xd/Cl4+1WdpcZbjyxRqeWe1ZFNSJzMzMRQUZJZUaBzIwBkFITAA1hgIdFhQIGnFJhU6nQYEi1UwwVhwYQDkRly6BxMMeclukOpQcVMxk5sWfgHAqGjuF5FhXYhT1Xl6NAVw2jLlfoIVhnpceSxBK+MooxBK5FeSSW3H6WFwNFJbEbVNG3GrO9KJFCIU79qIQNG5HANl2m8rP3SSpuMPUDwx+UwBBE3JYzZqTFJVvZxmU1N1ZurX+MR+dxx5OU8mgqH4hTYwW/tyAYzdvyy3EInF5e+kORiETVLUl1NAMA1IhOSp9pJaktLe1GsozflU9v2XuSy90F/rsnJRK5+FQRY/5mD5TH33k0/cy5d3Jg/YO6NmQ3NFFAHMSzNRKFaU2TABRahjwsFmGJmtGDq95DDkjCDCIWxQyh4WBmRPJGEMAFFGYcpFMIpsFhUkEKzEcSGXLLobcdHEWkNYpYsWZlAUWfpx4FUxYOZxwhFDiyz6wjVKRjcF312PIpy3kVeVR0FHluACMTIPso2yJatMpklTLQakx6XqsNcUHAqbF+FxJ6gZeBo5VqXZldrMJuWVqWKZKBtggRt2cMDS3KgSLG6v3ZbEZl+blJSuXYl0HVaTqMCV6RDPmstPRXTcaahCXrlUalX/+6DE6wAgIZVP+awADGcyK/81kAmO5TS3pqtXkU/jN0OUr5+NOZRBdovOFBDLCIjQUWztaEVdBxGvv7B7+0tmzDM1K6KXvVhq1rckgKMRluEkmpVQx7xvkFbLl2VlclJDI1NxhVaJyW7cyq4yVUCpTm0yUqDCgNPBFoaFmDOkpgeEL/GUrYzLhE9wcpQArSLZCAZc9GsdGrtEtnroJkNQTxVGyRVViLOWlMVJitaWg1uCFO4CsJjTUudRhrCWgwKqVjUyxGVdqP87UOxigquJGovFXwbk7Losxh2CWvVX0jNHJ2gs7Zq3Ojiby0LZ4Els/RZSiauTMtpbs7QU9etXpZmXXr0MxHGI2JqSUkXmovIJyflFDI5yDZA8dt8p7CNQ9FNR3KljsVlEjgzkv3K9Ppdjju3Yd+HJZhT0/f+9Xi8KqROhlsplva1//pJLDUiuZTtyR2/nbWepyR2RoAKBIDqdipmDouBiUCZ+pGWHJrFGooYeIoOkx6am2m0hQiAAgXEl4wQ4OhkTMWICBxgYKWlNYDAWDpKGIL6OIz8AxWYrcpSACu9GmTp7PKQBeaYZkooXhflYjmSh9XZTGYYiBTqxs9e5nDzuwIyO5M3E+1SM4fuGqGbayyCOIPw0/K3SEMGx3CauQe1yCVjOo+UHNnWtqPwFLYMtStVSbeqVS+xbkMPsqZ8/Dcn/+6DE2AAfxZVV+awABDyyqj83gAiVw/FHoh6WyuAq0OxKSzu6edrRGMVXMa+4DLoFlkigi3CmdNitu6/DKL8ulNSXTUVjrq5ZqXs/gCBPqxt3dZQl///2zQPDj6Q3T3601Ypruf++rtO1auZ5/Kr9aVdq3xSOYEAAAQCBYEShdtMEVF8YLMasvuaoQJBAWhKVLBUwitTpNMM13DspLTGIQpSSleArSpQudT7mKVFrFHgIluLconaT5lDrncpniF4CwRw6ZapFbEe3vgJudoSKq5JBOlA+ma++Smznxx3ow1uLRlrDMIBZ8qaC3qrOLIIClrvvy3J2YZuSTNjzHFj07EH/hmC52JR2U5s5dupDdmdgp75h224OG3drDxrtb6hpoq/uTxLmoaWllkomakosw/IYGqwe6lPFMb/aSXuJDz+wFcoJdljhE4xLIKjL6ztHPR2GpTOWb+qPvpxM2kGcil1HMQ5OXYpJ8vie5ZHp+zINT0SlE6KvtiMdGQhMgQxTcKjVs3raMhLEwrDjOjqO9p40YETfNZMpxcyylzc5SNB1Y3FgzL5UM3CAxChTDCJMkCc2KeDFoNOZ+4XgOJwzlSH40oRIUFKD0JoJCTJkogQkzCBCkbgKE8AJKaJIl9AKcNZoLgY0ucMAgoEWBBQCmoCbECy0giM1jLg8YPBC1i8R0MYBGvy7K3b/+7DEy4AgiZNHuZwADOWv5/85kAGwODVcYQCAZQIviEDiAUwQS/bB1+CyyXwVISLikHwCyQwwAAGtJN6GkeH/LSQ2XrCBRYeRioJcaMjoCdZMbEXojLeFmi7AOMXexlQViC9y248MuRTNrTnxGDWcSFsTB6VStQlmYICeNwZMHDpzqYwW1pAYDBUQC+CgsGjQTtJYqtlCw8Nv5EvnaWIv9LaCfpe25yawx5/Zby3HbGHcabKvY/71/sU0lXhXNFYyRZQCICwUE005JJU7jBC2lhaAn8QGDRNxqWmYYoAKFl1psAYAYAiHCygcQAGirzeImGUBMy40MzADDFljq9R3QkAwozBF3qWq+hD3NEWuytCwySTHNDi3mfRx26LSa61aGoLojYEQoek0hFbZl9HKrRimvyllbrRxriXaY7nPw/ERiUNPtGuRuCY419a7p/dlbjqibRobQVb56agONxivHbkf3KJZVhW56xlTtDgyZrS+fjtuQuzMwqWyuRY8xnNWspTS4U1+Hsb/Hmvar2J2noKarVp7/4X//n////25iMS2B5fyrTy+HLFi3nIJiGn/jTtMClL80smt0trUNqqjiSgAgAAIKAQEbt22xgBgXLoTjIAwDVMy8V2FQwyDHqRaUDHxguEAxCKMIAGiokCF0HQgRAMOmGVCAkDTBGKZVjBAE5UYVpGWBZ0EDTEQRqHxpwFAJpw3oEBTEEDJQZNyyQRb9n7wrEU2Zcn8wlhgIsXRBJkQ1YkAOSwym2ngnmlPWslLxaK8U1gc5Ekv26bpPY+MpmHxwmq6jjQoDl7gTzwsweGGpymidp+Y00+Qt0kdJf/7oMTbACAVmUn5rIAD97GpvzWAAGtWZlssS1P3OZTN+6207KpfF8uf+pVG3CjVPIL2Gd7K7RxSpT3K9WRQ3K5ZE62/x1nWu41bn5S65j97P98x13/+V2KGvnfzr9WIk3YVgGsHQEOEAAgNFpO1HwyFYCo+aTPp+mJEBIDEogJTxgwyYmTCwMmkPEJkYYmEAAMEFbikSAeIGFSG0UApwIRTXR0IYmwArhlSrCbSPLOBwIn0kO4Q4WSlMQAeWTqmMGAMWAJgS+GuqYBx9l7NzFAgIEkrSVhXScp2JY8bxwBD6sBiwpdNPt+Vzv1qXMOjr6v81d5GhWoppK9LhZaI7eYS6WOi7LYpTrsMNxed1JROzFPZT7l8cRQYitdqMK1LXSdN+ndmodlUzrKarzVbmpXWzijW4eV+zBkjOIjTSNlEM4O1ch54ZXCX+iVPaldnGv3dvv///7FGRqDyhdkUxV/C8P/+e3jqs6iclg6/ekU5eDOu6lmZBEAAIqZ6BAJhwQAgCBJoJhYCdKCVOZSxdSVs/jPtYHSRQoHUTVEXJvbD6NncryeltOlN7pdyxetbh3K8KW+4dbj8SjWmixN6x46xO0GNpz7154Xp265aq26Nl0l4p8JJbnxvifb+uxrm3XecSi1E3CRYKtkdL4Cjo54B29H22vuZaGRAFkEqbZhx5gItqDoDUiU9Cf/7kMTWACJ5kVP5vRIKC6Xq/7CwBYGKtCVMh3aOtJYpCHsNhDE4LitFBpywh+86aHVqtQNQ9A9y6/LXpIxigEI1JqOX2sKc1EMYmPTyhrDpqnzJCCMFUCNQQDHLyu2RqpKs1ZrzLDZBmzIh4NTZnyxlBmz0ZtW8PocA1EBG+rr/8OqshEBAIAb7AgSmZ5YPTEIbxQOPCXFlNKYoWoZog47DsOEOmScExc+wllKxplhVttVe4KJUww3cM1e0oaii58mqjKmFbjTGXboPXfSjc+pjM579n6hDJwhNuc9gk34QjU7lCa5O3BSDrkgYknZ+MHTX+xYg2XkRMkGOLOmxSpkiaWiitmOLNRmiOhUsaamnIZDhrhYfAliTRCFg3gm1FbiHa3ZoJHMWZGYgWU3Nc4yEqNSsQsTGMFAJBB4mMWMTIQoOCTCAEwclHiMkETIAMwkBUnKxAEhixkwKO1A4tJAkRB6iDilqJCez0Kxusj6XGACJqFvhACjSMr8rOb1NBicdcscEZ3GqeKviw11KdpS9Jf16aeeYeyCUNJhhry6mlf/7gMTQgA/tQVHssG1KgTGqPrKQBA/m3d+X1jDTVQO7Vjrtw0sLHWCvsy2kjTIpmXX6bOeanjB0OSjCUwzeWkqJcsppZZAN6Rbi0EYzUdt3exOQPrDbuuq7MtZE+stvsCjc7CnVkMpsS2XTcboMJm1IHRzxld/Hff/+f++b/7WHe8y3hrVm/94dtB3quHWVRUBSRiPTVy6+TTWwLFQywCRpAIJHpgJpkSRpAaL5NQFQZEyMatMOWEYkzolOEyJh+gElW8MQsmINie9DFriiyiaDLc0CY8iSl6lhU0FsK7gxpTtuEj87aCB/3hWNVl7bqD4pBIOLnjD1spedkkDNyabXk+Lrvm6MMQa/1DA0ajsQeRsjO4u774QOzNdbxNlpXbij+3ZfNO07lVqcMaYm+7zx2BpZ2Hm6uhGXih/OLOFHpyZiFHXqUkIjEo3MZvcuuXSus+80/s7DrTV9SRg1JQzFm3jT7jMS+clFJOZy//ugxOyAHuF3Q/m8gAQFsSi/NYABufldNet0mHfXjGnJgB9Y098GVKtNWq/+FjG92tWtwUrMmZh1QgKJKcmUMBWSQqJhAEuGCjoYFyHgERGGvwyZfjSJXWJBsBGVpsJSVnYhI4fYO9E4gUON03PPNmo4Ys1epebpp2fhksnfUPebMbv5RhFRE817NqFumJi/pF+3Yx9vvdT7umMjUYxkvfzE1tdXzoMKDiDfrZ0/nZX83vtmts7r+ObN8H3Jm2d1dCEiSCm3mxF41oGKJblW1+AxypnkRsLsSNNRMNuc5HrjvSmQImhUGjD6QQXZXjawKDsWk6GokRpcuc0RhRo477NiRaKMFKUyhBw9V0Km69G/yrHHRJinRLYNKS8h15TM1ykSQEGgMLbWHYUMpLySedvczDR0E5VAsjLhofW4l3UkMQKKKcnX+OsUpEBU30rllhyljBYDdkY1MYrRLuW810HbxvNjU6aVB1ZKDqzt6EmhsS32XQm58+PJbaR2TSlnJXT2FSR6LfnXyrO2pStGD1zLau5jeirwuqxTbDL6i+q+W7WMVc+TiUcUcrvt/L+5hrdjord/z8W2YN3uPe5021rWtaa0KS4jdeWWFFkOGJUFcxQq3n9vjwIoOG1UuMCchwyZ9LUIQiMYBBphQIoWMGDLrGIBoKF8UgWCIbCIt0rKRmL4pGDr3Fii//twxOqAEQF5Tf2FgAH9pqk9gw4hc0XayoPxCxmrpIJolLZ9s7MG7hx1hm3aXk11arcoIa0yZMBYj8UkYfe/AMZkEw5URop2xfupWY24XnBkTppX2ftuVdqZR+mvy+H4bi8X5nIZRZxsZ1abC68Luv9DVq3j8Bv/Txl243MORFJJL5TKaSMW4hT4W5K8NLQy2tEeOQ2KPz9PF7V2np6e/GIY1fpP5//////+O/y///////5yNy+3SOzHKpI2MFImBEWBIgSQkFFbL2mAHg85RqiEoZmhAN8BRElKjpVDGkyKCLLDiybDze4Lnv+XLZeHUmnQtFpCpkkAqugYPmHiSYtSczAS7qGLst8X0S9jjyP+r9r0RVtdpsIkS+cBMmza08TSY4y9aqVLeQ8xKbjMkjU66NhlL+S5rv/7gMT4gBFpe0f1hYALm7Cp/zWAQb7QtYSYgdPRpDd5G7zRqjZHiXVAzEVi1n/diUUrHnocuAZ7Co5cCNhiL68po1XfWWxZlU2yy/PyOAZ14mktefZyXvuQ/LOQHBDzR+s40A5WJ2NS/ONchqXY5W94yJy2JswtPzLaefxuUtNz/dmhvU2HKpW2KGT11FR0catdZiTdk220QRVdAzQUTLwiAQ1TTFKXQadYOig4QlDIQBIFgjMNBiheIIQ4ocRRdJsv0y5RqJDoi+CS6rUZC8s60tkzYGcs/KCDEU+1tqfZowCUOg6dl4EHlhmCtMZO2R3V+096LzLe0r7NReWkf6NS6B2cJ8OU0+RVo60Fuj4wRFWxRGBnCpJbHVNJbSQFSyCtA8QeKMQ3EZXVg9scjpb9TVrP4jJHerWrEtlVZ8LsQs01mvlW5lE7luvQdh+esT+FicrVpVat2r9Smkkf/iYeI2eRZiREZCQiES0i//uQxOsAHpVrT/mcgkNZp+g3M4AAiGk1K0DBYBzJUVWFLqGfQIykEIQ4gPDKUVygggHCLBpAS2MEQKgcpeQIAPqc6Fqbo8QAyItAqZoz0zi6IGTmeRWxVSaeZpcDuKsSy126/jsrQjMXhlAhKFY1gFjOkuWHVsK1s6dvmUaelcscmnukVO7j2qBqnb+C1133dv3mcz8y7OLkNzfl4HKjUpa+y97X3fuBMZ9/p6OvhLrEYiUSsymXxW81mplWWI0ycmIYkED4TkXpofcZrURdmW0sphm9GXQw3cpOX5ZWq2KkvqWMtgGCvkxXyVmwaoLqEoCOBQIgMFh1UCEIEMCZnUIAR4y1AMee0JZQpAkMGhwEDBZIgAhEAx4KhIKVg4MXgDRiAZEdF8JA7iCZYdbKmqtQLmTGQTsNSNBAHwV8WBpvMSW0ylSaCrInimYLbsgAhCxqR0wAVRRL9RlkPZLPxutFY0XXahAiNDQG7Rl+m6txnFpQA31Wbg3iwzdnOUvaYz56GPNeZ7Gn9zbrL+VIlM4y2vfdSOMoYnLovRQ5hF2c//ugxMuAHB1JP/mcAAvnMqh/N4BANTadDLwSmXTLT6lJUhjO5RfeuQbg8j70svrVaavnp3pFGoNyi1Bfxx//////////zsWMbeff5+Gv79Ljl3LeW93t8t3e67uJt1RDRCLRy1/7SSEE0cmTMyJNe0oxE0zEiTNNxc0jAjMo9HWkbWuJnJ9HWE8YaIQ0qAcQTDBwNogk0YcxWA0oDBPHRQjBpZiEhB4EFKBTIQEAJqjIsiIhIkRjECaXIGPLsmCC948CKAIqJUm2gDmSybXi2IcmIhAdAVRGcCyCHpEOw2GhQmHyzKxS26JoqeCgWvNwGkxCCm9R4jgrRS/IgBk6XresKd+IptERbzo32VUWfmKLDaNqOw4BDbK32euVzqhNA/KmLTWVID0qRIMtBDryNLhlBdx0ABQMrAyiIX5mVU9Xd+U09e/ZpKeHmcP89mMsr00/JqF45+I6l0XpqWrfMHwcEr3vsR849K1qaIR2RURCIQEwBbalabkZIbUBAAXHF2kgWaLAjIINBZMNgE1MTDTWzlJowcYMHGCsWEIaqgLPcVyyqUOApfOMrZc4Tbp8wa01bCV3tedqMuispuDYHWavPQO48Cs8cVsDS2nwNaYAwJh8uruorHH2Dssm5mzBrsv5WgVymwtq8NPMyF+5FAF5+UBkmkbpPrIqJozeOg+1I0iDIDnaeHaT//ugxNiAIkE/OfnMgAOPqOd/N4AAvzERjcOOTKMpVyzF7kKeeFQzVcSxx/3YlcPy+N0FLlLpLD7wYQh05yYimdichu7PNcpKSX25desfy/YMmBUWra4CeAw+hFVWhWQxISQBsDRaUCgRZSHNsWp0x0PUbMOOTmV41dSMcCTFhIy4YEiE4CLIU4VFlxIDxANGFaRHpzLMZUo6mWAhBCMW+azdWaMDpRlBqKo8KvV43Oag6a92hUrLC4wOZU6R6EZT+v601HlbjEGSOuwCZJi2Rr1TRaKXGhh5aGVS2VTLaxtz5S2y54eTnLMJoNWL3y92nHo4lL3Bh9/6OTQ/KKIuOmYo89D6rzlTjoAqel1SfYiMmppRXnoRIZVLaDJJdyUwXRXNMNMaS67zvRcl0zKq8puynDG5Lq8VhmkrTGW8b291MMMP5////8ijT/PTbh25ulrbs8defqyFbHRmNGdSJmNWKoqB2ImHT/DkQgRhKESgBkJepqAFEMCygkEg4w0nMkjTBU1IMiCiEEAwgCvHRg8dTNJxKguqBrpCRQEFQEgSorg7DMuQJUGwB2FwQcg7F3cjsCNZKOHkIggdVC4HKbOsLKXaiTfLsdO+dRqMOAzNqyCB23KeaJVHwV25bqz8tfkWQ8qCdfgGOsYu4XWaa7KPLSnaYcr2lvVmjQp91HEiMXdSHTXayhLU//ugxNgAH5FxO/m8gAwlLug/N4AAvu4U0qdqXUsArporlvkzY3P4IspjtPaO09dawqOc+AmQdcvvrNWnRfaLUMql0koX3s2n4pL2f6WIqgvxyHuj8qfONz9qxL/9wn1d2x9qZyrZ1o1axzb+y7eadWR2REFwRGsQj1uwBDgw4EQcDjXEaMCjMxwUDGxxBQUMdGkyKHTFInMTjAOHgEHxkkZg49qaGFQqKhn1Mhj7EReBmsXpRQE1t6u1gjfJxqVMBSEa4AmGcBQwOPI42milorFahMGUrCS57EjOVFdAa1hWKHm7PdAzN47D7+06KbE2/cSMLvWkuqNu1GXEnIhAsOTdAwRIOdjat6m8uaVGqCHpa7TTpu3B0LiceuzlVOvKzD8xOQxIKdlTXqdnT7PC7Twv5EInfltL2Cp+Zvy5xGuYMMdTNxMc1BH1npbAbjR2HVBYg8bXl25d7/6//1///uOyykw5vuGN/uf/78txk0YqTdTkRllLLO05QhmwMgEQGkkaASUZEiYImYs8ZtGdFAtg1GAyZkSCNYCGpqYhgxxiwgqMHkaCWFAYaCUxh9fylKaJiGCpYYccoVZTtYBxC3aW7+tAhCAZbM01GIq/QMc2C1JqVt1kMcTqfFZMEMWSEZRAmLYaGy/MOMygyLzVHLoaiKAxZqZlG/yelPMzeUWuvDAVFXwlHwDY//ugxM+AIZWRQ/nMAAu6MCc/NZAAl9PPv5Ty+AIYn4/JKKpT1o/JrUGxSvTQ3NSGWald/drsO0daAa9LD1NR4SnBk1NhflrxTUdpM60L+8/8P0kP3KTOjzzxprWuYd1l/f+btUvMc+a/us8v//sEawJVqKh4N3NFMQQjkkdjkcVraGDjhcZ8ZYgXPO30ALBCYY0AuwNOe2hdEwBTTTR4EsiLMLgNZJpBKgjBzjKQRLLWs3noqwJqrTYfUXRxGksXo5NTNZaA2N/24FrVAYi1Bl7oPS9r6KRT3f5kbUIblD4sRfZvoFmYIlryVHKd6XUrYW3gK9H25RWHcIs/lp97UvxidG7j3z9NN3rr+9dr4xZfaJ0k/GZdLaj9wdGIbjEDQm92Mdu3odmo070zZitSmp3RpoxWo7MprWM5zCWSuli/4cqYz0rs0uu673Dn//41cFWMrP5yeabLeVRmIBIKCV3bKAFlyAFFDmsKh0CHsYTHL2MEXmup939dyBAIB1kGPBwd5WTx7a43tAhDA5so85ArStAdhLME0CeoYyxdrqsxNnpvN0M5s3t4Qpk5zZaB9spnHTcy+N73Od+w+n7OPqs8tul7GJm6egzfzT4ZW6uve+7iI5XPh6OiuaYES/QWEYCb5NuYRUYyAEEEKbSggMA1dnZmGrKn6pay1gqpmoM5mZfImvy6L0Us//uQxMwAHMFhPfmcAAovqCg/sLABmb1W1KuY2pVD1qzMymmKPRpkUTqo15YoktzmvfRe5sThpFTyR/lF3OIyoqqrx9vt0fdJ24KRdqmfOY77DAsMOFUG1YIwLoX7b/fPozNtO0HL3wZUrxSMjIw9SHMSCBmiBCPZmzLsYCkyGlNDaEShrD1URUhJFQdpxdAFDVO11hqfL6uQ3cIQuAwRROOENBWhYosWBrdg3FzqVHFD8Pg0TA5lExItS1PznbaD6vZrZa6YWIt1Rt6bh/siEa1nlJiYluG+LZ04Wp9Y6/j+vWpb4VekH478kjSL3bAkKOmg5GpVmpi6aHRmWXOGm12tbjJAAW2nVETEl1HW7GAENONOEOIBIkDjCxldwBMGAXgIS4aywUUZS5goJftkFlQwFoKQpMWY1IsNPMzd1qsDt+YoQYWh8Dg2srpY+nS8zNW4tBbGkeKgO6jy+FhpTXm1qwLyJtrOT7tpzo6MsUwToqMhdVnzvPNPfDcinYzZXOVhIhmGGUCFuy9daGnem3ah6ZrXbGdykwvbTgYG367M//twxNkAEP19QewYd2n5J+g+sIAFX4pJ2kgJ3qas/zKpTGYyEpsc5YelhJEQVV/+x0NMxDsqggkS6BBi/ZYR9HkcpdTXFtQKePcWGIPo+zECEE1w7j48oOh0tUJyJ1JaEvp1teTWpWdYbHnbd17YbutulbZbDuodLrbBtbadCV/3J2Ue0TsN4kjlSh116vxY1Wo/80xBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVQAA1bkAF+nAgICej+M2q7ASqJ8MBClqGsYCAjxGWBoiviJ4NFVhqWBl0OlQ6t3q6fLcNExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTP/7gMTngBjk/TH5rIABi5qlf56wAUFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMCACQAANn/6Tnh9nlP9H/oOf9KQgTDSUSjXAAAAAFsniE+7X0Jj1sw8KA12ZkgCAQQEgvSjmnJZRVdh6KzUdfmm9//2HpEVJHunUauP3ygBGIUa30skm832tLYyKUSolyhWEDwmBSyEk0llHubuNl7UFFh1+RGUdlq///vfMis/8goNdDh0xPvzUpG4z238EHOpMl1kDpKDEyBztJpUnqqMjG9R2+Zm///G+fcf/v9tt+x9+0h91dypqXE7XIM+/497DhH//67KmoG2G25XYCQAAAAAAGzRjQQRx2+o6d8Xbn6TPWvtGIWnmPvY4J9IjkhABAay/ZwAYH0ZPM3BK//sQxO+DxlxrESAIZ0AAAD/AAAAEAkcxc/SeM0VaIrSGvu/Vbr/LGjbmnrHLHbWg9G0AEgLCmXVR07VSKwuHSSsFZCWeeIZY+6MAXDsXeXu0D+xXThWPgeHAVKBQiFK57zd18uu5boj/+xDE1gPAAAGkAAAAIAAANIAAAASEJEVokXERrb3zP8IOOvWEX4spFAqLoT05urZIHdYFfYyQTHUjbpbDZ/+vFRUGnk0p5rcBSz2pIkSJFlRIhUiIn0y2TrEn2w+1Cfx3EjHQL40SDP/7EMTWA8AAAaQAAAAgAAA/woAABHebhpqJQm89EEq1KZ/IoGkF7LG9yPRTPCoIScWckFRKsiPZ+uhzcydIrTfs5BbbW5bGgB7ilFia7GBMfxLcM6YJfB08kSZ2WmcuJJ4pPw2OeeW+//sQxPuAAkQBGrgAAADilKPzBqAAkil5iakQ7pIdN5fa2HjHhBH/YYqjVorhV0VE/HP36vfHxQoIBr12uUIBQe6lvNWRMJJqOyNogDHCcSGgx47UpOvdmXeeV2djTC6xSc04qhohcMr/+yDE/4BGJF8S3CEAASeY4maQYAD4i03CcZrzaaSUNP1JRA32HBVSNjcMbwUNimoi1TKCjjte2ropKgSmPTN6sfoHNFbbsdu/74lh+SRIgBCFZv/gyqQ2ukqd5S9TnbapAihpQaILXe9RXF6lO5u6WdBkakqqv+49mapWy6YxTt25//tAxPiACcB5Ibi2AAFaG+P3kIAAjq9WrpU4yax77W7d2/8ht3//1/9albbDQbkjRABUA0JQGlr9GPZMXsEGY37ROxcd/WIp073B0fx7GG8ljlt6jUEiR1OUjuJQIVsYw4Nc5a59Bp507nNfnnsu6ldq6sq7ccKQACZTBlxB/1LXbPEKzyyypdTNd0qqw4bIySZgeSzE9MJSIZiUljyEX/2VwZGxx3KElhPchYiIHykIiGD7p8n/+1DE9oAMhLcfpLzYQVocY/TxmHj55Hzervf9W+3fE7XAHJJrZIkBKKXAVEWSr3/qOyR6G2iU82sXA8GgakVFCBNItfYO5wZabLMK+XsSyo/No076218i7152rtNaHqsjcYsVci96NIHc4gdNhRQQw8H9G4IWMBhxy2yRgAQAWHSB7ezdER3dtrtr2Jgs4OhmwxFFA5kTH2aPKzKNKd7wj2slBe9SQztotyn4mP5cP1LtXzPE//eqjRKTjaUiRAAPgDPkkcqqzFM+RaaEjE29//tAxPaACxjhGaakcUkzkKLokKThPB9QJkya9MIIRrEIbLc9COamA5wgm4ewh8OuMvlZaheWxUzF/kY7GCOZHOJ7h4sSWa5A1reYSub9Qq000W3OeGSBMnRw6bK0J/4NuUPCXGGIFixYlZWBYAwJWZBENBTyaEkUWc02crfWMfXXpt0UYiIsCnXgiIEjzB6rxp8c2gznEOUIhAXPb9M+sV6nGq7If95zqEtMao1m6UAhQzB6GCL/+0DE9AAJCJkZpgjJATqZ4uiAj4Fdq8RLksO6kxrD6pepVdS18KAnGP+rw/DMoNBUBPENCwlfErg6oKuEUtDi3FVSU6p+sO6n6nlVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVf/7QMT5AAqsxR2noMfBBx2jtHMOWFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tAxP2ASkzBF6SYcQFqFGKwkwrRVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xDE9wPIMHsTISRhQAAAP8AAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EMTWA8AAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQxNYDwAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=]],
              ["Bameware"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAEAAAHIYAAwMDAwMDGxsbGxsbLi4uLi4uRUVFRUVFVVVVVVVVVWRkZGRkZHJycnJycoWFhYWFhZ2dnZ2dnZ20tLS0tLTDw8PDw8PPz8/Pz8/f39/f39/f6urq6urq9vb29vb2////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQCQE0AAeAAAByGLq+SwgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7EGQAD/AAAGkAAAAIAAANIAAAAQAAAf4AAAAgAAA0gAAABAAAwlobBAB//JbOMbJTv6EIL///6NITT0I//o1jghgBnIT///nYODH/////uABBpONJEAvPV/yNUbMwN2cPuRGtRhBz//uwZCIA8WZExtABE8AAAA0gAAABEPHLE0CatwAAADSAAAAEIJ2Zh1N8ce9MgMTZ+/+RHbtCH0i93AR35r/H1FFIoCcBjwHDQDQCaAzQIghA4AILEqcfhsLu61qdX67FJMzMFhyIKAYiMmTQwf6qmTPr0H1qc63XU9nSQpqUjTOnGrPqat0jBb1uyS0GQ5vui3mXlFUAIFy7bTVIsfs3W6iQC6DYCnmHCRiQcYMAF4AABGFChkhcZsaGUCRa4xAgMoIjGAxMyG3/egtQYiImIhoQDy5MSDmZsXTQLvllyzZeNFctmWTLXtuyNFd/wSDmJi5i4yYuMmLgqtbO1VDAgYwYIZqCQkxEXMbGTFQsw4ELoLosVocsPvIq/aSGJZLNxunlkYfh2GGLsXYuxdipy65etkcQEIccWVm2DpipeYokg5XEgtH93ZdII3lb1vPP908bhyMWN25uVu2y9EwwYwDC1x6aksVM4YdiHIxGIYmH8rUWsLedb952aSgsfnvPv61UqXrmW+Z/v//+f/f53ufP53n5Yc3rf9/8f/HfP//x//+s+ZGbGWbmaEBgCQwACg2ZbveOGVu7KMattoy2THxFKQ14uTbOVTxCNgYQQjJEB1KPKzEjWUIwGUAGVVu8YEMAgwVQQ45RedGtnAEBpTrXDEhvTqGwQUch+KCCkE7KF8QxNsHSvUEaa8Rgiyr4bdB32btwaIxJn6bTN1KyYoxYxQQywALghYhAj/Qh8Er4HnJflMyx0lYKJ2BYmIAyWBjQICFoxuGl+FwYkPZGpfIIhRPuseLKSgSFRuKUMCgAgZgAhORElz/ushQg/ATqgEb/+6Bk7oAId3LF7TdgAAAADSCgAAEhuYk/+b0QAAAANIMAAAA2kleS5IL3wFBU+8cteaEP5OZ+sELAFg0gVM2/L5vFCO/yUWLzrtf73mPOb/+OvUydSKa7////99kr1MvYPB+Cv63VhhNABQAQCAAAAAALc5wEkDNFxlIaydSv4asqbYAaQcAk8uOASUXFp4UAGIABRoRAjO0yIoQilgSAaODAcCOAQOKLMtBMSFSrAAI8ogxYxKoaDmeBmHImCQq1mKBAIOlc2zWzHDfMiieZeYOGFplukwlLxiUTAAYBBAgCDQZZ0xYd+DFBWcygZDIbxLJHRp70IUJfNxCowukq8UAM2bFMjoFAE0NcTdGcvU8kQfty0OjImlxRPVeDuPPEJC3Jr69nZaEzhg7L4IgikSshhnLaus301Vh9rqxWlKBXMIdgGd58VlT/L7a9IYresf7vPu7bkMfysPPLf+q7Vx7oxFf/////83ppIGqv1vX////4TV+lftksMfRmJGQAAAAAZIGmqwY8FGFmiZJ19SdkvEKCbOSpiGBBxjKyMAwAijIsk9enOLgTSUkwQFzGZGNMMEyknDj4iMJN0z4ITFpOMZiYwAeAURjAx3MKnIxmDzQgACEuCSkZ8FZiIHGDwSnaYSAJIAgwtgkOvaXeMDgF/gwBCgFCBYECuWvWWUFgISAox4AmChT/+7Bk0wAIv2HQfmtAAAAADSDAAAAncXU93b4AAAAANIOAAAQCiEMAQMpxSAABMYBhgEHIkmGgOWAEKiEHA4kAYhAZf8GgoSEgWAjZG7tKDgKHAcwABVMhCCSEDLFUtdIcC4gAqE4vOgkMRglhiEx2IChpuiwpg8Aq/X+rptIBIgMDASNAIRgEYERcUqgRuUOvrA0XvRqikzQ8I7AcaXizpfabyE+WuywaD2+dt+5FhL7cHU85DUZnN4YbtUtvr6UXN1O/25V5+5jUsb//////+3X/ABAAAAAACzReCDhCmNq0JiOh0qjY4FSUpIm1EsFBQ49SIUBzmuP6IRzQDInQqgTNgaVDohAFQS10pZ8MEYNALPMgJ2dJqH0KEvrSdRupVpLqkBDmlgXItwSIHCGiyLsvEbRzF+LGOUlp0oTYV4pSVCHHmN1K6OY9S3KpXHcnn0CMRpjfKyKijmT8zNtXk9LiXYQ44nNuUrpdE+L0hKdevnsKfdtvVDTMHxZI7DRXMNH26+1tjXmdCtzhB6t36c7ACHPKfQGAgKTDjzDFx4WJBVAwEURjaHj9sCJt6QcG/ImcSkj1D2DAoJePA1VM7hTUFMQGAndfo214iBhjOQSKWdDS9k8IidJez7XT4Qtl65JoS8tq6nU5PEqGbO3m7I2rpTIWMQlJJTUePIhiGUcgVJtOSydLhlMO8N0BVNcNDNK420crkIc+QA3oySAshCSRAjw0MpGAEKquhv/hPcfDYiqN0vvvdjhTbV+v//VPFqaw1Op9av+TBgAAAAAAB5YUusDAzTwSNN2MC9ERx0iP8oWCpIQVXiud7yE00HBqBP/7kGTQBvYhWFNzLy3gAAANIAAAARYpOUPMvTcAAAA0gAAABBk/nxsEAVDyRhnB2ZdILoInOUiWy9eE5kuGMRphN1fa7Y/Nr6ilaJz72WpbYsqHU6sED02qitvcH2ga6k9SRTwPQaujyOT1SczATkitaeypTsqIUjsQlTInE58uldEYxzztISs56o9ik7KnscskULqLR1tanViMroc79CJ7LbbqnOHxwcf+gc/eQgQAtd5pqORNjIUImcBCHhcffgZI2YucHuYun8HFTPZAN5A3QfFTICGRKGkgk6qoJExIGJIXscdELpWazcIfWmH+gGLsYUlCNmWhKEQ4T83ySPiHQ3A6C+ubimWPJgODpD7oxaYlzV1mZnhx1JAiBhpdKNu9dWwcst7rhmJWdRgJRWreVfJEcDNq77/P4HmGHBBceMOEuqy7DwsV4iiUXpLcoIxzGq1Dnx/zB08Sf9ABmt+GBjAAAAAACuxDaRACHaQboQNhMOMFRVFBiyybC8U0n+QnIRlzRGUNSGICJYy8vkGSjRigUaWjWIoDKeBQGcbRgv/7kGTThvWPXdD7LD8gAAANIAAAARZddz/sPPkAAAA0gAAABEpLDMc75yU67kE8UUBKYyzkbnOZz6tXjmcFqd0rW45ozVVqmy9zq7Wkd43H8Fvcfa2Wa3xbK6jFuQk73QyHLxJXbPpzpJi34VLXGp2LVHOPC5h0JLQMMxQLW88/NbfideNz1Gf+IX/ds4ggAAACAda9/X0JgOmD4YABMrXZ+TCgoFSSgNBTs6botpXiaC+qrwv/KYcl2Wr0MQjJ4uyBhtgUH9LkxRBiyGabB1v1C9E55BnmmC/Vk2bXTbqKK71RltWHnk5w/h+surpJNFv9wKhTMXd7zyqny7yjR3ol2MnhcSBIKg7jhDKCQQ/Ub4nPfGjikp/wgervtDIiAAAABmtJ6GIMPGFuwDpEwamCg0GAQIZ7JoNA4QiIcKIKYs7YeMTMgBtTeKqlolVGewWyNgj+MwZm77JZthDKXEV4y5rMbe1z7Tww+3R4XPqwxGljtGmZK48nW3GdQK9DsU5cys5ErfGOQdDEbjDeO/Ukr0VYHzf6bgSpfks/SXqOV//7gGTfgPVEXdB7Lz1gAAANIAAAARH5d0nspPdAAAA0gAAABE9O7DJ3Qaw8c2o8/edM+jHFFGCMsjNNSzEbi+dC/8bpKmX/cwm4P7OYWJPUwh3OxlKY3WhjGlt5fhYud////r5fnN538OySrTxneqljvP/8uf///4c/9V+9+hCGqAaoYkYEggIiISnaz5gAvCgJMBQRAsKoRxBEGBCOTS5UWsZHdYOPkTDO4YPA4KgqcTZRohZoa4WrMdlVFHchEYIOJhhTojgoUCXPF3KXSEGOuh6hsZKJelChCc090JU0+JBw9qVu9VCgyHdONdQ8C2uTbPq19rTZ2HI2K8CFE91xtIIpwIiZVoKFdKJMudqo7sbCBzLLR+REYY/MLNEoAmGCApiTEK8L+KDSd3k3C98qn/tMPLtoAIfBwD5F2JZCzcHN9gAAs0TPJjFSxls/yeFNalMEM7gCQx7j8vS4DA3aRoWc/E++Vl/IUyF0//ugZOeABvNkT/VnAAAAAA0goAABJFmXUfnMgAAAADSDAAAAYo607JKO/hqUwXA0PQ5P2tXvt1KTmb6R9gbisT53PHGrflvJyLR1gUWcJwYrdz1EKtHV/6BAAgAAAAAwMFHRweMjBDADAZiwNB5hqmYKXmIJ45YixqRFkZaDTwYx9/2epmhrpujpdP0IwkuHwXanaBxDggRdErw4AWEKoIRWWuBr4GaCw6PZepLQIgFAjbEC6gwUDBE/SIwMBQBLBA3cMKB0gCSHFMkfyQMqtIsB0QzOJI0I6QDiDaUC4IhQVQMYwSoSgEoRAWYwSwJmqGEoXnQiAsD2D2xnGjzAOLOMGCmljSxZy0ABhY0ABGIoiRkmO/jE3ib8DFlnzCEUoct9y/zrtkfdfT4M8YND1p/XdgSIpBRRW96HShlnLlOumQLCSRG9znScTCmUPQBtSyywjL12tx54IF5qb1zGZkV6rXa/jhO90/z+b5/7fTX///8kquGnv/9FeYAAAAAYRhOYYjGcxxSZWgUDQFUHEIMmEAkBAvJDmGw7mFpTgoVU60ty35e9C9OlkYISPa88B0s5kHHE1iLbEyoiFDzvMNmkMiMkgUlC5oCDAIDkgBsApQhXwBICERo9oA+CKGhZoNWMYQM3DBRVoRzg7wxzTbIZ+XrCAhipiwNWEQ7PBAOJPjuZQkZA6dSK//uwZNmD+RVh0HdvIAAAAA0g4AABJmWHPdXcgAAAADSCgAAE6ZAJHFoRGM2g1+VDBIZrAWKRmesRoAQgmaXotRiRySI/IA1kK8ELBiluKXuLbDxxoMi3MgR+jZEOZqBI6k8I0gMuiKv9/E+YDHhVpKdOA7jgMRhh7VBgMqwhfShDTXYRkUbdodAeFLxOCRRtrkOSlW0uC0ycp4YkMgfOrHH2WflblVfedyLVb8zyH4216zAbjvFJ//fXLvd5//hADfvSA//8VYcqUdeGRINHY9Fmkh4M16waCmAiYybmmsTwmPHgKETGHI4BUHFQsDQAUzSBYFRRgT6ZKJAc2I0tAMHGAYoLioLGMWnc24cUleW1NcVHwd1QfQhpIHfdq5lLiZS3SENB4aNIQWBwMu0hCg8RjiogYYXDWCXUjs74YCYgrPIESTaWwl7rCW7bs7LWAAIvbAoNCSeg5lcqwtO1XkMsV41th7U0wHIpa8aXqmokRC0632cZmTc2uN2ZPFog01z4ZW6AQVOYYcehYNDT1Q8sV15XCptvJTOQ1YnZ2Zk0qrPy+zTFprHl9xgDaUk22zQH3a63R1n6jjBYexv2b/bkhfnkdn7UQ7zrfw06kvmWdsHXRH6Zv33yrSBc0dpYNlTswzWwa9Pu7O1Jv//////////////////8/qcv7/vO////////////0uFN3Lc1DNWkAAAAAAAAAAgChAxNsxsISVmpMmgTgwMYg8AUBhlZpgwFImYFgkwiOkqho8EpLrMnBjEc0eEKVNRGB2VNXWUyhUJXA2jRWsMMLkoayBrL71naf9Ohz3ngKAFRoTl8oaP/+7Bk1YAKWoXZ/m8gAgAADSDAAAAeoXVV3awAAAAANIOAAAQDaw0aGWmtjV+vtlTSWUOEyWXP8yqOMNpWw09LDGEoh1pqirBEcqZQZkSdTQWSR1I5Y0GwWpcTDo4szqzTRaXQ/DDb3JU158JPK4BenGGaWU51c6Wh7Q/eh2R2KaapbPyiNawvUtvHHO7fpeWt0lqM1d426Wer3/3jjds5YZ4U2q3dYfh+VxALIUFAqiPdNIlkW1u9BpXxAAABEAJAACmAApk5PiWBA5cUJFjgQWDSi6wUbAx6XbIajL2RKOzuEFPNQyeGHnvVpiPU7tTc8/9R56WmklBT7uVRhiTGROoUQdIgWmHO7qLkE7GMzko9uk2YNGGokiAESH+w7YaHb0sfzXj+6t8U1cyMV65aeNRips4pq25SB0f0o7KyxQSGvUpdR8eldrBpmOY8kbPdQ3ttUGoaeIyvuaCYmgkAUQC8lUMLGbllDKIUcZCEJhpKvrJQpRtoq9WkRBtHNgKBmvRi18niQ16Y9ZXxqV9/eVNX92YUxPr7E0HpxhGer2Kzi+dciOz1qjqWqFeYHXkfVnl0Lt/swMlzKc+OSsVdKzztlTFOddrbWa8t68K7zzeeGRU5xtLrpfH3lVSSKPNIwr5lblfv/8RNxiS47skcXd0AyLNo9kMzATEwSUAp2FCO4pk0KSaAYzOEYELTkYYFEQSFRxRdNaKye3faVM2YJkgVQoaRk7LBZkJpKkuEzNa1qKcPF9oqtdAJa1l2s0FkL1Uaxwyz5zmv4XsXrXGPEK0kVk4UIiKxR8auCa7kmh0lqne6AJ3/9ajesSViS6cLyf/7kGTcAPT9Ytl7JkZQAAANIAAAARONb2nsMNPgAAA0gAAABMaq/oa3ZG5nbnX+//44WhnUnXw5xo1ZA7xuR5EQxATAgGiCr3UMoYFELiJxoCmCbyilkh0QE6wgbapqrSytxzLF0oxE7MJFBMZxUGRK3ZxcdQs4Q/9jFoNqoSUgIYxVMHtrCOUehm8saQwuHTlquVcGWY1MZbMncW0UxDWQlCCLpM3nVaii1yIsbN5//QoO5Ej4uMt3bsC4S6oV2SddEYrf/+2X0m/Bmp8NMi1mxKHxMAAAAAAACzCFRCcYwOhhkEFlZ9kBCZM03KJRjmgneMGkMYPMc6M+KCBColUaCTtIQDKPv4Bgh2iEp5/UATl4GEvK85jKfoQqhZnKRTsseRQFvOVgUBpPmZqhLrLlAlOTDlCUrI/a7e2WK65UDvMBcMR8MNGI9jNFjBgkJHUuUk2QRdWI18OEVTK2sd1tt5/Ll996TwMAoqLL4dcxSh7KhhswTYJgqsRG7iAtOZv0UyCo7PVEJZYlIeqAAgC4KFzMRkfzEFlnGFIGbRGPDP/7cGT8gPS2W1l7CTT4AAANIAAAARKBa1/sJNPgAAA0gAAABGQcryLuFnRlANFjDGzMD0cHugKekjVJ5aIoPUgGJoEhUtgNOlpr2NebhEHZfpwp9pfOz1NdUFf6L0tJBsBVbrjoB3LaD8q5HPP/VRMvZROrtqVp8Sni6Tj4kFJWH7GISZcXJHzb6UomZcPjhKiOTYVjqxFv/9NJw9xzpM4nHIYqsXD0irB/qaFhe01Wf//0lzMYz/PNdW539srHhnDe4va+9Sr1FAEAQCJAAS3Z4XDdQGWV+SCQfLUHUz6CAiRhdlREHBDbYmUbr1GuErCIoImlmJdH9EJjEhRkgnXvQeIHzM6oPBtNJBIdR6ZYaLSw41Fm5M3a2L9qsnLQiiTqmVMBND0qGrUlrLFDSzDQNWPWlFNrCAX/+5Bk8Yb1x11Q808s8AAADSAAAAEW6Xc/7TE6iAAANIAAAAQY1GVVP/iZWjbWof9bToRCXI9mrZqbOqGc6Lvm9kUjy7zy2Qx1MLLX7G9u7X99nZAFGAkwAC/ph7lHiqYmcWZCoQSMawnsOGWImKnUrIs5e8dcC3hBjdzDgmBUS1ycMOUScuLJaFjljYN0CzH9qkMmtw9TKBl/yiR4vteWqBkHsPpaN49mVUjKJS1RfqswlbYi1nZP6Wfww/zR21v+HbYY69Iulpa5CRGMjxMM2n/JVmvsk78XzEG0+VufR79N+ZlQA1JCSADLHocVgQB0cxHUQ1AAYX2SKGKNcHQyCNp6Q/KjVpXsitUZ0nSuvZ+8cS9ubJ3CuPBr2BFYU7RnO8vK/PUCXvAz//Sib/lvT2Xi/nUSBQjAXNqg9KpPOmVT3JvT9I0/YSmNSZyiR6s4ao1//E01/Emc5pD9A0slev/mLz//ultumUClSewgBegFfBlDYSTAr6Ast4aa0gWIVZM6LloDHdB21jrHfvtpuDu7mWzrCP9evSLBo4YqUtH/+3Bk94D0+ljQew9bQgAADSAAAAESDVVH7CVxIAAANIAAAAQiAxJz24LQKUGa9TEqgtCcpj/IDg7/Ccf1gWFgBAODzZv+vF+ff/sK87F8lizpG7/sPqSc4jbvf//p9ZpRmhWUTi63cRmLVvg1FX+9yJVyN2VHngD4DNsPeBmYIBDBR0QEiA4YkFSKRuAwS8y1rLQcCyhMIRS4FQFhKaEZew7r3ZpJiOqkI2W9NeEqAyfZpa07MpcXTZcupi2tjo+nbfMzrpyEoLgVALB9f/S8f9fMqs/P/qKirbknDL/8oW1qMkPVXmUJFVI8jb6nJba0zclAb5TWtXZMrcwaOl5QMVgCKTEnCWGYkzoCgZMAkfFMVnkLPk0qSlQyzGMf41Wmz5asbZnvOdiRKtmSKTzjyxKyQMl6rsSz//twZOoA9C5OUXsPW/gAAA0gAAABEKEpRewpNqAAADSAAAAETVabJJgqb0XkdklClUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7YGTvAPPsSdB7LEP4AAANIAAAAQr4wx2MJM8IAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==]],
              ["BatHit"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAFAAAKjEAGRkZGSkpKSkpNjY2NjZFRUVFRVJSUlJSYWFhYWFxcXFxcX5+fn5+ioqKioqXl5eXl6SkpKSkrq6urq67u7u7u8jIyMjI0tLS0tLf39/f3+zs7Ozs9vb29vb9/f39/f//////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQGkU0AAeAAACoxSUoi2wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74EQAAAJgAFv9AAAINGALjKCAABv51X3Zl4AD87qvfzOAAFRGuFRFbkoAAAuD4feIy5cH4PwQOKBAxn5QEMHz+XD/pg+H8HAQcXB8EAQdKHOCAABAEPE4IBj/4Jh9QIODCwfD/4gDEHAQDGGInB+y+TVxM9JQPg+fUCbxBUD4Pg+fLv4IOwTD/g+D/EAIcHwfeiJz/+XBB38EP/y5////B8EDiojrTyyGjorI29Nelc5ZAswcJMnB6jfJIAY8GlL0DyTGQUMQ0AQiA6jLqknfFQO5XCQnhEXyTFCLsVgfp7cuFh6xWoQiSlNAnxOSWFoh7tFnX3aiYT6b46vO9iVarkQx/OnzKQo52eIrJFwdUsDKvlp9afT2P5SQWHDs+3FXKx46gOEfDGrK5coLHlyqn1HTwt6spp26e7ao4H19bxO4MasiS6p66VzqJAnjV2mjsrvKvpv/4wsdr3EdRq6g//wn7NHvWa8D402RW5X7nbN61//////////////LIzs/zHc6mqNLtDs5OZKzUgTCCi0UYghiFH6uq4I4eZggkmDTFQg4AyBAIEChC1KAxQ4Ehm8aA9MJFJawYNlzBlZ11Q7BzaiAYOA/7ySWD3Po670tmYhAceyduRwS5eU9dljut1W2u9kTRn7h+L7pLKpJDKWoNvJXlubhc1D2UvocudtxypYpb+pW0CX2pE7kByi9UvZ1bc5XzsyGZ+mzp7sn7Up+ZOlXwl7vzMPyjnP3f7Rw1PQ3R0O9Z3sI1IaClp7+WMmuUVvkvu9/XP5/0Or9Fbtaq9/HOYuxqe3y9vDKt8QuxKB8aeSb1///////////////////3bj4963f0KNLR5iWl0MlEEkiyoISaCAl1IsiMosytgqK0OsNWEcZpzqQHRCcwQywFBGkwktckZXArRpTvFSdd0lVKZV1VDHXodtJfn6URbySkxHsmzHuFyE7GLTndHS/0X3/3J/tX+1nf9+X795t1eEwJT34S4WUt/dm008RBiNQSkjoPFLUl4H/LNJDII15LykKAlVB/47QQ9GgicRw7EQWgwkvg2IpptWmEaqS6b5Sjt6qClleJmOR3z3rta3NVxXJyq3f91PW3HazcTf3SN0tXzxz3C//E/xr///3Pz8/X8bawkWK9/R2SIkDNrzWaqYZDSxhpNsdNBa0CsxkEyVK+LJqI3KZJ+Z0jM84feJAdHgTAYMMCwA3sIDhCjRskmMVJAKDzLOw+ZDFZ7uw6ErH45mJfaRXVVLI5khiQXKDBq5KVO6oZvb+JLzY3NThowI5Tuv8/h5mScXGyPCiVhGT3fn+a+fkqFrYDIYXc4udCrUdKNFvMqpBMs9kPFjhZAnk7AWi9JZNLRW50yUS7UwmoVpc5TkSmXQ+zP/7sETJgAOLJOF/YQACdGwsHuwgABC1e4HsJG/CQDNvuYMiWKKTEhCyTUUaquayiSWFM6NEH2oJXRhAsHgseAnU7G93BA62g53GfBJYseRspiEVFvLrdpP1Rqp493uIo2iw8eFHza+qVMnxFvccV1r0TSwnTC/d/U+b7eqkVkkGSJjy3Fe70FdpmcdyikerlrUgL8u7GWDrLDwTGHLihEoAFIkICLiNNZeg8vBO9mchfXN/nZeladWpOtCfEJGqgQolxtJJtMaR0THDwAaTdALUrozyhjc9UTSjDQ6iyVAVNCsASQwPjpGSgWYnRj29F70T8zCjVwcDrRhI0wmtU5OJ73w92/TguYmJTnu8z/3e23KzfEb+37/HzGasPQtGtA+yl4uqXIQrvk5VCQpoBE2QpusCxR7KctYOjlTHEpgIFaymzQVb2DPR+lZ5Gqs1iueCmdTJB+OITiByyr4qapLsfMuiJRZh1bJV3KRZMeICIsHhgsHonV1QlTOwxTP/xJjD+Rv/+R+Zd0UtfTMpDOiou1U/3Y4iGjhWHRIVGQ3kjWLiYYgPFQTEZAFA4qWCVOHWFDCYoYJJqNlBV5IUL0YbSs5i1HGq6VMLmKiTQxBCMmnnExf76SicXIVhTBbtqQkztMRA1sRHB+HLcQjhqM9Lbwy6Q3djjbx5rnMzqSiJBf6dzUBg4hDEzz9QAxrKiv9bzyJMJ8lV6RnM7+///nl3fnVLc8tDKzkk2wtJyXImMXvslwk2m12azlmmTEwykUSCTdbxNNkMqAUQxqqU5NRhIdkzdZC4UStzj8ubTUC2qTtm6LsmWaiRqEr0OZs4ijpo//ugZPKABNFjX3MpNKB5LDvvYSV8E02de8wk0yHZL689hIppkVMJrubdf71WJOl/FKxZp2HKjmyTBjA7mWDgMcC1KosyPm/UzIARMDBsn/3nFahTM612T1uYM6NT//5bhmvVWe7My1BbE3U5lFCjgMsocSQMi05iJZbZTFTdL9YZrUADqLyIy+clYNPvKt/armoQwidQ8h7fvqqhEMZJSGIc61sCD0IaqwdP1juvn2Q1hURC3Qsxj7mBR06bmVv/e+4sclPQ2++L5j56lV/5rR7HQ8/3c93MdLt77PVfPNCaGrso6/Cj+dYeby8uEBs5HG5xgAvAKOBohwSpUPmrqBI2rMXVEn/ZOalY2n67hGBPnxqwbxX7dEmer+Jf/mVVaQ2kKa8Dwqywdx4RJc6zH3BEAPskYfjvf2EATwF9CqKcXoWeolOmrU2/5e2DDfT21t3F3zHz1iq/stUk2bDz8Xd78x0tx8y1mVX40k0mE7LFuaZidB1AkZubUIBpNJGSkkBoqQAkwGFB2wEws+n4jYX3YksLL1BAPgNMTqBclAOibvKZ96/xvf8Djb6USi2DLippSxCnxDQDKjRU0WKo6RVaeJqF5I2KFn4mmT2vqjUnoZ/1xk1Tjj7ge5EaeSSxz2YNHDlN250qX5a/ncw0ZVXbFR8ccfrGljhKavNR3jJzQsbu1UICMpJJ//uwRNOABDJg4PsMQ1qNrHwvYehvUVmLe+wxDSJDMW99haJkTEOB6JbAegqcFDBAJUgYqxQ1gz9KjUsmWWwFQRyOXWrwdd5JOPsSLnXdKPV+4RLMdWbUk32rU5zwNLy4+g4XFxpAlOeOGWRggDyylaJOQRmGs19UNFZUd/rWM4SxRItZ0jr5WGex0pUr6r1cvy387sKh/0zMNi8ZpBXwaMcQwFjpLXHel415zQoqnZzHIEgTKTeEJBtkia5nlooFaxflO5GVHoOPY+6LU2AG6ajBqMaq7AbX7DCexdrFlrbhrVvffx29ouYt4tJ8+uffxcFJqVhmiyC16DGHRFPVqJLw8R4qIZeK7Zyrj2/OO1Z6+DRkC0yTI6RClaphg9ut/5qFT4v+angdND4vm6HcDmf82QyHhwpU83qUJg6uO/rGmqXv5QAtAQRzTI+XpZYJSHOTwAgAAAOUXwf4kg924hfzixgRrR3serTR/HZXHy06CcSomRNuU1gWNIBEgmdmpXb0G5YoHlHLFBOTG5aT9P/zQq6DwIDvMKUOy0d9uql+a/+hV8T//+PKt2symBYpHHb4PB5gkRsmZhnX6PhlQXfXChuiCm0mbCB8GCvw8qEzgQ1q1h3s1+I7lewmGtYuvp69kUUa1/rVb5g/NBVRZFbiBgSQokKorIJWOUYjsio6OhnLkqxbFbOW6qgiIxYUQClKKlcOOIoNFWKiCxWpiZSzB4tTP+9UUrVboiqXqQItQk/KUVkpKCrPd9l2gLZGoY+XY3Gc/E+V8OKATE2DGMcghBjVTBKUM84ajla+ObPHTQlyQQ7swL7TOGlFY20t/P//+6Bk4oAEoWdd+y9DeGgrm6885bkR9Yt57Dyt4aAx7vz1lfTrrgdcoanT8DQ6W+HdOoFQTKAVc6l7+df/sqO96Nr///7bf/p//zHqjYl3YWH/IzaLy3gQNyAoO8DhCBAozRi85axd4s0VUw9Q9OBdr+wXGluvllVyiIhXAuXChzTRowwaePJHHrCHMKhukJZmu3r8FlqUtfA01eUqpmYWaWbt1dY59ZVSxm7WRC1VhcFdxI6OZU/mf4dERi4iyHFe9A8Vv92y/KWZWGoLPh0naU2i6ynUD0ZbcvDilvgEJuSh6xJWjCh2dpGlVdIWIs/dKdlN+U7hLB4T3R9ppFCgeYPmv6G4/rSyULbtpbl2iIGsw25nb7N16iX8PpjGr2XMXoxmlFNVWOyBiilPUSRHpcqfxZvlKi6UlpfNbV/8v9oFVAJ+QCF0gaTEsYAAAAIE4ZmAvAcAv1gKCcaTMMVhgcWyFHddTlq3v63l3O3hD5xDkx8gpvP2rwl9Tv482ZqzSwnd4rDEi3iTe/0v47YLv/3Le8uTpwP7sWM/7xbDp6+gSR7zM2IGv/l5Mc8jxKjZyC4A1jTbkZD1p55Jnp+vwwe0SQ1iT0kqgaFAaBI8IkHRCCtDyyiABAABThiYOwNYwaBBBYyavcMPQmJAJiR2A2zoT4BRZhvVPKH3M7FWOEZKLUSbU87+LPX/+7BE24AD8mHbewgs6nbse59hYpsRUTNd7LxzojGx6/2Xlm22LtsCPSSG6h5gzU3itmb9qC7/P9xg95AiZzG6on18Svx4+riTKznKN3qxWMfeVmukplK4sKg4tiQkAjlKV7naj25eqm1LUrfb/19KOUxisLcSFg9pAW97AAAIAF5lhsZI6hcjRpf8dBhgERQJQpWEvCXFWHgEIAk7mDwFMv5BpVAArXIPOjYvzWM/uL+8lZ/5/VLGrkuvWr2s8al2TUvZuVXbFLN6MEALdhlNNqYP1j0CxTUWfMrvRdzVaZDNYtWsY7NeW9LkETx1A0gxUaR3aLy/BYwgERU5w6LDjF2Sil+xnUsRFVeIlR2iTascv//PaplL80YLAArTqoAAAAAH6rsoMhVPRVJBJwutoJNOB7cP0bwTdaOz0hP4CtT9TVq2/l6TS2C4MkePc5bJZqfsUNqZuUdihy38po6Sd3jWIlUVKwKzQT6JT4ll9GhRTPbwZLWD09imFdjnSt79qcBjEQSei7eh4aaTGCJRs0ZERP0O/Q70foVdJyxv/+ZYFAAAADg1KRzyZwMogYmQ7BgQFUoBYBCQNayDgmOhkRgMaBbkQckHEnWglNYwICThcpNHAkIBTJEilisDfBjVK4IVCbUW+rMNjTdG3uyyXOzAy/I4waGIBaVFJ2jmnHZNMp2A4RyyUpqvbG5aKUdBhHOPMpCMDlYkMcC+rpPKuFYxn8A5YF3zaqF0mILgurmKaRFM7ch6NJ0N45T8QBIk+zqZPktXZMS9Pi75VipPBqclDj+NiRc3PRf/rvwzy25W9qJFLCs//mDFm1ZEu4Ak8v/7sGT8gAURZNVrbC8ohsnan2GH4xkpU0LuPNzhhSBtPPMLjD1oBmRTQShoEHbFWuk6fRjGmc6XXd0d/5Rdb68mIsbzzLvb7wns7A+opX+pPjUWTfeyTeWGJjLJpo+SGlkVPrf/9RNyC5R1RCWxg9aWIepQV2Xr2CVDFm2ccGoAVAAAAAAAcGwcZ3aYYejCIGaUYOAFlTEhoRhKBFFEs9DyQRZJlcETUMy12AqCnMW4k1rolY+kahkOzYxCKGjnPexKNnk2nHyiN918OosOLTN+KBWQRhKS9j3jg7EIghZRBKMTRcEvHIEzKVpCdPkPNk4Wtnac4aoSlwPbQvL0BwlKTB8susp3aUzjgwP19rdWZZk6af/KkQ1w6jXVVjqCb/7zgMkj7cewC4kqkUWdJYMSCZiiUkHncLW61sbk/9tW/xK2UhuUlszSRZX3nfw/dxzI81D8GOBPKukuIElRhgyMFYI0IBywUDuBKzSD9S7//OXE7aIFBAFsUAAyrY5nYwBUegggADhLbCoQYFreBAFpY8TXUDQd9XjLZTmz0sDgDMjA4QbDZlcPPlTxiwpBB9/K9d9frzdFOYVpifwjMuwt0sxR9gWLu9EGrw5Jn/1nJKZ8YCXpH6WxPxeV8uyKBU8SR66NxYmgXYqR/xgXbkVWgZFX2i5BiCc1SGQ1CSyUkF9e9AfFU7i6emZglROuT8rJ7Ipv/vzTf7X869dEZu2yCB9/N9QKfvfi8gh2mZcxKapiI8oh65Lpd/4AU7e9k20mqkjpPkT+7WopEuqLJoUSLH+83kOVR/1REiDi6TDN5lbw0pTTMCHC1WiqSHDiP89k//ugZPmDBNVF0mtvZMhdSBtvYeJvFM1DRo1xkal3Iu09hJX8qHW6v0Yor/qOA3d4lhAGmSU/xAJOgbMs7a6XIGqekOyHYZQhJDxEC0LVyTERTSuSmmcE7/Hi2qte7f7QSKTtIket5UjzB5WoscRQ0oGpDm1eo6rDLTTvQjq26UqrBTX65PN317zZxMGj/iBo+4FymlxpAhESf27Hc/yTx+vlVzx8XbxI+pMXKO/8WAEiTQwAAAAAOC40bW1SO+8EdAQNWEtaps6y7Z2NRGu0TtmkZmYKLLe4ObDAo1yNqAQuDVswnMsy3lpg3bLt/hQNSLX9mwmWWhZ1TbU7cWtbtXSuV2IivyUB4XuVlicsQctz14nfqM6C+2VKhRypmX/rs9AAkvEKAAESEFOYekpEQkmJLfJgIQJBgUcBIdhCAWWrEy0UAy+G2zfT0jKzcRxIXRPiKkDezFDALrUgyFrXx6eB9jFdMSSp0raVyo/Tz7V6szcqp5lU9ujwNRTFJW2+njYau3f8+Dk+RbFJhA+UMc1IgSZnZ7Xnf//Pn6X6S3AnqK7aLmaWe4XRKq2ACTaLC4EAWtGNJS2rKdQai+rCpiFwIegoCcVE80A71ZtgxDvWbImQVplEK5KjBJEzbdk66CAoE2MqUuu2dtzGMJLA0LGyVNfVGLRr19fBJZF8a/R7VFIN9PcFU+JK//ugZO6ABA5QVftYQfhzJ7pfaeebEM01T+0k0qG0mao9hIp0mkRUgG3SOr+4reLVAGmFhAAQyQwdwJLKI4JKMVHhxhwYcKQtAwoEAEMm2gle4IAwPKnP+gmVHB24nNAPxXUcwRnweZKNki8ZlUEIRRPjJJ6Sskk0ZxIZ/ST9IkDkX3v/99EjbQwtmTWoZqJGsQQJq9XlIMqsAI7zOwfXUxjAc7Fr20GgvRWl9GqWLhuuujSpfQALixJgAEAAo8INN82XctR6B3C9khaSWfhaSaCoYakwdL8sYQbwFYM8j8zFFhMTEKinSPzfJyBmnpJ2297H0zh/BVnM/fNQATzxh+x+IEZwlpMtbO4szJlJHq74oZX3+q/iooPDCR5J//pDP3I3/vZXSUAZ2IhkAA2iy/zBgDLiiQnFFbjAPjlkjDhlbx4IICClTEFvKLM3fd/LU7Fm1MmPRJzq3jr7FDP2SB66CbKs1UTbFJxZSnbWp4KqXXbyMdkcq08vNtVc5HyOKCSqLoG1vdB1RWGqGIR1RSiHeNUKFEjqDAQIfg+csE3W1vQBGYEwF/fTPZuduiCzb73gFa2ug/IWAz9psBRiTv6LATPCCwLm1x2H9//zenf/uS11uQ9FF7bvju7dPu/V9BLotRZMph5RSiKvMV+cWRqNaiAwHqghK3o/+7kRuBG4962VKgFXhVUA//ugZO0ABCtU0/tJFOhyKIpPYSidEE1TUe0kU2FpHuw9gwpsAAgIP4BNTwDTOLx5ONBQsJEAQiHJmlAksABIDBLSi8C+2cNj7PyhpZqLIODyyN0skl9SJ866W5XeWksstO7XIWlpHvFKDNHPbOMtOzqpjCFn26JHvV2Czum5NqkVCpWdRW/djri9NeV1CsyB5nGVhVEcUi1IwRlShimcVgxvwf2ZTDD3U0sQ95MnTZaDrDDQ6IIEW2o9wVtWc+3JM31PXksbw1/btvd/94Zq2Rb+Pjn2am2dw7PtpD9YgRLYnuIP0m1nWIH6sy5CgtJN6X/p9uRglfowoBFDVdR4Jmmf+EFoCAi8v+puduCac/4gAGapiAAEkUjvzEhgEZBhYSBCQoLgF3qmh0QgFUjAhl0oRhApPxsaRVL2q3YRQkrsfx+13OJyxpNbOqyUlE8JOfy7AqWU1oOynMpHM1gQOqLlUfsRDJHya2IOzPFf6jv/3IL0jieokcsX7iQzm0gxF59aySg+P/9bmngL//0wYjWkgnmFA6BCh2qGtoBMZ8Q4HJHI/xFMLc6nu3ryULOiEZLEF+m6RhsKft7bdaPxRSqWZ7FR2rsYIwr3MK2m1kIIDpL7n+bpR/TQdEk0x1KGRaAoltbk//TDWkaHUCw7q7aDxrK/2jzB0XUzf/UvK3R4TFf//4w9AEaG//ugZPWABJNUUftJFdhfqOqPYSKbEWVNS+0YV6GqKao9hJZsVgABEEBewZcHHmeoigNJgYkBNlnCYIGCJ71Uw3ERVc2CW17zOHCc4ickd603STA5GCWFKBYyibU2ka16LoZM3JXMWfEU17eLMP0BBLye2/cr37zxFvu5+2/KhTF+s3+09TyLRiUCRV52jlqO2F/sfqCzafX3onP/EZ+xBWiwQ///WAM0rTmAmNJq8FtiHzdYMajeagKlFolGIabjxYW/dmTo6OK6xwT9OsCAQEBeRx7JUmjKjvyKHXH7eS95B3AiuS0s4pf//SB1vu67C3c/QcpS89ZiC///j0xNuy/4n6wZ/8RvAHiHaCATI0n+BUkDjDqrao5GeUgOFhAuAjSmYXiRyaVKXGetg1qnjzxgyV69fHuIUw2sIf3tsNpEdmUBAg8mnJ49C/pokhEo0hcwmUUtel/nl/mGF59/On/Zf1nZlO9klxmfHOwQOMu98y0amUEKPOWrfv7E61LlOnH/8nfvf/1U7wwBiut8Yklqt24KnHCMW9fcl5CJSKjJ8I3Fkilktg7lYh5ar367O08gGcKrI9Vghgg6BA1vIVqu2q3+ey3M2EeSt4PKxthL/296VPRem0Wb0dXiiJxWl0tqP/tnEEnEf5b//rVEnaiZQDkstv4ASA3ABkHmFQDxGSCvBihqCKDf//uQZPSABCVTUXspNLhiZ3pfPwaBEGFJS+yk0ymKHWo8zCS0EZPxfRppjhvGYUUBMIV/u3aQmVRRD8rZtb3bJCZqEEmtk6rvVUnHK/eNgqZKIzc7n6hkr8W8a3tNsVLsbCa2zyDoSRZUZVCtiz3BcUjvo0XvnWf0dXyaK/wRIAIUo2YmjBJLJt+CoRLAtipysIPBT5ItF6VBGlIS1mMAYC+uli8tWYkux8+ds1quNK/FLKrMe9jYsWSWUR3moWhWv/fLOU7b0tJcJIpXelZhXk9xyqP0p9SMkrSipTY6Kaqz4U2Zrq7jOLb6XFga+dYt6PfJjFf1GE5II1mPVCByWSvcFtSsBYJLkMwM4xBL8AQ5dZ1Ui065c0JqDkSjvOyhMJ5O7Ix7uEYwJYJNlGHNnYjGXpo0VJyjBhM4c3cowchCnC/jy00kTcsSaNZdoFkbV0XKDdVVELcu4yvGfe2plsjNQTur5gH4bRmUDCcRupioMEetkn4YSVkJEQMgFBWi2LShEGHLCP6c8ldGTStlPcM4ARClnfNYPpdJEZQyQMDB//ugRMyAA8JUVHnpFPp4qmp/YMW7ToU3TewgU6nKI+m9gwp1jTjASqhTzFvi61PTxvPfmxIlCGw7llXaMx9u2SDObn3m+HHoy5VeDVELl3GV7PvK1UWyMNw3c/hPw+GZQMp1IomXliAnW1FODHRAaBpDyRFBKwUWY2i4FsqmYdXZSy9747FObyjpDF+ct/WqTE54LNVdQUQCRGu/E0W/T0MEseqF3GIq9NWlOw0wskEjDgmoU8zdCDS3F0w9EmLEfDTtLLDf3h+h5z8GMewws4DjCgQrITEMFPGEHZ6p1FFK5ZwB58ifH5HKMKB2fbIh1U2UTa7dnHZ+p2G00Zf/oHPWq2Y0l622WKRqpPcLl7QLIm/n/1Hnf75BYhdORP/zibklbMZ36u1jMYnv0BgUeNa/VhvjB/X060fEKgB3iHYgFOtJThD0pES7flJcoEzQGJL0FDgAQLoUIlSii8ZptcYfvTxMVcfM0UdBgAILAKqHHXrFSJlFRU80eOqDLKOGuME7hmdlhSnkifqKHjk43myeoiOcZ540bGYapJK9CWyKhhzVarahVNglhb69IhzO+OSGRkghAUGOoTOTLsJu7WLAHa468xff5s1eIKLhnKVUhP0Cj3CznO+bjeEgffy8trU1tUkixJNiZlnFDrfetKp71DWlqOoUTKkUlwWkxUWlN1lLpeXWX1d1//ugZNOAA7pVUnsJHKhhyJpPYSWdD51VQ+wgU+FsmGk9l6UkJw7at4VT31f9ThF4p2YQMyIlTgIGEWIooRmoKXhtQYSCEyCAtHFVyv2wSOu/BudyZgAL6gDetTEh3clecn7j3DCEAQAKFQYYgIdRYx57K0UyQsg5LFS5Oxnq3/efOU8HmVBOchqLLSx1BrqUYf6lv5BoQji/y95Vg6X8Jbz1KfPDumWgdVPEOSv02xgCTFaIl5boGpl0ujrQDEkJnQ8JQvAhDCXh9BkUPln7qGXHU9Y0aG7AS0yu7RrEvpykCp/3+vnzsXJQxFE7b+HkV76K/KXRpSmP/69N/OD63Ebv6XCZmWdQV2uS3gyHAlglOlRlioPI+IxL4KogDMFSOww2Mr2Q9GaKxGCEDQO/MHQSGDwrQgp6FkCMeNc9fHFM40fGsjoS5VnpRrHJdykzrfdtNS6arcOTUmH6nA0Hk/BZVxdD7p3d7JN/ulfmOOxJN/V/JlzlRXl/pFGZsg03UUoM9tdMAdlKYM37M+jrt6SgsKEsdRlI8nJYtw4CTM3P0eiFIzn66uLssC6NR5a9d+QooYzNPynT0U2Gu/GBG0091pp4qSILtzacmsu0Tk3PK7vI/8WVRKmZh1AltXLuDLw5FM5ycq0yMBoUECRtHACpkfU8m5qmbZxYNpIXcctHmH+bTk3ZY3Ee//uQZO4AA8lV0HsDNehb5ppPYYZPD01XRey9CSFjmGk9l6R8vGCSsQnnmsManNOJEJy8ZYdoNhCj072hYSG4WB0jrdrKV0uHuZHFLw/63F5awGHmg/IHlugvAqQZzvQjqHYUFHZGWPa/6vF3SZKj9x+OkaIwrmbMANRmfgDfjEZPICQL0j3NSMsaN3stSwNl0U8P4Qg8r48RTo5SmGFxK9oOWV8yDHCjSlwR0sHTLeUl+MKuouJ3SpOx2SM7xQ/8waI7s10v/87A5Xh+78SwE5BioqGQFcsdl7P7AmZJuoIzK+aEDHuqXQHGtgT+cJwGTyh3sIl8FIdJF/nCFgVIVZiWjlQ1WTU4klkRKnqqvqC10pzZnLXuzkcLqZ8tKdumStKk0N9em86JfVR0fBFGmITcqwofhPBqpSu9BzQv9LaGzQqONJ7+dK6OMgsXx8mXfojqNMv9P7+kwKMt0UUrsN7AA4KeId5qVRtngCeWmTGkdMWMUZ25Xtg5nC3xHpFbFcxpWdcOZOCtNU/HJlGFnBJHAtVSUj032fnyq3NbW8/7//ugZNgABBNV0PsJRKhc53nPPMiYERFZQewlE6F+neg9h5lsqsShihsHoXjLtER4L/nIn+IhNEHwN/1qNOlpdzBIm204DtKwMaM42DIRqmRnSAgRByIoDF9E5QYCBAl619KhZYxDc5ali1nUtbjWuRpA+JQfOHTcoVR5h2EDicQeUlcm2okef1cRdTBiijq+8MtMsxwp5qSqb6/AYHHyJRg8zDwWYba99yRJB6R43mHoa7TA3/Um5k6SH8/pumVtjKzAlTKdAAmIpGtSBAe1btYbKcyWbk1NS2MVpFbp4S8K26LXFEvqaFsNLCs0zOLHRZUsmps4Vc9q9xL783sS9PlCvdVZXapnLlOFspNp1UET8kqtNvppPgkOS6pMwZXURcMC22SzcGycGEtngAIQYgDUGrOssZgoaNKomOzhirYmhUFDYj62cf/ITYAYjVCHbey74ksjROXDhAxx40rRdhtqfUpW7DYMpIqKGvu9qYddRr3S5VxqvJs46PFmJx10S6KYpE05wfJZTxK6Kb9zdOni4jYw38bJ7jiXgAmVjQ6EzqkuAB9zA42sUwNFJHSA3EARbULalj6L5KrdYpOeLP+iJkkY6xSeF9ZcHxLEdp8fW//ctCms+0D+taTba4m6lpXFyd70ySZlmL/5SPLaV6Chi9b91P5Kn1Y1FQB3lmViMuRSSgGuRYAp//ugZOcABA9ITvtMRJpfx1nfawkfT8lTQewlEql+HWf89JpsVQr8B1Fiq8MoggSD1ABRTqlLuf48JHJrOYMA187mB5gpqWo1rM+CzLYil0LS+yn6TG80kUQQKSyJRZ5fG3cd0kMz52zOs9Ra8mOlO5eHawZKbCMn5bLHYV0MPxSPTwpvyizMR5p36fzocMj/2I596A8Bqpl7UFmsj6ACvyqXNPunxTMmCkj1SZ1VLkZt8VUh3Y/imOWRm3MvEKEnB4wASchAQJC9WojH1bVIfoFXBpo6zp4Y7T0C1J7td8/8/4/LqEy6KJI8BTH/ep3szNoCXe124UIIaAitBKJnBIGaMQLTSakApBYU5D0Ou0xGKxcHASP/1H4iLiXIS9pFzzUeQo0OIkSKfr2HNmZYY0wIUICkxIdDBurDz/OqvqMpc1JfpG/1VwQqCv8iJtMKwVTMsmOcIlAfP/qD60KvhoCOuppRWX16gAEmUurWnlcJCshgn2zaINsnbUH0b5qlQYEFAfSGJEnAJ0yok2ARMKghQCA7MAnGdVJoKsP1XZqTNV4ODEGAoLAoBBQHCgJPhJI1bCFFUUAAEOfDhSZwpvMGtkoTZUvzlBIYmxosFQkg/uCOfJFYBoY0viV6bAHFpIF8aWUGgOdDwAGhZZqoTPHJLEqfejqs7L+c19n3fbRVbnLYkFW0QAGy//uQZPoAA/hUTnsPMrpYppnvPSaTDk1VP+wkb2FDmOe9h41NuQEMaAwde2N20DRAE0SJtlVWxmAoFl/H/YjmEiyagMU6ASNRBdlPcgkbU/cM9keijL5iU1LSpikKVgSC1CAX9ColymAUI4QhxY0iziITCESuUHcGvWCoKnT3++R/////y0jBKSSbgcoCyKTJKrVZV72Zm9RUgFQfHNFytezbcqq/qSHIqoKDfwb0KCpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//tgROsBEn8bRmnpMyBJBOjtYSY/RCgxEyCBKgCqjOKw8KCFqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=]],
              ["Bubble"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU3LjgzLjEwMP/7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAACQAAFGIANzc3Nzc3Nzc3NzdTU1NTU1NTU1NTU29vb29vb29vb29vkJCQkJCQkJCQkJCsrKysrKysrKysrMjIyMjIyMjIyMjI6enp6enp6enp6en6+vr6+vr6+vr6+v//////////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQEMk0AAeAAABRiKkt3pAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74GQAAALQANbtBAAKVYAKHaCAASKFlVe53JIKya+rtzEUQQiUlG2p5bLuARHDw8AABAABn+Hj/AAAzYeHh73f///wHf//mHh4/xH/xGP/9gBn////+AADv//8AAAARmHh4eHgAAAAAGHh4eHgAAAACMPD3+wAAH7Dw8PHoLUmlM2SAJJcD58oGCgIAgYg+8oGCjhOH8Th/rB8/lAQxACAIP5QEAQBAMA/wcBAEAQBAHwfB8HwICAIAh8oCAIAg4eD/8HwfB8HwcBDIA+H/DHE4PnwAAEEEAABAIAcVS8nLDEsUzAkCTDw7TUc4AICphYHIGBMxFAk5KbQzPQAyoVErOgwOApH8yiGkzRHlIkwGCdCQv1axPavo3YJQgoucy3THPA7J3DNbwi7poB3OEizALNBQbTYaFozEGL2AoNRxeiGjcAwABhAA9MARm+zGmMQUIXhlejhxaA3fBTBkCl0G7AqUFFM2m21kT/5obxZ3o5TzstfRmSARzJm1dksTaM+7LJytGPh+Q0Mvn7k5GZE7kksP5KpbD+Et+9OvXCncljzXpbKPhudz33rW5fK4Lk9h3M+143D+5ZV59NGZfPxvDDDW/x1+Xd73p53bsP3Yqv3GIphnMUlbGXztNfqV5ySTdupSZBAAAGKALBAIFJMuLilPzA065fLsbKg79M4lNPeChS38iq55iUxxFAyZQzIAvFjLBmdZ5SFbkAHGaEETKSTusZcckiQsI5xMy8mZG5BT5DCJDKh7wrw+SMOGhkXydMhzanOMgJvOFIuE+tYgYjBlC0SaaiuQ0pGhKEsX3096aSRokmbpoq0U1pKUt9Vk9pyszP0DNM6Zdq1eo3u2/8vE0bksQQ1K5mRzFwhiBFETdqMQBbkaIeIAXdQCBtOO9soECDQtlIJAIxg0IYQWFVRyAYCBuZD7Dm6yxvrIlAjiGqkgpAAh9cfxJo2oHo0io4GpgszTr1IrRRwsxSHfNNK2oqzFHLWqxbN8WpI7VShWmtavlrFTUteWlVqCm2Zmb1r//7ZtYaTZZmkVWijuVWG2dr9eG7iFj+JGCw9iTajFTfyYV+ATZEMso85d3SUgHFiUa6lUFqVXeptrcxnR7U3ytZ6/ytomrSlNLghQNXf2e77aHsCOzoX1WaDxXusSr2RK7AB/pqpHbH/ReCAsAAJUAjAAESGDABoLlZmMAdytBBwg8v9EyBWIpyyx4O9FaQlgNDRBGSAgKSLXq4IsIl3RYdXUlJ6HUMh+2VN1ayUsKqjUGiNmTyElQxLxelxTc8TAICVhfkaK1BCk4KMUdq1awkiKHuYkofxVnl/z/9fNV/pPg6oIVKwkhJPBL6AZDMOBAwExFZiXAAACn8ABpKSVj53KwicbypSlvaQiImvFv/7oGS9AARmYtp/aQAKPuT7T+gIARK9k1etpHGhnLLptJEavERGfZl1RpTZWUBb75f1Lm/+rF3bDHDPWOh93YlDzOrGRR0gyvZ7zMrve4kokzvkSaqqvWXLTvv5GUSzbaWzP7jJv4fq/dHK/cYz5TIZJuJoUACFVX1svklkYyoLVlzoDECQcgS3mY2kGFVT6BABwyHMSVfX0sM2Ii+z1WalA88m1S08cq2LdaJXGhU81Zs3XQyzMcq1fYlqJ2/km5lhTn3pqy2CdtvMWDEdUBJCBAwqQy6fERYRX/QobQzg2zg4f2mh3KHYbjIZmhfD0FZ9UHVO5FenkW0I6PRDQqSrwzgAIjo3kl0kx7DCQWH5cMdN/J9Socsz8/PmyiIHPcOtbyLTNb0z7uTYduPGsHk1tc0zbvw7wgWOu0GQk/7C6y5uXT5TzD/y8zCttvSxQhi3EPrA4PzVTCGNgZMU7GARMM/+11jwsYLoHFtJQxEPjigiUkAOPZ+mODrOe5L9rVgBe1LZfUDMB8qPYyrA7pgjjsyepR0LKNpdC1qq6aFhetykGHQFWEhjHIdKFUTj0WCPUI2SaVAbER1YOHc9hCKUOVeO5U7baWOYue9h26lCpsWh99OV89cuuwnpuvSBRz4qViamQFuCiyoQMAw6Nr7dG6tbNFKBAFzd+2NdT5NiYnAeBQNg+dCCZP/7oGTLgARxX1V7KR4qXEyKryAjb1F5kVXsMHEpeK6qfICOLTI/fRcLhJWR1M2XWxM3CiLFb4XHlKBcjDOdGUpCzq/8StJ63OvNz/r2Erl+XJmfsKygsTJwEXjG7fHDLvUqvJYAeLZt/9W3GljkQkOEVKYmEEDjzQifUOEJl1ZCI+29UvWs7TQmlyCHvIaaDTfkyJVZU00gIzKCyFkqNCcnRNu21J5BnGn2PjsTzEEE2giB7MIGDBIiJQNGDmGWUItKZnsfnNcPV6h2zOIpw+vC4RsdJSPpqqH0/ku3e7GzFvhcx5cMJMpb7apb0QWMdt9/W1b77X7jMgaI4KAW+rF/zh1CycJAyHF5z1K+pFNo1BBMKKPOCjPqnm4pT2wqQUCYgRMBUG7qAMk9ZfJH8W8Nn9cyn6PpWI7TqJ5iP8rCjLnn//Oft9ySMXLxEsFRgkDB0pjjgkiOBsxcD03EqAQ0w/utqSgmM54DRF4AAZWVBsSi/4loaU10IwtOIR1qOm/iV5a+cql8kChssgYA5FWVFh6hA1HHQ0gTEEqBJ8WsokOLRsiInJsCshB7IUhiepc8oyB9L3CcY7Ncj0Wj1z3pQ+8vJkfWpe5ymXKZZSLctStTObUl1Fx5NRCF1+P5iQ6CEwDFtdQBY6dNI5CQl7luZ6gMjREinrZ45az1Y3+ERepl1mgtbisedP/7sGTUAAREXFR7KRxacix6j2GDO1ENhU3sGHOp4yco/YMOdas8BkKIFOctlS2W51007vfHtqnahqA4dH0lFAvWeYW5IwuLJaqmxGremsBnCTjMWyi2dfh57pLtmxaGl5eFacMmBf3Nyl4koANvJWerPIFcAgwPkqqWA6p4j7aNEsTWjmNRBYxDAiumKaipfFkRasIl4sOjjwVUuwEwaIgFSgDA+XBlojNEYqUSIw9RKJC8K2aBW3ixEnGPtTE0KqV2T+5LRX3WoNJM3iZS5J04slqh6zkXnbUypKqlMijzJ50+WvnDLkXNyzJSTN/IyupsR7ww9DT8zSETzLJxeLRxNIAdNVP21iRln0ZsJSpdXt81BrC/S0RDEUxrh+iIK3VwtGYWhXpC0gcs57TSLW/RlZKsJqGpy1opTGUgzWxJBKIeiR1IbFBYKBCau5IFjxFTF04knIXiYgKZIhT1vWZSM7B+XN0znP/pGciHIvlUmOoM5Mh1MgdfMEXQbf+YO1bjkRRLE3kvjMMFUhGklc7pCC1ckDBxLqoURl3l8r1brJHPi9noyZEWgQWdBFklqJplJqJXEMlCVhcHiBfLHxZsFECpyFlEcKNo/tFmd6SZ5x9RC8c/VSQkEpodr1XRpicqkpCzSQe0M3MwzQrV6dXaJxT1Ot1LOm6G6qIoulkTRMwePyWNSh2cfYsYjmrwzshxlkkgMQpisSsMHXbahqvjKtS1Q628zKFoNOWSC6AThQ2CM1zMcagiZRM8HSBVvE0Q2/OXP2W3GQJnYbBEes8nvmr1qZCrqFy0KyjYjK5ONmubcS2/YyXemfPHHRNYqJK3//ugZP0ABENi0vsJG/p8zEpvPMOpUdmVPaylEMIJpKc9hJnh7jGy3fUX3ZVaulybXTuaERM69biOPw/Kwu0Xg+qZxgWWdVbcSKTOKRSUDmxmiKAEGGFUQsFa6nMisq9NZm0LZa3zS2dx9yHphuZo6p5Gwx5+7DlmSiJkskxRWHPUTbOUQxaB0G5Kb31Zw0amOW62oafZmxo1Km3DakWWZ0o5FKyxOzMFGktIgmMFKTLKuUDK0ZV2ddAREOSYhUichGasoINzBlCj5EuAQ7MsbZRBR2xqY+UMpTOCAaG1+Nl3jX4yxuiZYMKjIPkAlBJEIDJQJEXeNqELcJsQhBWmVF0yiCakiCLc6X60OuiC6CLe2aOfplUEhCYDq0xJ4gGQ34qIh7kvjMyOcBzMna/5tq0hoVbL8lCklfdxODW5+tjLlpZYYQqgISw4IuwkGeGOPiZo0dmQ+lFU14WIAVg2RdIeoJEEZJ4oSXrWc5a+KVyF0sOFABTgJE4YI01kpRQokhtxmkSOGJKz8isuYfGPmUzHuxvscJJS44RvZ2Qr/fkNV8tzZSqHVhw1fIMDUNpDL+srxFqFHYcY/zc36ayHS6TxiJg5OgUis457SiVQ4xsVCytqySpZUzTSJCGujzCd53EXOaUjWzPd2n9I5eix13J4snOlACirCKBCbVimYMAZFZMzAmOsyy5Z//ugZOSABEFjT/tGHMKHrInfbSNuUDGVOcwkb0IEMOd9hI3xG6jKMUp6Qk3gvVO9pJhNipmUDqjksNRN7BQzwuHStnkcIxj1pa0+gvPzI6jy0lSOZfkuR9Lj+eR7kRTKhCzrxRwfNe/AQxk6QWpaqVR4dHzsQQKCWwAgHORQEkvgDhICErkBS1nZU1cm6wVl1dBLBRKClVZBGcb5WEINhyJ46rFD3vOY8z4+q6kg4vCpUxtPOw3rVt9n1qiRhiCjRhZRvVSY/X/nmYFDokSCFaHnm61r9Vdv/X1qlrGyqqfM1v5nqrWqpMX8AmnSPVVCrSUi2YjrBgy1NSysjqf90kQDmplyV+Fli7woZcwVEX6eFgL1vLaljeutZl8VpZFVokPSVIm7VDsBeqmXObckqWls6kOD1pZFe+nCcqC8/1Ijg0zq8ZvMaMZtiSh2uzevdQpYn2PkVVux5lNvIMfNtuqx9Ly1Kea5OBBgqjMGZSR3tkVDPCqN7icRDxCKKQtMkkAeIQLEYCAH0P4dwXQQ4CEN83wkLuSU2zEqlQn4VcgH+YWBBMQ5BYf1C1fbWVsD3wFxe7KRJq5c5tLWx9bedx9AfMXF9nUpxMO+W3mxJ4YGrUukGuxPUVSqMXc1nJlWwxlUJyEyCg5YZN/raLUPChoF7ay1zpZf/L6WRUxEw7sZHLSwjZXXfppz//uwRM4ABFNlS/sMG+CADEl+YMOaUHkXJ+ewb8n4I6T5hg2ZKEqlVW2ZEvZoEWettWQhw2IZikM2FTp8uOTttaWpQASJWtRgaBmBjMYh1QOgMBUFUYCCBRnaCQYMOJOEpkwcTc6lYjq2TutIzOltOs+YZqrswzxjcuk5oGB4tUNOak385x+//mwVtiDltd0+PDyfBtX6t6WxxqpAgCCJserYXym2u2f5dhLlX92Y816Jm4hYTInoSzW/qoWamhTFJlE1ccuMVWUJLkvYpEJlqpKkJNUE1LULQpUTGZofGb9mZmNV/hnGP8p8aszf8FAqdPBoeGhEJSJ4C2cVO+GyukRHuCp0qCp7//1WV27WuRsJECCXF5Cc3HdVb4qlUOj9HpFxLjbEJXJ5DlUzbTkQCqjYLJaaRZea0wlKJrEkjhSlszGpRuMfV/VVVowYVVL9V4zNszTzb9VXIMoiebBUq6WDm+KHvDUkVg0t10YS7S3UHVAAgjA8Jf72+JXfPFRrv///+p/////8kBCQBKIj2IgaPcq7h3/4a5b9Ps/pX12qU//hR/Dss/poTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+3BE7oEDqz9Hawkb4GenaP08w5YC9AMVIAAAAIGAYdQAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAf4AAAAgAAA/wAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=]],
              ["Bubble2"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAACQAAE5EAOjo6Ojo6Ojo6OjpRUVFRUVFRUVFRUW5ubm5ubm5ubm5ui4uLi4uLi4uLi4uoqKioqKioqKioqMXFxcXFxcXFxcXF4uLi4uLi4uLi4uL6+vr6+vr6+vr6+v//////////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQEe00AAeAAABORuQQ5bwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74GQAAAJdBdTVDAAIN6AaHaCAASIdmVW5zRACFJ+q/zDwAAMCXAJLjvOIACEKIBiwfh8ufWD4flAQOCQEHYIHMo7hjy4P8QBj5cEAQBAoCYPg+D4fOcuH/5cHwfD/U79QIAgAwfD/4DB8HwfD4IFqEAjUEATeADhObYD4Ph+CZ+IAwD59QIcTg+CAIAgcrB8Hw+CAIAgGP+UcvB9//drB8H///g+HwAAAIBAiAgCAki41JNDFiMMZJduRnKCrGGB2bVMpuVTmYWcYEDhsDWnZAYZ7I5WHRQCA4zGOhaKCs67kxoEzZQ0RAtob3A7xlSoGXmEGGAAgYSTvS5b9MxBJMzZ0BH2QJVpeuo4SE1zFBxUGZEiGB1Qoc/a1AVEyprcXbIuVLwMDmQEBASqYwIAgjIoclczG5S5rZ2bT7PncdW2w+/Sc+GHjaRO587Zmn2iz32MJW79qX55Xqliq+0NwFJnLfyJTcXoOVs47HHplEYu2nYdycgB+P+kd6GYvHpTnbiepJOvPH5Rey3XkEGSCJzuP6wwxymMK+WHc7N5ss5vPKMvNOY4Y17ly1uzBnPmnGsyun7btgAEAIAEQHQCCgYBBzr+f6y+rDUb1LmnoSF9KwM/cs1GZInrK3+oWTIIE8k8on8VaHQYByPZK61fV9/KZb0ysWpTWu81l+b5YBYTIU96ZzmPJXGotI8tZ4Ldu///VWIU0S91y8d1uoZL3vr/01r///+JH181xBw8uD4fp+Je20MS7+zM+utX/wD7AsNttzwaCBIBCBUE0oQiS14OKiQQylswYWOp8Kml193rACwfgtD2YFgVAqHM3Hsyw10xQsHwiiEPi2uGrJJD1dGkpsYc8zYsdUWPpWYpuG6VVJprck5rta/1VVr1nr6laa1lVVVb///mGY7+ZlVVV5//mNIr/HwM5i55NliVzm2BoDAFNAAAAH8+PuGzt1cPBrRmY7nkS/e+PAMHTZb61qPMYcfmyqKlbeXcc6mOComrERwy8u46sbb/RW4806JVfb/9nyMwpgCw6K3s5LvECRk4QACMX3HL0Jw5ABAzBNNBgMLUCSFaUulZLtxBntmgWgGjKwTCTftpSfhappy7CsXPRDqdMusxRPPutDxAWkbcP+vWkdp0UiWuEokUZfM688t5k3Mk0jJKzZf/nkYJHFVFe57nQbiMUeRYaR+Zv73/9gpIdtHnJBTFiCaFbNePnMREu73vctTux5xVzvu3TLNPLpLeZQAEVyVlws9syRQDX5RZf6hsWXoVF6BFJUiWZi9fyKYjGkcs/fCRuGkVbCX4C0uK0rdSzuzF/WlHz//9zzvYSRl8OHPNYUfBsNtW7/9H/5z/syarJMBBXda1u3snJrgLBnQBo1RxYOAFLmSaEof/7kGTrAAQlYtnvaQAKQ4PqveecARP1l1vssNFhTZfqfYSZZASE7FA2zPvKWRU8udqjrNtNXasUXC2+d2agmkpjRYJW56I4y6nz3+eeA3ckG7ltKDJJ6l2IR9RVlKkDiLa2y75UuPMSHD7ZAihjsMuqmPkb8b86RlTKpkVTNtzLnHJFz4kHNleMAHRlCk7gVdcxDKgnHHKwAIQrKPVcZ6X0ypbvJz/gQlXUESdpYtdsR2SyLDtbf9cSGI0qlTepWUoZFhBf27U5ajlIDTuys6tUYACOA3Dbf/f/+v/q1Pt2MBqZZvrrpJgNoxsCLKCJXGAqQJhAX5EIxYIoYAFZ4tRNZgK0l6QumfEdkPCYOspTvRIDTTRLhCJCE5ibTGbPJTdcrQuSfJJplzmWJiSbJUdy0nuX3Q5qrbHJaazNzOefqrjaR7omB9NAoM1EFJFCk3LJqjOpG9rI6kvslUqLGVEr12YpEjmB5LFx4YME7DFo5UQcMo66uhe9fDQCt1j//7WwpCFs7KMoC9ROqlgiev7fPDgbY2PQa3a0yON+To5nof/7oGTLgARlZFZ7CR1KR+WqfzzFaRNBk1PsJRFhPJqqvPGZ9KgN/nqVEW71yq4XJNGk1zkt0m1+ct/jW9JZ7Ics//7P/y3/6n+rRbljAniXjf61txQMZmZxokyoLiXOVSTIi25gUONMgF2pW0puzLYhSQKh5QVkIkRF8M65VllIhQ7dNakdFfIjcFFp9L7FxA90MvfNzeoZsmJdYiUcsIUVIpgpLWZbk/DLYtQqBDHzKDlo5ORvfZjM2ufm4MqeIvw7lDuxqJQPoYrBMpjAphGdBkfauIAKSyeO1APELJpRdoeUMDeo7XJbfk3DVLagTun2xOCLcYQGicwG4qiV5lxMW9ztMU5jZTZKqpY3g0oaPDAwXGmMujMq77vXbbf/t/9v////5P//+9OyZA7cMNkyoC7zD7axpOAP6YYMEYTrDhkCodL2VocghD/DRnMizsqlmm8g2AG4mzhshZalZ7m5x3sFx5bG0iaGsUZSRx5zJXBmSJq4lmgZEpqKdiNAS2EtpJpC8xERCXXWht8UmCHFNyeUka/GVJxcg/VQgxl7hA7RCUMDzbm4rSgsnHwIN+i6ubKEDuhiiC/RSIBpLv/FWGSNJheOKQWuppcG16FAzRmIBCCJAibLKYuiXWYRoi7pLOWJnE60pe7fdvR/36z+PltuJKTQxTYWiOS18ZKUgjFuCYwFih827//7oGTfgARBYVR7CRxYXEyKTz0CmxFRjU3sJHFpYBapPZCk3J/7//+Q//8uiocQxod7ZUiSgw7/F9QMSEiSWxo4lxi1qcOmSIwrmoG6Q0kDMQOWNIXzapAI0es9QbVjBZRTVNVmsumxvvIEW3OVfYTLdTc9XTI4g7uiP2eTjIQdWJ1RFKfjSNnHfQ8mzDSR3PUXSOkxkt4Zzmf6ne6XjsbIFtNtGwcHaVBw6qaAC2dXtjbICA/1Ah2IEIu1EURHD2o/IAULbzTk6VTVmZZ23kmahM5VsfEwsCL0xBSeMdQkmKLdeKxSXTk66yGQkluJv/uLDcdpvF/FrzVQNM14FrrdThJKLFQQ6IpT8aQbOP5eTZySO59dCOkxkt4ZzmeCNTvdLx2NkC0E8/Xi6F5AzFB1TCgqqyJHWkCUepg6MYtZIyFyTAFXaI0WYLMD+WIpl5aUr4lx1oxA4qvtNm2M5xY6m6oK2hxhAmEKjAWlnoeMmvTmeqtl8sybPmsyptUkbCq7DSbW3HWtTzE8TF38XX1UZTNSf3MTELNxLtfrwifpzEVb826PUTVR81ai114tUUfL4/iIYTyLh1UEdkMr4VIrhw4SBwYLS1WKnyFw8vSbEhbbFAtbTX2itdcp8ZyxskOOwjKdFkXW3NUS5RlJOtG03LzvsFEz5GIXc36j+1pV3Do5nf3RBBmubv/7oETvAAP0WdH7CRvqhixaL2Ejj1DtkT3svQeJ/rEneaMOIXJywxz0cuEJmGZiT87FkWnKKQ/XiJ+T8hb9N0cpkULdDEizLwIaELr0fDSFHF2Ft0SGZFbcRAKOKJVVQRBAYgBiE2YAhaIlUIYXfdhAK8j7steaB4adhz2USuP3Kl+XSmRysWmIljChqgNE4JvSnIVJ+nlSKPD4HwENs0yGucxiMm7a52ql8+V8qPrfPr+t+G/wZb4jONt7ea/9b71oZ9asyNtuz/d2seGn+drr++32bQQZO7oZzz0mc2mGPWRLKtkOiLhax4fTZxgE6I/MELmpwK3sJFQJkPWAw5eZNNF3XAcGZSGe2DxAhEpASyD4rSTUkofQM5P3OC5MxIrRsouSzBOZ01eoguLWYK+fOg8yrh7QM8lM1CAyM8nYSv//6fq//XMVSm7OqRtJIhBfAIOgCMAQZNOYcUl4gLCx1jNRlqv3RdxTFkjRX+p4kTigE1SVXDygaiKsEyWjLDKFEpGYplQfUktqbuu0W6SaeKGXVdp7yc1FSYakZP2ftsdrb/+tKAq1HaW+Zc2f3Ykdedm/7azspfZZBt1qzt9jG7+c/fXn67/lFqHcxPAkrwSR6+6mP5hIsBBNdeqdXKv3I2wAlYmLMAqKwLglqVl4173GfxilYkjy52T7ulI8a3a9JNd7qKQDyf/7oGTcAAScZU77WDFwYeaKH20jfBKJiTnsJNEJlCcofYMK5MjVQsjMs2c0vnmA1ZuiTPSC+r8s64T3ci+RaLk7QXiK9DBpIjG82mQKRDN/////9H/+CH///0IqmWR2QkrRQUDdJ7AIyXTaKYINL7SLUpnG+aPQiKZhqsHE9gYPoS6mlgrESBLbB0LCMHwcDKGEEMaZZRTM8xykSS4qlzK1ya2SK1GarUtOtIShxHJquhUG2q3arZUFMUsN4y13/15bKb2JiJWKu5jiuZ5/jqff2ZmthGEFzafia5hyi07srNa7q4d2dFcbaRBAsXrXLMOWAkqEipgIMvUylpiqzh0uTsNZAAJgqcWNHUMppoRjzhDUNinFESqBbWpirZeMeKYhrFARZDSMLymstIUaEtUSfhrS2zbvW1UzUsNAzBljfDXf/XrbN4ULJShfZqvf//L9/NuHigtXf8vjs8DL2Bld4iIZQLkaEHyPpFl5wPAbtvoWaahSNKhLlNfrMjYFLpVRvL8zyrz9U8tuzcOx63ate7pGTsKW1G3j1EPP7zeNM0bOOr9eOXn0+L9f77CZptlyiRsplwdl5nNyJK1/lq11fSXVi+ry0I9nEmOCAgsVl31ll9cNrHxMVMOqmcjJajDjOX5ddu4clUQjEwyDYREmnPiIgsBoCi4MFuyWRCZaKIfxGxMmYJUU0P/7oETXgBQ4ZUrzDEMgfcxJj2Ejek79QSfMGFdB6rDlPYSNsbUSHplGlkKWrGYUSJC8jJ1upT/zM0BBjQMunmilo46HFRTsDE5FhSQgRn5ep1s3P5r9Jf+n3kPzJk8v7L+5yQ1IN3/+XwF85OqahmeJpn9vcKIljCQclitLSfz7meM1qW0r6rlhUspnaJVZw405MFAIYFQHHAx24RVOEceCRLJRNIyjB5GTV29alqqxVK2AJMZhSKmpBmS0qvOgJG4CW6kZgmFOzKMG1VQFcSDFHMNVWqti8L/VJmbMdqkeXhROkY56UTyBQe5A7LKVG0gAIWxxIsCqZ/DkDp7ZcIwVHSsULiMMql4179qss9INAMJmmGtWIyRQrqSkiE+Kq7nybD5We3/YkSPCSSWP6Z2bRKLOxIOUv/+d///8jQABJBJbYwQABGJfNlk/+0j/5bSqfNSI2a0qprHnTQgZFj8ooCgtkqmiJ//uErl4lKvJVBXt9tP/+1xYjIIrd+gANxCF5+euZbRkpqd2z5TZu0s91o1E4aELgoeZqlv5KkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqQAABBVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7kGTOgAPrWEr7BhxYU0Yo3TEmeAeAiR2kAGEAj43ipGCMOFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETgD/AhAMSoIAAKAAAP8AAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV]],
              ["Cod"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU3LjgzLjEwMP/7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAAwAABu0AnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2d7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs////////////////////////////////////////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQGkUEAAeAAAAbtyaACzwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70MQAAAnM90/0EoAj/DMwfzeEQGdneKmJn8AkAAeAAAIAx5AkA5zud+c5znO+c/nOf/n6nD7iABgcXP8mv//6nPIHw+d/0IQnQ6BwAAADjhGHyhzygJg+H854gBB3KBgSAhuPVRW5tJVtDok2VUWQEUWkwDgY4B2OGkjAQJGcugEBY0OmaDhEOg4DHAAICA43MFJQMQGBDBegRIS3IhP0wBKxnEIUNORjBBmKAB3LbtxZxEfGojBg5kFy98IR3fcGlxipSOO9DsOROuXebst6McfyTMkb+vNwxep93oxVkKm+Fi2XweF7pZLJunU0bypyl7DGUpvNvcsRSPy8UEjRLJPUxnc30ft9Hkp7+NnKevbqxjn597Y1zDkEyqHIW7FLbl92WU9PHI3aws2MMKGvD8o5YnJizZ1YsZ/37d6OTjl27fKens59x7/aSpEqsnuWb9rmofln/+lD4Yf/upSJxAomRERHVKY1dEi+OoVhIQmuoIAQqkS5FABs4wQJkrjiwE4K4wJwSArbEiymIOfIfKfW6IAQwjsZRLRizes6j0VBJFNDGCzDEMs3cKaziScamRfdJHGH3Xh1H5lTvwI7MDuij6pi/yRtNWi8hfWZsP9AMffqumDEn6Zjuze7nSU16vdjOMNzMxI0MYk0tFWtTUvZRL7NN3leW8yt95uzyq3ZdTkyluTlVo1GsqlNrC/yrWx7SxDcolcopr8HWZvT9NKdK3MtllkolVHXh6mrdvY42dWbk9rOlt1aDOW9xpbe9VLNRwZl/WU4Q1PTUWlspww+tisiLFb///+Wys7qyqQ7d40HUERpYW2TCakraZBoaspColhljJhONTSprS7gWo08FCwssMws1/+qioqKiosxQsLCx1rakioqKmqSLCwsLNeqt7MLCwsLLyoqKioqKs18MULCxJoqKiq1DKqqq+3/////DLX8qKiofOKhyHoqoiUDQd5YO+oGQCCowGjuIgZqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+5DE8AAfQZt/+awAghkl6f+wgACqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xDE1gPAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==]],
              ["CSGO"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAaQAAWZIAChEWHCIoLTI3PUNITlJeZGpveIWLlJyho6Slp6ipqqutrq+wsbK0tre4uru8vb7AwcLDxMXHyMnKy83P0NHS1NXW19ja29zd3uDh4uPk5ejp6uvt7u/w8fL09fb3+Pr7/P3+AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQGbU0AAeAAAFmS8PCVfQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7EGQAD/AAAGkAAAAIAAANIAAAAQAAAf4UAAAgAAA0goAABASgWGSQRwRAM9LWgoCAEBP+03czkMzJKy/wUB04jZR8MwFzXC4DqmJX2czU/+XolYVKmng//uQEAGwgJWHDwAQ//9x4//vQZCIAB5RmTn5zRQAAAA0gwAAAJFmZcfm9EAAAAD/DAAAAdbsugOAGoFKrt/bz7+csYGs8BF1pphlu3aNCPSC7hhzDil7oKkbVPiYcQFDJLRjRNBT////3UVel5AkXWhCY+Ak6fgcAMsGLkLc//////UhGJZGWJyrB/5+LxFp6Yb7NMeNBOmv///////y+Pz8fn7eeW4v4QPXgvRY8jwgMGhwcXLwMp//////////1UsdzsYRjH+ZWK/QgeGE1VGmPm/EN14AgSo7E5qUf/4Ie6pec1kxyNlFyBJtp12Rx7Y305NWjhAPmOjbuEIuQGZvHGFjUwRZDCIyIkO3sSaSMiEoSeYdhkIdkyaiUpioAlELCzZEjNNDXCAFEXOqVeqZLJDEkw7qZcyjE4aCjtwPDbVnTgJtJ+MGWMA44zlKhoEGuwqciDKYRh4VToByAECjDLpKhkuxtaKmYU3BY89HZNNv4jW3CW3AsADgjdWIR2WskrKkYZIYGbvnCIAaegLcpiQEFDQBsKhgGALvk7iODSU0ARP4Zjbmtesvtf7GVanAvTTWH4zZQnQv9rl+Z7hO4vxD8BUkTiERqSKahd+C5ZFoig4PA0JikJeW7UnGLF6WYbt6Z/E4YdB/KOOw79Pe/n4MGfuUQW1yrGnYpXWfyvR0HVc7Lh3YiAkpJN08ZALQFEGNXIaBFvhiJUGTVJrIqqkYA5zcm2ixGMgGB0Ap0QoUarotAFFKbCAMCQWJRWWGzg8k0aECOSnkTmFdYfuxYi3Nx8wgrwYnAwzlRa3swkqwhZjUrtlKMqqHp1xfu3/Hzm3CpZsGnORPIYbuxhLq4/fffGNSnl09P7uePnHK9o10sZg/SqIljlbDLTTNN51KpAAtwAHAEAAAAvgkZ84OA1N67Oh///0PoJlwT2GPAf/gNbLif////9KtJEvERANGAwNJE+RRv////URQul4mhmQBUgHPIsajNy7i3czAkFEgQFYGTksxCA4iFrEzQbMwFXchMCDy5jiNqP0BTsI44rskIDOHBJrboDxIiRhxGmifXFBS4ybrWIR1hWk8lbJtI6UOnpmxKWSQplUZAUhErEGMfgNNFyfr25SHTGFQdhv/7sGSmgATwYt5/YSAAR4hJfebMAVL5i33sJNGg3yDpPMDAvF37Sie9F5e9IvOub5/J5uO2Vm8yLjH/1pxe3tf6p833zU0td4PRDVqIzsvD+VGqKwEBahFhToFoQ4MRndXAUHRkGA2rXkFtfZ/63BsAHc39v//tqv/MgslGE1b/3V///19wKYmrfo+OiJeKdTMECkklBEY2ONhi3hjGZUIwJLjw0EJaJKhNxjzAplgtrKUSOBbjtSaUs7NomoErXIY4wrIlghWZ9WwkjpJlZCTkrzTTI1NDBm9dHECjUEZR6ZOZWfN7GqQYnL0/uQ6knJBdZJ+pOix/DLEp5dsOiwgmXcyisx3bailQmW3YisZNwRe/bf0QLUUMdbcpD2gWEKkLIPhDldlXRYeXU0RtIiiZAxZudOvMeTzf2VHYP4DBICH+f6Kz/Z61Tn/1f/hj/4YJSj3FS6oYiiUiEoInjfZA7osUAk4ZgUzQQgMFDowJ0t2n0TGELoyA0DwLDHQ4KIS5cng8qJ5IRamVOwU1M2ixLLP8E9PayA3o6WR5fpp1A6EQyoTRdgLy2J2bk6385T6tjZY7T85zYV6CqmDE7vKwuS4qupd8vyUesv+PCDllq81u1TeXj7np5lS8OeEoNQOeC0pZpoeDNEQlpBaZUBsTBUOLFuLZxUBvOH6HbQAwopEFKt4OEIMoFNT6qk7L7fc+Q///X9H/qurVRGhndEMmUiApHmNMIhRZoPgAI8WwM6ZK4kGFRV+NMXY0wBJbHobJQMic4TCQy5i8krBzIqfoEVTPTVyZwqdR1EsrWX14pXITKBIwq73Ihuh09i5vM9Y9//uQZPMABNxiXnsJRPArovufDCNPEi2Fd+ykzwjXB+68x4wApdDG5sFa3OybrYuv3YyK73p2lTKMl2+w2JJlHP9tZKKNjEmIlDvAbmPDx8Zi1wbjRT1XyZRYqRgjSI7NJNkMFska2DF9ACG93IXDkCNeZEDOyot2TrakPo7DIIeHM2n08DUOG0wfgmRPgZwjbF9rnmmJ/1uq1L/vJ/Qr0Jza0dmeDVEApIBJwUaCimUhM8yshagZAIHWBgRlQWDK7S5GvxtlkVh9052Lv+8T/+8YeYeDIPHUarYwJ1A0pKwfWLprKB5pnIYyiBAQo3sCgFzUG3ttq4lkCuJ4fpbmoz3/5delCsbg227BllWMVbnjRqK3NNggrQ3w7DZj3N6f5Hlcl/KOxmaelMQf+tre5SPflSSRJfDeXN5EQbg7LKOimiEJlPSEAAl0ZNuAaMBUNBY1hkCYpOvalucQHRcspkk75+/zz4rg3Jjr4cS6ARk1LfRRegzQsE1LBJqJgV4aeR/r//9P//VcFniYgkIAQCSXIKEllF3GXSkINWR9R7L6//ugZOoABIJdXXssM2JFBBvfICOjE11/c+wk08kvFu789AzwrCK+WW2JsrozzzMCJYFwREQNbWeeqreak0yYWk5BcSG7DJqjaeORcpgPbOqrqUY+798ye+N2PMSimq2pcbDxKOU/ZN5a/mSrvis2/7mm3OVZcv/mZOes0oDUlwFG7MJvfSbFyCoVmtc0zTVUpGZAkgkywoQ5DttTL6iADdDQMOGzlIBC9ProVwmKbTaGqpkfpEolXCQpx4vZFk0c4YEQ9R6uKPRtC44ZAy4kORjQWOoo5Xg0z6u46JLxFimeLGH1VRc7LqKrDTcPNQ/VLX1VW/vUJdQjys/VUvsljBDU9cxaX3iCZvaok24vGkRha6IBLMnLhVIgCikpmemcw+IHIBhlpJCEImDoKLCo1LTcxU0ylRFIvF5iLXZXA8n/t25HBijOegXx4Xd65b69FELY/onnKQq92N7u702+WySy7V/od/G40T/OyfayoydZP+bT19DIhAnng7ZydIVxlkxFULTe+ju6dRmUMWfQ5KKIBh2BjPOKXU2xIBlElFOt0IiIHXiUag0QCqk/UeU20qI1HGDAqJHCoSzQ9WwFqOhcfXYsZTJznENMrfhVR3es6CmUlQxw1S0cxOZK7uqo5EosDEwChg0bZxDHqt6D4hU4KPV3OmGbQIKLxaB6XKnkxrSunztJmyOH//ugRP8ABAdN2/sJM8KHKxufYehWUGWHb+wYVYn+Lu39hg2p9Y3/4SWLKXHIbcCu3XrHe3NBIgtJOUIKBxItImWUphia5yoIWXeIlATCWBLZCAFywUC87VHAtuxTR1PeBjsDZ6S07sYQRndeiTn7W3gs3AenerEBxxxaPzwlm1V6GfRR9DpwxGXI7GDs2w9K+RJ1WNu+EKdtaWonB/gwa2Xh/cparVqNUZMzDoccg+++6aoZcPEa2tfvbXHj37/e3bLiSdtt+KTqbuVgzX0tjkSIGXK7MQTRBDozSmqroGgqYpy5TFgIBBJpEju0z8JXKSKOt4z9gMSUZGa/ZSF2dHRSm0ncSVDCCOQiiWLXHFcQMyA4V/kN//8+b6t2/l/b/+j/9//GONpMt3XEoKEIIJSbhVjEpTMxOLc1UzZLHUy4hZhrqHMIAbrD7YayIcKFJmA4dF9AkQWTBxiGCAzudnBnaE8LcVTqSSCZ6lHwz4F3N/pizuyospFylEEKcy7KLQJQXaB+vZXS1It329WQW+7jl1lmucRdJzKSTOnWLNpvl6hdsy4vbxLdbW3OQT+a2Q2O+9A+seHZj3ktLrl+zoDAAAj+IAy5wYEYcyDQjANc0taDiGbH00T4k1CcIwdiN74ZFgchSh2DqdCOSpg0o9DDF1hK9+9K1oIpBg4F2GRg4l5O/9H//9H9//ugZOyABNthXHssNNJcy8vPYMVcEnlhc+ywzwk+Eq25lgzgf+LKjOrfhEEUEky5REsFNA7giAIqbfKVBTAXCjaCQKeZAiXE2FrSgZ/5zN3Jrko61BpMLgMOiUTmCt/wILUIBGGiVtCqqY6QuogpqD1l9Zqrdsk2ZbsLS8ETpmZPbD6ii55N01Z3fuctHH8KzNn5igxV5ld2r/DP67tkVkTL73y/bdcafleHucbGf/DW9DI0yII7AePl7QDIAAAHZ32VLDMuGiRuVbj1ItF/sGd+4MS6OK4TGVMfYJcW2PcacsglC32slv62fy31f/T962JBlgfc0ew5RWdGWqsIElMJPmV54oIkjZjYIRgaSLiDnCAYKGXPgKkQECxoo3cMANAVBwbHIPI3JOjXyE6scQzhxQXlsnSlk9WwtQmVaThi01Qt4rmK/RCAwfhYljwkPFoQODIea5oYlGVFRFsXnI+p0jnU620GZNazZ2+tcxWtebU7N/dH3XTFNUxHjSWGo+IBBosSNmXxMdKMr0bSlmGmXnfU6hIABAAr3ghAKyIgDIR0pFSvVryhSCM7LKWS4zSUrzuoxmsaL0ZLZVOUVrLn+7//XK0/s+/CWr4o6mz6qodCFANJW8EMGICcwikjAfBYhCerYm6XeGSE5m+gARDAfDEcDaIlgiWWR5Oa3dKzYKAVamOdyztJ//uQZPGABIZY3nsJNHJB4euPYGVWEyGLd+wxD4Dvha79jAwgHhMEubJFEkAmB0Hkqgooptp/LOKt61rIvZGKZ8QnXmk5nGarzvTs/Kq3yddgZPwkk5JKZIwy3OpDC+9LI52/wq+2f95jW17NZK8o61XR2xRb0nHJk0zZ7bsKYkQSSb8VBJUHwbEQpKLO/1MguQWvQfBHYQZWcK1rQr6KjgtiE8dHunorjVlDUcoP9Z0qZ2f/2f9X+/9uQlni6nGVUEgkFOY9MI1awSCuMBSqaQjJt8vqMparA00CDgYvXIY/DLtObSxSit09ok2CgRHC0AeiVL1klaGbm2pEgyFSXC4Zedi7lbzh6mDEmRWsZjzg5g1imKIUORjiQzkbebqRCxNz7RcnQQZs3sIi+OYbckUuiagqj1RcgyAeBOlEIQCgig4ZJwOlJqfKl0MSgSiq0nBNAcRi4MGvSQVQIMHQhJdsUHcQGN8wSNr2kIVXBm7nnpiv7xkMoRCitXEUnKR3c8FGWpuheJ7NZ2aDIZ2wkkM8g7oseY+ccj/6///7/qpL//ugZNwABIdb3fssMzJB4cuvYyIWEWmHbe0YcwliFe19hInw6rtxIhQBSclNQ0SagQaPN9A2JQwAw0TFEJkm3LquKlosZC+/LHoqQzNiTYlFzRI1zkhAIZq0yeR0mRQWZOr7b06lu4gzIryitVpGUiO5zh8TZVVhZWacmVbxn6+sWgQuE5ZIpFhwydAjV6Z0HRIyEHd3UT0lORCqPR8/YxEpfEor5hIDxAfMXAGghOiiO8HpHxnQwqBCJJPq9C1oCFVVM3AI1pcWCK8V+mvDruozOFB0R3ddUBQR98gz+ROWRtkC8hQEIrQFarIZH9IzdfQiDFwEhjTDQReoHBFJf/nP//neo56opCIhBTJblEJgLXI3xYoKOodBkpGMcBUqQ9Q5sKlKGIBo4B8BILWWlJx9lRaW1ejS0vUwN1MB0SzyA+bxceuO1O4lxboUSZaBl51Q5jRTujdP7exZM9PfEfMx/2ZZOITh5EFSauEUqzCL7q3c6mJSdPLxWas/Y7Gam55zPM7N7LKbb20k5h2nUz/G5LtMZboXv/JVSB1+XQERoAk4Z2DQy+QTot47AxAgsyNsnR8d8UD5khGq1v7JCJ+Vnnvq7j9uKUpmRLaQxTjKH32kxZflZzjLfeJidl+2kokXajsVpZev/6f//z/kKgi6nEZCIlpJNRnzYBEhMA4jDoPsNEQKQ2TA//uQZPOABINfW3spHHJSJPuPZMNzEtWLbeywzcFMmC39lCV4QQvQ2JNR41NadkERwAjjhIDZcfQEz0CroGmRCWUaViKUoG0KMlk7stGVUSqMzJVAvTcHumikhy12oSeQEwnx0EGuPXmcYOaqJGX7oNLQWicorxrlGIebFKJhwseRfIqltwLHfXf/d1cV3MWpVxWrWxDDoROuo0Lv+hsixf1iEoBCCWr0alQMPDtWTpit+zt25iXx8u9MYvjX6371EgOAhQr5l2fJN6Z957n3v4UrvwKJQ84HEAbzH14Kf/rZ//9XrWarJV1QYEWm3nVMBU8AwYGADluhUIWhUREYS2QgJJ5mzaMQTCd9lCooLdMmEojQl8abPE5GKJozUZybZp5h02JGUQluipHCtqWakz1USIRjCIWUUUjBZJRRHG0bdKQbwQ12g2x8yySp8jLIsZVq8uSbs8FjLW3G2zpUc1d2d8/O5ONaLeI+5jm7E4lHsE5IuN0VHeBYkxNyzWXrrqNUYSS0HexG4WvPkVuyAZesxSopKbWmbHYyIa++b9S+//ugZMuABKVh23sJQ/JGJft/ZKNaEzmJb+ylEYDuE249kI14X0FIAHcY5VakpTPyywxsEn/8n//d//8r6FzHiFdUJEJWOVjBfox1BwQwRjXiAwzJEOSBjEx0NSbN0Ty0LVIZZdLJTTPRMRaWHVEBO22UBELBI4oqy1SeDtb9peU2UgJs9jMrVfCeN0VJW6qpfI1AUiQNrJpqTE0KJDQg1VHpFn8ytrSvl5u4aUWxyXyXNiNw6iW08I92jzn+b83CtFtjnHvh2locpKY7OJW3n4a9SegRuJBVn1llVDEEAALML2AsYFVLQKrSOJPYmAwH32xRUTkZSpX6OhEoeVuiL6XjLOXdOsOd2dAxVJDJ/MvhD3fy3//r7P1NFM7EhmRIJLbw7goEBjtZIevCZjpIAhbSAMEvq+q7FAF2sGgtOCicRR6qA4sIUUJdGcKxDedWVLyqVdz5npzrUvKRGrWtHlJnd/SvpMs8pFSBMncaTDHOZNMeeaGpn+vZ36vUkkG5mXW46Kvk09h5Mnd9tc77p6xfbs1Re0uKz/42nZObjl6qsRBLJpejthNN5zpYyLLbWhmI1YzQABNhRgzCDwXJiJZcpezlkgekLIuYz9z0EF1LM7X0HAcnob93bYrabq4Md6+V6Io8Bjz4gRoKf87//7jv/O9PTUnHh0JTFIkhOUvuxoJ4BpGxwEyW//ugZOaABNRfW/spNOJB5LtvZSIpEr2Laewwz4EZlS29lAk0C3RJRchBMPCoFNUkmAP7EioIx2L1qs9EdmhwTi8pfNSs4fkhpYSsmKtXTRk7xBRmhT4eF0bbEjWNkluhkV+/CCM9s+392YnOvfct9okfvovTomJ0m5XBTpmla57nXrSXcY0Nlz4aj8nZT73Py7+u9oGf/Sod7u8WSxec8HVgHPrMEAAICAA/hJADmTamC4hxFwKfT8kTSXakMyxhNEGF09R7M41BpZ6//KcTQcSUl8lUc4DvgTTD8jFGsyFYxWEhOy3/l6//2Tbzdv/0tl3bqzEITSSswCAEI4fIcrQ8ODsY4BWQKCUOuahLVrYejysJA7IncZExKMkYubEGkxCZ02mmPKyNo4B5a8VJUDRqSSUUApQyaYHWdnT8wwxSCSAo2mjkkohbQiyBKo6pP/J26q/e6v1rn3M+nLmVpGBIuTuQK2xhAEKhi4emzz/Dnuu8ZkMrsrv/Hd7QL55/h3KBFRomjnKnJ1Y91J+8eDUiEFEA/QGmjQkTBqh8UoqWhUAZ8FKu9/0mM0WzpuWQz/2/Bi1DIIaomSwCdXex6g1OlQxe2AzpN23/2NYyYOdHa+jd/8kqS8xodDMSigUnALJk4IGlitE1iAxjGiKl0kMgSBCS0FGcBoCi48KzBc8V1w0s0jTGTzUR//uQZP0ABJFg2vsMM7JOBdsvZ0UWE52Lceyk0ckkk+49owjc2YtG441sXlxsjWRU0FV9JGtiUUSw33p3ZKy615VNcTBaJuVVe5hzdsM+GHHuaRlPXNcDfmIfqfOqfSeeWNsa9G5jezbYx9w5um7yhjvr5zqqolNRJy5SOyKS091eZAZiU/7wamIgAADVQ85RihSI0gYwKVGIWGB2TVZhlY2aMJPJoiHhgULP+l+f7Z0achxo0ZF+qMetsjBm1iz09H/0fcv9if/+jLu9inViRaISlLgBowWxNgOeZCCzExwoJEdUqg5CZSC3X0eVo4njMW1OiKOcKo0cqYUWLmuafSfDHnPlU/girBRfRjWzpg7R0rEf2ys5vWyHTxkzopRV4TxJ8cWijq2orTIc8hPFe9YYPXEVE79M26c/eYszcEWqvErGYn8sJig4ECOAl1DmFlooKIwVj7qmYyYALGXQMtTGkgQpnFHUcEE2SEqjM+vGf+WNsAmYu5jgc9v0V+yI2+7FpVUcWa4CzDKpL+DcnfmS8AN/tGlzhDJjljqWPWwq//ugZNgAJJde2vsMM1JFpRs/ZSM2EZFvbewwb8lAme09hIjsZIfxvZXVnKmoRVIQUgUnBBQSMQrMVVgAShG0uYAwqWLmBhWSs4fdoLcWaxp8n6i8PTz87EHUFmtzyjrM1Wp0DJpHSc0pFpmGSHckYmfvly/0KfZR6XRKRCtlrNwrCTzdVhshteeVeSizxV5vliRhIZ7L59i+CqQcGLXqkoXOgIZ7nrDelroBOJaAxIJ2k009RszbMUqoqCkwztW8BGYzga6nUyui9bsBa0JMupFBRgQs/DiGtu3R+Ezhr/vv8IpRMkgRLHOPVfvmQgkjEKCUM1CpmZcqQ/7mA9GQWjVzLvPVfqJJb8W/6nnHpDNCEIklp1S4fGLbYqskLvkSAAeoMlj6VbGHfV2x2LO0O8EMfxVrD2aKDQO4kkGnJNglrjcVj6kRD5qSJPwSl0HIm95XDja5YixKmydOWmVaJqea7TRtZl1S7rc7PPcVUapKm7Gwf+3qsK3u3dQ6eeI4vi6vdEsm5dqOc5tnUTiR+LhtcutuxyaLVK/WiIXuuxd0HM26RVhRAJCO0NagVZmsaVfBMth9ys/zr1rOH2xM4sA4cHCCtRzsUs3rzVOzE9USo7lsjMJaXbRCILCo8InMzSPaZBJn/r/q6tEj/bNI/WrJtGMmaSMiASFNpJGJJpy0wl2NDJzRAszE//uQZPAABF9aWnsGHPJWJns/YMdeErFzY/WFgAk7mS1+sFAEfJIUABztGBljaiS0DSYWEAcX2wUpmHlYc1mNB55nGzeAhVLyaJBDKV0jALXGAhgDPFhEsXbUBiyKktROVldEue3dOV/kul3sVXcy1dc07ELZwlcNBr0TRc6VLvjzqUkAMzTLfZXT6QYuanZVGmjPrDTawfFo1Eoy2KHI1qPWYNtPNFX5QxUAZRlKW+kb8PxnKH7yiMXdmJPL2PQG/kro5HH3Hc6PcnOw3KbTQ33bDFJqX08mjbvTsMUEj+MY53cqCgwcZ6rsMTzyxmKzFl1XHpKSlim5//i7uQBBL/Xaz0Ou/EghyFTF6BHLed33HuwLPP/J3YopiQ0XTpQIwvAnCAgKJkdNR2Nz5tbHWOIhwjM7dCLqrEjGuMHSajd6iKgCfjOm4gb4qAFhIMO5EmwOqUAy7UDAqUxujkbJPUoXGblSbO5RKpqTSY5pATpRGfrRWYDygSRFScJodgSIDlg2qHziiEwVCAjvIMmLOIOI9H6UxpkNE9C4hUgxEmZI//vgZMsACI1mVf5vIAC6i/r/zNAQY4GXW/m8AAKCrOz/NtBIigSsOSREmiRLTfyRTcxPrPUy2kXUkUjq7e7otrZ0kVK2+1ZsTjqb0TVbIGnugpdFlJqRvsaSW9vSSyIZihkYOIlgtOKSbG+YRiwGYMMkQYeWkmMhoqXGJBxhYWasxpqiEZIhYygcBICWBIZEm7jZC7SBz0Cok04y5qAMZAazA4bJSIaJgjI2SgVCjm5UOsyUt9aDZJK4LvqLs2TmFAvqow0JFpmrXm4Ow94XCQGdV3FYIcX6prMSaNLFaU0OcRCepp71vsuRiifaakB3YzPLBQHNVG9fyHZLRMkYLGo4ypiKCBPxnMPRyL4OzMMwikiiTLW/dd8mWJzt1dpw29c93H1bk1t0XSduHeV5DLpG/7qw5DExcnoHpIe5BjvR6jjL/QI3JkUGrylsBy2/m052oJeTXzT0wFKpVFInnxpNandmLdZXLo4/0js1517IajUuh292T2njAigSigFwO4AygrK6ZgeF1zI3srLTMXRJowM0MHCAEDGGSlu2pYYmLRBiVbZySJsbdSRIgSdZdUZMbEmULGw51JlrGg8CcXDSYE08gXFkoBwBWAmoVYZh4ByRvC+jWF1OCDhXME3GYwmJkaIrSJUhGiSCRIifkiG2bEkPYlDb1KzRnzYfTViml0Tb/rbU+p3d/1r63WtS3//QEu/OLu/qqGVCBgoouYE5TH2DVNgdYLCVaBCEBwoLiSUSrCY4K8at4hCqdLNgYKSMViM08gKqy6saUnyY7Zb/LPsxvnZ7CqSRqqeyxE+43dycYU5/56truzvpPT51fcPoHtggjjp9e2e+2V+Zt89v1zbZTm1J8tzqdjzNOn7Zt/7bXtSl62mq2zuT2z1Zu1DtJt/07Z6em+t86xcnxXcXiiRABqAAAEuYpgcgyDxKJBgBJgiVbX7scprdL/Ptj//P/6kSTKxbImv//01lSyxl1Lpa81tgrjJ2BLMligRFZOkLnyfz0SoBURHpaRMNEhBj6UITYoRrS83f////+hoy1Jns5jozx727gf32D436iFQyIoAgp59QlQwCgIWQjmuEXAHRhQHSDBZ9YZnTAFa3pjcKcOfqoAVEJUjUZERVZAKhMQ5JvohCYFKjvbU9htTfjCyOuKJkBISTTlN8ZzkUzC68zBhPpmIOLPiqscH56RDpbEJJ8EUeOoXC+Q3MdQfKIXwzJVyryr81XJZ9xW3CU96SeHofjxRA7D+zCBRIsZD5cURQuH6Dj31OwgJkAJxXAQwarIixsylqt9EH5d+Unq55ZfS/yeZqDb7HJguxsxwmBtQkUMwSpNTLQ0zppBIPk7SYjIzB9GLkmJ4xV0YmRtwpWfnrEd/66QLANQsY//V1//ugZP6AJM9d2X9pgAJuJ3q/7SQBE22JY+ylEYmKG+u9gaV8GEovtQHHbyfZeruWdUISmQE3U01Ql+JeI2GcogES5EkA4qKinku1h2vpyvesVvJZdiZECc2kJZa85MjxDFlvBLAa1o7ARPKo5KYlmOklm4iCqHJDvv2NRN1tnvZaXlWy2t5zbmr5crRd7nTSJTLYl5BdK+5FLs1E2r7Falb542Cmrda3PLa9Kif/6+lIvP5s4RRRxFVeaNLlrRRTlIzMAAAAAADxhIEDmVII5YGlWqs1JZDY7D8M55/38cY1///PZO6i33p1Kcc/uNeMeKbgcmIhNJCArI+1HEZAFidsLixcbBEhGhEZDK3OmfoMwIygBaeKFiXEHcUY2gE6GKVSsl9bKrmMs+y16WI37//5W19DAQEBGnppnUiAVlV8gnMpo9yQoAWuEAhhCEygIBEgDCGftDNYdHt/2BQe9a34eo5KHAGDCyYatExQrSWPLqpOFAjRDwyfbEj4LnhUOQKvU1lnPsBOhKS5YoVQRw5iOOuhuKru6VfwMth+WlNOo0yVgbUkl/5G2ifxHA1lO/Eoz6xPQLBcwBcHBKGCbPTRDZPvq/4uEhbpksy1V53W7syiSQIa2Bi+ANiEw1tl4BZbSS3eCA0ZaRRDp90jgUDuG1iASa6kkGtFiPfTFAs162GgKwC3O/us//ugZO6ABJJi2HsJNEB5i6qfZSKPEsV9XcylEUEMg+w9rCQQeIKmCqD1vSl966pkQiZCckvhJEZXhiuFMrJLXESA4IICkcPKBwqeAQZDIQIgHiDJUlHCLIo2mNWDBPStIFkyelQ2GKI2sjMLvmyoIDppiDKveqmJLq68Tg6ZSMIW1ijzxWnlIE3w0jmzzsa+8ZDbjK+vO47Z/ktnlPxd399FHot7dOl2usaevx7hteS6BH6Va21j+hJjvEla6TZ6rAKhAAAAJQqkvZK82CS8GA6ISAIRFO/PCRU5/23/l0UykN0746auMTBOUr4PtR5e8msp2qyxF0znZ9v/kqf/6o/rmadCEkFly9IxEkExVwB6GCSVhrUmWISl31HwoBpyTrAHufImgfPRQIDlTg8J7/9dBOltmFiI3Biv9SJBJRUkrnPHovSj2+UzXl66WbwNataWy844v81mK/Uyb9ftp1fr246vlpb2OV3o4v1y95rMtLTajT/t9fXcaJzcVspmUZah6D11Tk4dcy/1rK6K6v8yZgT1U5PTOTPV6jsPQd73QuRWvFqwAAE4YgARjJ0wwxD8YV3cYc7jsY0ud2WQd+0fe6c3bkHbHf+Il0UMuv4SsLRPiZOfwYIAVK15zW76P/u//qW3kjQkQDQAEQAAEJIlJtS0mWwZZGtihjBWceNmBBpICGNiohMT//uQZO8AJJFiWXsJM3BB5CrPYSYgFFWJZ/WGACEHkCu+sGAEMQcKF4yBv+YGEgocMJFDDxJp6CcKHstMIgJAMwgQDohEwxhhioBFyHFAolAQrpItQ1hqlyCCLL9S6L3pwtDZOsVrMVvNukep9RThjlgQMHLpgM/TNp4ck7FplZ8OxuQSmVF6Jc3J+4eZbL29fCpK4TL4++sBTrRMXdm3Ia78Sg2Cn0mqkIltJGMs68BXr8jh+Vu1SO46zcIZsV4hH9cdWD6sB1ZfOxeH43LHoazL5Y/surRuCLEG14jE5xut2fqy3TLcH2nN4ynDP4c3/+1h9ofnN3Kl+OxVyblF/xaNM7rWLlDjHYVCq1uGkxQqUBVgIgEoIkoe0YAA6r5cCaazD0Q0J7A67VbC8YpOvqZg4bIa64iBXoIlsqQkFQgAHB4h2UxZsjBFB1EHATFaY/rJ8b0qlBeZHdWhpbYozDDrN+3zYVDnFfBYzusvhhvHMv3u43Mq9JSZy2brWsMcZZdxzx78vw5d1l9URPc/p+d/5+8t8yssuIJASoAAACgm//vQZNEACHBlU35vIACH5dpvzWQAIr2VVfm9AEJfHeu/N6JAJG4t4ft7HbNRxg+s41g9MmOAQKAgFMrEEgzKBZMYdADAgcwoHNggzFxARg5KBEIZzxAJEYcVcKZjgWZQGAFKFB4StNOQAgxmDEkJocTjcVjyqakUVmioUFlwCBCgQFPgwg8auZSrar1NAxxQmMgUykmypuFhzJbB7dl9Sd+aeZUDQEPHSvxadiBblyX6jNqa96ozKXhfqmfSQvBSNwlUJhV934Dl9B1TFrjswBKqe7Ny+aVI6Mw+8ZhiJO46Eohy07ECW3ogSRRB2o480Zk16UW4l9alopfH4lSv5TuzBtZ1Iw7mVZ/pjLUarXaP/S+h+m3KYvDsprSOrdrf7cZFUxh9iMqqz8dtVcZiY3ixgBhPgCQJHsXnwAADSVRWw9QtEYOb6LrOAwYGCpmLcZeAGGDQJA2fuIDlwxVetQVYnqr6wEzh1WkuS9C7F8jooFUz5sHIlNLLoEl9i4gCBANaCOjxsjcMmDpwROWsFYa1mMwxNtbstDcibwpJYu6tlHsc3/jNLf1tYRpkUvQ0/t3Df/jrm9f3//vP////3n////9nJYn5yXcwAgIsl4CgIDmbQgtyCzxCMXpGjGIygcEkbDlssiV5UHlMZg5JgJdGRiSy8oNSeOkmoH3S9kQraBoqVorOJpqarjWXD4byPRxjWLnrUZbkkmMtdmdQOK5odXXYtL+vNye1Ot9paLJVbwoqqj8s0z7v2Vfyca3pms+anMa80KGLMcmcpjWRLb/lqa0qtWv1T3+gLBCq1YvS5kgAAFC8A5oNsEqd4HNDg2aqpAMW1TSmVfn/mFEyDIVXx3VyprUlkyn3zA2n5EAkbJsFD44+vibvft5u7hESkUf9X/2/d9cftXEOYCQAGCoVbTXYNRELKIlGGusEIQAYYIjGCJILPZ6kHCVcv/HWAxGw4TEx+Sh/iIB7Y8svVnCVfc+2yx9eSFzWnLK9eqeHtbVCMD1lg8dgftfVC+a39h+q9SifHxetZNCWV6ks+FK4mjxEcg7ZJJTjjaxO7YN2lezZD3ourKRq/s4WdNE4T2UH29j+yjf97MlmfzTvibV/3//7sGS+gAS/XNd/ZWAKSgWaz+wgARQViVvssNHhOxUrPYGZrP/Zt/vupu7qiVMAAAAF4BxkMRJaPRvCYzDVhC5szlRW5GIutIElgVXVKyhnBYcO9lM7PsZyw7xKebBOHMx7bWxlvb+pvvf3LKE68I8mA8Hz/9a/+1Wft2UzAAAAABMETqesKG5Epk5AYQMgorRCQ7PGsctykw77tI8NAR/diYdB7bkTXXDzmT7ssPfN11lp9u4CABalKWYV4mot4LAiK5c9Vw0DJCI2EwDK4LUERUXomxLG6l5nkVQZStxZbO0kG8Wax6imHrcKpVpH6fiTyZwJ1hgVARGKAjaO4OFViAVhdQ4Yb7K5McJTy9LW1lzXkSbpRl8Y1P5BecUpyV/7aWg5odlRqqzP6FbqSDlKVu8h0F4wk/20sAAAAAACUGID52jAVQMHUQCUVm07BUSC87CYa3OO6MuaTWljqxbfmXSVVKNsUCshtysLqU7OizuPBzRczFd4n2FLtp1IarHqdYVPR48U0x2J7SIrV8yt7jCvnvGuaDXedbiE6yciQf70/Q8hZY5SEx2fMupAAABRUxhmQPKmEAGYRBUEAQ4jBiotNlBMQAQYCQ/V41tSFkp2w5TLc10rUrHaTcV5bXw9Z0uKhKo5YiSV5fiTHcRpG8fsQUSZLY3xQTSMT0p0yyQGKCpYrcrgGsrhREj8y3QO56YRfOSU5gUKHJSRDEM+USyGMrWJY1RUUlebM9o3otur2P/uw77oHqstm+U2f/+j8nPze8cC38VeHSaIjf2WVjACAAA1zFwEFJvJK+NMpv0y0QWm0bIAgO8/NcAXTJ0J//ugZPyABfVfU/tpF6ByRfpfbG9GFIV1Ve08zcl1HGr9kKUshBlTLMqKw0zMV8xZVZUNrpMnps5cWMZZk/bxl9Q9mc1N0fX/68e+vNOH3////p/97jGg/Xlv9SrbFY793pdzAAFtucskJrF/A5JhiA/FrQQsSU1NDoIyOEhCofG4Sr84B4JAUKmCKVtI+KF8eLwho0kSJgExIoKOckahW8ibnNY6OXKJwUCovRu6EhSaNvImo2J3XIskXCQk9nCrRgdcgZsHo0nOlotHmFnXKNWh6zf5K1qNO8FnEv1gqitN//////9b0e8fqXzWK2pWzYBAAAANcygSvspUTTSpkEfkvcGeMQjzawLF+0kg20QWfaGnJqJIsKobQ+hOYrVGyrcefOWUBgmL6r1dO77v6fkr///rjdupaCEAACy70LAuAP2oKVAJal0DAgSwlekeFAqOyNSxWBHls0Xdt93LoPjYgNCBImIQoFAIDc9Tmj11RuzVtZ+EmSN/gtiVZM0RXJGjM2Kx75xpIl9eoYXChdCLbKbGMundnlsrcuPaC2MzkUoKn93/qSDfrSW42YInUKva3/vnb++gbH+3msST2GMX5nERAAINsQINoT7kGBZXdlFYoE10ty79QnPd2r5x3HlgBZyDJIObl0Urs3aCO85IwucX50q7d61P1nf7EPGTSOiVd//yan+9//ugZNYAJHpc2HsJM7pHxGq/ZCZXEYlxXewk0KkYjmp9hBkkh2UBAAElKdGphKq5xAgwNJ0oEGDBkESHeMOUDFQSKAiggV/xQROpeQsgniaGkM86TWirTclVUpVahycevWWO+kkw5sdtK+LWE6bLw7L152RbXTDnGqxoEveOD6sOuozyuPvzXmmzd1C3NljgZeOcrr0+WysG89ZtwI2vrclLbt6Y3X69vqmo2sX3P6w4G649t1//9cVvncv1R7Gk9+2xKyeXF6yT0wAABrzHUzIQAIBd/L7hZgCcJdGmiok1E9ZDZy/+a3zHh1MLGdaNIHcyZgzxv5AaHuLFAT+h/Jta3ylDP9N//3u/X/4EiYznlTFkEyMAUcZkSj1m9MWgwwMFTCQlMBA86cMAsITFBUMiEYhLBjUdtOMKmseCZKGhUJs4EAWMIApRAkAGOECyUBiSAmlcjePBAsQQMCggzIVIFkAiAKtDhyN65LzPsmvJIJpuEnWgyW1XUrGtRWBJx6lRK3l+EJJQEaUrYy9p7LGQt1fdrD1qxPdLmCKdN1b91ncZ9lL5XNQSy2hh6VN26wyMwCLDFM3wRLL2Ncn867/T2M7jQNpNRSu81x3dw8wyQSFx1hLb8rHcBbNNEJcwSjty+nf3k4waJzcWpHZoMYYkTU3QZPONs0yAGzMnd3D6tNKKsBWn3rVK//vAZPQABVRf1n1l4ApBgxq/rAwBI/2VSfnNAALmsmi/OSAA05n/w3DbsQY/7KojCWku/EYXLv+HFHHjgt6WTPY6EEtvTxCybnnOvGEAZgLBUKRIKVHEYIxGwkxEglYjBATecUORg0MmCi2Z0kCGwoE2HLGMWDQAiWMU6ZuGCQBEci5Li+C3wYQk4D2KpMkyJSJ4uDACvEcFtQ6Ac9jRIQREohshNDMl4c0m0SMWyBUJ4MSDkDHkPGaH2ZEwRQukXLhdMyHmQ5w5AewNs3UiYkTHCKgZGh0uGRfKs3dTlw0fZloI6/t/tqRTtXrtpa29u3/61f+hv9alOiTZmWi8QQn6arm2VUMhMxIRCRQKLbccsPHTSyxmbYZucnSpYKPzIENK0qkZkA2CRAQgz3mCiBgg4kcusAkBhlAqUjC0lE/UjzKcv2JELVrvaQYQhz0HzAgqGQtVAupWJQ1fiPi9VRKXsHeddktWNACKS2X1WGR2hoGxWOxFuWl2xpgStrxtxfao4EjiDHIkxqA1dP1HJC01szhK0w1FobhuQv7BLX5U+1iu+kRjUPR117sEVVirDQ82Wej2cclNRrtaApK0CSWoMjudPUjtO7U3IIDnajzvxJIDgPbuvrDVx+ItG4/Ke4SeIxKAZfaljtNfvx+GI9TTNTm/9/OSSJQJGIefunoJit3/jd6s7L85Sx2X2nJnNZr+nUgmFVKlKWSmQNIfaIwEqZUYHHs/NBkDPw4w45MAARERg4IW+oERChg4NUuPK+hsXhmhCFA8XRxClRbx3iAryeA50DSBAUihDiIk0XSaOHWL5upRNGyiBjVGgko3FrImxmXhgjfG4mRgskrkmWjzJIKjPE4mYk0bKHgnVmZgfTS26b/1/63////Wyrf6l/0VqLxue/d+qv/N6XRARKJJUEAJkCi/JmsG+UmiowyowzjKDAxBZpr6AUt7CWRIPApDkBwKgVB85Tz/+8Bk7IAIdGTR/m8AAJkKqn/NyAASEXtT/ZQAKYMXKX+0sASaKioAUPRFWVaSUFg+aCRzjVJNJJuDhgtodClUPkceOsoGxyrRR0KpKVCqxQs0TFsVEypo6Rw1rZ9RqP60tSs3HXesfUqv3KjLhL7NqVWmYr/9Ua7xqVFwM55pVNHSwpu6ynVFAggAekQGTTITkERAOMeUMOCSnQVdARBUNXFpp29l+zxMSHWQYkJKi++jVhcWJoU3lFzfn/lqyKKitNbpHrO3E/O2FYdtUur/2vZqkK1gEV/9n7aZHK3KLee+7kq9zeykRQSUq10GCEhWDypM8ZQwBlkEooiBmWuysBAtc3m+rAoGlzhBIQgZSauCLabl00UlkUpocSQxsKqIxLayGNs3i08TJXNRnGNZVCqXI1Uo30v9ucZyoIes1LoUaSVVQMaqsarDAfh6w7rKvVrVdZ5f/9IqusPDZ4NaqhXQzASmrv77yWMG0XEADCTggIfMoMx1AGUuQLGkBjMYdclSlAKHAxikBo4jrB56mEI+r4xyZYKqmBknwokdUzPf5km5pqP75OaajXr1WvkkfRVql2OtGiMnLPnmyLw8O8upDSNMsygDqL0pXF07eeBshLIG0judupAbgNezCUBpFJowkbRVIzytcFqncql0qyJWtuzUvn1CzVVze05Wt9ncInXmTpyXn9k/lXFb22UttDkcdVFWcFNveZyf/rdnts/V7it9X4L2Z03QIgMpMlCwLNbfDxDvKoJErQDACqUkpOjLFhOo3X8ehxCzANxbkmcrt0SMsI3mqoeashVzCfJAwKainNFW1ZtGLhM58y5c5J+5uf9iTnVulyH7m4r0btF1X5vlQKpoIBNwuFpEAFGR9Py1iY6KgSNMlEiiVeTUWrKronEiWm8SSS3K2TkjhxGTcc1HXIkWSLn/zmNZpFJ+ao4Gjx4S55xXUHRK4iCpYGgq7PSrniwlSP/7kGT7gAQQYc7zKRxSWCX5/2WGZA7ZSSnHsM5BSZjk+PeYOWtYi+n/pbAYcsjrCRIAJqJ/yX6qqAxpssKk2SwWE0mtVQwmhghZVFMLx6FMluN9ZF1YBMaqpfqRqq8OAQo+BfWATM2GAoTPCZ7HYigq8qdBoGg1iLDRYrd4sepMQU1FMy4xMDCqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7UEToD/LGK8ZoSTMQVMXI3Q0jegAAAf4AAAAgAAA/wAAABKpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAAB/gAAACAAAD/AAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=]],
              ["Fairy1"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAASgAAbUkABw0TExkfJCQqMDY2PUJHR01TWVleZGlpb3V1e4CGhouRl5eboaamq7C1tbm9wcHFyczM0NPT1tja2tze4ODh4+Xl5ujp6evs7e3u7+/w8fLy8/T19fb3+Pj5+vv7/P3+/v//AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQF3k0AAeAAAG1J4vKJJgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70GQAAAH8QNT9BEAIDiAIyaAAAJ/FlWH5jQJI+p4pfw6iAKmJu4dkJ7kAAIAAAAAAADGOMeRz/OchCMT9TnOf5CE/0I0hP/yEIQ53/I38nU75znO//yAAGBgYP//9NQIHAQAAAIIAA//lz//y5zlw/+Xt70S5g4hzsQCAAAAwOSaDGpBrOYCGIgWUrSbQhdBgqYThzjjMbcRsPIBsRfqnQnxMqGcCqFSvBweVmFFFYPACgEYtJpwyqcoLzTD2cxWjkcF3/38oZRufjb/FRNQ1HjpSSFCOwxFLsuNYDaSBuZbWAmJGIAs/OQlS7kGO5RGLDprvddrVV3YQhNMsADQXYjBz4u0IKgtOp5XF3/l9uxb1PLtMk6MSLZSw19soeedmRhVwd+lPMqa1ENf/7+Vy9/IcpcL1vu+vdTUE58foJV/3Z67TRSli7ToZfWm7KIxY5Xt8zp/lMMwE389Xq4yu7M6rb3hqha93Ch1AM/pkAALt5pGEhCaVAACoAASAD/mK1bBABRDKtMMmtmTH1V57fmdT+VJ5l/RtCcAWbq3Rvsf8ZnUM/3LfeQu/7vKqnK36SlAHQAAAJciyxJMVlBqUpiIml2Uj2vKBMjqucyplMJLDokqREIg8LHhtBIICyisnZaCBwuJpm5OirRRSmJDSCPol0bRMmheEiBvGBpEOkVH0YESIkIDAGJoAwADbMiUJkuu3WTh5SxkT7KRMCeMFCggbzAYlJgUFpEiMNUScOThkCEHAkSQtaD1lpIpfSLJX/zQzU5wmU2/0kjyPpGQtpi31P/MTEbHr9bJ50jr/5m/zUUry5HAB4AAAAcgQKNIJsbcdgn5DRWYJlxElzRc0c0sbVKb9zT1JMxiSIzjBhTl5GdKwJgTCXXf///Og6ADYDUbJqrZaRSElAZYI2Mr/rJh78UPeU//k7+q2WdQCQADJ4NxC9QNNHRA4QiVcELBJlRZCXcUShl9GZvu/kghivogvVJKxjZxJFh9Tucon39/mmyMe/Df9olQd7rB6EorNuq/YiAzxI4iAZ6CYKZC/Jo7ccUCM3wYnZvfUpLHyhvKudMs5+6me5JO1ZLDyHpg9umi30vppRLbcodODFgTc1hP/+7BkygEVo2ZUf2KgAFbnqm/gtAEXYbFL7Oz1gdEiaX2E0ozxfsXzmuax//HRoGv6Dwi4iqf/xMNCMzqFgez/4+L5+pw2Amd1O+OvLA5O6ndR9P/Gpa9v724UBfAEpZXWjdO5Y8UQrXfx8EOqwBIZmkGNzT7nYA3htuk1GFK04+Z/a9Q6k0ZlGUCe/MH8uGDKQWGoAMIBciDqNRjQBkQBwRIdB53///SLgpIL1hQMgkmpB0DMugCkQNebHsmEUF/ppt/qbURP89/+us6e/YiADcAAABGcGeI6ki1UhGkaQBFioVfoMJSqCqLN+0Z53Qnmd27ORYKNIxLDlwb/63M7O2DY5dbBGo3rD9wA5v/+cSU5zw7ALKjJV+TZ1K0LXiBTMHZMPYtwpfxytdwkk9a1SuTatUtPtvOU7uJbGcBhQbvJF7NMzeeuPXio2cUQpDy2AJTzlJlevePBDDv+RCbjYgf/yyzuUHgHzjv5CUY7VnEU/VvRC5WMHUVhj5q9ePuIYAtAAAAwYi4zm1JnOwuduF17oTEEi2CMhWCondxrYwsWPLE31Edd9gCRgGjuDAG/fZ5uplpGAYMACAk+7olIP1ANdgDDyYZkP//6EyCI4T4tAoNXUQwL4gGDDAc0//rS/8z5p+c5f/v/k97d76dwAAKFULfj4F3LaN4xMQQRBoIGnGMAQRIPo2LTlbL23ZpJ4j1uJWS6h8xz9fnyjqUEIpM6SRPbau5/qCKHv/r3u1/ajYwAgkdjmURmRAfEluX/Y/Xcavc3m1+p+BO44e//MIHbAYFkrZO2bVexLbu5SsAc0WzK1Zq2fu2ce/Kl/8dLVP/7sGTTggWQYFX7G1Vobgiab2B0ohVVmV3saPPhqh6rPPDRxHBQ3+o+zPZz2NAOmbv0ElWyCwKlmc8nq8oXQTjQSTDOPtoONmVne0qAXgAABWQq0FeUiWjoezC4GyzRoKKQmKkyWWRM3GqKn7tUfeiYGqP/otrMA9sBiGQp5BM4S4GKAA5WSM0Vr6i4+afT0B9gYs2PtRJmx10DRRFhfAaQuPkb5//TLr+Vr+IP/6L/lMhVrM/rRVAKwAAHlVxq4Qht2UnGQuYsqEEWDXWOgymFNGWJ0NCTDf6KXc5QRM9NxbnP9dI0mTKZE8gZmdZeG+3KBC3QLxDwEjy3z5AwElQoVQRIxNRodTScxJk8yzUlpu0ylMxHNAelC5JdWgaUjxeIYISgZIgQIZkt3/kqf//UXjy9aabsTtdtEmulBpNmm6hHZznKeZBTWRgR2WcydyFbDoUZZgTTv9fW1ZTQXBNAjnXzm/VIAegAA2oQ+iGK2D4fIUA4hIqNiDCmp2Ydaey3xriLxriZ+9kfU/7fbWmRUDkI1rSRMgjogyNP/929VSBsHGjfd3Ui2twRCLgHfxJ/+sj0fv37+o7VP5mw5IATAAATEoxc4tsbIQDCsjABDoBELaRUUAIRqDhUrVYAeV/nQt5XV8EQdJlLdsfnMUkXmHpUERdUmrYDUnMqLiNBfPKYk/UPohV3WP4GIAFcgZMkTHAOSCaMNXmBHmhWNkVmFSBgeapNMotrKZQYCxQtEFGbJAieTReGaMwMElIeo2/8QXdKXzTO/rERvjqebTPjW3kNCSDjAKEeY3CzLcMQkBdSuDIFnK9CF2fh5E4SZxqR//uwZN+ABXto1/sUTXhYhtrfMxNEHDWjX+xR+SGerCs8+gp8QVVakSR4KNaeuS8yv38RzcKKuRTtLOqzpPyC78qsXSpNNFIacaQRqPZ2B9ffcgMA5AAAboeYmVen0PPMb4m9tY3v63SBrdBpjWsNUNP6q0re/1HvM/MRWAMSlNk8rKAeqBYoRNRsv9Z/WQw962Mjo6AFzw6C+fW9GpREQCnDNS/zt/yaW/kW6V6sd22+/8b+x8iqn+/7ZpIpECC7k3Sa4Ccz8qDOBx9rCmchlIcEIltP227PFuv6p+DXt7tRJZl5bCWHbluISVx8E5wMCJxaMhrpPdmsbGpLIrnLnLUbys54XVM5Fu9u10BbBrou2tjS5o6et0Fp6CZOBPkWMmS+4SJBD/oFXsJ7CLcIomJpKoUai8mF5XRsgSRzorLsIakvnqNS2eb7XlnYXUifRoE5ZVSSWQidRRJAxskEKgjnPtxbd+9c6ENEWGrsUakoeZOweUaLCPwuDG+UGn2SbCnpJzwKem9rstf/NwDPRkv+SpV7F8GkG7Z5hlgLoW9/1t/686K+S230yOC4cuFZvo//2Vv2/L/1v79jmqAYAA2qqHTCwAdD5a0yRWfDwxgB1kJEUR0biDgWINOrS6n1mVSlq0AjeKcKZyovy1amYOKGLGUpB0EC2+fV09dSX0+7Mcn5bq5lKjQYrSCmrTuhg8irk3ZZO09PlnvdnAnTE9SRSUtBmOkyBVKpqnZ1LeYgNJWR/8Hu2m52vCBxTs8ts02vUYdnV+8VbV///5z99RIEDBhAwIFlpvn7IEyZ+p9IVWOyaW4yLNfMGiAAAABKnUb/+7Bk3YAFamjZ+w1PIFTm6w88MqIVwZlZzMDeSc8cKfmGUogNBCAsG0EOEXYBgZkC8H4ZS6rxu0sda8eq50AxddEXRdK+0n8mFfcz7IOGylZDOgkhxen03QIkP4BC0b+iRIoB8AOipTNk5ZfOFrl03+x9Y1wbBIzaSSe6qIhcAUIRAnDb4l/5PEPR/yfP3vhlclBILk2f0BuBbVSlQBZhXyEadCi7xMaawzFoziwDBzJn93hzOg0G8DVetH+dbMApfUzBXZqa/8F5q38KelrQoQXdP8bwpw9RvG1GjWt//4G3dN11669YQuCq0BgcVAcqsQOAKCF/6CL/o1lYpDsZlaxRpAOceIoKlMJkXq3o3DwsPsRVQSN8qOxjSsI5XfvelVQAKAADlWqC1hJWTIeLVEi2hxRD9yk0lGLLbuQ7LhQdF7WsSQROOkFqBhL6mSEQDMm6AvAQhQL5k2XSQpZKUjI2KBKga4lpVRPGw+weI0cmkDYydL6kkjR169RuGBXZ7LbmQmqX/oV/7SqgyKRvyqRIlhhsffp/hgICZUKqBhv+SXCsUP6BLz/zXZgMAAkvaCjgMoXHS4T7DwGeSFVpepgK6XQXJImCRmTP1L6v0Ej3HGg2uaomZwIAUU+zgvH/rNW583NtR0MAG6qnNhQ4bUaMYGyKvZMkaIjqNI1FBhJBN6PuFDBVX/yhN0bvKxFnRUU6vUziomjx0eggxDoyv6t7kKxnoRv+K76p2c9UNQAIAAuVAo8FG/kL25AEizkLDA4tDpns2yNhk0w+LTkMyepgIxDb6SCibPc+/lXtlQhMSLWHaMosK1atnBvGBuggOv/7sETygASMY9h7Dyxwictq72ZinlBpg13sQLUCVzHq/YoLIBTVjKjpA0Bw/aOaRcEA4GGy0pT/1JvUvv5MBMApFNBZ+7SCCNGM0m/uHFtJyUFzoCFsjIzHEiUEBhZBK0EDFTqX+tyAy6DqZ/1KVXoLzoaVju/JhoOACQVd4KH3iwjMJuBCsYAoYghSqfVDvPLCjxXtlcHtzpoewx0ozmsMjTIX93U8GsIuZoEyF9EUvYta6FHYsBvxEUU1JF0RMUe6b/pJGuYIurNWqctGB92t0Dg7zyDv/DBSlbhhJSHGFsYSMGYYjWFFQ050c0BQxf/oZI9joxWf+deoy0Xrn67LZmAAwASp6MjODIjYAlY8kgoosqVLZ+UG092Bwc2KJNkeG3lc1BRWH99Nj/7+7XE/mow9TxIONltLO18pFVKtiU9ZgB3LfJ5MJ+AkpFI3P/ywmYnqL1qNM6QAZMYKCSE0mrx1B6aCTN/4unyf87paZnSRYjrvPxK7t8fxJVyr///9n/Lzss7YRNb1l+F9C9PyyysgDRVfVW6ooGAACHcoadJBrkA4hB5H8ODg5dKvn9IQWcEoK4YXFpW68ov0X4Nnsh1CRW2aOwT0DArNxEgsJLjnuWC0YVokMNkM1KQEEk6cQSJo2DLoIrGkjyt/Wtk1FZ9MnzBlxN5FSrOq3ZJxChujU35wm///n5Rr7LtT5Px1pNSM1VTdFvaWtT/99//VZzZhyjNcoJicAmYeN9L/E1BogAAAAC4IBJggAkFEQQLhzCiwuHpEJDQYqIg801ReS6FxPdE3Qu2ZQ08fFzzCSiz3d+5P17JUDDQGe1MDxN5r//uwRP8ABFBjV3sRFWCX7Hr/ZmbJUyFvU+zM08Kwsem9qheR83r9vQ381jTUjdqvdbzf86SJ/41hQu7AgQsh2GrjPkK35ZLZsapkCW5iRUuu6iaAoDHSVdSajIyNUwwkQp9v9Di0T6MRTDjJpMKPU6HYxJTCkYGkKisxOZ/oMOdTM4izbi5YsfKUVNCnv9+7dnVgGC1JxVIUCCkN3ccBCUVJBPagPhQWKwlDNYdc7lw3B2MCd3MufwqEfib7zXBiCmTmQINL1kQ3Uo8oZjdLSNQIYspUTgbAHMjSRf+VnjJzxb2KSdRdDmDKSW6sxQRLwDvTLyan/Uan29TVNNVE81qX1SEHzLEbYtp8O/o/9CA7Qhr6k4jR2VCY0ux4uvrLtkYAEACF3KgJjpgmRZxASLAoNhcZ6AUWwYLDNiV+zOA2BwPK7TyX6iU40dkM+Dhou6TxFBbC2VxaQEET6RPF3SIV2ywVXqOk0AF5misxSI4GtBoDS6/+ZF5MmXUijSdCZBohw9/ZEhpt/5z0hPd0qSdQej33uaQ2/3+p36QR71Nb8Xv7VnfFmPV1mrKmH//12r/sn4ev97dl2NSiAC709QyTTgalNsiciknSgJkSacVml4obOq4bIYCgrHX6anogRVnrPP1VvMqURPGA+wwAXUvOFtd1l4/QQZEEASQapNQNKCpHr/6kdVPqqY4JES22uovC7C6ReUbf5vt97HaRqxWucTTugAMsFwMHRg7FPnfkT8mgIMMr9QraxuOJL1xPaIkm/e9cuoEtAEHutQ0GYcBQwWBkBUhd1BtbbbrGYI19WJ4ZW0GNSrv6Y3A3GZqE/z//+7BE8oAEhGVX+w0deJfMer9mRp4RrY1d7Ex3qk+tK/2JG5Xzz0VAQmPRmADQPCUXab9TbQsLe8H2h3uGHKhfDDn6szAIYCkf/y+gktqqLMYlEVsKre3TIwXAW1f9m2K79/mHU3avU6vIgwupQgxwLF9BLPWv/q0HbJ8jMhPwkpscLgO/A+M6Rd/byVWFUsgAO9Tc8IcIjILlwQMoW0BghQlWYwsqFGAMbLXsyRQnGDtBkFfRIha84MHjUZVDkZ7W/4aW/YuSRW3GL0li9lX1NwU4lVnhhC37sRXKyTLgZyJJAj7xoh0UZWva5Sy+MUsP3LFPcc2xkg/ztkzyJd41j7RjyrJljfRF+c7CQsTfHeVfyTQ4sdTHQiXP/4VGFfIyq9mNBpQxcknRCaS7Y0D0GeTsnhylOiGEetD12wU2c64JxFtj/rzCry2GUPwfZthoCRpZKyn6jxXBwiZnsgdm8loV9f/PxmLmKK797Lh6MRGABKxksPbQ+TCaqAg0ATKY2yx+1Ul3MZZdVxrvA12Cq203k874ig2v1iVjFKpuRQBRHhqsmiJuip0Ct6gbcXzUxMAyrf/fR/1JjltRrfzomhiz/5Dg/5FNciPQNCTSRKsSkjyv0bv92M0qWqCbk5akZmhcTPLWGJYoNW4RKKohQZKpXWaA5gLXXmizzU8zcJbqgj7WGg581Pv7VpUlyLUpwmQ5VylpdYaoeaxrRJYYmdKZba5oeDS2LP26WmJqMlpaljeNbtXlbcsHcm/B0+2+jKZmHKzwH0WNeuI1am37V+N6x/nun93/+qrZh2r/vNNUwzzXp5vzP///apdI1E3rBf/7sGT0gAcMZVb7WHzaa2jK/2YCnxVFfV3sPN5JzpvpeYo/GEeKDqOkodxNH/+YBWcMX5nYAhABAAlqpTIZkXIIEiKgYZDA0pZemEIJT8BVoYqzrqyf61UlAP3nyDiTVJn2pzmJBVJq5hAQmOT4z1bMx6fTGMHPSoRjAMKtJDMCDHBGAMJqacO///5Agt4LnEP698wG4I/FtN6X+8ye8tfUvnP//1J7n5dDUCBAASUd4aHDDkqXliSPRggEQFiCSoAl4lTK3HgOtI5TR55oFtNnxlBNi//7r2/UfeaUwPdW7Oy+khyDFAFsmCKiO0htILGRxI980iJAqdd51jLogXVDGJAOpjxKfUokkolmd/6sbt0ijZ7oezwlYyPKOFWdHDASyjQtJo+MnILHCSILAyovhRIb/bxjagCGBGBZQDESRUnkSWjSJJIOm+KiiCX6VLo0jDRImbSYT0o2QHkbZxlH//Gt4wGDYgz+v66orW/I1AwTAwdBNsg7/78iYI5WHKpi9J3jC1jtITwIhPhcFCpkz/A0hVsoUDlDJ3NdSWYVuV0Y+kgmGH9tn3Clcok1gclLWpsroDMOTzgmD9FQNwFUX3qS///rRBOh6umzsgZoyaDiKKYn9v//Rf/h+Mv3QgEAAAAAICcqhrgqeCkhsqhlSwxZFFGkC4BftPRj8GwuDKatL70TFERZyiC6xEJM/zcqltsRFkxTKo20RBHFnFpGHMtR2BtlVQQCQEBkC0QBVTURVKCLImrmANn4YkiQWHrAv07rHyrXCBoKS4vtDjlM6kWENU76vy0mMJlMmeFcrXaz/RWQS6Jr9dZnHasDZxmG//vAZOYABpJmVHsvT5BkRusPZe2iHDWbQ8zpN0HZm2s9lr8YnCoIi7hgCdef7cprUqv2Zl3aCwaEIEniJhpUUqFiNmRCvjRbVSWmfq0+qyiXxEmZWRPdHJaq6SK5/zj4Wsi3P//nsKq/ULORpFaFDl/39TMoFIAE3GQgAkMSALBBc05EQIKKMp6q/lhYIfyzHlZXQhxvM5qvcglUWyUyJy3nfqz82X1gvd3SHOtXlFrUSiOoiDLQJU/HwMzJ7j8AXCgif/9Avuz9BBeYBWnkoktN23ma4R2OBT3V8E83LqQWeMJE/9bqr5u4NEAAAAApgqEmacYl9WVCJaMavnlKCWVFG7uRt1WmRxta1NjNLZFmRklIuDPDn7r5NIfOnsR9Qaes3O/fGApAS7P9Idast1ayzQ2aM4dS1+IYgQIWopeknMNI0Wb2QM1H1IrMAcZogjSWip2UAYRol/0DNvC/859KXW3BcQUx6EM1+/Kf+pbpkECx9cQcQ54YVSbPInxMb/dLqgAQAAXKh+LVLQg0LZwwYBKmKgDDgV0P1gFKVaVVmvxOXvL2rQo2S/SHed53909rNrdNrsGV6/eWPphgbkxLvLzXWKOO3uGTdEzFdT9a37shf0FMgRaLn+cFlHkHN2HuoRYaaLMOKhgiHxUCv/3Dwda7foODgYwksrGQwQfEXR3QYVvyvzXuUNJc8mubceZCq0b292u7gCIAKe5AkZAgUqxYxjETLcAvLKk+EgqrMGSsGdGKt/bn8fm1EOCoIjrL5gwhhvdSIUh5O2PocBi+IOZvrNwWkkjRnTYvAcDV8zWkl83Zb0EkrJsZBVHZCpTJusO4EsMzVNb93xD+G9vsO81jTLXVXakyllqAiKsPxAvUUdra/3xWf/J5e7r/GrW///7IcREK/9+3VQAAvFQ49lKwuITBQBvOXxEjMRYeiY3Blatzhw411rk9f2wlw24oVH6J4dJxBFL/+7BE+gAkxWZT+w0fIJUMGo9iBeASfY1b7DTT6kWwav2JIjU+ks+qcGsI/GjUcDOibMiikozAtxAivdy0BCA34ZUqnT9n7l08otX30OtGJEEXQYaPffOMAKC2Ovr7lRoqkk1slXUWfaXXN8GbZAy4qou6//a/T/8ZzS9+v/yh38NxFYtr9TMgAAAAuVWUwEAZWePGWijIEIODQin2Utqp3KYEZM2jfxKc3E3EH+zhVsVu1lzGX3bMjQv31nyIO8NYa9sKvXt7jmsLcyu1qFhJ1lTSnDO7YIYj1ZRf/5ZVvf/3KLy2Y41a/xdVxO3TRNNlJtQ56sJRv3kbOv/X+Ala5A+YzxjNpDOZLSdGKFuZnkKb6HE4UhyFxn4y8v+uoc7vf6mNQIgAoy4KDTNIirChVYiohJQFmQ7oMSJht2W2yCQN7BaEPn1OXYr9oaTefW/vNWBrkpKo++1/z2Cf/9mIx3rbNIyhyNjl7VehfHA+hwpsQt//Ljl3+0C0W1i5ARV6Ru0iEExv2//5VTHFa96L8tz1c1spzjU6Ypx9hn35V35PEWfl3akYACAAZsgFA/xCcR4MEz2cSDDUXBq0w0F1H3IZJixd/mbR3eNdGQrdwqqKE91z5RPe0lf1N2eWGwq52dWaeK3v3MvpD+edm89YIDv7GfJSDhDKb9L6nUmgtFTa15kEGRzV3UnWymBWjpZ/4gosw4vIiojRN0XKiQ0ViYOUJsotZ30N+nM2LCajuTEB5giy27V+7K4iQAAnaIghUQ8sRhWWh0EkzpIEUi9a22ut0X+wy68aIOhlYOwm9BPQa0bW/BmnIAg7wYpLKxtf4P/7oET3gATmWFJ7DxeSg2nqn2HofhJJaU3sNLyCEawqPYeh+FkGdf+CPs8rvXGdiGDps37Npgo2tpfj/5trMs3XXNPyQAovIkQTVyYA4AUy+av/4a5S/jVUiWn05rh86D2knrJS2vpK///5Pb+vx1RAAAAAKZgRoLk66EtDqW1bCmAgHbLUQ/VK1xgkJXFADf9x5dRcKAbiTxQR3vNazzttT1uZZTzHL9Z1Xnw/8XbhUu7+MRIBqkuq/STgEUpFTBv/MDFktlo6R0lA2wdxcf9RuCg0i5r/wbAntJ+LJTpaGcLCZBZToQCFob2fgncMBQoFLy84kPvccLz+f0u0CJQBYlzYCYARUEClZiGGVfdJiCHCQnl54dXk7U6+5kkuVD/EqU2mD7+t/U8AqFU7jHYW2NG/+CBJaH/DLq2Qcw4LceW9//IfB4RKQtU1jP+LKxpLaSzY25kBGFkK//cqDpb///SNb00azd3DjVCTJN0O/zMylDfXK9wctnuuvhb/+TTVX53IIUACHPHwcYeO9L7kxQaRPstkps3cVG7awzNGyzccg+KyepdKlmmxAhIUhw7+f767i/7XYbWGi3anpuUQ3tPIeIqI2apQ1AMYlIMfrK5wCDMFgaB6h/Tfqb1F9ZcC6ogCFBBtR02EfubN/otKku2pVYi93oCdgx0JRHmKIyK39wMQeLO8Wf/7sETPAgRtUdR7NB8oiGsaz2Hrf1Ihj0nsUFkKAKxq/YfBvbLBJlAKaBz4i4+tyYRQEgAEy6XGsIXUERZ8EBIjtgUBaW46qchdlfJdoShPBSU35TU58G37b7VBimELUz7sM+9f6QDMi4vnSkeS/N5xvRZ8RMRg1w0SlMH7ay8kpBDU6CfREcpoo6VnTYT6jVX9AvrVR9GpE0WicR7tRNnWySZ7SnHdHQbq/y7Gqp7+xlRABsABXdD8wtZQTOQAg4hEFGcAgEBGws9bspvOxSlZ070jr2rqHKR2FlLh5/41r+JUE1Kz2mL4wNbotXaa7LtYcxikP+XwNsDflwvB1Qo9SJMFv+t+pH7m6YpFbGlJ+alEPmIIi3+K9ViNShJegcpQbAghyCWDRYKg7XUhAPsBdYSQf9zk4Ef6q7VVAAgClNlFT6YwdIvJbAwRWGXKCoWF3EHH+WVF3idVwWIxVTnxA8TEYFbn/wn+T/Gu9jFGSC9ITz6PZKRpYNE8rJ82zMBq4jY92EIgMh0+Xv503RQNnTprSZ3k4NgeztoIsyjYCjm1SCHvSOt/qdHSS6LVIot0vSLX6Tf/WWvPb3YyoBEgAB3rBg9MjSLwKAAoFN8QhIQp0MIW6+MEtFZC5EQeyxPa2shZ9gLLAqLv4pgxT7rDCxWSdkUC4Owqm7IEOIlUxOFkACl820zhaBfENSn/1Gr9SXesxOCMjiCK2P1pJmYb6S3/qEtP9U+EhH0WvqjliHDmOUN30PtI9fpag2BEpExN//4IqXiKwVbY/YQ2AAAA1P29KMG4qai+gEoqGZEg0mEjSsHP+yxypU48Lc+PTemq//uwROIABFRLU/sTFrCBqxp/Ye18Ee2NVezEc+JQrql9h5Z4FEbwuwJf/X1bYPUsWZ4ANWLTOL1ucrNaWQu5wwoL2p+gSVsPYLYrwTahvPSeD/8brN4OrZ08cP6vLPgnx0z/WPuupT5JkoGSbW9f4/Fxq7tZ6uotGgufoZR6h8PFFxB0GgM3I9A438aIN/ilft7LZCAQCAQ75AHGB8lA0aQERjoRdqCrKcvs5S1l3wA3ryQnLvai+iIeklk8cv7+PfTakdXGcSYs9/faSXLNsy+zldk+da9dsBVEvq/jhcDPweZOIk0l+p3mDekbsiojBBcRoqs1QrQSOhvZLJv/iuMfvPwUflSxP1NAFKhqwdBxKMWEnVhhIBUDrpMIuD1WQf4zYU0AAAAA5xyADaDLirFThHwFFCWWTR5SrUoQmOitqOaa8lZfi3fTcKMYMYJlYa5+N/RIWBI38qDH0/P3Mxpfa4rOq8iZ7AkRjNHPsIDGzncLNFMggYeMgx8h5sbfU+YNmTzdaKlB8pe1P6xaAL0ru3/Fh6kjfHqWlxU+EVXtz+kX5nz/6r6B0NBnDQWHOrfJpn7MIZAAAAADyyBoqBg6AeCLIBzKHBnCZDgJSWVlJ1vs5LKoOqyO1Ub4eatqzFAlnHv1r+iRJf1a6o0XnnN6uzNvB+YeszUWeCxJ35gWfZ+YsM3AuFWXTwAMI8o7fazPZ/vDWGdY5TNOswLzUCuAsxmTw00zxUW5hNAMYaBcN1N+osL9FfdBA2TMzy28wjJA5IP9diYYDdqOztrIdQSCglBpeSBobrPSL/WZLGYAEAAC+WFFITyoGBKhwuUMWgD/+7BE8QAEhk/U+xIfKJJrGk9iI+QVCVNJ7MTeonmqab2Ji5Tacm+utRxl7BFLHkeWaeSBc+5uEVgsUaUdn+fQRjhYStyORaPgA093l7KILJrZQNZqt2hd/C3qGizdeQ28M54OkBaQ5h41dDTWmplHC6aeYGTIIlgI0Hkmy4ovE4imkUxCIAvZDC8aqR/nE/X5yjHPfwhYNWQM+EEB6P0dBtYTEQKqyIKjtbJJr67ZZUAQAAApx2wFAr4FTl9EooGNAI4ULVilaNaaNlojFYGpYFn9ZbglQr2EK9zz7+7WiqEuOxquLHZ2eWbO6kv+vhtsEPPfOz0glJgNS2vzlDLhyYSGosqPn/+WsucRZSKb6ioznoNA2UgufVM0h1BiU+t1fx1RyfOsGFcIq5zKpSTK5RBGcpQb9U0+7ONV6uyv9TN0Gvs66dVAAgAAZwugxkBoy3opM5SOpVitQUGb5PSCl3u2xJ0n4abP/f23BvdzK3v7/0GXFUW9orGk98svvUnZZLZvOz8TjUak9mMZlwLcsq8orwxwcENM8U39bJJGiSSKfUi04agGyPKJrn0lLYUmCEjA1e/7B2RvkSKVEm3bDkg0Yw62MNfoun1dno1GdG+hX6AM/m5aPAEArx0hEMGoT5RCHThVqaAYGjVUS9Xw4SrWtP88cGtMl9D8Ari2tpmndf+8fYEnFeykqdE7nlzd+YfuYluOM1D1NZtUOiFs7VxuT9kE5DZL6Rkv84SzaSuiYsyUNXnGRsrmJTAYEWnV/sNU5fd7WRtGJMwtHAOHyoMD4uPYXIlKsfTyuqzz3MZ//oL5R/ndwAAAKZo4uErIYf/7sETjAkS2Y1P7MBeYkexqj2JC5RIdjVHsTLyiMqhp/YfJvDvGAACQFOhCVJIsq7rO2go/DuRbUXmFt9kqhqXbRVV3/jeBoqmHAhkCj3tVtsZivWX8bn7BYnvlZRI1Y/vKxVAXUPeJFjZv7paST6K2sZgSQVbumgpqjM0A6Eropf5+t/utT0TFZtW6nSZi+gi5kZooo50+g5go144gcD439R/Pqq7f62VhIJhEOdmBqACmjoYcAol8khVstSaaW/eebVPAzV4tMPHMc1Bbz22xKMb7z/7ivtj8IzepBD/ftXb0SFlxWJUfGyw+tK5SAiDFqkC6CUEkGeMRzzSh5SpP/6kgyKNJk1oNTdSIgRBFlp/g3ht/DWJ8AC6Vp7wjORmSUhn9/T//Y6PKh3+LZWdrrlmYDAAACvQ/JglrXagQSKUVQGtIRplCMr2INP6NBwJcTtoez5LJG4SYOvep7zW5VzfViWvN5zmp7MkjbEuulc/dyQGc/UOsrI8VvDjRpld0G/TZlN/5QAJRUdq7bl4BvF4qN/qZC/VXMNc1QU+gyCJvNDc3SNTdpg4deRrbDoOrKkv6MsvvMqIgAAAAEykAQG5CpZNldLvKBBQJ5ELnmCwLdXxhGm2bpBNHR41kO5fKPMYInaOl5SUMSjpAuNR8ijhhLUboJN/3L66oDn+ZqPsnsQvdDD4Upbyvdg+LuAIpCIyC5DObwl///7k6cpufM0z6BppmwJ0PZoTyJwd8yUXSsOWbGRcWef5VMVf0MSo/V25aiRR7FHFUCFlza/8rf//6itfObbqYoArA5obk6lQ1VkCi37AqCyCHESiiK+yd//uwROaAJFJYVPsRHriHKeqPYfFvE9mNQezIvkI3rCm9h86kaBjgy19oGsc1ii489HFSZe4pbrFe0I20x6yDPR2IsDy7LeqVBdmRBjqRknsc4PpTWpO3q4vZe1id9P8wqz6rFM5eWaUNF1mRoBF5FXX3llzwVCNMq/9TpF63rSoNMqKmzJE0SuoyLzF1Jy+j/5if+x6fq+tlUAAACV/GPA60VMLNIJXjEQ40eAAU4U5kYUsHaUzijA7TOpBTVeyyDuUyTHf/LeVO8jH6+DYRoylw7U/OCnzykdXOCYsZKokqEwuGy1HjgWXBdhWR6vWyJuy9nSXmSIhGmhQTOOpFY+RJjI12/qq33/v/PMORd/7Xv+9yIhNMpVrWUrF+/0/4eW//EN/e9Ms4skACHchGiiSLEgJLKTEno4l3UHKpfdOtnjWSTKdTGkdLDCwpmbqQLdoTsTwXOdEl6jQMmkzwN6xk9UfaPbbUU9m63WQiDoy/+sAQBzB1+uy2nEFootR0ytYpBsA20tXucBsWapf9NZqxx/r6DKTTbqZNfTm0FymUkcs6PvLpSMAJf4rpOMtwM2gIMSjYIBphIMI/KyqmfxlTd2zxB+bNrl1PxM+xEys39/8r9YhBbrXqjGaSlv1vmIMheV6thM343+vjpqe5dHv7c6H5gvhBf/1HXrSet6KAfw+xomyK1ILLomCbPb+ht8pU1rK6GvcWFxEOjyORgI5R4Ci2bT/larf//j199pWJSRAAAvccGx0okFSQos0nqIgM/Cp4ZWSzFiiddE+ESXLdsf8tY5dhxiz93q1amnLjY5dvdhxMM+fbxfWjnZdjXgP/+6BE7oIEeVNS+zA2sH+pmo9h8G8RIY1J7Ei8giOxqP2Ji5B7Zmi7ynNNXKjNiL08oBrQEVEk/+cNZgyTcvo1lILLicN2zTsR4N5Dqf/SWd9uWpt2+DQMHZyqVXs5noPX/hRf//+DNd7t6nlgAkANTcQie9NpU0LBgkBSmS11bIaSldJgTJmJMOd18pF9r4MYv6Ii3nkooYtooROx+i+mRyZceoni2b6wb8RY/UYwhoaCTTJ/1M6jyBuxeeeZjI8HzkJM02TudQKAoc+bJfQ6jkYuJmfRTKQp2POiiLQiPsLXjL//9R//iauvuqHdoUAAEvKqX1LNrsTdDBA4qAlJxYlRe61VF2RvLLIJgCNRecp2VKRpktm9h6HL/556bvI7G4khPpIjfpN++kLzy1nDL2k21M6AtRwyNZqTIxQVUrvX/0F19CpBFYY+SJt/mAYRQf/mqMIUoMjxvMKOJl/JaaMc95QmhbPOfp/2E/7/kf9P/oi8/dtDYAAACDuesgWEOglW0DFLniIYkNI5iaLUwzxZjAZ2atRqjpsIeKJ+TYMW+VERFBVmR4yDYUNE3lEipEzCqZmSjNAXoABJA2UXDdYQUWwnEDZvzhcKyRuW0qz8vzc8ZBvpffnkTqZgRoccylfRxSNK3LMhKuUNVUNKV2FxNDKgurkAVXz//nI3K//+odrZv3ZEAgD/+7BE0QAEClhVexEs+IrMao9iQ9cR8Y1N7ESz4nkyqT2aF5QAApwYCKHFn2OL5EA5YFaCQgJnZtFdcOFDi0wmmOq/8s7v3Qr3lFHsr/38pVeY3P4YytiWWPe4YKpL2hVA9mDcGgONn2hh4Qwv33u4s5IC6UCzQmFrkAX/MSicU+llA2OBqkiZo9XsWQBgRcNv+JnKNN0Y2gqQUZx5ugrOPcVKYOGQyiRtlL8ujC4REzUF2QcICT9W8YI8UY/L20WAAAAAK6yggQRoMu0CipHjKEiEJo4pTFKpjsZZg78qaQ4dnLTMyj1WIlDc99/Vr0CDn8+eGh1sN91vGMWprGYp41N7+Xx0vdFqLWVqZKwdo7zA8WZxtSaUwS1tSonDIDKLFVpWRQROgCgfdD/OqydNE3DBlD/hAjiQgwkodgShTCAif/lEjXkf4izqz4V3AAQAA9xwinZRFiTWSJq4kfi0RZXrcWzLBSJXkVyZ3DWNn4Ik/j8WvWg5FSsXDQh44zfUcNRdDjNjiRgH4DLmRUdcGoVtZ4yC1IbS1BkkP7UfvSmAiVFv5YDjT//jNS8j1R3G0P5JhhgUpSDTI0MFhH/+R03n9G/9BaXzq/IZnAAgAAr4cMpQuUtsokgELRDylEg4EbQairT1aGXRKZuyeD56o6I8K/AZRDP+/cpMFGn6im4imJDsvmaDUpxlE3Ws0lLFp6ZtT1da9uiqXbU4ENIOTDl5u39v9R8Oubo/U6x8B+KD/9CIMbo9EqRqgp/IIcQwdSGRBbGo7//i8aQWRDH1NKXs3ksiABCnaEdjkyGaukWgGQLFbgg2w9c8436jDMH3bv/7sETbACRsWFL7DRcofsxqj2IFnxEtaU3sRFyiKi6pfYmLXPD0Sn8veJqftgkFS3/7v2G7Qqlx4+lLhhcyhSsjh5/BmKbTJxQBarGuF/zfWbHAaxKZvMmo/kX2UkpJLaWAubFQ1rfWYGAWtFw4y3/DOQ78S9QppUVzpmRh3LUoWcruQ3/9HLhWL4cvxLUqn622Z1AAAAAnkyAPAaQYKLT0CohiEMDRxSRvr6XegFbWLvs/7Q56/2YEIo0/bWyUU5/38p+4whk8pwgBYGd1ezppi5DM9ftRzGL3dckkOqKOjqmraqgMUCKPIGh7/6bfMGRcIoW/7G4A1iCl/xyAJSu3wKDhhRJTdjxN7IQGDt1cn/kHVIrBX4hWdKztd9KRgIAAAVwqNVg2JlpKRRZa5icPULXP6BgwNDqrHWo3ThcBfrTYGPaWUx3LLu6fLsENnyqxxrNJjuzM0Q4JCN6LHaahX/Fc8JyVmCkU7+E7QgRWjCVb/QNTS5cRTefQmhfDZSimbnVHnrcmQuYc8gtvwp2FPyttoZ5AvopBaMjlFiHEjHEn+dvVyAR1mC/xWfzMeWYALACCvKogAFBaIiFaccKZfBDJfQ8BBC2kcHEYk/iUTdYs6+7tAODtekah5Q5/P+/P5sCc6H6sNJ1SPncauMTdeW0tJm3StSf8qkKttDjjy3TBbgHRJoGT1vSbk4dKbehRSUHHEIrsmppiG8Fc1/5ykIYqrkcpEI5Ed/M0UY6K6yAfyjzf9hEYyMfP9NUpQWqpepnXQyAAFOWBrPRjX8soxnT9ZWgqwFp6Hddygz8M4ae4j381+pcoXSNiczDm92+Z//uwRPGAJF1YUnstFyiR6wo/YoLlErGPS+zAvKJlMej9iheVR5TmV4WlnU+HcPehDk+b+Wc6qwdNT45vto6vsTva0XhkCrUAo2gzf6jRalmqSKKaR9BIsB/Btm7mikeiUBCcunTX/KNFRZj+zqdxNRJnH+5ykeIPmYxzP+X1E2GjhjiIg7ZzT/V6gzkZ6oyd2GNgAkAAO9c5QY8tRUYmXjLdr4LmOPBrIocSTUQb6XwPbdm5duDrRYFGSBJo859etSY3oHwq5xXK7lVu32wwrV+kjU085Fa1mIAINQu3mwIQT8OEiKWtp1XWgbfdlpph6J1tS0UnWRwdGYv/yBlvq2ClIiO+Dbs0BMLUAZnPoZKdhP/Z/chmgfFh35BQNOE1y7+ruFJQRAAEp8LSmeEHFCx7/gpsiKl6u1hGGl9GnpgvYzuF0y472/1AbFrxCAiRD9LXfWMSjjPB4q3+AcRSX8q2FZJ6VwT36qTryS14YtcbIbiT8T31pbCgEGwLRiQZkP60zScdkVOgk6zUUsVC+amB0w1GRuIDI/+Y5C3R3UpHKVFqidLI4q/KylO//5iMhTHIhjzGozJ1ZUDFyJR2ZlO6gBAAAW47kRgEKRbQyclIs8BKSGVgLwxZpCQrzMoZs8sWd2f3mSLKzWlZSiP65jextyiLby09+Xdcu4vi79mVW9rBw/fvVKstL0yiNZdziIKMVyT/rNVHqKkNDQdZnBKW/sTwGcc/8pWxT6KnZl+hhLCQwuwwGLYGIMkGiXw03DkFfcHyDPuxdF3fW7O+xooGUACZu0EATgw5CdAIBCNMhK5pIGCpVHLbMWpUKv67qxH/+7BE8gAEmFtSexAeuJysej9mheVR2UVJ7DRcqmcxqT2ZiyS3rUGwPi2JLGk7+NnnH2Jh782z4VJj1u/lMw/xoYpNNhMaRrJQDzExTqJ46GXAJnHhD/rM6KR9dSzp8+gbiEJrUZmpdQTpxOqkVKb6odwYRFhZDCQIIFUM6egkCDDnBkFFPAgEoTFv/5xYsjsCantq590FxtWO3th1QACACC3GF4CN0xK8cXMaARNBA6N6GVUvv7GUHlVmruxLYzJ8a6Oo1Rkm+TC/zn17eoMkdakgtdlecpZR/wCq+1lRXUlbdmftcjjsWc+7s2hOAb0WG/1OoydJ6KmRUistB65IN/cdADdLy/+QzfypIwM5/pMZDBy3rDjTsoUKwk4mRLh0wxKi13jx1dfcrLBkQAGZvKxowjWmgiCKiSQAImprf41RxE0mvtcbSPPg20KrdaLHpXtvb/4fWvYPWlllqbQqzx5+8n2by1/9pHysZcw2CkWbX7s1AggVyf/zIuHUDr1Hi+knMhaDc1sz9zAtmtlN63FuRaudWfqQZXi6MompQj0dEOUf//zjlQF+2Jr+9xkVQAAAAO8QXdtEkcC00xBEksiFlK+lzVYXHFnskcmzKsXulteHSctxDulDr+fvLToQupjYZr3+83qOJ5T8o/ByGsVcM7cTQjpbWGs4wENEGKKH/Whs+qn0g2UidPdNNaA+gLGam1/1RDfdplocFop/1RqoSRrNo/VqpnMwNEdv+vxn6Vnaz1RGBAAAA7EUAWwma4QycGDXAgPBoBa84gQaYpi1aFsAZWoTDz90mom0DCVpA09y79WdujryiV7OOk3J3//7sETsgARzUVJ7MRcohWsKb2Ii5RDZjUnsSFyqX7GofYojhO/VsqpWKTl2tAC3KZ6b8Svnvs5jzG1LwSZASNGjv/7PJxX5odj1JEc94GrBdPi4JBW36/+xbFGtdUlRz1NDEdpup9y2WYst6FhQRoM6Jib5v/5v6/7////xyp6sqGRwBsAAzdVMBXh4ym1YFAlUNTdoDCYsvuStAa86U+3Fk+5PKds8JhbCsr5a//7LaR80o5LFYCQJwuW2K27TPICsV/uMaqo6ZJgPBInVFRcNQMIgkVM3/ziKTI7UENFID4c3siqxJgjiDP/uCL39fjq67cZi+dGM9Blkp0vguthYuSdwv8i2uPfrVEQVBABCoKrAiqc4BbbLSsnC6lg1oVF/NdcNmzdHUeGCNWsdx1ZthngsiDYX/3OWyCaQUZuwYMh7TYYfpuz/zcvoLaj11/I1R4VjsaB+Yah1lQEWQeoik/+qJEFarrGKqh2AUNjbt/iShBAUodM1/zdrPNSvUx+j193HAjDHShDQ2yLEhLPEnQVdlO/Z9whKAFgAB2kg5yhAVcwxgakHWCjBhFrtRsYCrIwOAWrV3fgF3cJHa2SBDSMwSDwLzDmqszbTLQuwlFlARSUcWhmnoioI1LtaX22RSKxnXieIFBuw5vmVR/VCXAl0os7vf/6zoHRKDaTpI7moYDGjX+oigWQleYf+2N/XnrWwt8/8Trb+u9MStjzb0U4Iix8F3iWuBwjlfz0hf1dOiMSAAAF2DvCnAC4aADABKConQZwiE4CR8ELmlDDpFDrtMPbPT7oXMutycW5KP+gxxIDyjfZKgtf5l37jcnKo//ugRPoABExSUvstHriN6jofYojhU1E7Q+zA3mIiqKi9iaOEqa5GoKd6NV79ycOLY1et0k1OAngHEv/5Npadq9vciwXpMZG9rBgdv//8WS9QrRU1R1JjFrm46XbWLkfawYhq5Q7WNdR/4mqPvMpWYAbBBD4HHj4G/OKRGJCUOmVMOiTIbAjw0Z8MF0LugO84NJ91Do/tIo3L8t/Zu52Rwal8AzspS3y7ldv3ltV93vpWf0lyNT0OvGtqITuWWVYvjhLylNRekzndNf+omw20iaX9IvBgpBSX+69JKj5lUo3p1NZ2zvC75nmlaQzpX3HXQUhiun8RTU2CAATsHFodO8kmJIAAqABBgcCle0uwtluiASAW6vDSyykgek7tJmcYE6EQe3n1p7yoGxydpmkkSsC2pqz/WxRR+cMMG+TidStP5Rs1FJu9KanY8CEAE0jKFVP/zRNk3Q0jNS1kVOpFdJOiiYmhmGWiePmCj35A+0XPPRHKWack1jkMVQFIVowhRATGkGyjF1OXp9Nf/+Of7/6dXAQQABMFUR+pe05VYADniJRdgZY2JOggIghf2AJO4VJLW+hm5ijss/QnJF7valMVPVbxtEjin1G22bMJkhKuNlA0QqFEkN8gK61i3fndPajFH9t/OrYzmHi//vanzoKSS+/jXxXFQiJYv////Ntr3/e3Y6U5vXOt//uwRM+ABD5R0fsQTzibjGofZmXlERU7Rew80+ItqSj9iJuUf1lI8Taua9t0HWysO39b7KiqwgAInpJgaUN2hDCBKZfkUUmoIA9SrlyaUofN/4Q5buz+dBVgXNR6liWP65r1sua622ZKKxi7H5ZdjbPI9QW6ldhKvoFnbl66Aj09N3V/hJg+EGNEG/3SWxxNmzGozGUU6V/WcGIm3/WehE/PWazsU87LeFeSBLbLRUxhA9L6LmeWlbrT/4jqy8/ZaIA0AAXOGEisg5iaDjGUoKHDycIJA55KJlS21/PymEns1B+ZZA3HiIh+qiTKo8+2ey7CZVrXRDxoOiVk8Ko9AvCTDchNjFZWUyms3MzA0IJXOH/5wwdAvqdVejMQTsOF0SRPHXSMjcTwJOifdb/++h2Mf9lFYbmmMln/Qo5y0UT0kw52KSHR9/iGqGaQAYdCUwcNK9s6VZ5igrVd5CDq2WpxCQyxiz2Q9K4tlzj2RNqlfHPdapbvt1TMo78wqLKazlMtskgFmwxGZuUshhqdgeTS60Bqe8+d65Nho4PCTbFZyb/LBBlmJEzhTLJqVTQmzRJEW4eSiYUUFp1mAj+r/65UxuecL52/WbYqn1n7JhsKFBsL/lre7bhHAggAVOH8B10j0+ktSoRU4cdTovQ1dT7TF6vg2CO1HToZFKPvqu22NLLKx2e6RpGUbI8CtqcrOgVHw/f7Uby7sxorXj92mh3Lxrf/M1aVXrdRiCsn6TNfl4G063W38xRrVTs6bpJpoVI61TExlEyPonlKWgs1Oyhru3vxVVUdABUwCtQtQm6wMVGhARPT5bkOBZ0tFcq7X9j/+7BE2oAES09Rew012o8pah9iZuVPiT1H7DG04iylaL2JG5V5qjT3gqUeMw9yvKQlEzSjpt3KeR214KWzz6S9oEKjEOQRcsKLMHfmQVePBLuT1qq2Rb8UkcvoKbwa2DhOnzF0f1pJugkpFS6lonhyXSSWgdpUh9iVO3/Vcpnz/2p2XMnIvnnNpf4HLrdXR6/O63QwAgAIviGzbYH2aylKAIFyHALZApEHlx4bZw0Vmkil8jj+ePtVXHt4Us+b/8+dXg53een137ure4KX5OzNi8n+1i3jS3ICj9mmy5S0o4SLDjWikym60SqaT10GM1mzseGWGH9C1EQKmg639+S95+7u/m2lrj/+WGG0bBurJIIzCyGyxKuvdlTcjSACM4KgwElH2SLlADBqKeaYqgj+KdWqRTa7CYOfaMv1e3YW5tbUIvUX1cql5jUouWOrDQ527y5lLlf8vS3BhUcszF7N6RY8mmp2bw2EPxDRzvb6i4nY662TRNjMwNBax3pTdldUPlTX/28RLZ2zvL40Qb37RPNhQb2i/ZUfUiyPIb+ZjoigCM4R9B/V9hw6EHJUxUZbmm5JF46bEvSRMQyf3Ka3pusa3BzN5mgDAOq2YLBF8xPEkEhHApZPCtHY6jFkCkMQ4ZJJMSRNGAprZT+cTYxNkUzFFlNWgDwZLRRQVVTUFmrt+QAGsRJ9DHeZjC08UPsLQqHiz4e667N61ZwAkAEXhG0ok9SdWxKKDhd8EkWCZ2GHdljChE+zSXyGFS2h+s9vBrFXqY1YP4UTzKE0RX1EqRYnVJmo5AqJkeSNUwRZMyss650GmxS45qdv86km1bLpMv/7oETxggQ6UFB7EDcohqoaH2Jm5Q9NL0PsNFPh+KhofYmOfGkwrhXTUh+kKMYf+QAuYUtuDLxBy8P8Bow0uWNClgoNhvFiKu+d20RwAAAM2gccBwZ1fFvl4AAltAuG9QcFLAgFOl2kBritBae+SmtyCfolwYlBH1f+24QO4tYl10Lff/s+EWHS2apMVRisjjMxIoF83V3JrYd4tbO7m1///5Y+lbD1WsCNB09XnAJ88M6/17TUbxMKQd///+hCkSiAGkjshhRg70Gj/Bgkqw7g7llsgdbf72y7OBIABvcIzjSTARRiH0Ak8+KtiO8cR6bii9PSGNyt5obs8UNZaiLEIc9rTLx8yLzooFBPuowHGbprWYjcUXRuCBKix1IqBLAuEVl/+EnOhqlcWoxgeVrunUyG28NzjPr/8hKWvedl1/7z3c/xUtc254c91dXxaFIkd7t9mZwEEAuXgYLOWUMtEQQBaIRzJIEZgOKXbXg9HpdatyDzcYBh2C5Ze3HGOeHdvFv/+QIh+7VCPQ4FdyYSIzWePTYWh+oMQdRhwqZ5JiNcHaCPQyNC1/6f/voTVGxA//h7apQgL2j6LJv18ZSBsrEbf///tpw25+MztcNeVFb2zw6pHfdY6XeYsBaWy7v7dZXAAgA5uAoDNVJGpat6WpuYGIEggUwOCW9ECCPKEQAzFEsnInqa6f/7sGThAARxTU/7Lxz4fCo6L2GrjRGxM0HsvNPqFqZofaw8XBZKxTb//zTC7s26sP+l5bQdeNeDazBPFi/4DKpEiZzDLsDpYv84///8ldXxaWt8V1ihdIlmqDanxe2Q5HGbWa++9V3bwI8CFW3k1/AtTO6fxPqs2PJqtaxTisPV/+/pZWACQAnsC8BqMnmjmFUGshfZKG6QhcJDgpg4ympf1Oo0kfMLfgFLosk3rH8u6pE2/jI6NWtrPPcJ1yzqEDIQpWvq4gmRM44ha2ElLxfPIJtV9Fipl06dU4mJ89I4nTrQNgsjU3T6uikYGRgldNTo84y3bZSaR5sGEiH1r8Rz9btsjgRAAS3EJJoj2QYWGAEIlSvFvi1LngoCgjPk+XMfOOxp45yl96uez5qPMv/fPRcSDwzoEgcP1vKlgl+dYd03aHq+8c/LfSq7OZa8nAfyaep/6lGVabutBSlJCbEkkP2KIfMaf9wGhDd6iFkYq2NA5s+wqi0gI0I8tNZr/1f5uyyQAFgFqYP8cMiAiY4JauUIjBBQoQCwsWHRlRRl7RXIJS/gGKl4zLk9BQcex9//6i6JmTbUrcHC+vGY/k9QIsH5wSI13UsLHRKtmzXyiWPioYHmPMVvHh9yxs3JnyhcBaD5xlzOwABd/RutXWrPM9najURWNRGnlSmOzMa/du+z+llgBAAEO4JCAYqaCMbvmsTtjLURTGS8OkTnS0fdLIdczS/z46Yj4Ow2v//jBVCJao+CLjfG87fl5mkxqd+8crVqBhfRvjdgcAECQNkP9A9MO5xBMzc6sM5Yki36IcP/5smxzW9NBJC6Do3qZRrB//ugRPkABANJUHsPa3qACXoPYiPlUB0xP+087enYJKh9h7W9H2+I2UlVr+/9Z7ACQFr+ECxORON7k9xCdGhAMnoyNV6PDuKNtRbE+0MwQ6cqopFgRoHhz/23B8/8gan4ZRBhY8ca8pLmS/4TmZumD+IZ36Pyz5unjahK59fQLrlImjMuLp5aGoxLgKe5ij1sx660tNSRkaowwfCYXWBjKjadvsTX7ubDuCAABvcJtF+hCRZ44Ffb2oAXmVQZ0sOs1OtAc4TxK8bNHbWXvQ9/ofKt7vfkWDt5HiMFup8xLRWL7JmJWLR5GsG7jdtRgEFDSd//WosINWmpCtE6JtTTNmuhRdIRuo2a2qrK1Lpg1KCqezz5JicsNs9hkn//+F9f9rQ4AUAHPgFrgqA8dBMz0tKXijSpIbgoHGf1hLMVNHQpnkjmF7bGGzYB+F/1vCJLTRRmGRa0z0njFHKSaKzI1KBKoumWEiTVmLLUTSmYP9vQSWtTosmtGtQfmRLhqtFtkQkyKD/fBAQHWazLgNMGYqmRMKtTDRDs4/f79qGY2BADv4SeC4C6q7GMgaJZMvik8zJmjUmZF6oBct0Ze1Ps5jcXkt7YlwVCCHrI8PEyzALmTztesnSsbsxgPZot3YGx11OtNEIcRBJv/TUtbrSTbsoWg+kgtNFzRcvh+iKLLPak2YKVl5BBsOak//ugRPAAA9FBUXsLbHh6CFofYkOtT2UfQew0c+HxJih9iI59pFxiYp+rE4l82Z+1r87/mIATQZ96FsiYFTJ5twJkpnkgEMwsVUK5VLnvXfEly6afEaGk2p1O8LI2//7ayWenTapiQxnGWF6Nr598Whvd+NWyoez+slnoWR/2////w9VsdrU1mF+4bxi1msQsmryV9mf71iYOVp196//xkYwKp0UhpNtcgQMFnokc7d2HViMIgW2ByTKJCBnkoA0GlKapkplv+tlOhkidbxtnlrzQde5haalm+KUHNctWJeHiNTUsBXFdA2ZcoEFucQI4SdZs5mYAMoyLzrQYM+DsGrf/GVUS19xaR5I0u35rKmsO97yX+YAnsZzsRG3H13BxRTCJGmuzep2gAZAN3AIQg5KFVAm8VRMDCxk/1aICWlAGDavW30Zciis1/W1L8CyPv/+DNkgJqQ8Sl6j4xbdHx4TuG+i3kWam3qjpb5/IEa0lNTf//424uUStYsk/tB34Y9Mz5tiap5cZhCBuVLxdfO7yWUBcAMmO6wGqwciGHMyv+76V4EQwBLwEEIOOEYSnEYiwZYVI8SAnU0lcsGx1oZC7GCoEPSkLneltpE2vr/OMkZMaJGO0OCu7R/YzJ9fzJlLOMSHGiAONHK+b8K4IRP/5maHGW7JpGbTRw6ppou1BJaCYK0bJpnvT//ugRO0AA+xF0PsPHPh2xtn/Yi+pD4EZP+w8c+ncoif9h7W9pnLlJVE4mmco3m8cZKrevuuHgBSAFvAClIMISzWkvISKQtQ4NgEIVpCU1DnlGE+bikQlxXXKox+TI1t//FMr5SxrwRSIt9ZVaSBp7iRFMuPVBMdF3KQpWV/X/+41avUMatErRKAVEZ6ssbXDkwDNu+udlQirGpFof02EGASXe7uplkAKIGvALsmfKt6ZKtACey8LlVUQ0iawbK9vY9NSB4Zg+rf9seX6Nr/XzrIUrlnbYEF1vMHcwnRYnOLiUoZlukzg1AJ1pZ/bLcKDGv7///+E+Z4uNfEZ0flm5dEoaYUOkDE/pEyTW9tVzvGrZySAiSetjZr5POKI32ylY5198vEgZgD+4CdAMnFFrNZBRwxKMiXqT0tSUcRVGBVyR6BXEpL057VGr9IwU195+P9GpaCuAq5KzU/amiBf9kVF67zRnx8f5duKQjVpG//+dRGxnmhT0s9g3nXTWN9YfyZrjc0lYRA4lcf/G/+Zr8O0+saYYhud3bzxAoSAbeAuQGiVe8LpFy4yq9uLPFKCzT0P8rK3Wfv1bb2bhhNJwDigp+sMJA3CndWtYuGxopZ9iVL5cOGCwSVEuLMT8zBMnX0f5IO1bJ/2Mg8NzoP1q1daQyM2V/39sUPtmPnVdERMvWHFi1XezsyH//ugROwAA34/z/svWup/KOnvYeafTsETP+w8c+m5Iqf9hq41oDlCf2AGCAJ7NnKISiALV28mkxVGlFn3VgWu1pw35i0Ln5H8ean1WSm5v88sOvQTBr4U6AKf1fqcGA0IMpAWGqyLmokAYS58uLLk89r//6h3srY8bO5YU2pFscK3FgQ6b+vjI3gmG3cMPsaQFHVZl7tosChhAnoAMMjKwJoTYWJKoBc4OK9LeMOlToriZRcqZwJIIr1hL2aWWohlY/9czVlY5OVmNpGXbdXOxML6fyUfytKbdqrcsUCIWNrXOcDSF9Uf//IWmXPpjfx7Oia3A3devO9YjXmqCdwzlNtMPhR39NeajX/4f939szRLaE/uAyc5RVfylVU4gB4ZiDMqNprVUio03Jx11tIas151O4V1xdQ+pefllX56iiTOvvJQzvbuGUAoa1AoHnlDnHiw4TZh6BhAFzLK/9OUN5BzGvCix5ruxBtxJt2xred1SouIXLyu+IrWbt7t33igVVkb8BuRahYWVKViAjyt4sR4WvI/SSUseo6qtx5HksrnwWjh9io9f/i6JK2HZtDUwKRqyNdnz1kgyq53a9q8csv3bNyzm+/////xdS2Y4uWKtcgxqHo1Pe7AHFLOjiwRdBU/4fHvM/81vMu3aVBFwRtABwEHjKXu6gMN4qLsTdFI6mVnWFfZXTnx//uQRPUAA5M2T/sLfih5B3nPYazhTfTZQeyd+KG2G+f9h6H9x1H/5V/T1ttscEby1+t87pWZqEvkCTigbpUEthnB+DBKqOALBIdjYeLg9QgiKQJBkJf/qnx7dicWr6P1db8D5YflIjrTtloD8vNsk3tsR4j7//em4BJ0lvwDIB62RQ2wFHAUC8k5FEvEDkvZYrGwJu8vhi7Y7URodRE26ax2BqGGTOg8HjckB/UpRUiks2PmRIVrMgmxierUsD6bGG3v4OGJxcqy8iggRMI32tOEAsx8qIwtwExxjs7tqHsUvAW4AFIzREl9CIxFDS9CK0VVxZWiUC6LoLkqkeS7MKDhMz6CkWfXztUfQD8bVKwwOT6a38gxhPwIrj21ueVWZbpD+QhtHUX/+suSz9Pu3bOXE3exk2+a5AWCDXyW5mZLLIs2AJmAQwGiLYdJdyVqXqyWgs8jqplOnnWdflTYXkopNZ96FPaGRVm6oL/pFkN4paWoW2FS8HbzLqBu8VrVUK8LdRg0f1hxtAqE07///1cuOy6r3oc0XHHQamxdrGtI//ugRM8AA4o3zfsnZihnRsoPYaiNDETZPey9a6GqnCb9l66dnddyD41Q2dW+zdyXwB1Yf8AER1itKVVUOMo27O07C1W6thSEcjORMstXnZfqA4jjSE76QliQF0hdoly8Sy6xD0FBCxgWttSwsW+9Os/f+x2+uva+/XGtbtArfes1re+KaN6aWNvW6y79xcax6xNspN3WU7QJsgCUAAKBFoRIrCAnZQRgJEJqJ4zBqVAa55nKhKgZac7jF4Uaxq3+YuCjPHeMlrvGMWZ22u5t5XM9poc0YM6zvU+sICuz9/0xfmhlujwigNXgx4zVrFk3fi5eZl5Mi+rF2AApkuNFG4NsHPR7h10aBu0OJvplDUmXM9eOKuvu57ZXy2lMt2xIsbVflh4k49/dXfasW94XklVutNqyvWEIVT4cLzP8AWPCZD0FyvJolIm7X1rV8fe6wSB1he9revpCJNvMXFXdW6QBMkm0AAkG9nalMbZfkWzaIwSAlRPxajDxzohPbdsvsgLR/vE1skbPDeMj8z848WpJVDrD+K06Y4caoQ2R9GtvAmga0G7/c9EFYxcld3zTBV6keS78Fw78s6q6qZeQdwF+gAELGk1oYVOj1E6aMsujiHytSEhljdovcbo/krkPM0+qCLCIxFNJ9Vzkr6xkmSCHBYYXhJFQw4tKQLvY3kbywZhRt0q+itus//uQRO8AAz04TvsKfBheBsmvPajhTWDbN+wh+ml1mOa89puFTU3r+mNNlXzyvaMPpG3dVSRKXfZdUzzzQDU3z1Lm7u1SzZQF/gAcwprP+19B59Wdspiz/KOMBbSG3h+ClIw+3tJ6bzQ8CQbq9ou13EKIhaI0AlUmQOsqUDzqdMyKTOikEWOG6TMgGIPRJ7NrqsQFDa9fzl5jLUY0dt1q64eIiVVhKIA3AApRUwnRBR6DIRTkiCXq0sUETIuShbEINCJFuXUJ2hRP5oH+Y21wE/Ftoyab3EPWDkBxcqNtBamsmy6VrnTVV6l7c3NXMVM91XUeDaSTXMW1onBko5xTcqm6qnaCYgE6ABmEkc5DDE4RrCTiCqDeHA3BvJBjO5kUyNxxkEXsIclllXdkB8ioLRTE/Prdki6s2UfJVRWJx1sH6rRqTWH8NjlqP8yWu87VI6Tlmzm3uff+J86YmIh1ZHzCuoAC4CIePjNDBVGGJyby8lgDwKQVKRbSxqzWtNRJcgfHDey3rq1Hb7wAyvMuV1xFmZYpxE2fbKYUo6rEVQ1O//uQROaAA2Y2TPsPNHpfRsmfYaaoDADbKeeZuElrm2Z8+BptzHTXUcqvaGDJOS4hBELb//gLVMTEOyQZ5kPwABQa6JRaelwZytBEtwxeCJKbOlPwWxdoDqV8EGl1dSnn/3+cpswQ8aGtbUAizL3d8+1QU07e1uMvIzVGQVzqXoA0EAwuym6uttdlmlItPiiH7f2zkO7PCq4m4A6wAIhMtk1fTk2eSiNQWz6mg5ddA4TVX5fqxF4kyxaWRXtumiAnRGgvhhyXGxNi02mSLGW5UnOY+vCaJDmZbrb1LRdklHHpbKSLxYg/+eRl4iJZoIpA92AALoHGJmCS2Ou2R6cwn6tExTyNWSNpBIMsHtxaVKm33q1oMgE2JaDU2BBaPaSeh3pWta1MBlZt7w+KmVltl81IUFsRTneLqF//Bgw4Lssz1Sf6fX3X1ZaIaZZya0G9gAKhmtncSBG1q4+RgmSrSfHi1nKqs79WjRd3u7zefYYY89AgiSZlUDyrpYBpwnQIyt3yDiGweJ2t9BaGpI4zLSWpM6ykSs83iK5qaqcokbCn//uQROGAAsU2yvnsRLBcxhlfYanSCrzbJ+wtsUF3mGV895n4QAByihlypFi8RNTQy2kpcCBA2iTEscWV5acHSI96vhAmyLuCyPtbGcs6hjJlKipY1FZZdJgox0LqVVFvmGEcDPMlJhwgq+Vhnh2eHE9AdkACwLWq+d+ywra2HKbpfyRJyRMK9mt2pY0YbrOPaFCgFkopN4c4e93vhIK2mbbYFmDqamUfmnxTpYUDkqsbp/v3zDm6g/ipeUGd9dzMzVVZNEE8gAEFQl9mE+hMO5cmCJ2rxwtKmQhCT+h068s5BwozNNbQFcbUZiHhvWNKSuTy1/jcWp+/X1W5GYoNr8NBQgoXDaQN8+qoqZm6oS/D2IAJIaFcbW4NoGIRmoMKGW4upmlgP5gmr2x10zN//I6ycx5uqc0tzyp3GY8/Gg8o861jIWktaUHCKJgyqlqW12ZVIvn0MEzXlJeGh5eANQlUAAmhK64tGziZl9DcD8bHiEHsF5VaVFkQotPXWECIimLAFGpSlOsaScmbMfH0lndRkgMbSVQDGUzJlfq/ZTKf//uAROsAAooxSvnobTBPBimfPaONClzBKee8b8EtEWY89r6USImCjWXd3iohJ7DtAAdRle9cywq16u2yxtcyV8EvK2e5O8tcZk8uYoNq0lnLXirE6lGtr91rfvuh7RbVvpFM7DJe91H94z8jtaIb/etW3/7YWpV87GmHA7eXl3iIp5A1EoWhbuzX6vsWuhAXJT45ry8WnutOFkmi1q1YmokKjcAfk0X1GppWyRgR61IJCCmXeExEiM7k8YF3GYlWYAWGZ4h4lp/DtAADFNmW+ka/rDSySNCl0tjmXj91kOjwlG62JVa+9yFGY1Xq4O+NPiWMMAhNdA+HxujEiJb3ElhKEYgXEVzf+bTxKpu07wEx+kku2EZBkAALSDJVaSOAJsXM0Cep9dmNLqnbkDpcB2at/jW2EJn+UpK/4+Wpo9vl+5V+dZMJ9v0+D5Ic2XsC9phCd8PYS3fa/UTBC/M9vbe1IhqXmhwDIm3WLrT/+4BE8AASgDBMee0uKEtGKV89o38KuMUr7Dy1IQ+Rpbz2NDwyI7YhPHpqjw5zuLGaOGvhvXIOmWiLP9cLUQlxX6p2fPInZsVwiWLjhDb4/uk/JPVvC2XarTA0tGf/KohRsZoih4DdNVOvmOBatMthW8vhVKiRxkzyg4gHsepnAbW6NDv8rpATbtc+X28W9z5p87vdDSKYH1dKncgD5z/1OlmVcAZmh2ZfQ6AAA1Fr3dklGRebWJdTYxTXTha0KGtfvcK/KFKvEAE0evGghPyHImi9mDh/uFAoIx9cZlvAKI3LbtOHYAAHpbmc7ZyZYWHZmXarTTO1sJiDgy1cGPP7X3cSeWbWygIDKn6Svh9yJWbG+kZmSk2oJdJ9xL/CQI9fNtmxaLfD/3TEZrgFsruoUCAvVjvwpGeK3V3ZinvnB7DXyO9H0/o/Y8lGRENKgRWXqTiOEb6yALUzqzXGMx/YYHjXzChsLabjJlBYMv/7cET6ARJ7MMp5j0UYRAR5DTxvCAkMjSOmYZJJNhIj9Pg+STVOxNZ1W1KzFJ4lvWSXGWwh+RTXXz8Vvwxil7CmNly7VnV8IXdtPIr27GCHX+3a0Ga3+t7V0oD/xuwmAAAMRO1//2QZNOk0QiUsyz9Mjwxi3o11uWCJdnDOk1WVkZDkRUo0jAcLWlVAHGBJyoq+ihtCygSBIAAFKzZDKuKJCKrEMVG25moF8WmX8tpgVHHaptTWKdKjE5uxEYXSo5IfGw1CXCwZF3zVfOKK7sZ+JQfCX017p1zbaElBs9i/Ha1rJmpbGvuavGQNXVkSOSlab/D56v6OPj9iwIbz7dInPLJqZrRB/Q9W4EBGbY7biLC2KggAurNPw/g6KO7tQnCB+gQWWORwPAgK80Bw9bfcCdFsxyChDLP/+3BE74ER4iZKeU9C2kuEaP0zD5RHXI8fpT1pgO6R4zS3saG7U/XFgYEcbtobAAAJc0z5GarFScs7pwRlHZGSY2NVtr8NaLqrYGjNnNfw+LZ/SxtjatMHrM1uZFxLvXg2BYBnAiAAAchD3e3ks45bK+sX4S0Vj5rttMqJkyg/aFuMJRFnnEM5Km8EaPbWAKO6wxHZJthGPJ7toNWgYlRFd66hTTzCMxb007pugEYnp82EvaJa/4GNf/nhyKX+iZRWwVMruAGm/GDhP/qYUJkMIGT4XIT1TtLTO/1GwQMapBdOdUitVZsSFLkb6xz3HsII4+4Jj8AKHkTAAACKy3TMGT+VnoujqpJkUGUDiF9kisZl6DoCPDym9YmpSTNpmowQG2FsAEHjRIAAK2rdH6isRShrG1a8+i5U//tgRPqBEcwjSOltREI5hHjtPCsJRxSNIaa9K4DfkeR0pC6VNqrDxQQ04MZHMqonpKXbGzWtCge/t////9EIDD/6GjbL9Dj5xpvxHExQRilE1oFYE9gITM7FyBjVi3pPM902uaWI1ocO11ABgqYDQz9KocqkBCS/IxTCeJjrmXGAmupwppOzsgMZx3TR2LD9upAX9v/cdlXf/X///+1SYCDaEkigAAAaHe67yBxrP1EUUXEebN1WMxbVHCHdk6x9Lt8qUukhLhMGsVwEAJNyRMAAAPD9f+qLQx6CSTGgbFHhOxCNjdJWo4A0Lil+B2cq0wUf0lqgABnIiHLL/1b/UURi/lIw//tQRPkBEbsixulPTDAxhEjtNeiRRnSDHag81gjCEWKkp64IPCyoWBJr4x4aTa09xWcBt4jI3NMdNDADActlArN0f6l/4/nljFLPDM4TVopt9ziOG27BWHTCdcbEodRVgAAMEDshAAAQ6zzjvlQhOv6YjuWwUKrkeMROM4lk7PPQkUjHpYAAQEbagAAAQpVb+gIwgcXkr95wu0v3dBeJ03KDrOaxoidNamQAIaEf+Az+/lWqvvVErYbSmx4VZaFUsrTRKS0KkZ5B8ZXAAJyEYP/7YETogRF0H0XRYGhAL2RYqjwNCAWMfxUlPNgI0ZGiJKenADn/+r/gyEMrzK6coQQ3pn2ToPzN6mWSoqqABC38AANPX96uOCyKwSdfqWeeGmds4oT2UdGDjM4ajzhFPr/d2MAAgCJOMAAAVm/6pIoMsm+//4u55nZOcQqnYpudcTJJmkXRtKIBxP/nt6ri4cUkLrN11obEZnv64ON0yqOVaoVcXTr//RAAgXaBDe3+Y1S9Xee46Y9izPzgJAVtKgaQxSm3Z//////RQAAqeAAGEXP//TiRaGidlbhrIN+J+I2EE2kNQMfp5IZcKEf////9X//VAABK0AAKzW2/uJi0fevoa//7UET5gRFdH0ZpQ2oiKmPYzTVISkSsbxVFIZRAlw9jtNQqiHPPfwsRo8dFiMDY4Pxqur9Bz/X/s/64AEH7gI1HF//4y8aJ+WbRwkXrE91xDkjnaqEh/PoctIQZ//ShTYAlf/xMWcT7JTRqucuhrBYMoUeYJOj//6VKAHPAAAzX0/KF5pfrMionqZfOhcWWRCgezJQdDYx7P9v/22f06oAAJagABWXWzq+xwmFsTtR7tS2QTbFBZ0qFFQRWHZNL093///oWJL8Ayit9Q9EL53n/+zBE/oERJh9GaUBQQCTD2L0sCghENHEXg6zwAHUPoqigMsBC6KcNWVGaFwZXKjY897j0Cz3Z93Z/3dYn/4HK79h4tKmUes0ofVB+ncUBxyWECgwYOMIP9dWABCj8AAEv/1f/PFM4dT2396flHUpYMoaT9FYkz9CxnBEAa4AAOOv+nt0wjQY3SVAQvUU91t40S6pfWB5A1AinFf7/+0BE9gkRLx7EyUA7ECJj6K00C1QEZG8TRSDSgIoN4mSgHCC/p/d///rCstAtS1eVBrqHmGfvqYzojRSY5UmqxX/9AACDdIHf+irsQlgaO+lakCYTpWJo10RjP3GsWWMR/6GfkgJ1QAAc7X+ypX3aGxtk0Z0DdDeEU6FWcidUnIHTh65aU/9f1AAg1VAAV7dOIQ+gzdfDtRhkJMKmjgCESRrSAa6vXQgAg18AlrRpv+Gxo+mhI//7QET4AZFPHsRJYEBAJqOIiTQHBgR0exMlgQEAbQ3iZKAcIENooeCihOHgbU0ZESwl/3BBnjutAZeuE3nHtupI0d12sYKshXGkxVgIRYW/r//1qoAEOqgAAtLf+CoNUqXp2lZqM35Rq3KjFC4WMbtvvgEzAABBvt9/0rGQ6+mqLUUzICnW2NfleluoDUGyfp2fJUfq0dOAAFhxgVv/VEIyhUukz13Zm1eFGRTUMLHNjA1KgQn7//tARPkJkSgexDDgODAl43iJNAcIBGB7ESOA4UB1DaKkoBwo2X344Xp5qUEIJcnZuaXzq0vl36ez0+2v//o+msBjQAAaVeJ3y9fq3d9XgcMPaOGuedND1LAkCf+n///68AQKibAAAFZSL/6HJP9+CMTqU/l1u90pia8u4j/////XAAhLcQGFUf/ypDfteaNHs3NdAsGHVWTrMLfR///9AFuRgIP/Ovqyv8DXe5FWfu9zI+/w0tr/+zBE/AkRBx7EyUkdkidjaIYoSU4DJGcTJYDhgIaN4iRwIYiqgEHAAByd/6hj/5v+84i3/Qk71/R/9FAAAAgorAAAB8Y8Vl/23A0h/4XtsOv8M//V////9EAABAYigIbf/Bn0fR9H0wACQNff9//Yv/6m4Hn/9VF/3fX9v0fR//9H7PKVhAAACCYAAEQoM3v/4+TAr/6N/55MAHH/+0Bk9oERHx9EMUUZ8B6CqJkA4koDyFMTJQCigH4NohgQFQh/6fo+nkAjv8AAIGim/r2/iAuf30sqIy9LqKS7b+yHkGP6cAAECA0Ah/7A1/4iWCqIKgq636g74NKDsFWkQ0pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7MET/AZDuG0TJYDhAJSPYdiijsgNocRVGgOqAfY9hyKAdiKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqv/7MET8AZECH8UxQDjkIKPYqjQKBgPQexVFgODAXI+i6KAdUKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMP/7IET8gRCxHsSxQDhAHgPYzTQHDgHYMxuFAOEAcg9iGKAewKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE+4EQ3BjE4eA4oB3D2LksJwwBtAcTIwQAIDoAIcQAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETdj/AAAH+AAAAIAAAP8AAAAQAAAf4AAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAf4AAAAgAAA/wAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq]],
              ["Fairy2"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAQQAAZzIAChAQFhwcIysrMTg4P0VFTVNTWmBgZmZtdHR7gYGHjY2TmZmfpKSqrq6zs7i8vMHFxcnMzM/T09bY2Nvd3eDg4uTk5ufn6evr7e/v8PHx8vPz9PT19vb3+Pj5+vr7/Pz9/v7/AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQF/00AAeAAAGcyQ/rkAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74GQAAAGgAFH1AAAAL8AJ36AAACP6C1P5nQAK1DArPzNCQYl2VmRUalApBA4XD5d5wTn6gQBBxc/gg4EDgkOfLg/84uQKO/8EIIf/8QOBD/g+///4nB+YmZYzMkSbBdYLg+8EATUUBAEA+oEHFHcEPw/B//B/4Ph/5Rywff8ocWH//+X5cH6iYiWh1uHi1emgAAAU09ZDRLHRDGHCihihmXsDhBUIoxVhJF1IFkAgQ0tTWnMM4twhW+BpWogRiQwCgGKPghIVOkmqgjqXAMUGlsCu2ytf8Ou2mi+yLKbDNn5XfA7K4Vf1Drtxbn099+YccdBGDh6kSz9kdAiHmruKJkR9nZnjTJ48koXrM8Iczr8TMvFS5HNfafypr4FpnXYprQJh8y8kbldn///ilSdxyw1UsLvpZu3dpblvuedty37d+d/kv1amZAMEEfrWuzE/ZpH0YQFQyEDV/9usnjkOPiz6d+7akP42NZfFH+Lcx2927anvmsf/4m9hAKsUXNWKL///0wukgfn////////////////9dbn////////////////t3mVMdsGJLLRONcEgAAIGjtlu0ETh8EBDAcCOFFpAZwisEonDIeODUFDARQd5FwDIoGrPgY1WAM+HGRU3M0y+HuBfQDSDlmaouccIgOSYkYiKYaXqKBBJwVoJ+C/GbF8WE0HGbVlcdgn4ZsuCCBqxiL8jyfMC4UyfS1kqChcZJHWREFAyfmab9SOanjyjRRw0MyKFcuDtICRYmjf/1k2b0DBvrPrKBr+S4ohc//HSILk/b/0RtpRVr6vNqGmNUAG5rgRAS2Lagcv+SAVigJQVTRXGa8XZhbuQgiA8HCZJ48XygmoqotL5vSW+bHlpq3X2OKqSsaM7IkWJ4c4A3QcbNFqQQUXyyanwDGBlogxbdaDf+cMtZkhWyCtN9btVurVVoaA62//r/3MB8nkdba6lr7v///rIaRUTaIWRKs5O/0Q736wASbbZir2IhMTrDEUYcYEgwl3LAulIXkFvFgTlEguocYtzVReSSH9IqPqqWdWbodNtCZ9RcbOpS4PEbSgyKXqcwJQCCBkSf//oqTc0mA26cD6kN6GFjLv/FQ/qaT1v/+K329tu0RHzAAaLMyZkCFgIt1DWGGMQgUWPYKRDJDRJMpPiHFqsBZDLWasigi/e/OL4UzuSl7Gvpzu89dr6VnzF08Wh8y5Zrbx+mnbn/vk1LPllJZqSxLUz/VaWtzv3aaNRbtLYX8BqygOMHL262/k0nSLhm1JjU1YwP6FKksnWNaa2WiipI1I8UESbeYpNz1Rh7+ZA4uRUyaYrXPVNJ3//2vZAqBVDVWfiIrM0AAAPQw+r9aSh40uMSA5I2lxqMtAUBcYY7a/2Iu89S//7sGTbgAQpaNj/YmAAZ0abL+e0ARSpn2Hs0P6idbRqvZZSLC3+g5gdL6sC9Z2wd9lB99X4NURzM4z0zBZZMIRwEkAj+hCTQCQhswEToBzclk8zT1j6JcB80HEWfTf/zBRecvnmWYpEwbmvSmLKPJJJHX/Wa6x8GqP//+iogon5L6idIAQUiRLF8hqI4ims3f5SPFg7+dOePoccjMzf3biIe+AAkwhRDnErgckrEEhmJccAoczHhYdFOFo2lwEgXShqDH7fyOvLEZdE4w7tNTU1uVxH1Aqako5RLo/HIeob9f9Ybr0l2N///ymuRt/oDhWldnQiiVF6a/hYldH/6vANIUT7oM63b9Y8O7jQ+YfU15nmB7S8IWypj0m69xWSpv9TaGMcw03//WihDSarhh1Wc3kNCW2qpC7FXazcvCPh6HIMDTc/c7mVXR0gAkYlBCwoqYFk1ijaJgxsxQHCERSAKXgxHpfkDN2hgKishMD443NVXenlo9Rf3jIwhbrwqVf1THtJNsT+xLJY4YBGg7R9B60G5MA1oW1fQ/+7aKHUk////9M1Rf///0m/rTufRusyZB/rY4riXYnf7d+7iq/gCc9FYQY2ZAQOKh8IkAo4cAi0vR+DIK4oaxZNRJtlrBXmdF3F3urPR2xP52ZRXjNarOVaCeq8jTexbv/rDGr207tTWHN/+UdoZyLVVDQvIGMqZQ3Eqtiav/9SZV0s2kmL967RyzWGH//7xkOFuzEI/QUVNTR+MT1LrPOSZQ9DNI/TdXQi7uwbIIemaVr0Aw42zWk7xQy3Z/G3zKVRl/ak3OsDr2rH7sSvLDkuiCg0rnXa//uwZOsABUZo2HswR4h1TBrPZTJ8GomjZ+zg3uGyM+v9k0n0r0T/S9JUHfGbklIAxrJPLz6LMuWRanRAQGRH0vf7e95NokQAAGQ5pWpjOfTBJSQNESh2gQGqvGGTrhUrQ/YLEPzcbU7TKP+cxHf/ggit+/du+fe61nL5+k3gjgl4qz6R80lso0yMHQACo0zc10f/t/qSf/7L//Z0v///qM/6zzN9J0n/rb/8yNG/rLyEaHbIAJ0MmTNAElBpmsi6jZZWxoywLxIfNPS+TQYe/TqssZy63Jty6j/wA7EUiz89xp8InLdY0El+MxallMXxp724+3RmqXFpGU5ZTBERYW8zSH4ffyrYVRaIEwVdVviH//23jGBX932lpKWhq17VFTyrn7juTxrXCladR3lH6kXLc0Ie1Ki8T/+1mfev8fWs2bRIzwr/+wQ4kPb4vB5HgjEPZFGciHsjGyH4VbxjQxXpw/z8bGNuht0rdDbpGtilbmWeLezyDajlXcWsasau8z4g7vf7vl5p78AIx2EuOnNMM9OywU5ElJ6agst1NTaVnYRYZI5tJEaJ54qhSIRiWZ9lcGyRNGbdsOmt+35jfL5YdPHgSC8/PPH+cGCtv/mv//3f/s5Ut//y393XzvFvYAABoxIRHSAEAjKQ5qh5jRxihLUhkGyAAiLb7tut6TX3kaY01gbhSmDWmW7Nmau3+afRp3K/1rUUufrV3Lv40tJKqz/N3CltMuMXN7jdFjQK2gwSaYe+FmUTGu/L8KrogIgKI1PmhkZKQRWg5m1aOigXp9alPNlnCiBRl1RUb5dLzeiqUxZ4aOINQf03LFguAfz/+7Bk4oAGtmjWexl8cFalOx9hb4wYIaNd7UX+ocyz6z2WiuCPZ2yNhitC8V+SowFp7K4srrHqW2Pq2/m2N5rbeM5pvX+LZ3//jwX7lPmf+W8QrdAAInMQIqjDGpDKCP+47g0+38WMud5etPXqwJVi+GBwbErU/f7c3AFXOz3JrT6vrBfmRed/6DUjo41zyJKmRkmVBbQEeBOhxFiJqfQapY8RHhTLfq1v+Vqk/9Tv59U/aiIQjf//+i///////Bi1jvz6dldnAAANI+goc2EzkfgUdSwKjTCJEsxU9JlO2SyeHmtwJB1BbeXG1lqrhu5UjHy9JiOOllR/9jYqHHPACOQRLiaL5PJLH0Wy2L8DIXwbBw2TEmTFFFkTxkMuBEYVGMlUVKrZbfoWZD6CkzALLR0E+eqLk7VKs/22wxHaKRJr/c971nB/XQZKiqj7olFQ9AbajDJOyoSjJ//Fc8M//////k23ZiZZFhTgAAOiKp+8eRGOjKgEYty6bqLHR9YreafAbJY8u90o/PNapXIv35mryz/Pt3YljEJmnmq9JS0X7//+5UjE/SQYYqSYMIwSlooVWhiceNTAsuMiEhHqgCpQTWqs7EF1gDaYqmE2RIYrdaKP6i8alx+tBIvlAEpiAhEyox1E4XlJEah5kiiR4hCIyLq/LxNpnSWKQl5eIYVEykR5YL80JoeBoiUHIqYGh0urUXi0n9q6m///QMU1fb9wrS1gARPqEwoEFBoPVEPCCy6qIENZqje9byp2QM4MkhboOJMcd2Yt3LtPl3lJU7le1u5Yq9nuYd///9TMagDGNJUhh7XIezz/DVLB5iWi0f/7wETYgAUiZ9b7FF1ouiz6r2NTfxZhoVvsvN7ihLRsPZeifLLZu7nDdyzhdwxBFgeFNnG+2a///+NeTDhAk1b+kloHMAtp0xpd5xndMvYuvH+Nz5kF3bP/+5P22lH7YtNceWDHlhuW9QRIk985nYe0haitbv4h033fuRETe/xCEOxYSVv5udUPL6gBIfkEwKlGXl9xgCCg0ZQZV18GijQzs0SfbKH9hpzqKir4WNyrLZNJI8iRYjXBrqH30K9v//8Xnlo1DRQlEtP3h9mp+EtCMlhVcW8fFaVtkDKwQvnXk1////vyakeW16YznE+0gI6cu2vmP9a+/q8bIXv/EYhSdgeFDReV5u2L0BrDyglRDQbiILU9zskQt3Y9ERJLv0SE+w+Itc36/4N6i0AAF4QhBRdVNe7dTTLUxaksdB4uwRB1lzuvxpkrpW/VInuX+Wa78/hYz7flMklr/QZjas00Rbk0lz31g2B6LO9nyfmp3lwGzD4Umh6V01HZrVWyFU4DDOnMP9MyRuJIQbBjHa0oHcKJk//+evy9bDaDXV/bOioAKGmUs6uBAutFaL+y9qvZAtZ6ZnFi+ZmbdZ5xfnOdM0eij76+6tJTUBjsrLqjxBPDYs+hvQNwHbD55Y1PYGUJKXi6hF+E4v8zdh2p9yAAtyCCrQ5wKPoGkJCwykBqnRv6/7XoIdxkcWc53IJbszSX3s8+fWlMekMNXb89KabThOSp9/Y7D97O9ny1Wldyu3Fm9NYr5X+Y5Moh4mBJZqVVY9AJAABMfLcrCuKSD//5nNepu5vPzmXOgJX38s6uBBK0139l7VtiGXR++ZnColt+7rrSo8M2IlnbrxI97n2Y1p6feuS/jF4zxGojPfhexvDvnzyyk9gZQimXk8B3Csv8u6YUVowAG70QgVuaJRWVDAkyFREAxMKtNSlhkNqAwLFYR7iQ9KJ6V/ljSU97XMJZT5Ws8efnh9PS//vARNqABhZo1vstZ4i3zRsPYazxFSWjVezA3oJps+s9gqPJ5y/HHeP15fW3QEFQ0myWW5bu7lPWyDJijEv1jjcvJOAVeWTOIC+RN3//0jqJgmzG0+fPJHDqIcmQx0WWggbF6Ys+6rSHFNDQ68M+zLwDDzcvGdwg2WSfGtL1WsSZWHYGOqFsSrZNltVYBLmcOliU/d7jqrRaAAXuQ6VOleY11gAsCEUpQSBUyHqCeLuonrBrVock8Tl0ik1Fc1DGdNcva+ey3fq8u0NSXbs5UePPx+/boNUxKNcss12bs/hlMDgYjTdxxyxZ8FV0lW8DAf//1Xo6XMyzKIg5NdMedz3/H5ICR98/cJzBM2gdCOTT1WMCaaa6TizSkuBboiKHFWlwc141YupDmeazsq+6ujM1WMAAFwl8cTIAwQVNIy2Cq01UrqijrJZcoY3kqeFh7iwHL7z8WKe5ArAKKA4IfiRxKHFlrMXOxotIzVd7PHlf+DYVz//bsR9tbsMJukwmQLsct+i47zMElDPhmjfwNh3HOCFhzWZnctpQIAEMn//5UZpAIOEewlGcodsBayPq5qbVSrqt7To1KoTqE1UaCN4jWQHE0aiuoF3tsIXqLtEi6EVljIrUQk6h9LLylydT//2TpKuV2usSZ/bnQzQtgAIewpEwlNY0ArxBe4lFH8YFYSKESWtqkZhaaZVijd3+iwlIa+Z/eUJGpuzTuDhLOcofN+qVOZgG0HaN11XnjozYaCf6pAxJFWC2g0f////9j31HW/+ZGJs331NQoMpausoh8IlT5wjyLvbsrHV9blOSwpIACVxecWWWiQpPwQBiZJf4xgUPWRr+cFD+NOFPOCwZRx7W9d6kjU9WjVNXqZWuXNaqrtaDl9Xe7kD81e/USh6W5SRP1K1+YIza61klxJobTiINKbV+f9V2EPUXNb8NuJpvOam/s5XMBiZqMUK3j9TOvvPsuTynWUv/+7Bk1wAF4WbUew1PgHOKOs9hcogV/ZtT7ME+ChSz6j2Xtfg1ULq4FkG/K2W41X1yzCJDmp5NWJqHQx+ctMzLxIm2VULGwSaQodz+ozJVsWWzqpBEGf7btjdWhAASfJAx74JdBTZjkFrDlEDkU60vCzpCDMubJ7OT/vgNY4jGO3XzDZXOm4zIzNm65U8aJt/P2pG7+N1vK/snUKHFPv0upFqYwRDQRKqz3B/DZF46ZGMAgi0zf//6j3Un50hliT8yQPf/om7f/6m/OlN29ZBal+pL1o+p/W3RWaqqqs6FVnJAABvCw11IGKczIoAUC6TLgxae6uH8pFDXlYdDdR/J2HH1nuXZZu1yn3d5Ume3Gx1eUtzlp6rtu3/63y/g/78YOpaq3qcUe5s0+JBVCtrW/q2aGIAusCWqUMAiWUlvpP9aWxsXUjVlLP+NJ9baJ0erfpbJoiSjI+WL/2qb2VlVO7zGTEDA6a81JCJEak081W1WF53X3sdwtzH+dr7OqE/Lvu+t2d0RAAD/HB16F9GC1gcKDincSnRLYStW+q1ckEOsl2z6vAUebyd/HVfHut6vVqazprcmw7V3cj0u1z/uZYXNZp1z+qaEWJcKKqxWHpASz2UeH1srMAgMGnzuAQpE01o/U/6q3c1QroovqKb0byRWtMsGMQ+2PIUjfWBBQRSa//ctRMsm3OLHeH+sKhyeP47eOZlORapFeuEJlvP8xPbbYyzY3/mP/8w9z/3rrPngtz+JftqatSVlIAAAXQSCOabiG0vEJSQ0Ao6OozlMSNTTW3/o4g57XXbiEkhVe7fmrfMM8cb0xZuNgi1fGlwyfP/7wETLgAUuZ9T7DV+qtM0ar2Yv8xRFo0/sNN7iwDRo/ZgjwCHK/P/VitKcZ0KWTyW5Y5hXIFwdxWcgCNjZb3PdfFJwovT1I2O0BdRf//qTWyCRmasZ1Hp4umSbay+p/+kcNj5j932rRQWyF0NBMkTT6wc48XQCGX+nBcyXl636ZFf7PyEmkC1oZ9O00aGiAAAAvsBBKScaGrtFukpacBGJZJgoy4LyfpPhkz5MjcCWwI88/V4/EO0li7uzzCM1+xSM00Stz3X+gerz/uRd6YHuMLcdA+rTuzG6plGkWDQUqSC1KFrbL5ZjQUrSwIc8UdmwQQds9//8wYXZ9/Jl3waEv1c0aNFlKrZq/ZQlET//ni6s/Plf5sQBcRa7emKFBUXFhWRhIPB6NIFa8PjpqRlj+htOZlHCrjhtv3fJUiYwAAAvhEseiJkSmSS94gCEYLvjwCAyNMcnWLNxe+GnodKJQxZgKkyzu50v5Z9y/WXxeW58w+mprGVr//ChyuvUMVI1u3E3Um3nHBYdh+sBkCg+XTUu1Nu5D6NzfVIsCGgoDf/9BB1HjTVWhUySb+s4ZFT/rNikSpU+J79RAYwsQw5sgpeRgPoZSDLIFhZ4v7S3Wd0bn////PqDlbMzCGkIQAAAe+4tYxiGhWizq9hISFqomXJWShgMqddxojAUfyoLMLqwznhvOPz1PQYVpPUmJ7L/uVo5T8//3i7t7cZW4VlcpWF8HGehTYzhdaSq2rCJ32XloqS6tsHLU1zaWCWGWML//jLyxcVOE9coNvGGk/XNtknKvIuv+JQ1Df9dR0Rxxf/wUCZldrWouHzUwZ2MZab4aRX8O69dV/Gi0XPrMp0WVjAAAmGUiLkSWLVS8t2CiB4dVAGDK8zp2UIvuTDLzNwh6PuDB2MZvW8q/K+dPMSuvqbZDP0NPe+1Qc///8525usBQGmZzMjk0iXy0B/V5ENSvmWUEhwxpbLD//vARNCAFPtl0nsyR6Ci7PpvYijxUyGfUezEvipaNCn5mR/EZ+SO4Amh2D6//8yIiCbqVEroAJJU0RmY/8gUxfsdGzs7GdpJEEBQRK0pBZzMchJlFajytV//V1Xio6fqqpESFoBF8FVgepFJlQjCQ6pXkQ8rLYP/NMMa00+lemWsvkcNrCfEonuQRTKv812ct1cW76xt9s8oKPu/z3Mcx3MDIKIzRZ2GOPM0Ut9FkBC5AVRK4CmfgPOAU04Zm5UEMkMT//6I5hOOl9CDlGHhGZs0woQnK+rzEQ0Fg0X/WcqU/Q4VFvXEUiUDqHMNy3/41b/mi12KiJowFSAAAAfmxQu2SHzAYoLLJcjIqPMsRQnFvsTpG4/BteGJtva9vmOGWd3Xe28M+P5fodVb+UAWKmFj5nCo9lVAtFQaJeSGGR337YeyxeiR5BoLYZwLLYvDb7rvUGVWXewwDLVQtDSU1N0E3/yhz8irnkT5YWwlwWBoSWn27G1Bsoe//3B+HghP/Orw7+nf+3auHwtdt/2qLmpqTfcku2v1F5///SPJHvRWSmqq4QzRyAAAVyWIZcQiFgIUF4S7gsa+mqzlssMrqbhL2sQ+8baQ1Joxf+62Nz6SxOYW8bmeWqTGlq3f/8fr8x5q9L6GFjL0FpDA2MNK3p/JYvKxQLRIsixItCsbMAo9ipJW8LBgOywFJvb/+eQuUIiEjLn0dS40UJQaI6KSCsTsPXKbkyHHEorBbJH/+pK7t7ocEkRL56urKRExhAK5gqlv///i4er521+qbVDhABmDCwYxdQchOEPGhJaMX1L8Imo2cUfykOlgHB3aDoGcQWGZqic9f287uskqU8TnWUlW/I01RJUUMNlFKbGxcIoeMQT0UcWa5q5PpFEbpOmpFAt0XnQ0FJ/9mSRdaK3TWktU4YK8vs3UVOvk4J9N28yf//pCeDWrzspxR2ZAAB9FDgJ4YdQVWZDgIYv/+7BE8wAFZmhR+zRfiKas+l9iavFPtUlX7DJNYmKz6j2Gn8QiJTNo7ypYLTkYn14bzrRnOLSa1Xs2Xy3q/e1S2JTV5f1nQ9v7lF78f/+ZaxhLNUiXurXfrDAG9wjoICYSr1jrt7v7f4IjLr8AgG0CdHv/+aYYpExlMU+qmoKmR90FCP5rIx7HhUc+OEckWKkhSRGpbyQ2AQSHj6CMMPqYh86pf///8bpbh4k0MyIAAAnaOhuARqHwcRYFDNCIos4UsRvlyyU81zyBzmKP+2lLCr1XWFNrOkwzztX8asAxjOpL73KCQ4Wv/CbdVk+LxtwBRU1nIa3ONTbIpey2AzLVjCBrkqikZcWgXkZIJamkZgMGzAkkL5anSCHkm/uWC0o2l8qTYm0CgfTNDgncrpvWaGhNt1/mBcGMHv6LoIITA0N7LQ1qJ8UMSTPoHXLBdLZ0tmZbzMl50w/yibf+Uy8peZlWiEzAAAAfGAoVJHcHUlJhUEmZTRcsWFJgFp9VUXCzSFQQy6K5uW+kUwgi5BEXrZb7llXxrzd+/neyr1qL///p4ddqaf8RCAJh83/l+UkJSG5yppQISA/zBsIT8y3ZO4HXO9MJbA0wNgHYhWTBr/+GnWjYP5lKx82lRjKPmUeofPkWL/5bO6SwBw+v8lG0NCx0hSaZAsfYT78xBHHwJDdPqDfarjp04bLdIr8P//91f//7ic8tLShERggAAHt6W+L5355CotmTBFntyWky2kWI87cHjb9waexR6nf3lc/s1zPKU4UlZ9OU1enxpqCTf//uPw61l9ZwVHLMidiA3/bkkegVLGmmRSgcQXlcFpMCw//7wETlAAW/Z9H7GqcKtYz6X2ZL8RZhn0XtSP5qhbPp/ZgjxMy8LGhkC/EMK5C3QBemZ6s8bf9ykUDM1MDAqlEwKpmiWTQvkBLAn8xbHSphRiH+cJgEBt/OnG1KmPZ1fuNgLLpNOF4kljQqN2UTRiVEn/FQ3/U/A0aBtdVVTOaoSAABeVFEoSKQkGZUSCCxbvF5553VXx9h0ckjL5E9kY1FoHwrTWVBLt3eZ55ap6sonO/TVuZWf//3N4284eLBhe3V2rNzKbg0XTl7BBcicwuWymim4snugvAcoUXAYRcpRbZ//wiWEwjLLjnRocgHReZ9pKW7//+rCRP/XEdCYJIF2H09/Mg8AuePxiJA+LgsfeSN+G//8an//+NW7qiqZHdkyAArwKEOc3cGJl4CCl5YTMgjNfUUXU0FoMM3X5cSERuE4YTOVSvVov53lNyYoIRSTd+auWqt///eMtv3aUkGpDLlWW6aOq2ibKcojQZ23ylsWICZnPSToEeIs///RzTDWsVmraeaLl0Olmb/xAWDT+YxpuOnPR5FnoEQtB+aZKnmjYwaMjlGoM//Q79U4xVW1mZKIzGAAAboNIxCACG7TC+4MGg+W8edVdTKDWStKZ1A8GssneReL8ylE5GOYVv33tW3jTSHU1z8bv9//3y/ljOCsGbfXjctzaM07ScwltLBYfvKtFH31BYMLU2D2bf//opRqPaPtUQB68xBu1ujc9heV+PDQ4fIRFJl2WpvYFAgFDKXKORL+YPMVd8S/Fm9liREiQAAAC4RvkU5VlMAl4wqMX6nEvy2CWjD604zh4XcZ+98DrzvTcssVIGlUjl2f3LWpNP8ieqOWw5nrGHbH/z9dc+lgsA/j3rIntqYKDip6GsAK2gFsx101lqXFrz7RlgTrAgCpJhBAHCbq//8KUmeWhY7LFXHJQgjv/k2VSr///Hgdzv/lb8oGwnHyYSD0OdalEoHZDn2//uwRN+ABKln1HsRP4qPqzqfYifxFcmjP+y1fgJfM+m9hR/ExbTWz8m63Ld5n////X/yTzvthp2cmqplR0JAAAnpCN4IGkLDQoQQyZimWrtQ9ZzoN8zmKRJYaXw9K4HiN67BWVaplauY4Yy3eF6zVv1LWEG4X//93oruhk6bTaLqpssJcFCI0aJXhZAPKxd1M6WVVUZC3cCO4+oShVd///qIox+NWikCAuNehw6Pt+bVGJEST+bYxo0HTprq+hw4C4dZWQshEaVjx7f///5otmuY2nInYgAABcqnaGhhGYoFDooqjER0ZEf1QqByONT8GPvC71Pah6U5y+tZn8J79U9mN49+ntW8+dmr3///8AynCZL7wiK0W/61kanWcA5fMIJZDtyVSWPS8FwfrsoAxxzXX//qNTyai6ZMkgWnMi4fOEDIkn50sLb/zhQf6/dJkqP86Qc2f4MBBhQr5ShGkeDeo6iiCOqJET05nMZw6QAAN6MhhIDkhYlAIyiIqK8RQYQDuw2JuSuMHXi7pxbmcogSk3VeeE50vMrONLrGHqXOpMVrEToO//6+7P1X5Q4qawPe/TlkLGw00fES0NVrUuX6oI0h2xsoeAp4cb///y+RvWf6hxOgqrITVNHU1hQTM3mYRDpmDymMIOOFPFgBBaiSHIco4UfQc9R////GCrZMXCErogAABOOBkQQOHGBFmjKQ4Q4wskup02o0LIMW2lUNxt0om/kSi1mGKlS/y7yns14hZ1Vxtbpcbu5z//9516lyiSeUBUnXyzqKLky3EKjVBG30ec/xr2MFL3Uj+QJoB1EEt4/v/8WkkPzHXepJ1jn/+8BE0QAEx2ZS+xEXuJZM+n9hpfMUXZNJ7LV+IoEz6X2Gq8RScQ81/I7fbf/5zUFKr/01z6c2SWnEFrl3qvIowBGv9W886+/MThbW6+L55bX/J22OuclURURAAA3HIA8Y5lnC3zsogAnkXKSUVtU1wvtBh94urufS688C/vCfqzn1c90sorSmhbrY7cwzpKsYsf/3J+xl7A0JYLIuPLv8JDKFSJ9RCQJS3tjP9XXTE2sVoXmANwBe///qLI5KvUgahIHpK3mD8+raNZsKI35CL0kJoXJKRMJzKWJS6uPwBYniueagsFScRA+Lvo48Lr///5Aqaq6JnFNHUoAALhKwemKK0wpwUBFQ3JLnU5d1m0rgpW+YZbTNu30GO+5L31K2VbDlveOdmt2ms1KbDK5k+07///wxJZTjIjEAQem5d9yFoFkxUFryMgknPS540iilEKgFAHLYJa2BRQGWZGzVs9v1p6yeXG1JqM9RTHmigy1EgcSWSU8gqyjE6kO4PD+brlasFxUl4MZdRYMX0bkkcRFOlncMrmZVuRKpAAAL6fjAC1pMkg8aY70IollV1IjrycRtIYf/N6rMhp/faTXasjhul1T4Vr2Uu7qCLt2vhrXyjuH/hMzGPuKCC1+w1+HdEIT3Ud0LWlxQwTH901VMgHA5XswTgtmZtUbmDf8yo2KFqGdSyD0ctU0qzGjQloWV3GiDo0X9Dc5MmxrHPMPBIqyNLmuODwz7jZ1Gf//+UG1/u3lM0M0AAn+SoElFmjACRgU4EM5KAmTobR5UrFF5v09EokjazObCH+zq/Md1Yty+xUrYfhRYVcrGGsef//TVMM5Qmkq2TyzPXaSR14kBTJBPrlCcM6bJlV3GEAAeEWb//6nVUQhhaeKhxMRPUMRFKxyHE447ETaHLoIkFsDr+6+DB2UJvcVBoFQCr/lG+pd87OxjW1ZAAAvR2Gm5Fu2lg5MPjAxkaf6s6P/7sETzAAUJU9L7LX+omsz6T2ZH8RIFbVHsNV4iUK0pfYafxXsvXKtlrbrPQ7Dm2XgdBdMajeMN01mrdjlnlW3hhUq8s3OQTN63/3Lkum+O+QIVw89j/2h2cyej4WOUPfi3hau3JccUS6vIwC3JC2k//qyuNxOTKPdijnoNR+qaqjerKcqINzE9nOO2fY30joOwsWHnKvQmQOoWlH3HVfyIqzM1MAAACcICKN0dQyGuOAJdN3LZQcyBW+kWm1B0oXan9RLOBP5jS01+p3l6r9a9alkdy/7O7kh5//8xGLFd6lASKVpLtX/zch4HffYzKlvNNXJS51+wAAgJ2geYEYGXjj//+JlwmV6S1U6XwJiO/wWgjXl/70m5QK1v/W/+qSJv/qRABSVf/5BqyMERFG6b/8T//8wt+USmv3LtWNlBAAAfXEVqDPwOWWoFSQYMpiTLphM9Vf1YZOeILSdJx39kMlajOZ18J2mwvd7zGbxrtEm/znrlSDcMLX/8vtyqbigoAgSeKznvIYKHi4uokYRzTkiGSd7X3KAGrIc7YGURCkDVv/+IBKYlmbhqMh6TO9e8dVJX8JMIHAUNr/bWvjqIb/qSwaPX9ewb5xGRXdLJr+J//+YW/cjbialRI0KAAAXTpNHqCEoAB0w6PEjCi6eDZneTWfpW9nEDNAgWTwRS8p5/+2LtNfqZ5XJXVtaS2kcTs0vZqORn//9UD5wTdsl4wxQ778vvIqwMDLggNMU2o5FJ0pDD0ViUlcoaSu5PvmB3sHGoq//3NUy6dnj6llx1n1nSVGKhT1M1T+z2MRlyRP+k/pN29GYD6Sf+MaUikkZd//uwROmABNZn0nswR4ieTPpPZojxFSmfRe1M3uqdM+j9mSPcAB9Q2N5Rm9fX/3zldyklb24iVM2UkAAC8RIl4DBJEZjQC+AwI8yNEbRLZhBihj7SSSPZDs9PS2zeyiFeWazq45c5GuVWV3aamypbr41f//rx2Xw7VcBpCdDc5VLJjhUKKAvSkC1qWjQ52JTseiLImlxaCHGAbILkGr//1UVomM3orLjqPOWB1kupOtFla/SXuZC0lA95ij5kgt1t5u5KBjV2V+JSlDpaR3Yyy6TxiX33/NYzxgEVi4mKETNCQAAH31B0IsGVQIPEAgGCV8qO46qW/s9jcuda1jA7uP1KstV91aS3SXcpbWktJcryGtFH552Yqd//uROKttalJIira12UyFyaZO5LGo0YDmmcKX4kk7Dq5KqmCnb+VYGCkAdn//6qaJ6ikdviWeCKbNTj0m39/DJhkPDMnR/y6rtifwf2V7nj0CLT2f9ZwzSQhsqONrdbv4///5ziCo6qvrqdYyVAgAAJzCeKcB9wvoiCY4CxwEWTBwwyAtTL0QEv6FkMsgeG4hOO7X5Wv2LOFv88+3eZs0p6SR42uPja///col8t7RqVsmjducvzcFOdPMIHhA4gSThqdlLoww7pfNm9yRAKgN5Tf//mCMmnNWvRdaBSMjJZ1XQb606k1lkfBOnvWk7MszNXpum+ikUBGxJoJ93EVFFF1HIL8rG6f/i4mECpmsu9dFhAgAAtxwDmkyUW1ZS8pERMaJoPFqYs4C73TirXX6dapNZv47+NLVlNTPuG8e1OVqflSkk/NR69//+spbvCVvkmDP19P/afdev/+8BEy4AFKGhRezRfiKUM+j9mJfcSpW9L7EkeInKz6X2Iq8RphBzNAqYtS/J7mDvK1N7i/4BPCfW///8e8qMV+616E/cTEqKubflQhmpIAzr/yb3A12Mgq5v4PAoAjQL7jIRGR5oeMQd/+olPVW4rqypAAA7lVighzQ+bdRIIkCmNAzQN5AsCA2GKfZA3Rnc3S1ILXzOY4ZXK9vXKe7hhjgodXmaket1Y7b5//zC9S6fEQnIhNnoa8elbPG0qM8EewWVTnDORzkejoYyD5W/4L4pv//zHU5EQoppE/YmGrM61H51+quQk6HhSlvj1bSQoj3b2ISQCMbGu55ViNTx+YjqYc////qUdisyrZTRUAACbyoBiIOCnkrsRACLMNSFUtSPWEl76K7XBBESg+LfbgXv3co53mvp71Fn36DDPW+bmatrn/vsz3r1koVaW0vw3BPWfrcsSo4RY03a1fh+72MwDFbEKBECRMr//qzbGkzDkLsejQfK082qGHHPrYyg6Dss//jSW53PceAMEWd0HCYikC5rGue3/yxnP/ci+RESpEiEgAAetaFigcIGQTriwoiLqYF4nGZknPCGzqEwC4EExKC5iI7g/n4Y0tTle1cjEqs3IBpJd9Nnlcgef//qZu7G8kpxg+EOoU7URaQoaW2CE72srMpfMUFdBp8rmd3wuANmNWc4LSgOhBxun//zyzTKzyb7gglK2Y+kJExNPJlrxP6m1knRjVf4yLhB0oXEMOqTnA6lvSJo/OIYjmRceMQieMlh5UE//lp2qrEMkQgAAAcZcrkGAcKGSwdP1C8ujDaMDrx2A1jNhrVqk9H7bi1N1MYHosbe7Ni1bsXKSUXJJ3f3I5nz/3BM/ljRBmBKLLaaVV8lFXdoo6XGI9s4X3FZZP07Sh49G66wYQ3C65t//7oWMFRcfK61VUND8z1i6Ophl/8DUtQy3///v///8A3qv/eTxe3l6Jv/7sETpAASpZ9L7Cj+IrOq6H2pr8ROVn0XsTR4qbaroPZijwLp//5iSkmlW1jQQUFt8zMoAmYAACezGxYGRgLGCjUTMYUWFMANk6D5fSG0iXKjrgQl3orLvj1PqxzDPHuu75WsdgjD7P45x6f5/53JVp+JudNgMzQI/KaGdkrFCumNN+Y4KQbtPnX7XiMbFCJfQNnAPwWnN//68MIajJTKuoLgOb5rUYLjpkf8lwxSiACqKyPS2TxBmpSlr0tAkgeMd7GqDco8Rf5AWk4vJmUMmUEAADd0gwkGpvs+ghSGQGgKZJGNXUOkrspVNvD0CPdUh73b7e1MSzGxF8eSKtKbte3O3Y5y3fmL+WH/8Zwzsy4FBDXLVJXd66RexoeMNGFUENtvD1NKX5eFnaCsHwW4IBGAti0g3/8xPGUxcwM0nWkmgszGq1qkjrHpj1q6RsLkM/rSW6JkTBLsykU1LTLRqVhHBFTUqFtzAzkUPJsicURMNDdXZX/ZFlqT/3XQb2UNrYnMUkZYgAAbxWaKp7FKqYu8CRLNDAoNiOCVuaPVyo3WApuF1H/jdNbrWrdF9zKms3KSt8vzpY1ds7j1z//9V7svmWqICl/NrIsMPf8OtGVbAxrCFwNs5f8jq+VnPxTtwBJB4q///SN1U2e585xBPm5hEu+xuqFShK3s6HOxZ0ajrkyC4MTVNQuxxU6nOfQt/khLA1dO1SirqQAAQvOEsgZwUa7KHVAAOFYkRCVI3eZblAUKsvdD7lV4JblOb79V1e0v3Pyu3Kexfq4yT+3Ifl17/uY5dyfEVIhBBkKvU1WPKjjmABMypk3HQlUgkrERl//vARNMABapn0PsxN7qUK5pPYarxE22fRexE/iozM6l9hp/ETuWWVghwsg6r//YiPso4aXKl5SWIA/LOfPuYep5j6roaguFyf//9B4Fp/44PGj5VWc0cfObq6s3RDXvJmi1i/vMozSVbAATnC1VEwCZcrAABkxLa4WqMYW4tXqszeFymnyt7bVPG3K5am+V6fvPwtazkOpZL91aXeWr3//5VeZVeFQjsQ52NTkqYosyWy8pNJX+gp1amGcpaPFbMKA0kk///YeZB41mocxqmkRAWvoo61H184Uiw353zvZ27uDoznP7tP7ormp//nNlVm9y4c0dUAAAp0OIngqDe8viXmTYJmF0HqZqpq+bTGZ22cP5Ou1FYTDEnllPRQDRfcwpbsSj1Nk2Ckr43r/wZGreP/jYp5F8dEGAoHONPFAfXCfyfWmnwLyltDDc65NtygLOKvE/gFYAwRsn//02oV0c7U6ygS+iyzhHoIp9VSRxFxzDZD22qNLU9OukWBpEumhqabUQHElAVYo3yHE+vCmsLBCYt3WfqGSoSAAF+IhKFggq7GHGOxxc3w8VQ9fIEVpqEI41qStrFsLb845/bt3+ZY5Wqa7RakdNlSSrKtyx//92xSyveCCyVDns4dGVwzD7WZgUKFGlAHZwcOSS2Ow0TEikSJAgqA/t//1JLlhkdSamWpZAjyn6iPb9l6ChOpp9EtM8zJ27ymXUVl8zYV0TuU2dkTdOC0BeUKtlsvPifTnYilAAn7bmmRGVIAAH9SgjgApCV1A1Nx4TEFA1vN3Roh5nQ0WdZHuQW3Voo1Cbc5TWrN2OZxvCbi9HHWvwnPGxcyjkan8P/61yU3cxyyFjXr2d6Lv6RQrtyOPB9ymstdGgn4yssKmk9hXQINkyf//+n1I9N4qbhjLcbXxMMPPNG1f377vJhHr/JRkdK0lj5YjkktdR9z3FYOxBnVnKorTKB1CLtJVzYr+f/+7BE9YAFJWfRexMfuqHs+i9iQ/cVpaFF7E1+InutqL2Jr8S/6v3xE1LXF911VtKJQiIAAO4XGWckhZBkhZERVZo1UGBTAFhSguMnQ7LizrkZWa8WponVuVZf+7ur+FbeVWc5lN47pKeiw7/IhMyztCMzXe+kxblMsdmBsiAZmIXuTxmo5QS608pGOExKMgBiEAmf//vQiKnjzZZlSnS0f8c9f2+nzLB3N/+1kmebSe5k9t1jqYVNtG9Q+06d5rcaysEnWvhmDsKpIvWL3NlGVkJAAI3HRAcKGHrBQ8GCA5EZGJAoFZMptfgxckEraZlalkMw46sp1T01Xedm5V5rV7bu16XO1zsu5/f/VX5RXcAdSWpN194WiQJuMimjCieR55VIcsLUTFgWOyuqDbgZVX//tvQgHWkuPqNRIIJ9Q3ErC//zEzg2v/2GonjkPzCZx1Y4JQFjsqv5M6G3c0TXwO0/JZO9vLxUWViIAKvHFonD22AvoYQEgFDFOk0iysE1UOdM1t3I+JjmipNvgIhUaS/toapGkUWlrbUEd5L+CMmNqPEeRIqlpbpqDBBqOwBfhqscJ02rRF6I8MzozgZdIO///PO1z/pHUq1Ey1a+hSQQ71oMxFz7/SRajoUfvYZk7OBwlZEunT+997tXkOztkAAz+pWPVAIHRsjTxGBkqyFSLVRzcFBtfjhuQyJ0n1f27KLl+9Xlku7nlduTVLeuN0l3MefrVjmv/7Xe7lSgUMzuU/ucSkY9PR8aOpF86Wi3WpZeivLuRMBQib//Q0sVGRhIWU88808oziOHb6HF//nEY/b6tLcwZFU96zaBOAQUGP/7sETTAATIXdH7MEeIhWpKX2ExexHhS03sKR6idDPofZgfxMSsTk+p3/I583MIKMhAAANxBuLSmCaOp0gIHEJ7KEv2CQGoZbYq9zj37zxRSMz7tw5K5Vfn8O03M7ExbtcpqfDK/ypMv3z//WdR2KjtiBgHBtMgOEQxQoMBzMQe0BEMyTPydDvKRfI8jGpQ4AJAWVN//zi+rdTEOIoVKDKqbqxY1ej5M5Aeu/qa5VCVlPkHNMmHCgElRGHi86ynIxuxyG/M//5NKp/K3WZoiaABL8ZFGjV+gUFkwYgou2rGEnk106sWq0csijW5a/0RjlmQyeavS6xvC1bv/nYfBP+7SySA7nXwcnPD/mY5SunVelucOzdLc3VUOe65BIElT7d6te58Sj4OGp7nAMoNX//8fQ4tR1ySrMo/EQRnvmp3v/ipiFGlnR/w0/9HkfV+hAghEIqMOcYqgNQt//xFXXVUpHCIAABep0EQBiKpf04BGScTAR8butNmdIv5w4YeLkIgKKWZ+HJVS2aXn/q1O6itvWHOZWr27GPf/9Umcl3Bq/ZDA+XLlKmU02iegxIUkIv2e39qjVrvxxh4JFiVP/8/nnGGpN1NQi5lFJzapox8xxWCwIZvuxT2PaRPssN/HR3XVQvp9H/IZCPyrc7LhWqWiAG+BxrBRbrBmxF0gIglIIx23ATkf9e1HDbzOBFZ503iZjJ5Xfnm444S1kTyy8enyugcVdIwV5dRNZDQz8UdjA/WRg25ZBDIPskdIxLxBRBEzOFgMfJ1///1llMx6oOi2sWEicfyNOv/mpWLk8X/+Kq/lOYqG/mQ0bUyediKdUJV//uwRNSABKdV0vstR4iNKpovZUz1UDFNTexJFWp5Kue9qifUAAAA4ITCwZQIHR0BIsCAO8SmTQY6nQ9ThrDt64LkSmYfmMvzQYZz9Wks0m97uW7VatSY/jhXj773///pL0pqyEQAhoBFobi0fgkvPPwldBhZg1NX9CqZ+KCoFggOWNYf5kIGNTB4GRf/+YtkwtEzR/LIy7KUupIgqKJ9LmiTKYzFON0f1HWqtl2SsTJ8kZZgh4jGE3GlE1R2vbvvVFl0gACexgseVMIcHHOSCiQaCXNC4QKJZyXddmGl4xVmzzslgSPxFOmFUtXBhjUq1FvstpZ6z8Iea9Gs7WVBY5zXfr4c5HUeR7unou9xR4VxLJIPIj+Umv/VfWAmzmEJSZtNBKxcaX//3UrkRF7H6DHZQlZlccSiTl///2LqOLr/+NLVeihZvfb+HUHW2y0Rlt3M1amSsQAAD2+w0WXrC4b+kSwiAVjammItQeBdlnKzHCai2WCHYkF99IpVztSyT54buTlFT5XJXIaS5V7jt9rH/+5RXudhti4tpC7udLSp4ky8ra4DYQWjA0qlszKqAZAEIMhiLlAnU+bf/+6bpGtJOg1aBmPnutKW1NR1qsmookGNH/GqtVob6DB06iwbX95k6PF3mLuFeLJ5uZfsisiAACPA4K2QWuaor0OGQoLepUpTJPKwzzyJ3Om0OMOjB0RtZyPtTOay+zzmsrFnsSn+fzv5z9/nfzxuWOaHDA4q33XY8spgs88QzIms/ty3v6GaWDgTO2BwCJv/+YWMKC9i5MchRjCzkROSmpQ/X/q5Q5P+8n4jsOekhdZmIghHG5D/+7BE2oAEoVTQ+zJfiJpKuf9mb/UQ5VVF7Kjeoi4q6H2Gm8SP65vFWHZgAArgGIXWnGaVtfE0CFbXS0AyEsoj9SqpPs+iGkWa40wIq01n7edm7cAZ1tcmqKapan1bOOr+f8z5n/Mrlar2MzKFss+pqVSdKOy6KyWt02fKGe9r4sqD4JhkkApv//215mXynpfmCPrfVyhhe//tneOBnv//2lPJfDSLQihdZ6UwUutaDJ26u0JGQgAALgZHBaRriqXyUHEqZq5Xcogl+Wap1DH8eGTPM7jmS623kSwrXN2O1fz19e/8Ab3rX7xtb/D8s7NNuPEjyz+VuX/WgpddnALsiJRVpqrOWIcduX62FiR1H//22kuv/TqLFxP8bjjpb/KmmjFg7EW/+2KtcoebTnS0bU4CpioOim5mtZXZWQAEuFsIci0bjRsoGgEdgSPITUVi8kUVYW19K6A38ZbF4g/s7y7fgLDszzLO3cs6tW8/x3+pX9rD/zysfQlQrO7de/yMtYVrrL6UwDFLspauMpicApqY0NsFMFu3//tyiI3w5rKkg0HfUdrX/wvdwNIH//rC9k9NhSYjljAjtZrCv/d2JiHdIAl4LDZENwLjuiBSFoV8IboA9jA3okLLXLZBUpHXjdJDt/tS5GO41KklXjTJxkVHUUndfopTgFQMxqUfJ4usQEBfi2r1qWPwjRBSQ7Sp//4lFkTSP/e2prFBPNTAuIAso+eeVjexUSiJ7/P/jUr26+aoEb+IPvaqrVWaKACzAuAUWQJLwUiEHCwCMLys2QagBs0dcuNOM3ZyYDksuqdoJRL3lwt5Vq2q3OR2MWcJX//7oEThABQ2UtB7MEeKhgpaH2Go8U+BS0vsRRVqFyroeZajxDHHveb//kFf5KkaTBuXf/6N92hV2jCkQ0E7/4X8e0pQHPc0A5kv//HMzbT8HUw+IFaviKYd3/zXoyA3r4+2q4zXpZHQsPKnAzdM5Qyaj97MdllmwAG+CAb7ucLSdwABacu5PleryoR1WhTZJywUOk3lraLTe4VGV1q2rVk3GjR1vPmi71TePT4pEtUI+KmfLuWjYI3CMAIGFsz2i5TFJAXskVOLQMj9X/akykETbWit1ulNtSj6Z5Tat60kmJxmtrstbnEmPXbu5kQPSbnZysQ0dAQACuBmRWyCUWKhlEbggaqORVAsIX9pmBZSmKPlCn2ga1AGONBTWc8rnP7uhs1pDRcs47+PWu833+Saar1EEg25a1HOU9A0VCCZo0fkUmz4Z47fhmYljG/XAN0pP5z/1jHkUu/9J3s069WgY5BU1PPwm4Lz/v4UdCJR9Comtd9aQNF141F/lVTmbKSAAXgAMioDnhEh/QxReUv4no8SlaXjcE8GHQY2eIw49FHTRp/+16TtfK1nr7uFv6samrVvuGeN6xjj+uZU0tFMqdyGrlm77pFfevOCApnWbtq5XgIkCWgjNyShGlw/oVdL+lZzxMvMxy1C9RVciCMlfi9R2aMOB83/7ocsZSS8XvXW4Lh+k2xl/P/7sETMgAP8UtF7D5N4imqZ/2Go8RG5Vz3sRR4iNyrn/YUbxMXbIrIiAAlwokF0kMQeeNiIaHJiyZDLxAGHmxrUZ/FXPnZ+NR+KtNp9fhqtul5XvVecrP9QUlq3jcmovnq/+qC/RV4KSqFpSP8cZS7aNOb6AiDbRarlrV54xEGpuDQPilumk3+2alQClG76SMHHYmHvN/dJ0f/3R33cGxv/+wevO2JEHru25oE73D1ada3MynJXVEAB3hwBAMaCvCAzAEtsoKWjR0lSPUSWHkEseGvSuRWtTkH8x3la1Z18v3W5hMWs79Jz9zOOv/88cLj0EK5uGb+dqAn1SCmZwgUzel//3WboPGdTdKC8mZ//3Kw491VuIZzTgnXnmAyWWxbfLLAu6AJCJUTf88X7yUi301Eg18+L31XVszM6AACnAwABgXeMkvDJEb1bk3WdsNSAjyi7xabaGE/GHHFgQqtbin4eL/+LC30zTcSTPgMFv/JrMLOioECd/+ERsIjb88xMWyLN37chKij96A+TU0b/3dTWIidkUmIz6SIbZj778+kxRcDeWbzLFkcohppCbSqEJhlU9bt7rocuSABLwooNyTUDhJpgrxVGjmj+XmXcr6YZ6/z6Qw/W2JqVzihkFjjUzTXvbL34fMtMRt7xCmx/i0WmlcIaFm2Rq7ViFikPUUDCw7piJSiHgJ6zvQ8h6f/9jiRkyKKCSbIorTN3KlIIVsZnGQMEsuz5zL4OEsa+60ENGpZkz/UXDYhlLn1m2qtLtkAN8MSBAUESLbqlUZfQoWBrIRK5erNgEObe1m6mcaKt0n+9quockCs0KIw4xVFM//ugROCABDFS0HsHR4p+SboPYep/UOlLQew9r+n3KSg9h539byS15NZz/S8laYBDIat4lj2OQydHqZYuMKFndV5mLDfcUGghu3/6tU0aoUHHRT2qG30U8waGGfboTLk2+71ex25prMc5Vz4s6s+9+4N8glACbh4Sl4VyLWpi2JkImyianOtdr9xiLhVrTpujAMKcOExuLN0idM3l6xeszaTkGNVIuPZF/UxqmPgN4jlk9JoYwuqi+MGQSYPdFRsgLELQmxMEEIP//57YnDOlbc6WKgRnKhN60CCJj2NRccpZeLaOBB1/9bvX2kjN84f/of672WdZhoACbgKDT4RQJQz5VEsGheX1axDLVZiBF5siZdBQECQ/yIEqgwoUebr9ZHOjY5NmdWop3+1l2mBYNB+JzTpMJh08alYgx8Xd6R04TtUB6Ze2v///2fyfpvMsuH47UW0ks9jzh1CXUf6fuoChz7IeIhbaWOtI3/91uyy6KAEvBUBRLUFbC3Qy5gqaHDIThkFPoKAVBGC5NlmzunUllMtI99vT9Tuq1xbXhUzDl1Sm8QFV7/2lvGxhIfV4VIhAzGs+G6lI8usUbuU9MWCuJn//V3KmuN0dzXs9wZMdiJSzlzDtHOaah6i4dfAOTSN4GRI52/vO7w0RIL2GIgkFCp0iwsDMLbAoSmTIFyRtP9XrdWZP6IJW//uwRM6AFCBL0HsNXVp6KMofYSt5D0kZQ+y9T+HnIuh9hjX0Dc5Bg1qTFqLrX34P7yndz5veh7F8z90q2WAJExMsgu4dIMZWFCEOaHC6o6twRWW5OR//9b1IppOtb0GnFGzOgs3Okc2N2dFmUtFRodEiQOe4HZWhVVXPvM+EWIsICtwRNNYBAwSRmIghxG7kI1AUZG4QSj4ycXLDwzRlYrDNTlh7Ss2b1CUlxe3UrBmmfcn2jq8zOU+ZeBwwu47p0LTBwnBbRXpoqPqPBGLUjUKmSr//61GC1l04edFzBE1aaMN6aLKRWUTVJXpLrprL3f9OEjO/397O1zEQBdwVQIvqGtDiANMYRr0bUYIuZwojcU0YOzZ3H2h6F3XEq00qmRoJLXk6ZPUUPZ781JVf/SbT8A+Y115xQJLXAs0jSltplQYffFQd//6oac5A5IpqorMrhMMOc5KjXLp6aFQuxq3cslSqoj3527DO8RsBz4I8NAQhVdeC4hozKUHI9SiMMFoSn6bGxV9akERGrC579TM/Lsu0HoKWH4vGSbLTH4xo9I3Rx5jhPpugdMhOWJwYgsq0lqk5Z+kCejd//4taZatuIH9RBB3vFyDJCLX7rbqwjo+9Hlv/e3IdtdsgDaAHRYguNUy8BEkvKJFL1pVXkE7T2SOw3R35Yk0MQ5BC4ulIZketPiuosurSQzhgZi0rG39/+z7WLKssDhF8Ox3ET1yiS4LUkXsD2RTUzsYIjv//qRNjOPcsKz6RiYnjsxH8FkJwYJVLZI+oqRUylvzhNPV/X6X/zf+XXYbQAtgMS4ewYsnvEUAoGNibC1upqJ8rxaz/+5BE/AAD10ZQewxreHGIyi9hKpsN7RVD7DUVYfgjKD2HtfxBMUZq9sVgW/XkkDzcSkjGzD2nDHRjeWvRucqQ/6lt8okpfc6So7eGRsnczSy43c2CIbf/+lDBJY4xyjPNNRiJtDFLOet6LzyEZnf/o7+/9t6ydGALgGYiYLI1iyAv8XHZMhQiYgs11uLgpfca7UirgN9HrkivRpJ9mzKdLTV7R5LO0+FW83y3U5FEbYvlhgW2XB3A+P0kioZLVkAy//+pFi6evUmys6eKPqpvR/qRUTa//t/paMeWAG8BGRraSSwcvEniM02kTCxgDwxlQZcLYn9qTTXX+t24zQ2LNfljnOcu3cdOJI7Fy9KJ4fBtQfWYu1jMYdJ7pHh5usnhKH3Z8WIS7OohIbqq/+rxla0sNCWgwkTcTwMMlLeJcdoMgMA4dwf7uvWVqhwACcAvSHjLtqloxCZYhiAldaZoKhrNGbPDzfQ/Djsyqs0WQ41q8AwvHXwkoii4XZrqqS0+//i7wsYDnWmKQ6iQSMAI1DQUzqkzh0hxFU6hBYnfq///+6BEzYADVkVQeytU2GTIqj9lbZkOKRlB7DUY6c+jJ72DTpVDpm6LelnSmaqrSOGRFzVNJ6ammC0XFcN4Yu/+/5h8m1AK8AGACEIaNyb0MarPIUVEAdOibcXSsZwIPdNNotnbA09x2JyfRYFMbt2zyE+g0mj0xJE1n/4j08N+WuNZ8iQNfwdlL//7MJwVtwBFTf/+lo52q/qEdHJIHnYY7upSI7oATk/3b/zDzGaAN4AEUSmWNL5sKHBIRJJbVBGrkRhbm1OC4KblE3RfWHo0BVfULcF0f1zVKJg6Tyyrs6s3n/1dSRgbgiSlPkwNmXgaYy59OtzpAwuW6lCgTz//9aNNz5qzVesj2y6s8cIiyKdkVIpoqW4rBcTnO/+7qVonWAb8AQAJ3oWO/IgcaIq2uC6i806YCZWzeCqlg7ksxTKtx9MQI1Y1bztTFuUo4EC2sXXSo9ffv5Y3iqw1s1+8J5BbTDqNqu7E4dOE5HIapLddGv9lLRTUYGyaLGy7umigpFHsg327kwehvw7d3+hmmbCAwwv802RxYEiEBFhgFJGdmqCWfYyytpcedA6DbYnJcHhE3Z/bO7T5jvI8pfLRbPffUbdvn6h774M4xGeJv6WiI3hkGMrr6pmU7SbX9yZ///scYwWSx1ks6gtGVNZWY8auj9k2EcBYIHKV/u/eiXiN2AvgAAR9EB3/+6BE5gATTUVQ+w8r+HOo6f9hMIkOCRlB7D2t6cIjp72HnfwWmUfS/qwLyyZBlec6FDhUQu6LZ0Shz5Uut4heubazh9LVvK0416erY+GBLc2wzbOBgP5l0BElANi2WQ5XQXCBeoVEX//nPnkc4xnZSc1BFkv5Rf+juQEnd3bzw8w4QH6ADCkpwN12WGBRaSQkJLVmqqQ6i4sEnW/KwS5imOS4agzKFLqGjpDfnsftaIzNWWvmrE13+6kDrlEg4tpWUkiiKFFVgRiJqtFSjhdDaEXWVCSSRt/+o4iaoH7sWSfZpwyGQGGdbrfbqbzExNf3e3phpqygD8AQSKYxeLX3GRkdCcibtCEUtfFS0lmYHCW14+CCprV+PrfffyDtEz36b0jwc7Wf2Jh+aGBacfYPBzC9HaPucBSdoUTf/+Y0qaqsjG2PQ4WyZ2nujMQv35s8Wxzf7v23m82gM/AER24L3Wt6eiMqzy1y1L0ucEkOXbiLBYminaKtVUawnhwvWxmxbcPFKvIkrnN8yxMa/0+1n5Ha471T5XZ9ep/HjXNdYrOYts8LsC9H//rQ008+7KelTiImFKvzHaf3azooktXby8uGan0YAtAGgGRrcsHeXZF3JXJGWEojw1aUBJ6+T5gtyfjoYwQnkBrtt899pE7CgnuswaRfBq1Xx/mWLX7JEy/+Wp6I/qMQ6c3/+5BE+gADLUXP+w9S6HQoud9hkXsMaRc/7DFNoa2i6D2HqfxXUShoKEcLss///R5QhYsqLOqxGJJOptFRUO/zpUlLZeZlsyzDaAFoAL0e+DgQkjaAGMNAV5VGdAD+fIdCOZ4eNm1hgyw7nodUKHje/rFTls/9q5q4Tf/Na5+BT0Oxb/iyqnD1Ssjr2xjp8x81yEgmf//9HJMqqWlggGrdEerJ7ZbHH7m5tyy1GkAWYCGAWQ6UAyZXbWYmXtUHZnStxp0wWYxCWiZiRKIUT5m0WsTcknGonXDvXm1iQljn9pnj2xEItVfwXItHgYBaQyh0KgDZbFkx3//6SpxKaaiGNqpEXJbPyVTVRTIsLCADUAFiLfmo5LXId5vrWTIUnaROqBm7Ql4WwXGzAIHKYlh6VqEpHGCHpeL5xnsM3/1JaS4Vycs04KQMQJMFCOY8x5jVIogcUGUF3G1//+kdTc4iYl1Z1Jqnmx8zWz8Mqty8u4hreVAWsBdp0G6F/sHJ7r2cSXbhdAm23J9YMdQlVSugzWvN23+hrn+9dkeCIuYpVqX/+5BE5AADUUXN+w9TeGPIub89RfEMCOs57CVPoZQdZj2EtfSaZkzLUzrZrbZ3FIf9UJ42ezZqvMu2oBYioZfVkb/aptq2acaVfpZ9fbuZ0zGztgBwASEWCaHjg71eavXZKkbKFuM/YE20SCRG/CBosGB9Z5tvmu95NZLAT71ZyXzlylOmKNy4mIPoceDI+ICZPqogBLjrf/9lPMUxDVdTO5wm3c29uau/aB/AAvQu3yvgmuSzK42fA7kSrRX1MIAlkwtsMdQ0zdmgrbz+PukbfSddUd4sPpSNK6ZvRqYtPdAkhlXEtME/WVjH4APCEuttbqf/dlARtihc4wVyVRCrqrqGeYcQAqAJiShVo5ueq1lHU9hGpwvz/T55JU6U/U0XHdWxOK1VT3mp833K30m+d3hMvxvHrBh963RH8vg4IAjbStUjutNZnPZS6+Yv//lSYlXsMi+0eyv8vbiqmmWZeNAKgAB8gmqTNhoHGhKmYHAn8AgKJRRwIA84x1sCOpNqzVGr8zRav86ZHsJqtnL+Nuv35YuPk9CPxTXsyGPmKkX/+5BE2IAC4zpN+ww7+FanSe9hh3sLgOs757R44W6dJnzxD8RiNNunwwiET64NOb2/+o0gUCB4cs0KGJHuZd3cPEVagZkALSC3Q2Czq5NH6kFUvHs1FGdpcn6GNyGyRgDPtIOpEhysdqLEAEyJ+UV9GMbB6RJMmIwvOUfGS89HQoDjcHAaf3/+lB8iYNJDEMmP+zc28u5u6tgewABgQjMsgSwxOGaSDGgzm5eh0gOHmnxNlcLhtyCxetOC1Sh1bgztA+czMgwVf41/FBeIoKZfOERFwKR+xhZiE8FwCiY7AECdnzn/9H3LufxbKm7uXi61gErACJB/s19dIPjdT0Yu7mHcOUxA2XCSTSG0RktuIko2nss3CdO8DyO0df+NDrzY8y4IJK5fGO1Tg0EH/zaYj3yA6HOv9YlY5uCvDX5RhXhoZFhW2DKAAhpS71BPpRImeaKfqgDmFKhlyUL1UqhhTkkVSw6UtTNr4j6hdHRK2zsw4TLrGKt0rd/DOKHHrXT0GrpdF6IfPiHafKeCa/uASLX//01DO301DwyPDurM6TL/+5BE4YAC9TtL+ecfiFWmmb88x4cLENM57CVRIVAU5rz2LawUAAhgtVYv2kNrzeiIxmujNNlAsdDdgLZZRqqZNICD3+llLtQ+T7JpTL3U02NoaYu9pgFgjii8JyPY0dCJ6BKS///1X7+UhmdlVEhciCQAAMqGQaYVypYnsO2FERkrTOVzGIAgSODwIkySqKEjuISiuSkWyGbvGU26/uM8/NlL7vmsNEMvwOQUWqarWAizU1+hu3VXZYU2axgSAAehwvjEirVaJf02JCKMhZolGhykXczZKPdZJI4UkaGlNApAoYwqTS14Ve3xO/6s4/7TI9le1RNCJ3f/KQF3506XJqJ09wpbqOKHWHeWiZ9zQAACyNHdopUjFaL5JyYIcXE/GMszROQqvXhYVRetSQtl8ytgXGNNZ2g5iQu+crKq3SFoZRUp2lsX3wlBFFT56S6Jcs+Wh3iWaY1hFAAKRWfFjNxH6+5qJIUhqCwkEM5E1Y0E66kEGjdJqjYKKNiIu9z1ZyEfUbdl9CiZW7c0VgnXmJDxPzvBOvyaQvf7bLfbWUj/+4BE74AC1zpJ+eoXgE0nSU89J4oJgKcl56XvQUaU5LzzMiBSABmq3dcLpT4tufGxuMz8dB/xy9sKPhna5I0d+ea2Mfy+oqMWkE58e1d+YBIW1w3NWKUIosxEVTOsfHwZH/HAtcZCCdv+uYipeYmY/oJqxq/sCDfPa2tUQlLkuNJPNp51Y3JyraMuvmke61AjWsSAvS0/zjAMuNZm1KrxHLf5gpP7TUa+d3JFICvDcdtqhWVWhGV9aFgACaKi/8GlfvNk4dwpOjyXg+bYFD4/sulreYwtFuAEUFJ9gPrpyzdCJtuIA5UsqRTM9QXhp7dsB+ANvwQjfKLX1LxDtERE+UjIACADpiTWOs6ZnL2ynl0+jnEfiOQ08XYfmzioSEuOxFjMeBYp+PZlG0s29XFU2vugPKmLhs/1othutW6W/+rSjbbbyQFgAAYHaz0vRbWLYqX68T52oYUc42iBiR+xT6394tmNgmUDUfHoSf/7cETxABJYJ0r5b2IwSCU5Xz2LHgmMqSGnrfEBGxSl/PMvBHN1cs8+Ewc9S0gCiNTAeFDW4bFgw3g1O2+WV/aa1AEAAIwla6yqN1pP7LJM1ceR+PyMJGVIf9MvVbODcTC0R1VTyklRDL3l41nscP59qwcPYjPP0HJgWPJJKonHLLHFCEAAeH18w4vruaJVLDi2ii7GShKlZkoz5X/PMSoQziTbVE0uI0m74vLCn3AGUjFqDd7Y/lma8rLb1p71LH/l9vXXX/bTQKAAAEat8n5d5dFTyAQUgTjswOgitE2HaaESIldpUbAbOualUHz8s55v2L92/ChPTaNER8PHoZ3UFc8SbclcrYLAABma9jpuIfEjtYERQJCI8m1/sVrJKmLRISCIWnu8wGZ046ZYejp8xVw4Eg/qpGX/+3BE6AACRSpJ+elbskZlKU89DYgIlKcjpb0JwQOU5DT0tfDHM1IDUxYYU+93EdDkllrlYSAAAxHMzEmdrW1XjsqmgtBdI+oZFSnt3eiqj9kvNOOL8bLrsf5u0tF2EBXXP3wWNvqHpZrM7TkpO+eLtYG2LrJLCEAADmf3o1DfTD+TSQCIDVmw2k1hze9n77pOJlV5cH8aby4W3Cm59vbV13r+m9+onS1ZAuh3oOC3km9GEcWumcgTAACxNufTptVAGp6gsSWi6dLaipaz9ePHXgKHrVytCHL7NI38BYf8pIgHcnTP00BmvkNGPXQmxLXK6CQAAyDy6CS01diAfQsA+NlTI/WfwzfqhZmLpaCpDGV50kLrbjSbE9xESuLqjZ7pFEf4vjlIhMxqJySSWBjE4/ujj5/d0DEo//twROgAAiopxunmfDA/pSkdMCuSSCilG6WZcokFFKO0wTII0nUBNbX877ztS4Nxqle5Mnudeudk3XnmuOeyAjKUWdO5xaO5u8dTMKnKFYGAJY5dQwAAGic/809BuF8juxSbqn2EqdWETrQaUgZF9q9210FG+ooL0CofSdNE4wrQ2hJWJYSAAA8kHUkk9XfbMEqokISA9nv//+Py5sLkA+Ut9VaysVa21kVaBQ6KJJp5BLjL9AUWogACaaTlCFFdWgiy2kmziNt/4r2bq6eSzHurcLATGzd9tQ8RhoddVRe7gXkabq2ZorUMxsBSySWFhCSGZvu5XRGqEkDMMtfd+X6zPfluchPtOb4yhhm3scjtVOzEeD5DeGQcO8zNlQI9NKqCjagACR/nV58gUhceklrf59lgsKD6av/7YETugBIFKUbpbz2gOsUo/TWIVAeImxumpWvA6pTjdLMtMLxYOGpXgkkIfhFFZPC+ZENh0o3rETG940xCWmTsZ+my7DfXeu3X/P81Xd3fpI3F3sJgSwCWGAAAGK/hp/1MHlg6DZJod3tfVIEI5OWVSkP/bM+8nvr4Ct2iO4YrvuYcVB4rmZB4g477feDOU4mWb/lT2juHxscMgyZNt+o8gF+a3glkPcB5Htaaj0xK0ez9nV/9DDX//1/2frYSAjQbmcDVOq/U8uQqPXs/0q6e1CVPku66ezXrWz96+3iUpnedV0QFQalSKxb51msBRujVgAVCqQAFB+6mX4krC7Oa3+iqdP/7YETlgRGJJ0dpRj0iN6T43TUtXgZMnxemgWDA3BOjdKSteSSgKC63I/Y5/2kPRjlWCIFXQiNZ/X9inXEff1fzrP/Qj///bpgKMIABz0/4UyZ9zb/8062XfU/zwwjR1UhKHtWHKa9aOEY5//7f//Z+7/2e//6QYe0IH//MXZ2ue6/NZOcMDka+X17YY8iydTwPifEJqU7wAb//Z///rgASLtw43/6qBfyZydiwOfQkyrH9s3tVfTH/YPL772oFwMP47///////o0KABEq9AAEv/xoihz8fCazRCsRnl8dRbNR8nYOtroUyGUhRn/WkS6///////b//sgoXIABxvp7LR3Nczv/7YETsiRI3J8OxSH0gMuTo3SALgkbYnxElCWfAz5OjNKM+wYHvn1zWIepDYZUQJr+b1OCg9H8SiX1//6f//0+r//9I4IyEOPSmNTkP/9l6L3zyTs1rshoUGrGvQCI81S36CbTkqQ48xEPezf7/0JU0cfZ+lDWlRe+kdBmSJN9xZbZ///////6KgAAKqQAFB//hn/8QRVJvjIZTMRGXrQuzGMzgg2W20QauFr6FfR//////t9nt9cAigDyAAJP32XIaI3r8//D+OMma7WmpoNv+4BFca9NTT3///6sECiCcIWr1+tt/1/+nbYt/sgLDrGtUEXmt+pehPsDh//uol6/4FYANiP/7YETqiRG8J8RJpUrwLgTohigoTgUInxMlJHoAq5QipKCleJsoV30lgrVna4Vk9Kf///bVwAyorAABKhcy3q2/X+yXrSq9knYRGmstTgQTazvZgRtUgADH9DD8cERlCeQATjoSHKDLuZOUu7pTbUi/YUBjYl1eotav9v////9H7//0/TAAqDeB4X/vgzs0+//TboNvUABKtmuVDxgkMlYIAeFX1qv/st/9jPi6V////d///0wAAV/gJJ2/+v07YZw3i6NiA12IzBmfovULhg9WOcLEXEX5iv9XaoINQAAQJt/QgUQrbP/yZSNngbGzo7uk1ngoaQ3OHhhNveeUjPf/u0IX/v/7QET+iZF2J0TJQVpwK+TohigLhAQQnxVFAOEAkZOiGKAcIOe799H//1VKgAVS+QABI1v+ZQmm1PL4loFgqNWqrg9ip1teHEtcVbEJ51axtCipDhv69NzmP5tbgr1Z3UWpRnMXV2fUKE5RFNwTp/v////////TAlAwtDTT//+rLVvudO0NN1KmnKzora/egdV1c301gAqC/gABJf6aEqDEhJv/mdE8WiByJrdfVPc5AKDoa9hA//tARPeBkXEnREmhOvAkpFiZKChOA2idF0WE4cB4kKKkoKF4BLyr+tJsUG////////tgAZE+AACE2Q7Edv3f/oh0oqIJIZdGsDMd+oIbR/0H///////6YAVQHKUUq/r+5kuqjDHozAPuxK1uDo5rxNH3/QRo0+n/////2/R/f9QBFYCXNf/sj9qG/9V0LowGAXcR6f/////////TQoGrSAAcX/44UNEb9aPa7WdDtFSs+x4paiX/+1BE+gEQ9CFFyUA4SjDk6IYcJz4GCJ0RJokLwJgQomShnhiC4we5+voLkf/t/////6dMAKYAAOPt//Qzmx4mun6eQm6VKAn1f//////+pf//ogAZJfAS2U0x+/satNfH/zSBrbnsjHDzXNSI4I6t/Lf///0////0/6sAEQt4Vuq7//zesVFptaf/C5Cru4QEry9wPvZfQAFZuQABJvpeqeRDLbrygzsvIP0svC31hxOdXFjf+gABVi9ADNf4HQGDmmJFQ4wJ96kpK5qSYx9Y//tARP0JUZAnQ7FBO1AlJGiZKCg+BLiNEMUAskB2E6IYsBwo/ZjEKg+Tv/0EO37Yg7f/////9//5iAAEBkBlZc90fcv/wFH/GBu6MTXampQf1Q3UWb/93/+v/6v/WxVnt+oI0y//2Z1v8F04M17Vav5KfeZARW/T15xofx/+7d/9r0Uf////1EAIBDiAAABn/zJ7//EDX4Wc26MUnatveH/En/fAAEVcAAFpfOV3896zTaaAY5r/+0BE+IGReidEyUFDQCUE+JksAggFFJ0QxQChAHMQomSgHHj8cDTrTtlPypA3TU3///3dUAB+hrp//9QX95xQX2dmVOYzTMUBqy+Jf/////qQAYBvARsYg6TMmf/p8XEfuXV0ec64oLUe4hGFV57TZ9OAAQCoAAVjf/1WSfAaM2so8S6v85nTYVEm/f//9b/71QCakABiuv1mYx/ytt0KZEKE6NK40dWvY6iQorcRDrq1rD9mr//7QET0gRFFJ0QxQTpwHyQ4higKCgUAnRMlAOEAcJCipNAcIP1//pggBUm/+h/T/U8JRe//9NtGUiJX//+pX//5YmAKvp+qW9fqSAOnPWq/XsaxtqHnjrv/2xfZ+7/8MkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqDv//1jEADv//yx53/11MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tQZPeBkPohxMlAEaAvRPiJBAqgBRCfDyaAoUCXk+HYASFwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7MET/BRDhIUVQ4DsgIkQ4mSwHCgOchRUlAOGAgpDiZHAcIFVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7MET9A5D/IURJoDuwJ6QohiwFAgNAhxCjgUyAeZChyHAqSFVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETkj/AmAEQAAAAICOAIgQAAAAAAAf4AAAAgAAA/wAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==]],
              ["Fatality"] = [[SUQzAwAAAAABHlRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc1RJVDIAAAAbAAAAU291bmRCaWJsZS5jb20gTXVzdCBDcmVkaXRUUEUxAAAAGwAAAFNvdW5kQmlibGUuY29tIE11c3QgQ3JlZGl0VFhYWAAAACkAAABDb3B5cmlnaHQAQXR0cmlidXRpb24gMy4wIFNvdW5kQmlibGUuY29t//uQRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAKAAAc8gAmJiYmJiYmJiY9PT09PT09PT09VFRUVFRUVFRUVG5ubm5ubm5ubm6BgYGBgYGBgYGBmJiYmJiYmJiYmK+vr6+vr6+vr6/CwsLCwsLCwsLC6enp6enp6enp6f////////////8AAABQTEFNRTMuMTAwBLkAAAAAAAAAADUgJAQcTQAB4AAAHPKGMRi/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vgZAAAAZwA1v0EAAA6QBofoIAAJZ4NefmsIAN3u62/MwRAiIl2d2WZG/ShAQfe0EAQDEEz6gQQGOUOfUGChz6gxxA5nKAgCAY+nwf5c//+H/8EP//hhmmJd2V6+7qVEGD6RAcBAEHFwcBAEKQQBDKOLg/DHKTmD58Hz5c//KAgCDuGIJv9//UCHw/y7///+GM/d3Kt0aVqAdQmJwoEQQGzN6TqnxEJNeDMAVMrAZ6YAGbUqaoqJBiwfMWRgI0ZkMNA0IAUbxqjMYVzGMSJSaiQCHQOA9YGRH5hDvAlC0tk7opHslFnuMkQXbS/geGIbQMdtDRXGM3KRHxXDrUEvnoAdSnduLy5fDEW/rweVAiALus7aUq/OVw2/bZGaO/GJDGkiGDODA24DkyUaSS7ok1+GmmIjxZYkvXW/kAULwQRDcxyzM9qVKamu/8WLiPxOU+L9w5E5pMS5NzVnl3sNxp1Lrr1svuRTTo2dV5SnRELMP15uL2N9t56n5tOCBXXmPotWscqepGL9iU8k9m73d/fwJhEM60PvbWqS6i0/nMMO2P/////////9272tb1///7//////////+rDJJd3ZLNahQA4AgAQDAAFAAAACTJkyA4s/31mMMkEOWGWBSUzC8Ypy2tgKBpyokHhJ9jRbFxBzEopsZlcvnSfZ0TpASBkTQJw6Rchh0hgzAYSEKGZgdUmX3ma1l8wLZcZlrrN603QNC4TBQFwCpjglcck1DGwKwsQ0DQi582WorEUWcLR83SQLhAzdS2Top2LjO6lmpfJgcgfJXOGhQIIXw+cXGTheFpvUaKKpuuoki8vMGQa63TUO81Y0Mi4eZBC5cJ8uWe2+y3eiWj6DqTL7oU///PFM4XEi4Lhwp/2ka7l9bmZUXYwBAkRbC6Rwsn2WbSxXQoK0ZsKsKmLp3N1VikgNIT8RI0MjxcSSPqMHsggZIEutEnTFlnBcwJ0GwkiYuxiqqi60UTI4mihWgqkyCFkFqshQJsvASkni8o3SVQMEj77oquYoos5ugptG5iXtFlMkklpHBTiCjxZiaNiiYDuLpsbnUklGxgV07qyYTPszvemroupSvKRofVTNi6yjY44kADpPLkFmSKn7NSf+8y3FnSIOAgMRCA0QzKwFq5laialDEMzLRcM73/0Zppaem70peVUoYT/VUvXRqd7MtL/4MO22e3//H8y///+XUus3i3e0yqy4EAqHYqRIhjwwsCYwwRCrEbIjMXKEmiINE9rtyAlMGIwuWylrEutTEq3A9LZytZP9E5JTUXK03MRSjtWSrEuGthqX09KxwIv+JWJgkfb+qazqSkuIUOsLF9fOVaVYI9snk+9zYPSbHxWG93ff393/z/bHwxP/r1xrVcfV7HaOlT+//uwZLuABWxk3HdiQABDJavP7IgAF4Hlacy9GwG4pO19kzXglhkB0PNLBs1xjB4wW5VujCmmGmsgZMXzd8RpANQoVyaDUc7qhvfJUNf9zTyrTLpzP/3fP+TWuuf1s0RCA0QAroLzSudwyElm8TVMIgSOQ5m4EoYPEZXVYVTZg9EkeCrIAJD/EOLkd3pmi5JpI1brpX1m616fdd62ss10ZoIMAYpNOoVnkkk+yFvquyT36v+l6xnPmm0ukiGn7J64f/8m8qk9/kHIvc+TqHwsTgsJLcGhG1JEDtwadNFro8Iv6SvA8DUpf37LTAKSijAkyH2ncaTKngaF0ut44TExKot/eXr2FNkI1Qi1ljuh2msxY3MckzM80yNVVW5iXXZLWoyAeQGSSaatSMdzpWk9akE9PKB5Wrun+3ssb0B86Rgsc0U7d8RVjr2y2h5ymS/1+/7Nv7zdrBSOfrKlRygm7l3yNWKdhjkn6+rplRBIC5BAwDLtmcZCO5Loxp42XFYhdT6LggNfBiW1GD4w7pNqnBpP3d8jgQ9WqKIukN/sar62NGf+33f6lD8Ak6TatbN//SV1+/WupvWI8LIeLY4h5CXDzJAcY8UU1D4PxgTCs3MDVZQMQuBKF5BRp7fZv0D5/2f2/zHY+4nLpBh2gCQJQcg4tQeB7hotODrgIQOMhbAZCBI9drZuYoYwlerGGNQNLa0Ypfd6NSr8ZfNai7ustxxw1WllqoQIp7XLGO6W9hF5LnTaiDEotn7WkyhatqjKpBKxeFnACggRQiDJZ1LJg2TMzqKLp10HpFkxRe71Hi4tJmQNUdKZD4EMG0IVQSWp0D7/+7Bk1QAE8mLa8w02wIBMCz9hDYYWtYNl7A6cAe4wLP2GorhvK6B84smTVzI2PpoqURIvLd0VaK/U7+piMLxL0isBsgq7WQxEtOxuDwr9T+20bDICsAds5OJ2JDQIxmbVmQDI00YnACpY7CdR0zgVHx9Uo5JnzPv3639SB1Az7aojxF9mnDWyjB0RbGB+6XZ9tJvU5w6EWSb+32/2/7f/2G43fSxgqSD4hiLaFhIouK1Y8l0CcDrRh39P/xV//IFHnSypqhPv/+x6yMz/indyASCK2KCIIJM04YgiYaQrMIkQAguAjGNjDYZYM8ywiPsES+5LZZar1Y/P9wtTJ1RsMsl1GyZiDRCfl2SSc3UdZ1y8SP197a269Z0nwVpNtrsojmMUVqV7a1H1t/PKbRb6ljLEuQZWIpIiC4mCQ5WqCDTByH1BZIRJsLd0pJF1sM+tpQRssPKrWm8lJQKv5DXRo5VPPOf1IjqACyREJREV2REUlOmoGcrZ0+i0ahZdoEQQwa/lKmDMtms8n9qWtsZsc9MuuRYiR/dRWcxCCAe4jZJJjNA6yVjIunU6kDugks1fPIbZ0jxSYYkRKmdUeQEI8lfS+//iIrjn8dH9V/8OC4PA3fAqWOkwDIl1xBJlIuoscOIu2R6kaM64i5+9GEFwqpsqmpP66P0Jx8usY3ZVLE4AgMxC0wWIy8HNVsVgRzbNEVVxwsaoqa6OoDjPrBTlwJjVraxllbdaJqm46S8TrIJmx5lBLAsB2uo8eSmyCJisljIusg5xJlGF6KLv7pGYf0C3y4lfNYShDQpcHilbdLsOaO4v4ifTr/jYIQFxGVZJPP/7wETUAATFZNl7EUVwlmv7H2JonBOtgWHMTRVCWa+r+YoiOHVIcFU5zC7WtbPJINJj1nla6n0b58kQ8PypZk9YTeaep+/q8fTTeXBMrQWBKDCaIXECEFD1ilZEdB8RfBK5NZCtRmRU1CMqCDOzMPOS2XlMZFw6yNE3Pm5+ko3nkWBJYDkBdZc4WqSR9BazE7Lqik6TscZlqpLVp1yyH4h+boo6TJg6CMCBcHiiR8d8zW8N8c9p/91sBEIR/2Tccg4iu+WPaI3u8yIvV/mup+Pj8kYCsdmoiP3vUzPenm623cxQaGjDQQRULTUgMmaBhmI5hkikng3F8FAk7mzx7vs9fqM/hDctqX69yM2Nfa1EpqifFLm9jWkVW7YCuBRFoozh4ydFks6Licyd0krqf1t/SEIQsIL5rqWekARKEjjh8jVDFOOhNOspunzn+48Mg/BBquVMxUx1bOrJNfGrLZUvX5v6noLn/ldfo0ezw1JXf64LCgCIiNSCChKEl6wAUvEu5xEDlRo9JwGsqc3cAoVXzu34OB1dkjXaVOV9xZJCA5JlpGo3NAEygVGGZqicHwQikvrJRjZ3OGV2/ZPUtmI4NFAsGKa/LSxyA7JeJ4vLGPJ19BXJRjay0e/pOrUpIvB8YpU+1F1oY6iWSWtAuFvVRexfOI0av+t99ZFicP6/lluxRb/MU21nv9Tq/OL+v7dg0Z4hEE7CSIE2OzGgsjSbGUIS0TmXRlB4YSs6Q1IUhZ0wQfV0oS4fNsVa4pC8/c3WCUBq9TrWdo6QcxaDa+v7f1iOA1l9+tpUWKfZ0amfWXPqtX3UnfsYj8MMMdDdk2TMyy6psgpjjH6KQw6tOnVQvzS17KQNxkNaThtEif7v1O92N+VkADOgBAQSSAhRMhNHzRUEDbiMRR1hTZ26hUBToiKeHmS82zZb8R90kKw3Fe6gVZbOzz0+9QRCBUFQD8bi1rXXpGCCqB8j//ugRP4ABHtk1/sSPjCf7yq+YTSGEI2BZewtrUItt+s9lNIY6pnayzTsrcY4LgybbolqJYNlLkaborVfRSV6v//OkaSxfbdrTMlvI5Wq/MV+Z9D7WvUcPGhprr5i/UUP+c+f8g7KEPX6ymGriwVgBkLBCoSEL2MzHPKrJZCgaOspuMwh+m/QwAI261+B2IK+m6SVZL+xrXbFDZl0sbGJQq/qjxt1gmoHJV0j6Dlli86iLhc2VCPQWizstB9SjXtUtSgPIjJWs6ejIt5R02bQY/9Pv/HCYD3QoezjEsjqwlljaM1CMSj0v9ft/NOEL6dH8jfxP/IezFqspgaEgsAEtxG6Owk3LvFUQKiNTQ7p/OEucRjRZi37GFAwe5jTAoaP7LoqathOMiEuEP6fG1GID1wKpUmVGsW0VrqSUmQ8uFGmREuOuk73mK9k3WWCYAOJEn1nS0wiRIq3MC2gpdeoxtU6+/37WUI5IgO5upPH81VsZnvXrMr1Vf9u9pRRNf84fXs7/51kp7H6/br7WRqqMVglkqaA1ipOPh1iADOyIwqhx1lg04iLD8g2zAZKJKq1NIMQ9A+NPBak7Ua32miVmtQpX978jqbrBBYMyz6z5nMzxrWwfoWifTcvLfOXuo0/rFoBG0iaL5ZPSMJbywrU3k97J9/v35BisLYjseVZgjLHujBVXoy0YETf//uwRNGAJHxn13sTVjCSzZquZTSGEgm1W+xM+UIKNCq5hFJQM7fb9TnDb/zPlf+X7vd4/z38pwCWEAGvOtSqteoyoZQAlJkIuypsqSq3V3M0ziCqrfb/35i1LZiAfJTPOB408k74P5UdAgwBcLqmRLspJlVopIn3RLxfqY8/WgrfoB/hGJXW7SiWoeQ1VuPySSvqPrenS//7KGbKRq3p4/r8s/62tXR/7/rMzqX+WPnfve47/hf1271hXJiEYKRQBh1SoVb5E1HoYCt9D+wommcVFVovhXRPWZY34spOFsV6MvCrizQ7sbm7VkpiOEXnziLKBooDTEXVLLskdPGWbie2Ig6CZQpzO9ji/8UMBiQJVKzVHT0HCVec2jJWNVSyFubaql7K9lEIFEAynVbB6ernzHarJRBui2n9/lu1phGJ3ryjvyFJejR5Nvpu5kgsvJ4hCH6FhYq34MMX+ETVmkAW8RdjQwRMpp+r4NGLMuY2gScPqQ6XoH5n0N5llZ34rytIGjwGMkalEeW0ErOy1l8xKlRXLlOb3spFftODlB75qlyyaw7hXtUTRaXVVXR7KR/799ZATJvryVN9dB/9L5btS+zPZml0zf/KRoquXEX/o/P/dxuvt5rnFRmIwQ2OtQmkCyL4yZBMhi5yvGWs+TqKqZZG9TYMIAk2KbMYDZfnCVaZrhTait6Bb1jJaPO6o8qtQTQBmF1SyykjFjrJIDPO1M8Zs1na6j/bXI8A0AebUWWg8X0lerLoT953T1/yIiD990PeKopNc2RMdKzaqdMnsSXktry2jWnDEQi7pyMshx93dnL63dfru5lC0ogFAQT/+7BE3gAEqWTW+xRVwIrOCr5hlIYSYZVd7FFYwg20Kv2aHniI6wuCSPkxYqYicADUz20ThfxTKWssUD1BYgKAyNJlxkPJT6U1pTU1PMzGuo/RqCF4DuC6o3VKUuuqu0pkiT7IT1rqP9m5uIJI+WUVB3hhrqkeWtf1K3NO6f/yY8X+e8sHm1QQGJWta2qxbt9u3PH2/xW3jz+esOX7uurT+8t2bKrEgRIEC1TthULGVFoEiY0hOmmwM2LCvhyJoMHghWefs6EkGseTmvmEq2ZO4nbDmf7sLdfyJbcGoIVgOQJ8slpcxZTqSFkqN3OKNa5l2m3+eAUKk+vlnEiGKtsjS2qttSyxXaj1+v25odKHqvKB/zNvVy19/+3+xr/neS6z+3rd4z13b2ACFYDhIAKkZlhkjJNGMDMIQhIhlULQ4A05h7groziClgdvxCeehuvFa6A7j7mLfC/NQQtgeAT1j+WqkXZ8mDIvzAwLTp067UG6tA6NtNuRq1C1CarqWN1PX1U6NqP/btyZSf/Iw/7nv9X0///sv/ll/M/K6/9Xn2bqLLxxwAJMm9TdSjRgOKlGkxwvbBTEkOYyXCzeUqO3JMeSrT0+2Tuf5UDU6DL60TbHSUNxCG99yLXbroARjBTgfbRG9RRZPNQ+Jiay+lsv1u2/jPAKRyoXkVLHy8mhi+iS66/kz7pf6/8fRcFtb1PH5Xka/+T/0Ov7f0zA3/2f0Ef8vc91+LDOT7y4BnZCxALEprgjiZR+/ooWhoUBKXLWepgJYBdlrnx4yywaBemtgvM8wtZJ33JGH4TQQzhWrdAB8QK6Ddqx8jeWtnVXMkDabv/7oETpgAQyZVZ7D6QweWz6v2V0eBE9tVHMao1CQbfqOZTSEEXIszTSqmo826L1EYSxn1EamgQcLjIutZDR7bdVcxqumZd/+y8oH0vUqgL406x/Xq+Z22NOr76t6Vv80Prrmrf6Vd0zKjZT1KvvYjuIg4ACAaGCbHsK0wEGhuuFGgZEU5VClcBBn6iNdeasAeEiCDCNxDSADgJgh4txNnEDUsCtCmRpNBtaU4TxRIOTBEQEngdlGUIggxQHl0Z5VZuHwrdA6gXU05i6budQV6CzML1ghFEHNEGlk+ZkPG/egUC3/TItbt1etv1nyKEHTT6nlIqWsalvv0ygrU6+r7fzsrf5x/KX+oq911fq1r7ctDuaBKmmRkoKskaTvAJWJlqCJSTsDvuqQvC+agddVdOQUUuMwwCJjvUXTAc06aLLRgQQvtR1JMmYEaGAgWsC5Co1AtanTZcpooUUiNrc/apSfVbH4T+3lFMphi8QOt1oEMJNN1V1zldpj2++rzdZ71KdZPDwrYuld+1dDpOn/37/b/LHznoypsi1byR0jXROgAUgIm4UDT8ESu6BQTkoEPKagJIKLHIRIOZTHi8CFZhUeY6AmeUyFQq4FDS7pgxeFwQM01/xhglAz1bZUCTCAkwUOAhKvZOUOAoFSsCwcWigFkwjKkGE6R1YJy1bUVxJQgoOZr8x0+DOFf/74ETPgAUQbVR9ZoAAimz636xQACgqH1X5vZBM5cRp/zfACPUX2tlRmkfugzmW/vT1D7ckF2ROpHtWewSSrYQaMhQb7qnQxHgWSt3uYRoEHCyX3Q5jQcMBSSUtUdIg2mZO9LHl8Tcf9jl6BppFoAikHJxCEKKAVJpVRRPdFhghIhVBcbNEIP7n9Zu053cmqdqQVBcMGHg5ECugssoAVVoey1Ca8/nlZx+rR7gjljV7trDd/V56MsaCzZeK5epLeqS312pBbiUCdkW5uzWxtbvbwj3///////////zf67/7/8//////////7utV9Zz9rtHkshB2Q6gMlUurCAJUENoQCgi+TKbolYW+pQhhiuZMOBgAYAAhxgZMSmEgJiSaxMx54YYIYIoAvmBSuoEGRNXz7JXJHuo2pUCIYBW2JACrEiEVQFKUNIbGAY0diTWSqAnUIQMTRFsUmzUOJoC1Sz1WM7gBxkHO/YqP1Qt9YziU40yanq7rKqrSYrV7rfrIp4+lPjhTMqeZ6yEGz01TEIBjCnYyH0LCoFkso66SxZtOJ5xYICILQ/J4evt45U6NGUQixrjcGVBgCe9IC3+srsh5lJWzRyR/+60C/8fhMxa1R1YMXF2gQLY4tqjwrXeUfeYaxt63QTmOVPTXMdby5vX1oTvJ+qSTZbv3a0Y1Xm2oZ3+V+6v6/v/j//////////dy/dvK//813L/////////9qtNl89BcnuZZ/9/UC0BmBkDTA1BUZAAcCAUAx2VDGowMLC8EAT/MAhEGg8wYVTIBZ/0BAGExkNXGhN7/mAICOmYdDWYRAp/iEDgwGh4MREH5gIBJgSCX/8Fy93FAzGA+TJIwTEsmDRqj///ZsWVbhEpKZ0LmY/F0YdoKYekgZJiB///qNLmZjWZcy0wMDcdAAwVAgwOEUwEAkwHBT////O1OJzVrdKYCBqYBAeOgYVAhQnKuL2////+uaDasuqReJt7J4ZcJN1wYKTJUpfRVH//////O9nXcmd1MxXHrAYwvlwYxRuFNr6cKN///////+Fy/QUvcMd4RGd3nLWxO1JVDmBQ22J9puDK086MM0H////////////////////////////t1lM0zF2ZhsMpqUNXlNDhUg0gjhMADgOLQkMAgIAYFgcYDg8YhDWFAy/zDsPTBcLTIBgzRBg/8wIBAiGIwRR4zStP/MBQCiJkge5jgH3+XHLhmAgFCE3TGIoTCQPP/4LkrwLnMICpMljhMGgwNFpH//8cAswaAlhTtRE1MgMyiRAwRcswaBUxJGT///ZUispjF2DNqYMEGYFAqAQaMChfMEAjIAQ////n56it3by8RQEQoALDEC0bXUTJ////9+14KBu21hy2YupJVKX4bKv/7sET0AAk9etX+c6IBKm9bH870wAAAAaQcAAAgAAA0g4AABNF7Kd9ZDGv/////6uuYyreMRiuF+rLW5U0zBVNKWZOFK///////+WUU/AFmvSYV6mVXV2HWfOFK2xOFL5JEp/la1EcZV//////////vuPe87/O/zf/////////7cYZmm6wzUgmU1I7KbF1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV]],
              ["Hentai1"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU4LjEyLjEwMP/7kEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAEwAALG8AGBgYGBgiIiIiIi4uLi4uOjo6Ojo6RkZGRkZSUlJSUl9fX19fbW1tbW1tfHx8fHyKioqKipeXl5eXqKioqKiou7u7u7vKysrKytbW1tbW4ODg4ODg7Ozs7Oz29vb29v//////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQEOU0AAeAAACxveY9eZgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74GQAAAHBANPtAAAITgAKOqAAAV75k035rBAJ3BCq/zWUQCACSIWG80zeIAQBCCDhACCbRO8mUBAENYPn5QEDmD4Pv/xOCAIAh9B+CEoGP/wQdlz///D/kA/0foAMAW25OHh5/AMP8AAD/APwAAAAZAHf+YeHv///0Yfv44AAAAj//9gABz1Y4eHjwAAABGYeHh4eAAAAZ//+wAAAHf/T////YeHh//AEAJAgJICIIoAjrOZmtZGt6h0YuKYoI2IEFS9AJIiTxO0IkGDUmATnHSDS0BFQoiEpZgABOIoqxN/ANIiQWuNdF1L2YhGS5ZQR1y4dJDcAJURFS2BDcZDZG13FrSx5ZHaGBLr9o0Oy+HqztPIyB5WktvFG9L6TcYctnkBvWwSvKLmrNqdj7tRflStDt2KQ3NZTGpfDdBDjxROOu/2nl09XlEDy6IUWMSlNX4m/9PY3uizpI5HcIzupf1u7F8YDir+3qmtTdHZgfl+5DGse9lFJbuSyH5LKOwRhR85/z2V6lvSR5I3Tv3Lfzw+tjhqxQ2onMTmVRATdvVSggGBKAIBKQDR9gofABAACjIgkRybp4omghUIQAsB+ND0d4S2hIBv5mGMp5YyoP4limqiOqu7Ktn5ZIuqES1pywUKejMlhQ4F5mwSWUNvQUdeMK9fWh7q/+TtZ1H95THdu4Jixl+lEv1f+ErTr//VapZ0sj//nVJyVIyMQORyVzdnoecVCg7oRoCTDeFuEiIPXyXLakuSBWdzUpBASFixiERz4CnMr37L148U1e/1fODyb5Sjm52zsJnGZn/2xhz2FlcpSn9T9v7DlrKFpXX0cdJZuxlDhz6XsscvSqyl5pN/+kr7TM0mdtO2df6WER3RZFdhX8/9L4xeiy55B1/9ifmbzfvvv3vWJm99fvSF9Yledf38NcnqGAAAAALcDxkZCO9V0dMJWCUaW1RbedJOwJzVmcmsF5giuvLSiJyYhrEpfhk7Cp1dX1/eZ/pR/3dSLmTUwIANz+tm4CxG1BRKJAgGDxJTCJ5b5YJIZEq5ksUrCu163dlGZKFcbwtxYlEVhWUoV09uNQHAUSeiKVoArLQlyM6owoAgYoSIkApJAs/rY2/6BFZSmqqKXaJKeywyQBoEsIpnDAfSAwlvoyZAeET0Sh62nbRYOVRgfEtBKDxbOHyYLGiiS0xmYFg8HxfUl4scML3W/N07tPLnvl6HlpJbIKIJxcezILOokFj7YkwQSFmuUXXMlxFs/ejxJIjuEtjgsbIrBfrHCRMnzQxbAAAJAOKVPmQ0TQNdXPMHgvlQxh+lGJCdccdSZ0bRVVIZB096/+jn+Q+J//r9M/+X//+fl6omjdhgBJz6JT+IggkcBkYcWESDIiLY8CCB7Q5SWlv/7kGT9gAUCYdl/ZYAKOULKKuewARm5o2PsMRyg1ArptBegDFuSHQBWEJbXv5Uq7bCgSbV2aFYb1xYtm+0YhOShgIkWAvwwgMwkqxGA4i/eyEKfsI+ykP1DR6TpgKVQRZOuhEj30rlK59W2pMRksfzo3xiFriWINqbo2ja9XVQg1pEr1iCrUJ0KEVn4zIipCgECsBkvZRvYkSpQjQED0Ang2jSzM9J6tJfbix2yVybNnGhDKUdRNgXded8AOTUIAEQHYKTsNLMFYZELpCOIsGQQ/1oISCByKX/80/el1v//2mTr4Dov0Df79retba1eDaSMBONNpP9pIxsYEBk1BWsI5WFA3hiLxA0G4fvzhMsUGW7uH3CoSRAY2Iee7GVGCLrG3nUsEBdP/eU/H0FibW9f2ZQlVv/mGJKDRZbyvddB1VOY3BofSeM2qyKgK3vaLJf2GDaUYefvboMGrPSSKejHKK5ZXQyTvHt6FtixnMROnFDcv6qflNBHFxHGeIIyA56uoDKaqJ95P/fdM3kRhBPAigDgDBSZYG8GccneVwRJhv/7oGTNgAW2YNt7T0t6MQJKzSQnSxQNl2HsqTzI/QrptYKlZJfmKIHy4HIxZPzEdS4FhmS+eDEiIv/yq3VmTTCvz3/uI/u+sl/uTqyQ+oditQaCVQcCFUAAFwYGO4M0gDhmMIw1lRgwykQBMwEMzMEGxTGdSOulsGMw/T2xD+YRtSVuBK58hFDGn7/lis6ggCXdR/F3XrAI5T1zKt/YmNCxXPLDcqUIkHdZbj6gXD932Hw4//ViOOz4DhK7WtUFCCNuLkHFMtq4Dt4/yHrm8SJ1tiATW7YwFM17UIgfNP4hBEVXw4o1f4us7IwTsdjh8hOEQjHFLNPf/Pa87jGMDldAFAoAgAtD8CdAbI6LKS06mGdQuMs5USFdWV0dQUEFwGB1/Y2cUDsVbPHrnJP3xkn/xF2GtXzv/oTb7P//3qW8SsCBVPWqSriVKBwGkW6NkIvTTD0QZ+PJg6AVNx0rMi8vyHs8fUVFAo7rlN16UuPhplsqZJAyPaoO2Zui48KGkX+7S8jKwLr2+7zAlAYUdN4SSLLKO70IQxI6G19Sv/1ANQ/M44cPEXygVCUXP77OSPniZn4ZTE9hY8UR+GFhU+8eUHQuhEaEiQ13cmp/9VKHXPCjBd1RRBHBcUMxsWd/mdWiCAjwQCAA+LaASLBJJoFjgTFIdEBINYFa3IJhpBKWuuv3bW2hPQ41M//7oGTcgAV9ZtX7K0cQPeK6PWCvZxSRd2vssRppIwsn9ZLiDPURBzGprkeHj3spiHty1Z0urPZ9X6SQaK6O7/16n///9iF7xUpDMCjahd3C/DIIne04IKMhUXAZS1dCAno+09cRwMK1fyjDG/KEBRW1fetNIcgzImtakE/VYyRL/Z/F0T7umbSpUr0Pf39GJTqBkf31YKPBEIWwKCnTev3Z7e95aCe9/oBEpwhDskoyMjXb7//U7rX5a6QMK0kanBkGEijdzPMfw32pbP//7hnRZItIgiXyJAHZCXw3T8HSz6NjFB4AAAAAJ/gAMiJxDbwc4qSYvt1TMRL1DSPRSaf7k3Wh+clk2P46eHjs/CvXLBDfIgoGu2v/4cfDw4c+9CkJkKEbf+sKYAUwAAAABk0yswbYUooxgkXswHRRMrZYHHWjs/T6SGgAFPlIOIy2ETijZmHptKRpiw8IdyJzb6spZq78np61XUagt+H4lmUFM6R6b5+H3fuVS2mqSpd7r08B3GfNNSGa6wcf22kQ0RnCTrJa9bo2yohPAsFxkfodBkUlg2AQsBCFCKRwec3E222qsq+Eqp2tvbVaqVdRocupWBAg0ebTnGWTPyEjOPTdo7d/usqej12wd4IlpHiEimUxN0p7RqUtqd/72NCAGAH5gAquAohpIphAqdsup4aAMCIQydjPO5p1lv/7oGTiAETwX9n7DzPiQwNaDWBPgxiVhVXNJNyJFw1oPaw8XNNzZRn+TRkZP61ium6G2AYRnP5XN8jwUrPL//5Xjk4nWfylrf0+3So6qUWBMBKQaU2HSR4kOLvhEQweuw1TBEgdzB8U3FM9DqwiqraAAhmTGNZ7DNUrMhIRgCylodHTo/GIqLCS22oEROHDAbbo4WJh4zlUuISHESquymSksUl5vQyl+7/3Fzll2ECOJlVDrbmdOLam5Zme3soZV/IxyU/Km2tvDjJiFylqrD0gywUSlJI0mg65ciFyG2Zbfrf/45LbxOM7lJchtVmM2nl+yTt/kiBoYAMAAAAO8AE7wySvIKjQ5aTik9EO4hZpFKqOgw8ZBNxduUSVpcqh2MkwhmLt//3z61lgBfMah0R5l4CYS8GJKaf4IeI/ZDwg7lFEXo/txUXrupBoYAgAIABQckCtRFBS/zBKAqBJQ5gywFBmBIGpxkxYM+mHhGJAxldDJwKARWBMoCBYS3FQVkrnPA1tH1lIgCPL2cn47h9PQV4VKH3gXizPTtYS/JSzTiGKABgKBU6Cbozqs0rFtEglO1qhM+KEuikojSfQ8yquikkeK9Q8nDPJ7WqJTur+b/a73/ZXFPEB6qlSJiU83P5tNxLeY/t3tfP/5d8otVSxZAsU22GnKoFXvb+P8anJZgBGCSC7cgGsAP/7oGTfACVUYNh7OEpSVAPJ72nmlRedm1HNPTZBG49oNYeZPAAJwBH31gZ/BEKUM2SbFijyDhcF2oFAdcVlPKEuHBGM5eqfFNf4ekhfuClxVeBFuENuHit/hys+vzk86tP+rRN5gZRFamqYIFEBKhhKOQkOR9UGGtUjSKU1QAEQrSOBikUDsoCAHma3Mt1dvIceKEq0GSOSt0j8Uj1AXqSwmoBrUOT1XwJG11x+xOL3WBcbUvN6JKJya2zatKZh+hu3+Zb+dL506hQrOzG7pkHnfgiXJyGKiybGBqu1a/jS9Dx+fupsbbG8EEoOEguQkTDhyWGwPNnGwxKCQVKCctDX0+50+KlyKJlYl7Hu1HWnUVcjBcmx2sDkYAAAAe4AR+1RVTY+yYxBsFDpiGw4lJmuGditfowuUAqmomkJVovEak38kUd5OICbWEwbLd5dBVfR2JrtY/2SX1I+j6pWTUiEAwGWIFqylhfo4lBRgcAHnJFBchyntp3leLDL8diEx5yDAkBIFBtp11frtfiXQ5RJo2KSnv23XqLgalo1co4Of/c5JTbDiElwtEYniIMUbSEIsPQrkovPofZYrkPFw4WId3jHllU4zOzJbtlTLywMSwJEvvuN/qWP5n+vWVnbbvv931735+P0o4d61SCfpNfq5d148bLDN77bbZfO/oFFb9AwxPZRzPgpjf/7oGTQgGVyZNb7LEXQRoO6DWnsWxcNj1NsaYmI3QtoaPWyFO+9OfplA9Mr4EX83QMf4Agzw45W6X2gYYjT/Eo3bwGcnxkxC7FIkuqbJIHLf58GQBbVtLSsEDy6sOQqH7n/b+3Z220VUcArIcKAMWnMyHAgQaSiECBg5iwLQGyl3zqiEECAEOBobP0ofCngU0Q1YI/DXH8WS5zUnbYcoYnVPyyENaXfeTsni5phaoEFUfxrzkc0FS57FdPAOBVVqIluTOHB8qvtT7Ltni9OdvFzTE0qyV1ka6jqEtsUlJ9Ei1YYHTldavP0nwhiRNGC0Xdu9O0fvsPjXs6z3zGSIEOWYizRj6zlpIlgQFcIEZ/Kg65MzNZ4Yybp13zyj6noBMAADPwACpPVtComozNMcsBjLGeoRC5RLINklEvl5b33aCpT3rlC91SuIxSirOVWBUxity5CzHyaELVP+qvYi4AAAAFBRqHIiXXSFjy8prlBnxf0x8w2ZhtVIVnLY3dfI6iRBlHMNqpgsCLNwtg0C/D6ZRvK0fyWVj5hWlp0zOaYf2XDyRTPWxjQ1Wy1eNTOzuJ5agbneQZl28ZVQooDpzivoMJSpJNu38k7NjERmVt2uXS02R2atHUd53seDeam7MGdx6Zhy3rPfOtUeTRHmd7xT53uH9btJTON2vfFs6xrP1aBqH9QpPbO/v/7sGTRAEW4Z1ZjTDXQPuN6CmGJsRghh1l1l4AI8QtoTp7wBDdJNUr6y6mrhGEG3b3/Wr/9S0lT9gD/cASTwWoQdlZ12ALiXru6mYHJcqRMmXphdOMja9ULQ5UhxqtZsCopR5dzOZHzztEDsgj0u/kP6cxe56qYw2GJJXRnRHSNRj1tCRSsQhY9tmen5M9nckBgKYJABmYYAH414AQ5ExwYAKGVh5rYsZ6pBcSKB41nnZMIA6w0BwMTAJr+jA4hRO4oaCECYCGIEEo3RXdD6wAsQdQQOcJsUjgcAvZZ8CNAUEU3LPtnYGxwvHAbgrxl6maYcAsGXRTyiRIFBAECrPa/GFYm6uk0KLxwQBFU8HHtAextlG07CYKRqbo/xxOUtwGFIms2VOvmZpX9ll6YoJuXyOxGFN5fO0tPLpIu59n1qN1pICiULfyhs14hKrUXjNW4yhs0rdOcjzyQLD9PC5mHYacKma7IbN+NceiKX4y/7/vJK5HhnO1822ooo/rvMnadCYzIJfPS/Gy+1DlWlNiONZkFHclsutRn/w53/5///////////////f1rP/7////////////vvdY441u0wQnoAAAAAFYxS550q2AJGCr8LlCwLkwgfi4kChFBWjz4QAWMMFFDDWHMXUAsF+RKT16ruiEK+lUO1hBggLKxXYjMVfowRFfOtIhE1GSzEsl7XCB6PLgRkQAAABAIo0oVYI9iO4KcXxIJENR148WhUwa0uFMOooYiB6amW/V0dQo8RdHKA/nzkiEElj9RTO1vlYbkLx13MkFWpWdkjQk8riijvl2uEsbLIfijRGXagbSeuLMh//uwZP4ACkOHWn5vIABTQtoTzWSCGkmVX92HgADdCyf3sNAEfSSXnU+mw3VhdEJOlDU5IpjKNI/D2UqGtrO5sRznaoaMLfdVmkpjpVzGTh+ysMGSApfHmaW1vV6G+Kp7NcXTU55xeNK14ZMx5KV8HOpq53ndKX+v6x5d3i+0b+mJ9YvrOM2nzrVsb1LhJZx1zgpolSUaAQAABAJ/AANZTEuViabHXxLUk0UU4Zjz19dWaqhazYnggRykqas346g2wDw+huMgqdZj/T11ddVFeAciAAAAAAUKkw4AiEKCgWAEwBoEMbGwstg8CMQGDGgIvJAzjq3uA0pJlgMA2nVj78NdTABSM/0hXOuMM4uCGR0gXFGpQdJJIArTmHe0BnORbyhPE8R6xKmSbJCB1gIRbiFJYlJY1QpyORYdKhHiqwQ6wYptIe5lsU4HopEiTUXIqzILohgngWk6RdQbtxLDfJiLebg0zHRSvRCVSxAnymH0cBJCZDGWTzL0RpNjAZj7MY71SWh7rp3Zyb1K9UKjkhJ424AqHIEWCIVEwsegw4PerRFmvq2lIuoKm4xCuaJ30hsvX4r6NdwC96x4Lurve2vsAMBgcATxAAbvvtERhN12svCYnBlNl0GYMTRyLJRd+qQtbbZkkC2meG/CXrzMyHLKWpbvZwAng1Hkd4xwcv0frV7gHUTAACMqfRCAJYzRMzJA1IADDjPkSVmLshwIWB6VzDC59PDJhU4QYaC3bBpFx9UfzDjXelNHLUQkVg5Dic0+3ODKf6GsZQO3ymRjC+TLjGexkhEQxHNCiMdFLcLJeWxRCPSKw9GOG55Vkh9tqwT/+7Bk0gIHnmbU829FckACyb1kWJEaOZ9VzTx1wQAK572RYkQmU0mNSl+UitPAv6iZHJtKU0U2mmhMjcQlfQBiyrD07lUh0ZeXcNWSMkZHLrb1jaJ479lfOUVzeSXbXUKFKhhxQFhs/L/Eg3g8X0xJyeQFEg9J0hkfZqHE7HsKUhRlm9vxUAMgAADAAv0oA+WUuJDojlDcLDgi06m7I4+yOxdm+uVaet8lMoZpsPBQHA0uEkM4mo338mPzb1nuinxf3bP/3pVVZwSAAgAAAiVgDly6AcqHSqzwoEEJkG1zfhC8JQPEj4MDGNBzcdMMLDDOVNHqBwJEDAhtnDLZp6qZXPaq8vKkly1voKHq8brM8yy324NpSLuFMzMiobxC3xbU69lbmJWKjdoCpwplwrGZsbUc5KJmUxMyXODEqH5kqFlY1YpFSoGIylWrU/EfMT6Z9AYWtXp5xVqYkCwG2QYFTCgM+hIwKu3JGiSjoaH3Gv9vTwUlvnzT6j43Nzc3vTNhMhbGd1axaCZNImNnVJ6krXSAAFAAAJ+8ANYzV0ZDyZjYiy4Cl6VjzlW6LdFjWlecxYb8gHl0TigJITAmq3eQ2sWayf9Qs8/69v85qj8oekEI2igQph0IuM1uawPLOYwGMcQDDz6HFnBZYwnFY24bYMvWD6SXYaZmIRAQLT3l1O2pRStdyfY881EGmVVCzn7SZOOksUjAPgWQAyKnPgjRtpS8qmvWXPvVuCNiNRsxDV4Ik68Enz1OHZ2MN6yWZHAdi2y7FWEsfU8XuNR++a9XBM9OQ+79vuzf4053doCCwAGQI2YJDfPDv1WHvLSPbl8cZv/7oGTWAAZhYlTzTzVgOqK57WC4gxSFfWfsJNeo/QroNYY9LAAAAABf+ANWkz8xOCfcdfpTBM9tc2Sx+Hrz0C3CEedlNO1FIGFuDMJ2SWTfyuRdo8o6CE59/sm7sVd4f7KWKr/3W5OARKJpO8HEBIwYqNDneuZQqRAAYDro+UJrDwUxNTVsam1GQySOYP7GIp6qYLa1bG6wvgPGHvTPQZrVjx46eOSs2c96qpJ2sF4rf02WQt9WrFpertbVZjQn4qbA/LttqSn69MDfO89b++lst+bjx0js+0vpafc7nof+aM2XJ3f2L7b816ubM9M/P1n1z1Fy7i1CxfenXtmZmb90/W026B4oOioAAAC/WUZ7hL9mWMuirDZ0lkeREXVu0uH5w0GbUVaVgIEjEEyC2AJdeSHzGqp0Fb//f06xOD4HECP+gMf//wfQ0IgUUZJcUEkbiSSaLkt1M4CDBhcwghYECrN/TTVwDCxsSOIwcycuGiowNVA7E00oNgSkNyUrONtIQACdB0g1LY3agx7EdbhUIj5RkhtKIusytukdWkzhYNShIBGYIDR4iBKCvTADpjgBmb8LUUvHAK3GDspXUywiCuPL2uua/rJXEZs+8vZu30APTCobmIfh5gc8yqZzkc6rBArnvg/T8PB2FRNrDSZE6D/yCHJdS00OxuLTNWHezNJMuU/8Zl8nh//7wGTTgAUeZdr9ZYAKQYLaPaygASNZm0v5vQACDjFqPzNCAeD3AhDWX7ZQvR/41NZVIhEWvWIGau/sqiD51JfxZFNUeZsEok0ufWWQ3WzxqYNdmY3a5rOkl1aml9z4YuONFq/O6vWqd+3/v8rw/fhutRUlDuXy7v////0oA0BQAoZMQZA2NbiuiyfYFn0qaVjFxDMgXRMGYUhYBcRrK+49BqPKIgGZIh8onk+B3MYgCFmxAIQVM2QAFFjyGFxWqZRRJNSKQhpBRXhkDk27Ir1n71VVsv6t9aaV1V711WdSFm+t3vq2u+6kFUaK19JL3U+ylalL6f////7l9OtObyI6aEUzdXIlUzQ0lcbaZCRDSMygAJAT7mBYmCBAgYbRKcc+FirxGJDo5mfGgoOl4LM0SQAaZ60JQeLAd6M4Ka5UoUXb2fLyQ3WFRu1MNq/rTU24W6cUJAwM9zYW6PWyiB23Tblb2tdgVs8md5v5NO0lA3KEZReLzcAvjOUleSRmzjOuzt5lELzex+zKc21gGXxCJ4wFG4jLZdLMYvPu0/v8qvNYgHcXfqpUt1I48Vd/IXM0dKxeApmrWrujHqCmkLWqfc1Mx2R543tvnYl1LjevXWkQcxN13hjlM+kvhuV0MD08qo7Uqls7ek8dnZVjdhdBqzGKkppKaPz1O/VDJspbM2P53vf1/////////////5XMi1v/KsaYZ2NCa6Z3Q0IjcUUjaBKSaNqcFmZ6y5ogBonBiThlgo+rAFEaxmFVhCYHMzKgyovP6pNsKaCCrH8BUUmIAuGh5EhiSj6e6dNUwIXHEE9WdNYf9KtoL1QpSx5ZLUdZ6YarsMedv1H4DeRgsCsXnX+beKRWlmmjQLyB4vVgFjcOQxLnQfnGUvqw2elRQCyzV95NFY+1B4ZfDkF4RqH5mWz0CXovTv9Dv8qz1iI4S+XVKlvOOTW7Fq7+4XW3V1nKa1S/IXaz//vQRO0ACLh10v5rAAEdMJo/zWAAUiWbTf2FgAoxMem/soABxuUtDR3+zmbZ5yeobN69ViFiN247c7Ut0+8Z/tN21lSzuE9HbMqxzkdBrGkwq2Mq/aeXbsdna/P53t/9fvn///////////lrLeX6x/+f///////////Lm7vqE8OKuZCSIRBKi6S/JGxV5nQga4IGog20Bnykmnsuch3akKHiwKpGCCg2ERU4xO2D40ajpW3JcH6dT+KhSKlaCvY9VFSuXvqm3vuKnW7t37u4rlvLW8692ziYl6kSddy5548bf+y6uDaPdfVRdczD0XXtR7jPVUt+9qhKYUvQebJvYqdTPOYq2kWNpx5HjlFE5ZGiBVkIGJSJTcLehEocSzkHYFkl4AcQRnrsTMQ3YmmApdFGuJ0AGoVMIIgOKQBgoHxtChQEoFxvYPiPTILyMQggipHQIdI5Y0gdzL1S3vcVPXY8qPaLhN15WrfOu0pJ1eIVY5Ys44Qornhq2Oiqa2+GiZfdW+l9rtfqu9UiidJHzpK9wlr9Vww1hut46r+5IoIU2ylMSSMTVCIkB70WTZ4FzQqMFAwgtzk2oAVtVOxdhi7WcP00mCXOfQ8CbDVHrZX6rZKO0LiKh+uBcDoLVQj7IEhiQOhtcmY6bwlaP0WIbTEMNCjQYSFnOrJEOjPUab7CkGKDmPdFAkdcpXA4kniDI2U3TGqOJafDG5D8v/3Z69lo3WuZJnPvumt80x9mfLyZJffGNZq3/y+Yf2Nqs6pf87mfP2qz0CEnbwZeqSSXZzDunD+/EIqJ/AZY+tDHjQCIazRHWUiqJOOAiIKge0cfEEmPXRiSbOXZ/rr6HI366/atWLtqUp2C///r6TO1Oben+Wj26lXeULAjI7QayTwo1yVf42JpQdnYmQLJLvMWAJpwONEqo1o9k0FgguCCCXYNFSxTZliCoAIiOgQsVKWJL1VxBLuNyBIUBCxIw+TBHh0n1EoUffWZpHNbbEIZ4MCB1xE1rZuMRdRMBrrKz1anT1gFwr1TbNKMRhCSkvERt2+QoQtrJe52utNJWsliD66Of568CptX62z29cWFg+DaJGXUhBf2hlSta+CkI2ow6GTU9P/7sGTTgAV4YtPrLzRiWUq6v2HiLRcdkVvtPTTg8gsp9PMdzNrwkTwRIC5Jct1v+vb+K8rIFE9cgI02wCa2yK9thEAf1HX7kjO7P+AOQbpHxG830o2O0+HwvWuqa9DmYJge24jkPh/z1Lnv/8l/yr7b///rDv/td78WXZy7BmAQAIAAl8xRIHjguYBRQgKIumRIA0+lUVnQuLdpAAsK1PkoVuDgEksR2XRq+2FgKGrr1t1vh/f9ffdcJINFpacnvkwWx19grI7jW8UTA2MWMdvSGrT3PZ2UsvpRZ6+x86rMHXMt8CFEH3qqvMMI6jcJVsb2C8G8ispKa8fJCyQwV3Pk/7h6qDbLaMnfrEIsmOQGSL6qUEOaNrMYqvGqWgkC4YW8miFWp+bFJRlCGTi2EshgAAAAB+gRZ3gOku8aRMOgVmZbscEKzyrJ4NziwjzcU6WsbeN/Vqxs3oISE/ptvSIu+5/8gZK/R22a//ndXZ/6////7kNFwDKoABABCTwjPAwwiVJmAJCYQBZQxW07DqEDlrqQYQ6kpB5bMC6aHRmsfh+SO9Tt2f1SpFurZCqbZGFEZ6zyMOm/INoqemjbSIjCjG3NAg2Z5xnUmVBzKbk/wUQXNCq26LkSOKPmI7ErbA+YCxmXsUSbnGP/8zWNapmJzuysKaMM//+fzYzggijlhfrpQ8oQpJCRGZJLMgbH0OHE1GJw/S1bYTxmCkPO6xim5xYzsIOkmoDkjQAVbdNiIYCeuDSBGPEiKFcXakglZJnMV3bEeW//l5q9GZrnLkLFO2buukDAzr8EBvZ+n7bdej/SZpcEEQAAACCTFNTwo1uI//ugZPuAZZdo1vtMTVhGw2n/YeVPFnWjV+zhKUDqjWe1p4l0hGeRrKDphhHCM7x0jK4ZaYky8y1kMFBkobTZakRXSX2V27sio4wYGQeEZOS1yxk9HoloR7h+4eHJO1bEfheuLp/UvHxYU3WL2ptVchrnHqWyyE+zAcHQou0aq4lizne1jLM6lWQbc5RzXvhxzH4t7HVJMWbWId1NXcjWRmTWKHMiZ/OiINUUFRTuhqnCgRjRHRjVurqozRdiT5FmPjzImUk//79UloAQAP9gBjMOAGitUUwcB5hWUYlw9iymInHJGGPb/6vcs0tu8GpnezCgJw23+VLzv+r7f67fRFxRMyGBIJQkGIJycAdMmgKEDptuYwZA5BWNhrwl+IHjztq2rSXf8EqO06AUVmmYjuMyVHaOu9aqHq4RYl9o3V21oczArpq5gsswwBk1B5OWW2NkhNKokD8kQJ2NUFkDraY9ZHR9rPfL9GWq/evrS2//lt724Zvs7CValza+O/ZjuSJnHd6lj9Ih0dzy36U/pnGSp3l33XDugpgACgAD/gDGkbwV55H+X4MIGsFe1Nw9pl2zE/OTnUM7P9g0xJ7ZpIQAbiL3RQHjG/WQP5PZV+tXr3VE9tWKeSWDMQSJZbXEKAVkBTETC/wnpAUCEJpi6k9GhueXgQPu5s8LzLqq0sWpGWwYGSCNOWRF//uQZPqABaFi1PsMRWI2g3oKPYeTExF7Yeww0Wj0DWg09KoUUJK3GLImJmlwuGkaUksUhK9c+55NScmSVvb2PIsRVbdS+QcsHpzRKoJXcGrKyqWkyJhZHmW1WnvVVTG+687hpDaTtvcdjMma0jVVWtmfs5+WxSU3hEAFhZRh5R0IwZN0sBYnj6QzXjWL6SJVoQEUADUKAAH64DO9eSbF0JTBUCctAF2fmI8Gwn/RNktI4vy9/mC+F4SG2ppYOA5xQvyL6PX6KfSyH3p+UeoZHcjEEGmgTRCMoOcYbLgAkTVL7AwYwGWqEQLxRhMxXHY6sah42y7AEQnlRMZQJQDYDMBoRMQdrEcIXGB0OkI8uouPStYgYxA8nNE7c10atKMEqUxiIiOm1ql6EIu5qzJMkaNI7F+65eRrLf49bDuZuwlbKasi/e6WbLw0Nua0aZpHEDDIzLvdqEm3vJrEtohQwweuMKUZGuhj3u/IyORclORvucoKDl39oBK3go5fSAlKp401qbQntzNDCyMndzv26DlD8uy35/u+tYd1SVQwBFNp//ugZNiABQhn1vsJNOI7wqpPMew5FHGbX+yk0eihCSv0FIgsqZwRt6YQPSN/CTN8CYGWSFrkCV3iF3qGM2ftuk/LGQyJcTAss2dMVYNYDZhGDRRuaJC+C4KpkqpbSk2JlJLoUSzIpECT0QqKCQWoi4cEhjoQZgJ4qCqFAQolUGAQEABsgokibwqRAkWkSCDgO3RTieRZKJUZ0vkaKIpupCpwyyUMOBgwEBASFD4uSLTUKXKGwivagyLBZ0AAolBcRphV5+CyVQRp9HLhHQl6Zgq53UtlnZuEDDmgBs24LExAp3sSj6tVtrf/d/+h361ZZVTQjBBNxN057TZGORQExAIMaKGUX+LTL/ZstZn6B0bgeGG3wpIw9uwRR7L6zvaVJRKLJ6se2+x1jtZeey3A/C7p6upAvWVSnaik+nWsTbOgrWtFlLMpc+zjNrWZbotnd6l7Z9abRu03rnbn99IWqwwrLRbvLLZnXq73d9p2qzvgtaa2z9z+m1pmj3ZVdtqrDnezcimYfvBU6QJ6AJLTSQAAAAfXy+PpEReniYQtlAcVuM2pG9Ay6HhnoFwuMmkFkynsgD2bipOJDhx5pW25qEIAxyGpeUWhvQYFXuj9XO/6NH//8EOlNwSAdweANgBgOCQZDAQEABhVNFhUMv8laDSBb4UP/n8gBgmanN/hDSEgLw+/0kbxBjAf//uQZPcABOJgV3sJHFI2gkq9BeUbE7GFW/WWAAEqCun2sIAEY/5KnvN0KoM4jwJ3/9XIlGn6yDBHSBrF2LF//x6lMtHLlhg2zqDj//85X3O5hxeXOoVt1///9oRzSIcvvlKhufvG611/////BVrj7KXbC1Pdf4/rnVsb/////8qmUUO7DFrI+rSV8F/r///9SuDwAuBMBOAqAwKCAABAgBgEoc9MIfARj/MamDkBvaRmYX+AQwcGGm5nF/+LiD0QECwGDOGiDMjHAY9gBhzwOL8VsYmorpBC6QIMI+TRHjhHJIoM6G2gPDCvB63xBYhxbICsmSjRZH+ObUOUXTVXSS/8yLyi8ZpGJFfmKLK/5RIqXVLJly6WCZPa9a2MlP/8vizh3ImJdJkxQIEikQ08E3etTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//uQRNgABPtW0n5h4QChasovzVAgAAABpBwAACAAADSDgAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV]],
              ["Hentai2"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU4LjEyLjEwMP/7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAGgAAJUoAFBQUIyMjIy0tLS03Nzc3QEBAQEpKSkpUVFRdXV1dZ2dnZ3BwcHB5eXl5goKCgoqKipOTk5OcnJyco6Ojo7KysrK+vr6+xsbGxs/Pz9jY2Njh4eHh6Ojo6PHx8fH6+vr6////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQC3EEAAeAAACVKHwJxVwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7wMQAAAdAAUe0AAAjgTBodzOCAAyX/ZtddY6wGBonD7wfB+IAfeBwfNCAEAQDAPg/E4OHIg4Pg/5QHwfB9YOO4P8oGKgQB8H/4P///B8FAhZhgAOAATFUhk1iSBwF4gLXyQLiW8QOgYhJKaUzhMMtWn0c6pjrExAcUoGg+scvoxpy4uJPUobslwGTgMmSPTL8PExR91GEOSOsaZi0m5WuRibfKbf50XfVO/j1RNTQsgytq8qh+LXck10Jqwz8RV+nIf157tPRWH/TEaxMxvGB3SYNad2kmpHGoduU9SV08ri8OUFvK1SSadtv7dsTcsgTc5L56MwvlS5I/w1+tbxwry/GMPbj+ubtU1t/Lstr26SvKLdN2a/v///////N0+Gu//////+9lzlIwU+62lXCAAAAAAAADtZIghYUwsADgp4GhCIMOcTjFwohNU7l8vglahNL7LggNjklirks0MFE2UQa2KotGAC5fMAlDApipl30Ml7IIXocR+meF6EKFD3jTgX3FUUzJRNdczSxJQpFCs5f4AgmOSabpigqoKvTLZgxN1ltqbzEQikCyRri5C+D8P9AF3jYGOOwrcv5QBJimgJHytVddYRfkFMtTkWmlW5bdHYiLRAgRQ8x2wc2mOyeUuupg2sEw/G5DGoAj7/pjhgjyOJ2WPvTx1raARilNhF/qRSU0svocspiWOw4mMTdzF9HklrAIQ4L9RW1Oc/WqlLErduVwP2ey+H7tPD9/lvX////3LH3KSHJRKIYr1I9164LB0DSgEAnpujpi/aho0kDGbiTHAPWoyJiLIGYv5H2Z0TS3bgycxzoi9CA9L9nisUfkEpJSo1SnkG8RqTBC0IVX/02naHMoY51eZvcQzDLiQd5vpWk41A3eOuKDDL5Bjapq56ngr9VpF02ltZsvqqaCxqEWxfxFhSP5DeP+K9hMsPVw6DVjpNNsFt2UXJoKXEx0XXJLJzj//ugxNWAIj2jQb28gCK9r2t9h6LsGjgRccwdM6l8//zzr7fE9VZd/nhV4xXbogSFgCtAAAXH4Jxp8gUaxBCGOFiZjxDifLXkBLeOXSG5Utqp0phOHzo4BtEcqFE9hH8CRAFClVO6vMvijlYZv7c34KtZcRHOCiSuQ5Dp858p5sM3rjUUfQ/S4k5mni4N9WKJRRtf7i+2vLq5JEdtifbvQ82mhzMy+zPi6sUF6KmOHglONORmqgMEQbBU1xXx9QW/EmKWZ70y2KVx+sFnqa8cCIw8dr13/9qDOLgk9YNKPAQAeTGQJA4GYYEusxhITStDQZfpntnDAv3j1o0r1nUIQREAooJbhrPjcShBIO55aygEKhLVXu/vT5a1WOaqZSjdAkqRC7de3ndwaqppe1/N40wWEwHTa5zuS6wf//vqvevjFH4VyOjx63X3IO9givIkja2FTX1+8sbWVrjnecVocd7Ztv73T+p7UXeh2RBIXmaXvFpf9uNJte1Yb6uvwbXtoQSgUl2TAAXFw6dn5bxgY4FQkpRnl0KJUVLhP6+GlOO+8d/XaUtGTQvhKV5XP4joJM5/2BaykDlia+v6DIntiRkiM4yw9axPN7IgWnXpjWqA4ktPaT7+t///ENy/xTN4YvW/OG28mC2OOXtoNcp+L6KxE4eB2ypogctEZHPb2isbUVT0hzqda46b//uAxO8AVSVhW+w9E+Klrms9p6PU9Cg8EqxKe7el2OzrMEkGA9FAQFzIAnfCwgLkwIAMaPawAT5xwzaLCR2CW0U58eDfKmASiS6kpKxYOzqHI1lYMwa4FNNF2pmQcefZtJQW7N8dUlyLBiAHeThkdqLgbof9PYhgExJgyLi1VE10byQHqpNBJAdIkpkYnCeWaJCDyYUg65cD5R7MUzVsPFI/dtrYYEmlrrqTn1ExkhKGVTZKyEp0Tbs/H/TptixxAuc4E73SpNXt0AKAQC+aAAPPodZIoICiS1RhLzQ4Keh0aWrAzBValFug4W3tres6krCyY9m5EMN13g+5VQUboKXDGtboQoBZ+rve8lLHOpJXdq27isi3tb13Oxkx/LtTtfG+PJYUOWv/5/+Pna6WsfNPl6M9u1H3iFGLhFvaXMrgVRrQ7JOIiYEzjDUkKCKOPec920VYuY5EvMClp9vvVCQ9si3hLUHsHyfbQgj/+4DE8YASsV9d7Lz3Yp8saz2pLrSAYH+0AAuhmW0CAwEAXnMIiGwsweh7Q1L4RlK2ltLAzUvijENYYPgZUQQ0ylyF00NNDIhKHjs4fu5avCIAsiySdsbyzm0AUvpKSXzNHKhgCep7FupY63N5qn8wqVoLKBKe1e///+/7V2wLV75xW64Q7OqZcH0Ul0fct3iHnOLc7/IIQFgiB8TUwNmw9944QmvhbcWOrqUUYdNPfxf9cuPZzmxV9FnJHrgm/KEEcFBfCAAFzECi46HgGDqElv5YFwR2TaYCD1HFmQu0vEAHx4G1mhfVslZuxiXBj05gxhbsy5dMKXqDKrGFCExi1JpjVx9kMndsc/mMpfVKiknIKkNeK2Hpl2+a3luYa/jlWqRFQFIVWazz/+azSd6m2jIn9SYUqx4RHG3EKOOEqDo62lKotYJqvV+D0fJyyaWpNau48vnZmd68jfMQc7aX7Ezan6GFGBAwQ995Dv/7cMT+gBQ9Y1nsvV5isCxrPZejzFFfuIEuCgGgD1yOBLNjAQVJwsnGEQzMDJOct87LRltskuEoCTDSMrJWdRPKynsZDFApcXwzWjsSKZiAQGQJU7zv6Z9FP1+OFyVgEHULhN5xacsp8jjf2rb1hF8OCk7NqLLi/1jmDczc1sQhYs94LFToDIoKnyTjgdDg3Os+zRwPiOeHrsLFDeb/QWq1/7sUV2l7yEr/5c+6+dNx8A43+ANDWBd0NJ12bNXLowaRMAQAAAPNcZTuUrLOF4woEdsQAjNkAy2JI3LVEqkjbEBwGVBgYjgt3/svsvkEjwP8TOWtZ7La1IhUqytr/y+PN1h+Qawypa4GCGlDmDAoDFiBGenqDpDnJehE0Wk5MhT0Pu8pXWGKPqkfefItOHj6+dNrVKzs7JP/+4DE6YBWDWFX7TB+opsr6zm3o003YZyGsaPjskGJFFuLy/VcengJwBA7PPlb3ruKvtvTtJgGo9BQUT3XRPqSn/nMEpgnQxbJ4qJP7RVgmb0sZA5b4UslN3bGdBFD4EMicMBbIIh5OgeiK0coNIBxt4rKBQwKZU5DB8qUqgh6T2vtunbEoeLMtfJk//1meMnU8lkJzuWK+nJTT/2onl8YqtCEd6lFgpkd/Fg6AKH1//8Ml79vcdzBRIrMdzDEhydFyosxpLf7YqKnf////xAq86m0MKP063X8/DBq5MDc9TLCoHYts/11/LUHsHEKwWy70shCAQAUrRkMpZgZGFcprIauuYEDQCzObdAEEIc1V2pTnlFGwBRa/rOWEXop9+1W3O78WSSB25/6r2yuKiVZZXO677x/el6UbOCNmU6Z35PqFO2wjveqSRCaZJdgm2WHgcULFKAv+fP65RN1DkGoElt9PhUoQ5DPnPp9///7gMTpgBfJo1ntPRriPSYsfZeilR5nLqf/tAUGlX8vSuQQAaAVavB8xIbHjslIQccI1DjQXyHwggORVVMvriqVSkgeje+xYksPVnQjErnnlkambt0M5XlmH3KKWVOztBiyBoEgvyy/TpIHbEqeq3HyvwtDUiSbe176T9S18OiG24JruFdIG+18U6cCVthkySMw3PBTV25Xn//hvzJ5e5RAuvO9+ObXJ2EWR7dZCHTqmdciK89GzRoeUGibzFko3Sr6pxqjQAKATbnSCEYZcIUjy121UXi1biIJF4lt1kN5YzV4RzY8PVTSUJHB0JCBVRHp/Bae1YzC+cdGmcMjMwIqpf7udr8KfEjtT7jKEzrAp3E+kLERF7nUIg0AxAKA8MYZj3ZRgwRzxZQ0TUCwopwcqh13/F/yRR7GQlJcDQ7Qa8vikXe3ExX6VDxMVPPpQ+kZMU8wElHC71/dMDqRgAIBSczigQixiVKBhnKk//twxO6AEclPY+wwduqIsuy9hI9tIWTGBkXCyiXJ1EiK9RMI/zmVCIHG0D/PZcBhGsWZ5vbPZlyKQ5W+H00qlmVkihXAWlXIact8ENIjkBoDAQHIRse4yzjmBxSEa8XEIX/H14o5+SSZGDcdnkvRumJZDYcSnpzrt/5qjXav27inHc+ayoqG7x28s25n9mXFNX739n1rneflFa+7haUQ/fq5B1BAAEBsl5yzAKCxA0iIxdxRxAWI01C5ckPt2Xl8cWK/r7RlYGM40zyLlhcAUmTLlihMFhIgqsicdbR1AAQB2ZIXZcPfLExM6XT2EIXFNt55HLcqb1UcMvPsYrU67czNOFXvnmfTFeHLWGiT+nQWQMz/IggHRjek3/Jxynf7CknLluZCnNCPLMzi7m6iaBrfWSMMCAYADv/7gMToABMViWvsMQ+qeDMsPYeZeCe5EaUhUKNICeaiPQIEnUDlCUXYhxpDaYwUTGoWnRSXU1nqITCarmyKIrYFpPXqFEsUtlfYiLJTK6CB9Laev2S8+SoHI5v2bMEFLWWq9pORHFYIa275zazC/DBkpZoZkHDkMX2Ha1ypNUUYQAK024wMGtUpCdQ1BCiEQxY/uLzYobH4s83PlH/DI7rXJ/mpBUBQAEBJvd9hxLAAoIeerWzEswDuyuLL8j7+rxyTcTiUrla8qSgpaNXKojBsEkaM+IHzPjCFgh2HqWnwyOHCkGXR2VQ81mGa2X84ZWNMxz/Y9TpXU9z/13P21qzMkrvW1zZCpt/k3hxEJyDOtIMKxPFFgL230ZGwcVwirSacszVduFbP5TAWKgnKtLTfboCoBAAACSdwGyFRkhwIsSEklPJ+Bkp5ItnzGoJa/YUqd63Gobn4hZghOpeCx+cNKEcED5WUGN0Ry3fW//twxPiAEi2baewkdapSsOy9hg6prHbK4dx3OSwZUbp+cvZTuc6ta7lsznTd7SUQoUNhV+JSoGEtut32tYsKCzN7VdSLmjI4KJEluphhXdcExQy83fseyDauqReOq/X9HaaWJhKcbuZxVf3LN3IwAEBJO9cRcBIksFMMQdZZAwlAko8GBVA05PxjkQdDqXEZ4UHmS6JS44MOp7sbLb8UcRwK39ye6YFRino05aZ/3d84b834x0IOR86xKoUYBFqt92zAQImhiKiwEOLolnD1EQKHjhXXbCBRSjkR727spCG2OU2aZkbyK1mWuQJp5vgTCgTR1FYBQhv1uyKY3MSEAFIKdPYDEjgRyFjQAcAzwqABCaqy4H4VKqaH4ZaPB1FiMS1opE0rLlw6OnvXw+T9Rx9g6MGGS1dGmP/7cMT3gBHNgWXsJHPKRK/sfYYiYCunOYcxAsU4PiIcztAuKoXRhtLrW4SzM23u6lLCsRKWtO1urOvX9uo1cqaq3GFHy+vz4ojPL1KXVER/3Pcc81Nv/1NqJVoWD8UFA+EYBY5I0Z+1yKlEghAAAEQn4FMpnQASlaEHW3QDBYS+0rXXdhixa24rPe5jx7NlCwIYkAXkVKxptEJJVPkJGVFrwiHEZRJTlHfXF51y+fc6/oiLVZmalKGMYYfuFtpSqWQfXrWIfWiktRpm9m1YXJ9jfW+9rz/8c3FkjCMX3n9V7sf5fPn/u3+P3b/PMO/iaazBIMcZAnmE0TT69PZ2nYzNf1W0URgIBEZl73jaDFY06B8lglpoNFgKDIcVi5ftkSYmDVbZIZCoGUSZdEy4NH3w8z3oiqKkCOD/+3DE+YAR6YVt7DBt6kkwLX2WIeXY48WK0xTpbL/+p4yvrzLUYLolUnw+/DZhDbYwkmPUb0de7VaQqqDczLNYiRTWA3lIeEEzKzVaxe/vQ75XrGi8kPzK5Rs0UcJBszQW97v8ivp6RmJBAgAkOccEDADrGRA6TnlxQKFJJRlmyYSwLyNCrtYozMknpTLrxVLiVhdKEpWn6a8wxu+SHhlR9TCcFtxT8GWnNveY33oD5HXvn8/f+ezJkTPI6QPUuZVHoLYKy4gMQhstKph0O8juZKT2L5jOCZmzO8dflyf+5ZvMjJCUIzjMDISEcO6Av0FKiif1DUqEYAAAUVMPAETgYgUQPNRAf0kGXqDJwKjs8K6WAvsxGLKB86FJh4mJyrBp44w0wuwojKkiROkKSEDA6EIHhOFTyKcl//twxPqAEyWTZ+wwz6oeL239hI39ahRpRcCOWKKK3Bl1H9LwdZjyVLIMzohoKNGqbT7zZusCMIJE18uXY5Vi9+ketK/4+n5N21+6pE6WuJ2mnS1dU1rv6yEZybhGxCkVExXnmUhCEAAAKBfIVwKsMKgGtoojSQdVEFka9AcJpMheALz0tQtIBsYJWatR+dgdtiGhr3CwdPlwu6WWUKx+tLNTt116VX/8K7lheLfPMqJLKOrIu1hJ6JZs5mPLeFrndz7/3Yyqb3ztquyzS6tCtbnkeW2vPz/mxTbX/t8fP/nv5OvSZadFG9WPO76zSSd2RotkIiqnUUqmfbMyoIgAAAIL51iDAogFTADAGJtAAoAkOAQFTAwB8mAKBMSg+U0E3KHtfaD3tltlwmRv/gmPh2VoGqf5Igkkkv/7cMT8ABG9hWnsMG/qSjDs/YSh5bISydBMdEyWYm2P3sfWvLQhHBD6aZ6a8Gs9AnRRJKRz+s5Q0w1TYf6JqmFjzVCUopl70pjrKKjqiSxR2v/+aVqetDZ27qIWJi7mh4OaHs3VlRZzFZVsc1xc0txkjJ2sebdkMwAILDvKShUIPiRJWFQ2RyLalrUwm5AgLRkelJLulUPKikwAayDtPRNIWf5UREOXiyJdhV5YLKBshyyWWzRajRMoDQFR1rMLNEqslX7NAnT14k3Wmb6+fWG2KdU4/i+NRVdlEIfYsT//9xNartK18fXOKrjLY4WFiU6uLUmgpXaqREQgZAblwHTo/xYqIAVkLhEZMohMsxuygwDwjGQkmhJE4sOiIYjyv1bfGscpiN/lsN7ezRdUCACoRlqo/+LVSjj/+3DE/YAS5Zlh7DDN4nayqz2WIqVqjiiTYoplUkOa+dpX/+viLkxihlqzGNjZcVoWg6kZiVOymVB+c42Bxz/1Y7J/+bChgwbKZoVQVAI2kX5HTAXAIKSIGzLMkgy9QUulQm02BvQqKrcYqxoGCpJigyOAVzqfBwJqoikAMBA2ZqzmaUcUwZIBjFKDUePKYxgEBxmEA5h0BGCEFrscxnY6SGPlQM47xKNeD2S9rDPn4fyz+TkQCoGqQxEEgTECS5ExkkYnoYa4/kIcuYr31UCZBnKpOIPG2SBVdwHI33MMQdcGCBBBAcuWBgNjVOwdW/u4xBIqUynM4V3qXp6MEZwwxOtr7jwPOxpxHcWEddlbL7c3Dbty6bisXv9r/+/bDzlHrIINj7dn2cF0AEDwdP8npgRI8PYz7bBk//tgxPUAEFFzVewlD2ndomi9hiF1OzkzLaD7rGiAAgCbLODAgsIgnHByJdQIuuBpDRFAsIO2EQpkAW2vw2oMu+GnMxQ5MuMI5kgsMLImIycKqKj0JmBzAQkTegjYyU4w/zlw4xRqgXfTzK0DEzNUMg3MWLgWCMIJlaAd2Wvw5lVizlt4w1T6fCtlJAUAPlCofrwS09d8YQELdrpyM6h5brIF4rnFQ2LL1Q/BQbsGMcSjoIkVUryy5RANPl5DHZMMlwFzqPirZ4pjCQCOHjzDRc4GlF2ESlrGUMzuMFqja2AwJEeQhiAQFCMsbCBBk4GXl+G/YgvNgzoR2ndiETMQ/SXRlYvK//ugxPAAHrFhPezg2yygtGg1nL68qaO1t7lMuHjCm3NTIhlVRCEMfjcEkHQMI0RDzSNOCznSg4rgo2RRoe/it5/tz5E1JeMRpYIECG2I1nfqhWWodxEhAAAAICnGAzFIGA2xkwzJoEIhEywvQbgjuus6Jev38a/dnIvF2EKwuushihYLBwzgwTcaxOF3HeWdahqCXTjSwDeMqIAEiEtzJYSd65Uw2Bs/xj4pVYWjJV7q+1yqmZmnqlkQztsTfkpuLukNRzVbY0mplAzJ9fd3P9ujKdnQw+kCXxoLuukm3eEuzlXRkJ9JDFELOBdx2Rirlnfs/eb1a1SuVlK4SDCbUT8k+F70rSxxuhd9tOcDuAH5HWlYtrFi9sS1/ytSMPr4X6vrAXLg/wCQWk52T0E8PF2z8kaoggACQA8DliIEhEQk/iqpCYOifBJwlGmYmuXLSDCMhxnBdVEt8wWKCcQRzVrIMYPTMc3OQ6eoeEtMBkJRoBryRZWM3cin/xZCij2Z0lh0NQk7H/xTrqn1s323cxW83m0rYTBcb0wdphDt7+TzGPdUWxj7+6qfpBUp4W2MjfNoXX8W7mOT6FIMi/mP39VNw+uVJiTmEjL93KO2URIDjCnRUHiCSxhQGMjo4wgAWSfpuQHKWtQNOLW5wL2ra0o+ATi5QFgLOE1OWC4KO2mo6ZbizskTjANv//uQxNuAG72jUey9myJkMqw9hi29ucDiL5n3xyqhurSOmArUG9/+SkQCxRHRAYlk1WFsZvoDVU/RYzgg1+Hl8kf+7YGAZ1yiJT///v7TKIUvl/f//CXAq5w/62pImIAABYBeFsmWZYA248MWKFTTbuKVoclcFZXBcYuB069aAugcLKx0ahLWkpRr0I+lcuUaw8XHpcEcxLIqLpOLKJc34OYRZV7ogYWHiqxRIwgRvoxjMsx5rnFBMwYQvKQ4LFXMx2Rh6DA0zWVROivdNVMOEDixDKMuU6y9+t7iiFuOWhlzL62UhGceVALCptvfoiYwAgNIF8s+nerWjHswdANQwCC4Cut91E+blIAGdFWWDAr1Mz5YPq5MtgfuXDswaWvN5h645Ze0fEonKZ24Cw9dK40kXbxgcDSA+xKi//MRPnTF2zjRmLovc8ixSjxBFxjkv+lkpa1VUzbW6RNbOOPMgdffdf/38f/EwvTPFai53y3f2jHEDXCajlZUm31kiOgAgp3xJhAceXOOsMRirvKDry20wUtELqdxQxASBJkgDvZ///twxOYAEJmJa+wkcaJFMey9hhW1EJOkNOP44W7pmdf607BBeNhwNUK7uUuhKWldYpnrMYl9wHiiQWLn6/3mKS+7ljiJa7Nfq4g4oTCCIBRSt5NOoRDruYZDhkX3N6zIguSLJenMTfPp980vMQsOk7oTRtxrFWrFNC46J5Uvau76Q3ZRAotIG8iCIoCr0eDWNZ3oIINLOvGkUjknWuV8XSuIBMTno7ANaWQtN9OKy42cMsNN9CgFDJOSsvafCxfGXF3fHX6HguGk2iPdzF/T73HEaE2mwy/kaXZInUlDNv+m5/+UWGhq/nlg/WnQWYqGqP+vmt16t7a2dfR7t/rWYsbNpI6YhX6vDNmYAABLBnMhw5RUI3QiXGUyDQVhKERfdftRNJti4DEzEYslMlXcTIZNDq58rt2JPv/7cMTtAJHtlWfsMQ2qP7Is/ZYhvTcdtHEzDSBEvaLjS57uCYPkvWn+/5h0fOubJso4yItHGRdNK358OQeRK4glIDmfdb98Wt1X0c70iDY+fpRISib6RVR/8wj/fT0l2StaJntFPe/zU8Ysj1UDPCr93TR1cgADTCvInqPq+EDBZab4gK8g4GfQxp2Drtjj3w+6KICkCCJrTekw01v+n0lkLm1yFknVUOxKgSwxiDjAfFxhRzXtEN8H0pDaxGJSker54ulKHjTVcb8JHOI5J558mXfoxKxb/wcPsgzHVf8Gg3a1+0Y2vhelS9497xw+kFJDvYT/+9INz6q2bVEhVIAAkyJxAAyISiQEBzm5PUBAAaz0lrnaYAyprbI4Fon1lEOzcdlENUhEHhyKTGKuBIgYYxlego5kFRL/+3DE7wAQ6ZVn7CUPajQz7H2GIbWJR8mk1P68rS1Lb6j45+xkobe55Uhb/vwysypRUd0LaUDDM7jhKfTQlWZqQuiKyfMdTHDw8v4lEQQ+yiu6vvIxvirleU5DjZWUQlKNdozHwXBSCsm1Z1lREAOIKdJEOMjmgCQfFAvQRLgIApTpjjcouth/XIWe/NJLIYpp3Udz4z+ISaf04GIASnciacmILuRKK8YiFkTzYj4/PC8c0mpBIvc7sUVfKd+qbCnGKmOWWqEuNCzyjsr1/fKhgMVLT/IQSrZ9amxHkXHL/yZA/GLKTLOeX/5aA6IaNy1J1VAAAFECchSNBTKORGlAECXgY6ac9P9hkYcFXo0iaSTMwFxDjRkQ+hFRCPUO0MEZK1axCWFhdJ5fQ/uFI4H7yZ9I59rZ8H7u//twxPaAEUldY+wlD2pFLuv9hJZ92Dwqpx7Crp70jGO9jMszqHhQJCZaLEjKLigSIJiRmFcxVNvRVMdmCyD/0cePShSxJu8xevmuilMYxjiLEajsl9EIscKi47PtyrU3mEAAAowpzGJTZgwWENOMZQqJUxaGsXGbH6NLKmkMpYbxo9CVDodICAVEyx7aRHYikV1LhxA6ezHGmDJg9mC0RMTuXgZW/3VW1lPLT96R2z9mhNwQqDCKSVYsAnZpmeTwEMJBAoK8chgT9Mu6sOu47l8gXtEHzeZxj9jpVf0hIf/kDQ4f/+c9E0xAMNbt3VndTAAA2gJwABaACEuxQcKjHkplBcAyBBE1xOVORXTDZW2KrhAUX5NR7GAoFdFzsSZqJAk5IHll2RWKhZokBuIWRqsyWGxpCaSIUP/7YMT6gBDJlV/sGHUiSbMrPYYVveZLChNtxLrwj6z+Cai1+45GXhdNsrP5LUfXjc1bRNs4106qpHf6TO6iaH+JAcPGR1crpdjbsiUHtN81Ix0LQU0f97lY0eYQlamKtmVAAAKsr9VoUUYwA1BQJXwgIXaZ+KHbCsK/jJH2Jxhg9Xac8QSavuSB6SPz5zR0ylnL2bNe44L4tKzbM5zG9UzpVKLBe6wqUPtV64G0qkXTTNeoqOGmlOcc9z05AgqbIrqvzURNddJcurOas/5hhJJJpjJ/USa6p41HIaP//1XueYn///+YKa+LzEu5mgAAJElwHDYyDCAQAQoZEASAawkNIYLDGP/7cMTmABHpm1nsMG/qUjPqfYSWtQ+3zDgLHQlPiUtEqE4Nl0agSwOoj2iUupSiwqXLl6yziIyMT3mo52xeNzmLWL05Nh0ES5oix/97a/T1F8+xw0VgoZbCwt3AcippgscaOHs2uVaN/TM0oSKt9f2RdhyHtfKxPNXtlS+ReZqJZ4ICndbsCzIMWEVBwBY7NEei+SGLRWGpW0CpoJRASIQ+gZLqC6cmKgpRVYVmJAFD6W2JKOFqUHhGhma2FhtI09Y4Og+BtvDMVL0tHWcVKxX7Q3rRINTzdZjuWGjiQUiqMP+IGqbFk6KLjcaoehZxN5+/2oSe6IrujxDqYKyxgABAhrgCkjBamTjvmJIogdwMgWMxFFSIlKxJgVHNG2pATiYbGXsstJqsNSWCgqJKhhRRs0xUkNJopv//+3DE5gARdZtR7DENqhCpqL2GIb3//apMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//tQxPAADy0BP+wxDKkTDqT89g1dqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==]],
              ["Hentai3"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU4LjEyLjEwMP/7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAGAAAHE4AGxsbGyoqKio6Ojo6SEhISFdXV1djY2NjcXFxcXF9fX19iIiIiJiYmJimpqamsbGxsb29vb29ycnJydPT09Pa2tra4eHh4eXl5eXp6enp6e3t7e3y8vLy+Pj4+Pz8/Pz/////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQCi0EAAeAAABxOgqzGtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7wMQAAAeAA0+0EAAjnrJq/zOCQNtESGk4SAlMMHwfeLgg4uD+CAIODEH3wfB8H3+XB9+D/y4Ph92XBwEHfgR2QB8Hz//8HwfBA5/E4P5QEOvJViFxICEneSGSwGnUtbzBMM/YRIAl8HFmPYBhzbQloJSpAyMiFLuEQqxh0QeZTrdqDWMO401dsTUAZWkKv2sq+wvJYVdrbpquAHgXRDKscKUY1Ty55nY312HTbJ2kizpxemdiH7ctlNd/HVeWkgmE3Y/YlteSMThErvy3KSunCa0xKva43+NJP3NxjGxIalPF6DKzbjMmsXIxL7NSpDGf3rFLzCrhq7b3v+Y5a/X5V7PcKS9et9wy+lrzmrExZl12ITO6e3l/LucNSOTWZpy4zZsXdY2d9rdvVLtLleuY3tkfrX/R6FJodBMAAAEAB2pogDQcACVMFMk7mLAEgbbsaxclZitFYrEWstkCyh0shQMZFTNcl/EZELwKkZ+JrmjQ7XH/qc7Vh6NsglkgtWs62NiCmUSx9Zl9n/dmBI5IoGfxtHkjHJXWe5sSgkRhlrmpimqSJfFK3rQYKrwqnx+aqwDDvyiXTcss3beO8/oKfX6////y5h/Of/c9f+W+fr9a1hlj/f7nn+sa9v7eNrfM+a3z9aq7zwtXr12Yryyky7epe1+44YYY565hnzv6yx1q8wYa10HHs28zE44AggIQAAFBFZGeYsXQKBwGByoKi1vA2EIQ8SiblKedN7n5ZEYs4fZ0DhDd7kHco2LN3MEFOGDEK0xqGUO7Rd3TKoKWd7n38/vqUIDIEm7XZJdiAjEFxoVs7vwxX3MwClSlA02MTta5rKs04uyDqNA5ataq2ZS8MSsUmWGqzZsRtqpEji9KVJiKuHNLMOwAT5RmBKTUmj7Zm08mOmZ8+U3eijfB9CGTIkLk1ocDpwmdFd9697CneHkVvJgAUwQIiAEkhoujpAEiEDBAGjwr//uQxNEAGl2XSd2sgALmLem9rA6oeSgj9DIEEMU+nSwh41TNkh10QqAnGlY0Er1duWshwuy6+eslln+itWMwJbsTRZ4HdpKe3v91YIEFhkLe5285+/ZZgDAEXWbXaK9ll2ULQQhkNz+Ycs0sPQCs23vf61hTxyK73+GvISNCIufA1ztwQsIBOdv4PwxscclTFFCY8giDNSMaHwiAjVgqIp6gmJHtDTMLtSNben1Vu3KrKhBYAAMQpoePLAKMGCBF3S7sLAgt3RGPGj1K1ByGDwhjkqiArZMucaXKO0l25cvxYShIxQdUxmJHhk6AlWTd/POvuvHA7bvTdi1T2a3s+MuXstZXJ/9/aTHqVLWtfyx0YNFYFlmdrV25WVnf3Vr89YrAK6mrkUG9JQ9/qGgtfiI73WPpNoiq64oYYJIQuZfiouLfL0eaTmqXtI06TGqv1Eo8zjoJhuh9a102r6W7+gFxAQ5YCaSDk6Ss8OgyhCukiCsHssZVd8OJIrGljLXadoGOz0EFewqrYq7m5coqpkijDzMXcfSN8xYUgDg/ms7d//uQxNCAFglBUe3gccK2Mqo5rCKoTKotkEiIRTw3Hv5jWmTHhKuGuzv/tpMHVpdY/s2AP4mE15a61Wh3TW3Ezn3YAXG/HRnI1vW02/N3szzXfXbfndlxlZ9w9RJR94FDzSp449AELxhELAJQaSGmvMB5lW/+hOfli0EAhgATI2YWCprBwIl1QFlXEQCTqqJfRhbBk71SNfZfIY+Fg44oTTUi9Ttj6tmqTEIcCQXDj8RTDg1AaUD6lUCmDeUt0klmSzIjwCKjjSRU7LRNBzxRDA2Wz1HB0hmUEnRM9IsFNFH7FciaK01Mgy2Liak3qlimcyVaUT4DGOFh5t8QsERl8Irt1cmKWf57Iul3LLWWTmfhjUGav9ul3v1wkwYI0zPtiZFDsWEIEBBhCDGAT+0icq/OMmc1lDRItS4plHFKr3eaWQ20f8t0C6hIpL6169v93VthwS7fvZY63qPIVw/+Nzte/lEwwE8lSzvXUojaWR/2yQDwACM7cn24gh33feZOOrD+W7pNqSVhOU0Ii4YWVaW+cuTTbxICYqOKLW0URpIe//uAxOeAFIUxU+083EKCsup9uY7osOCdTE00tmq8X3A2v5vagfumb9CBAAAAAAAgvoRGGQIIRG8oACENhcCQAmUYLH6QbnrsLjggBsQpaQdDJsinnRS+Ar8MQTTrmgd1lDQYFNtdN6NZtILkal0mdsvaYZuaRYNFGtvs5DiTE+5ZgDYWoGyNAJnLUeWiSqghsEATGBUO5dt56DDDU7DbclG3nl+NbONTrSV2goaPB6CM36OvT2MnCi8Y1Sn5B8gqF9naMLmDC0P8e4f+G8bO4Suse3pH1dxvZ5LPTZvla3daqjtbu25Cq+N3OIZ7dmzvm5X/3M3Hf4zTBu7r43dmPAwimjzwwsrf+XCVABAABccGni0SpSZcHMRpWVhrJ1v0i33AaSKB2Gzu7dgBPc5iwO3MTNNTRiam6CnJTGmUXc+f+cRdktqn3M03McMcYgpkFyAwCBZ+zLbff3Yc6x39tkh6LCkt+eKhCAqDYUT/+5DE8QATeU1b7Sx8i366KDnNGjmv5rUcOaXZiI1yP/pI4H59MrLTplv1uHVnlsSZJl/aS+ui20/SaqW848yqOL3i7gkAP/X+/+JciBooOW2hpStSpMWPBCqa4cKg2IxJsoaBosYhiVNdRSp8ZIj0Cyod7zvXkm41XaMGDwdT9xTWtYZgoSD8bX/s+0RkCAlI80uN/1YTcVFKa+fV7BdR8eWir3mDVlZLZvin2sDDGpgsvJS6dPRlzOHnlNqh3bvqGTQ4iSERmthlwKB/x1Ck3WsJGzzrOtnfKq3asHMAEAGuLXolgE6jyN4csZOX1LwltMgcgOhBjnRJ/G3qRmXJ+ma2hweFct1Gx0l2xbQQmkDM0lFfCapbdvjGgIRDh9HYy7Kt3LLSRgCb4ompVntZc3+7jPYft85vnf+tTW1d5GPradat3//+goTNvTs+u2OY1+X/8vprdnfvu/T9ZeTsYyIMEtkvUqf9C9pnc/TEfrR9rP9b/n4IxgwioF5VtTP9i8lWU8gqAACA1JpGn8CpJotiRmHBSsScldgEfDAxPT7/+3DE+QATJY9V7KB8QkWp672XjuHTTNY12KwQVIJlCUM3MZrOM8lEvgQWPlAh9GxfO17k9Su6gWBQVX7PN1LdNE2UGHHEUCgoKuH67jM2VyXN/+ucywx4TboczjjnGhBE7rLtTlBGOmZmeah65eH+36nu4tTEundYRYhuSRVKtupVRrr39TC5amURo0RQddTrTEz644Cpb0vV7+nAZDABAG3JCbcvWuYaHAgrXSEV/mRko9wMFIhnkimceZTCKtNUHUQ8Wdz/+Z2rFRugATh3rW6tNFb1SZaYGEw401Ta/SHQEbE4mDekpEP0EESIstkjs+dTMFrdmTUiixAHQU/UkdWXCSX1Ogl382e+XennmmBNwoP24Jn0kPtdT9GTIub255dpo0z4ZfzLPZ+Y1/1WDMIAAA3baPjh//uAxPWAFSV/Ucxoz8KLK+n5jSH4KEgBCY+WhR2Y8hqhbABrANPciB3dhcCS2L0cUAjRbMuq6w7jPNckCKxZaD7pq62TND5wT0eLX6JWSAI8ACojsv2UWAKHtK3zA02a1qYYWdlRvXi0HiocgpEXi7j1maaL1Wp5vmVhrhVmr+ib41NUlQoKyCsYoLvgrvujHa3t3/cJBZopJEqf11JzAABQsv2H7r7BKwFctkDxNjSEb5RYtkXdLkoSmBv7OMO23VMWBYPSZl2NNrsy0luyunmg2Y4MK1kcRIC3ZkMKjWFwFHPf9cieCWTJfeOz4MBgCRIrDQwMqHMtiDORS2BUFiPLMrSTKmjU41JDbmpcp9I4oUt/KN5MBGaYNQQgpf337fgrja0XdwRMREK77tuEBqCHJQcEhiGLqGAEUnjEALAEGlYs8KR+2u5tlckEEqorYpSdcxYr1lh3cY2syQp90ZrV1/jG146E2tI5ia//+3DE+4ASbaNX7Mh5AkQman2GotFTxrWhDdjuTFhmzVsfwpE+xuAmO4YCYCBlSQdsBoCAo0Ajr9aq4Zia+6VPOf5n9pcZjZgJjmqqXux3BcchRimWlNRHFKX3Ld4uuWX7aHqWkwNE5YpHS9bMwPktADgI+A4ikmXrFVvLVN0MhjEEv/ba0o3OHAYVbdzTJKJRDI0hgRkYg4ScZDvV6rnQhvJZBUbGiE05QFY3CuHIQgFOD/LgSh6T8m5/CuC4E8WE4jSSR24uCghnIe63HcmuK0SibM1E10SBlARgDIgQDBkEwNmwHAG0y0wG7QWXis7Izmu15VON3lKed3/tZNRAdh/OnP/eeUofv7l0yhTSNbX9rM5ERcKRGJhOROXFc2tMJMgwQVPlDQEBfdUK5EQFQJ9ojt1TrDBr//twxPsAET1fRewUdopQK+e9l435UdqDE9pTZLPvMrYiOtEOOKpAAgDkOmBoPlF2sSyk08bE2hK0JugoYNCkYuBd7/MsWSx0y5QKkm+IgiyKP6BjUmsKqPw65jAFgg3EDJFU1T1XhHWuBUkWTAAK/34zjjY3vsNYeRuTHWavfAz2wxbh+GwLg0TgLOgHANGoLSAaj9rKZaneshn7kF5qf9XZoem9VlGl5mmWtr8aOzqjhbHvkZbhVniyjJg79F/QwFijhLRNFgptKIboTbB2/uL2rsa06xS8fLKUhfX0Xr2W1cu+phMjENAtWcjcjKIwqGCU2mP+GFghAK2JEIu4XQk0kaSySeeduvW+Vtgypdxm3WdBHgBAZOu+kp6R4ohG6rckmmGQQux6mpvbGLVZpD9qhIEhm7CL5v/7kMT+ABZlKz/sPS/rxLRofYyzVBovLZFUDlaYtQjVscyQw2RzGEOz40laWVj7MLqxIWXDtwyTQNwd/9MzNc6p9NBdfkOXsNBB09LyGaYoeTK99vbe8Ztomva+PtwTqCMHNE+epswmWXfjxTWh9UzaY3bt/ImQiACC5aGKL8qXkjJCLFtqDiR4myEhW3Yu/E33pobh2bqQVS0nK92/NRR/qZTRzcpVZjKSWvyBUT0QENZzlIguCag8khXa6evFBaPujakWybM3Zs7mPUbyN3kOnOcHq1kbldz/6NG5cagwMCW9hy33wyZh/2+4nWVORab0EDm5lPnuHxD2bdlRecOLUkgXamO8FhGqz/zLElQAAAjLRYa/FpgGZUGVEq2jXkRy1CdYKG1hpq1qBl0pqx+XwLIZbSw/lUl0/KWStMeaTS2/8lZeKJoiWayU87FCK0arBIZ1jpsoyxRgxRxYVizEE/TlRZLLeiJim1PGcX765u/6+YWSUJonD8NA6jdlMfDa5p9TEvplwodYm5j5OHEFT0qw18yevimRvY9J50xEHv/7gMTxgBaFo1PsMNriXC0rfYSu7Gj1ZXHElR02n/dH/f3QDKokhCF7FbUlwQdB1D0vQ7aHVAYKDYhdBsOb5YMw00PTzWjVc4RFzbwPdSD5Te8z3QkQcw5Shhwj135IugOoWqwKtLjQ5LaIx40ozj+sZbISOWFEkr13/H/HPVoPGjTwoC7t/m6/+Ootf+Ny2kSr2kpqyJPccjBZZgQRg0aHoNHqugvCz16jqe57/c7lJUMgAAxNQcNzRwIURbKBs0MYxJQ6FkBAVgjfza7LDvnRh6dovpmH6ttnYhuWFS2mzswfFAoeLppbJpTzgqXTK47L73yDDtEh5bXFK1N/X5aIpdhQo+0jn///qYowd1bmhIDwAUwkPEu6hnnh+Dmvus02qvHoPSh13MjHhiZH0idlrZjWKjlvi++E6rG7htL362t+lVDIAADFdkLyoVk6BzikThxKx4AQBqBMSWWu1pYOFMOyk4ZnBVWrC5/U//twxPeAFD1vW+wldyo0rWw9h6E1OXyISQ+HMkMfmWtHY7OlDtWn+ZhOoTJbvHbLUfXOsoHx1HRwUKm1xdWlTE21/X//+vJhzWK1XwHNg2VHHUz/cfNQ01NQsbbDB9M0VqsTtwtt1H8qNJKLcLDATvPWsbVV3tyYVEQwQA1Ng75QptDI0HFBQlKkx2nF5UzoHV21thTW2ZQxbf5w6SrKo1jblueFdkUqnas7ZrJUlgYFwFkvd+YeCwAjSWsqLg00xOZ7hAkwCJ/scszLU3718yjQ6xmAEhn2iByl7MVO9+epaF1ZxFC3R7lTZDKVkLQ0qCQsVkXXcRNPuXf5TGyCQAoBu/i7osW7QTNmARl3kogoAs0gCa83zeum5LessHcdaNH1sam3HVy6OpBCGBrX+XpgMAnJPQ3U8f/7cMTyABJ5i1vsMQ/qLazqvYYhuDRNOJOWjtwS5cJYlLES5um9U5ef//f///PeKNA2JEgmTjWdv/6pFoqc127VteZ+t9suJzVGk4IMiXgX6nfP94Mzp8nu1b/+WeSr5LcwQjKSFlvI5lz3QFiMrFlSoGKBIy1Akl2Y1gzBYSA3JhdL3AwIHgEjrVZEignLM8IxcoA5WhLTmTR1nbmGovlLImZtaVsHVVcUGFMZ23Bdzpn/cMKgEAiQonP7tSQc2m831L7D7C5G9O8RIcaVkprzw8Vy2gvydtUIYHc+OLuBaHgFgUIiCJLttAViUhZFk5CBGWOIlKdBBRoUzGYDDhEwUHqF7BMNAKenebJtDK0OJQnFn3iATdDHFIGqlESocMHErtFAlBAR0KRyryuSKere1P/DQQ8cgAv/+3DE9AAQrWtX7Bi24h6l6f2GGd1RDyu62SN0kdW+NhS+mcKtw/rAoen98/VXpyTuHIhMualFTJFDlv/Jgo5VC0CUS8JnIjy1wtUDQAJTK0xlpqYS9OVB1SNuwZaAUSzZSFRXeQu5VywWZVSaVFMJsxzquFRNPOsKm2alUowaVXZm4as6xwKlKXSjUBgE5mGlB0JhoiIlg0DSzrHkiQFKwkHTvLOaecJgM+W53RdU/1Ufr6p3lbEJADgAAiGQBRYdmp1Y5F////9VvebOq+q+yqVv+j/1b/snp96/8n/////2d662sqIt9+e4wzuZDzoLoQTM13Ew0yVAP//+v//iXcjFJ1a//2///6dfoi+jL7p03VXqzXTejVI7OZLzJ5lSykTXU93v6+ldt9CEoczkmqgW73s61pfH//tgxP+AEFF/R+wYcaH5rKb9hI3o7V+p+ohqYpE1KEAUes5vl5eWWzKy868v55f/zTv5V+f/76osssXYVIwfC3BNSULJJkWQ6TGCzqfB//J+Nmf/f8rv6xdNG1jfKNuKnUdR3NI6zzDufCDqASLOFngIHCeJxYwp6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqvh9vz/f//nv5Y7l/fgyZ8Ob8ccBlyP6y9pSpZgJjrjZT5RyGVTbnqRkmwJaj/qI5rjlO5+elstK7lrdh9xaOLVoYOZmFqo0YTIe0UWJAyYE//tQxPcAD2DDJYwkb4EMPCJkcBeJ4TVchD5VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUz90Qi36JuwlVH0Xi7MLgKtHJgHdkDOqamWX6ecK8hxszO31rBjB1lnn8ClOFuPIPmUU1OPC5oh2ERGiVMmJGb9plfmVIq0y2pKkIyrKzpA8cZmsbLTefmwvjI2QQGWScVJBceLv/7QMT1g0nZ4QwhCNnZUj1hQBCa+IQMIAJTYBoKk0X5H/Wf///l68v+y//L+XnXNIWkzOVEUXRnC6USMBYdtxUyMnHJVm1NoCy350WUF5EMgyjiFAdGNKb1yGLVhOyKajiSErDSXJGbMY1d25FI//////11/8i//8vloamrYVJt/AiAeRy8Oj0v+n2v2p39aaTEQqjVnfRHHDjqjqMQ7toR1VAGExQqmD4m/+cv//L5//5fkf61//sQxNYDwAAB/gAAACAAAD/AAAAE/+n+qtTtoiSK5lsVZJlVqnLPVOlqLuvM77S2T7k6L9v2ynqYm3bQlAlR23ZCaw5VoXL2bM7gkgTJy2irCiDGBnaqTEFNRTMuMTAwqqqqP6/5fy//+xDE/4PAAAH+AAAAIVW84UAQovn/9fzr////8v+IXXnzyMVfzJylLwwi/PT6J1eU/l91/vxYjzTMSQmfF7UzZ5PVCKfajS+VAv2TEHrRHSMyKjK0akxBTUUzLjEwMKqqqqqqqqqqqv/7EMTWA8AAAf4AAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sgxP+DwAAB/gAAACG7PWDAEafgqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7MMT+g8nZ6QwAhNnA8L0hwACW+Kqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EMT8g8mp5wwAiN8IAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQxPkDyKnrDACFOcAAAD/AAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=]],
              ["MarioCoins"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAKwAAO0gADg4XFyAgJycnLy82Nj09PUJCSEhOTk5UVFpaYGBgZmZra3FxcXZ2e3uCgoKIiI6OlJSUmZmgoKenp62ttLS6urq/v8bGzMzM0dHX193d3ePj6Oju7u709Pj4+vr6/Pz+/v//AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQEqk0AAeAAADtIBykWJgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70GQAAAKnAFXtAAAKAAANIKAAARzhWUG5rZAAAAA/wwAAANJZLYwBLJLv2OHn5h5/xwAA8A+OHh/A8//wEf+g9///////xwz/4AB7/8MADPkDz//8AARIHh4f6QAM/w8PDw8MAAAAEB4eHh6QAAAAQHh4efqAAACsCJuPoAAE8BYAVgtBKIo61QtKkt1RWac0HJglu7A2KmIdKgV9zIFnEMK0QGKBBcBdEoHm7oIhQJNWOoLhoxqqcEVAgTpHWjKAguG0EiZ2FL3yAw4CAJm3E8y5RMJGbgLYWBsyEIiPQ0vnXNUfJjd15yOCIEatF1U9cUzvVFH7UCggLamvpbIQCTQADGgaq2BoIyRntX6vCgozLUUnIjaxvxeGNXtU+pvdWC5PLL0N3KSU0tPjesW4fr9/n77/48+cuW8r8ntU8s5S1fi9PLc9W5Zrev1v8cvy39URXfT/CoKiIKgqIjxGI0ByBqcAUABAAAOLJgUBWEqORoAMd3kIRI1+b8MxA0y+YVQg4OASYGnvCAy77OAqcDDEeFosAgUALj1AkqZPCIwNwLAsZEIYYIg59OJGXbZ8x4qNPgbGltPwvZ5MO40cFdlExDb3SsHARAJZdiyzkxeM2QuVLX2CBWYRg5n0NuFJGFJYytddi5evhgZlqZsxqktAoDu+AhE2r6tUpuV7kD1rGGNOzxyEEgkK4fhqAIAlMhsqKKFXPynfoaekhdTdintv3z/qORz+/2Ns3/b/pb3993fdMeD9WpVp2mTnP/et/z//VCzTH//tjv8+x+nxJgI76HoQBrNUBQAAP///////ZfWZBM/s6duAy4X3EsHCJwE3iPza1n/89/t///sX0/Xe5nkMRDCwC8lm4KjQArzELMgU0CydAvqbAwiVd0GOmKM40un3MkQxhWI5ImiaHSsvOXkTEpkBLg5Z5yfI4iyOpJi+eM0WOFP2RRKguEgJsDRqAIuAKFCCRbSXqZzMVw2eYMipFNF1LQTNDJ9zdFZVOmJoOsCAgCwAjDacT///tKIyR9/X/1osCYIPoi//UM+FzaKP/9e5t01AcAAAf///91N///1qWwzglAWYFjACcVsGuAEwskAtl5MrKEyWK4P/+6Bk8YAHtGFSfmuAAiyo2nPASKATKYNb/ZoAAUUiJU+BAAUuQUtC9GTyVEFjVFklP/5mQwQTIcMwapEAIgQ8iZAyDpGiBZHLHWHKiwgt7rqzCbp32AAAAwoafMsNAIqEwAwEa2RBKZxLOgsiGwPL1SL5yRBR1ZJAU1BlaLWc6vIDfVcktRwaHTsJfy5lnT0939/ve+5fW13m7kfbL7XgwdK9yMQuQ3b2e9fagRLV3KOwRRFVXWhWt/+1YpgcAjq/SSf7W01nhTwIFGL9Bv9cV0BEgRxU/+gXxoBZo2f/QY6wBwAAP9tdRgzmQ1xDgIhwDj4FTIDUMEIEMBgaVuCwsrnUDpAT5mXWczJLOkR//9YzQYQGobqU6eSiZOpckvPwtkXkIhjSpt7VkEXLHkCAABYQUgAzpVCcUhhJ5aCGQKeGxjB0HLM4wutgQtdxHAXQ+jkQG6cH9z+xhL5xBFzCHJVAdG2abe+J8/8+5/9jvO/+MiVHLYiFtw4tX1H6mes94TjRH/mWBw44Lo0kqzm4hLex3u68Uo6bn53pUBPAfVev1UNe9nVomh4jQIAJ75k/+yRiBGAOKVm/6YIDCiI/8Oc8sDgDjgel////q2pf6mbZf/QoifjnCTob01Lvm7xqR2YwVm+LgzPGpjgl4mYRhpDyHLVJZzmGeWpnPd14aT/9U7//mQFCMyH/+6Bk3YBUlFbV+zub+EYoiZMCj9cTfVtX7Gpx4YOiJXTdx4xiAnkL2Goa8YBDQYiGg3PDfQA6nDYhZADBTUr97NAZqongCIGAbAMYBbg4tSzwnGvIWcRKxYULXtcmnyepYjqvW3z90uFeKZyirFq9fpUDeti4c1VRg3W+MNUe3BP50b6BmEXwKZiSRf5fNDIgiR81TUadLsgg5nopalo1CKLu19FfV/9JMmBBrfW//qBIGPP/rMA3QgK8oP//kPHajzDnj4HAAAFDUr/+LSH6AlxYSt1J6zKX2CpWGXJovMYyamsCZg6ScRdmxiACLpBPY/d53/3KZbz//9d////////+VO+zlPxuaFOKH8UStmYklupGDJFQrthhl2FrcvMUJiXMQMgHH2xwTcpUgqI5m0hUAGKES4OBoRMVvCBk+YIYLUsxGHpdNSSV8qy12cFVJM1TuIY4fRA0kALqDmbzs3dTlEYZsPoCm4EYIiaSazfnWFMKayZNCacpm63MSysxNSknLibl4nTxaNCgoqoABBysZ0yUM0yyeKhevQs1f1JinDe/Ot/1jLgKGis39eaBxYvC+bkCPfM3/WKFLiSFRRuonTgAI/4H/z/+4Qp3f/9Y4NlS0lX9hWNJmJk4DucDLGNRpIIgQ4IhsdESAeRw6ZOU3GazfcVrajbyMkpJQyybdiHHitwa+tv/+5Bk5YDEMWVX+wmlmFiomVMCO8MU5ZVZ7BqWYEYU64wAm0iopyngz2zhl8vkUwooaqMHRCUAxGBJiAHyepBJHrH6/LdaGqkqMOqKJbWkIgPIn1i/bks53+s71jctbsCogYxExjv6ZgjLBjufPGaaTb9TibreawJIniahXnY48dnlxCYjqM9yruT+Dr//5/1YvoNRZtr////FkUYlZ+r0gBD1gf////4/yOj//1qDvdZoB1Ls5wCCESEQAKMgRFAkEjhGlKoADA6PqUxmB7yZBwFvH4bPakDxKNJ5Vdx3LUut12G0jOXuz7yzLYCGBJ0XJvAJIIEZJS2Nu7TqWGaB7aVll81TQZBEigoQrTYqkSw9Pm1tDb3taDs+MmHOirWtd0vGtLz9dqmSRDQ2Qdij420zXiEhut1II0WopKelOIKFpDiDybop/+tAmhSQC8ip0X/zIRML2kib+hr636ziatK/yQEJlnY4CAAJnGUR8uIOAq5atbxhUgT5iocJrnsaRCS1R+Jq0yR3igdNfjVyHaWANcpCVEoy5/6+2ZAJwtP/+5Bk2AD1eVdV+xp7cA9AGmMAAAAWUYFX7TJcYAAAP8AAAAScwEZrbpHJAICqFm0F6/+3JmMy52gAHnDCjFYesT+NBPb5a0srdnhXXmZTL6Ch9Clz5e3eqzqGaENcxEzM0KygKROam/qfpKRMQzt1vb/Wy2rCCw0JlVf1jOhdW/3/XVrO21p38QwJ4ZoOAEBmEgaRRdMaSXdLB0EWKncGfgqaX7aXbXW8bdHLomwsW72Z1lSzdS/KUT5NX7+fcZs1yKOdMQJ2LNyPlqXE1FPz7+FuB8Y+IpDqRdRXBMtTXugBF2nRVPzReOBYLSg7F2Ifzl1KpIGYcMqoGQ9KtMhRrdS9WYLdmWt1CUD6/PI7Kr86ENG+z/9xXBYjWLZDKPr/94QnaYw4McWASgAKNBxe4c0XdlAoaGENjphwMeAsSsLRHc0DiD0P/ssRuZE45NjhrceDQSmMffzhhA+0KEca5VN3Ic08rLXXn0UwgIB23RfVrdySdFAVuYDKDRCwYCywDaDhN4j88RYnCGGibzRNCdMBqH1k29ekSSd9TaspkXP/+5Bk3gH1EmDVexuVuAAADSAAAAETCVlZ7LI8YAAANIAAAATrUyj4+CZSf2Z7J/QUK0P//k0NJvUy0S4edrLMhc5PGiaDdw0AICP27dTRYrgApRQ+BtKRQoHTWlAAwEBAcLBRAvExwGjQIBe+bChw4olDUiAhAd6Io0NBxNNogcFAQQLg3SJgCc6clYvUuFkGeuZ1MHXeeZfPDDeH4Y4f3eVn+W4yFQgcbk8B1pDTxCglsPwxAcGSmL0i2l2olgAAQlTP5mAGSBFv2ArOZYud6m1b+MfSz9iwzKHYvKI7LZ+kr1pZfqV7Ns4Qz6IzHgxLIJjgbfq9IiGgjHEMaxDOj1/bHbmNz1IUxBpN87tzvpXySxTKXY2NyAulB+c2ywSCdX+2350zS0uX/rlUYUVeKAACjaTCpYVyQtWBITgiMcKHlexIYFNaBG9mrWwNdFpE0GdnqCLwqb1NVaSMTMZfZS6UNiy/v/WTkiyPO5bKpThGJdatdzx3rV6ZyQ6oEIV2rjlzXfy+cy3KZbLpTTVwuyG0xWVY/lP2dZ4lTjzDgaP/+5Bk/wD1PmDX+y+j0gAADSAAAAEb6Z1d7WmTwAAANIAAAATnyhimaF9GZGSuoiv1oOv8oSeNT9nqOgJDaaav46CJrKhvigXHfE5Z12WV94jwQKjUUAAgDtRCUVGFBJDiFsRFABQMiTDNEBtMgtMxGuS2AoS6tHNQqzakUqr4U9q1Oodat3f6y+6hfeWBGiTleHZ2LX8bba50ozYbALYS0ZrS7lu5P1lRNJZDBdgPygKDSIF9ZaJsvepMphGFoXnSItOR5JPeiMXds5RtbPcPEty78v/Iw2//URf/GX9Rpe/4ZYNWeHEAloCiGAaFxS+BAODoZ8VKJm5x9yUw2a0hmZrYMQGMREEqoS7aXPxYEdvxb4L574+PqgHio7wGll87wzZIDe3QcrsdBo4NlME1LrRqRY0y+pki6QIBtgcGeexiv0ltUViGJMYM6kqjVG/Wr8uv8vt9G1Z760iRGkj/W+gPT7/MfC/3f/bDmT1XfBAcwmKh1L5Bk6/xUVl46sBkonGVdESV+84Y1HIzTPxwckcuqo1jTDc8fr79yGPRg+P/+3Bk+gD1D1/W+zk8cAAADSAAAAESGX9X7FFagAAANIAAAATax8Bb4FNmR1ZHJdMNINTc2XCJA8TqXZemowPZqhUZj4A00AUITaSpYQ862orp6T/29A1UqymMjfsZkkv1n07OXlfMQ+Y27v6VY5ZElpWW7ukMsaIvdGOsmyumOfCi3+3TYXmf8AC1TEMkGIIP6hyETAFVBYGpb/BooCc/8oYSW8+mai+UZpI9AUFz8OTr4OvH05JC1x+5PE7uOtWKBvVZVJz2E5VuT2rO6t1pBEIKk6bNXsep5eNGUfLADB0FIBrXND3uWNY4HDPK//zqHrPCI4Z7FS6+povx0z9QY3/4wy0V7x8BQnS71AEFwy70cr82O/tm5J4jXogS4wRpkrBX4X+GWyyaexEJONeAhomQPCQ/UL2J//twZOsA9ElbVvsvm9AAAA0gAAABErGBXey+b0AAADSAAAAEEL1Houcuble2mSfu00+3jOZpdwACQeAPkBwVdLNjOt0i/z7zu1cCPCXdsm3uipLNTWt3A1YCctW5eR9FedOo/X/6ZgpNUskgYod2U3y0RaZEmkfdrrcpodtfqNk09A1SsUTYZLfKZFy+b90nfWo5z+2YlZh7YiE3AiOkBpaOg6MLDGWEFhha2XVSqwZ88MS3IQiU7GWCbTedaFZ7LHYYeHtkXvxPHgbP0ArEBRIzMQq3vXNvfWaxIkF8CTAERrKUlo0FpG+X9aBTAHQQKf3Q+kvNRxFdLPpI9NvUinqmJDTNm8zf1JHknKV19ozxa6mt9AiG6vWXS1+WAPVwxn8suAM5UEAAAHDMApEBpQdKcgLkV2gAAP/7gGTmAPSaYNd7FD6iAAANIAAAARJVmWHsvk3AAAA0gAAABBAaFbko1kR/PcMBx2xDDf0uDME8rM9+WOEKrWoq5jfyPuvz7cBQm3BrBeb5uW81e5Z3e1uU6jQgBnGBQLWytZ/fwnrXZZf91d50kdQQGl0AREM3llJbi05//40shcXjUtGY6bl1v9C99EPN1qSDvoGR/Of6lAS/+grgd/4Gf5w2fSrvxVAwM3iAAC+psCGSSaZaHMqGtNEaAHTdmaKoYhosSaHgVXFpA1OLWZ+Lz/c6eVOc4WHKCmtb/+6pJQa4kaYgXwxpe3N5Wse55drWnfvR8RCQygGYcp//LtypTz+Vq12pFKaliQoATHMtM2BNe1FWlL9Z//zBdT58qTWXTLWaGhcf6RkkhpIFNJBlsmUzb1hayk1kW+dHELX/8WIy0vXuEmLWf6/3ZZDJ6niAAIUqgJVg0xQGDQCMvcvgMVGaZW0T6+soHUk///twZPeA9G1fV3svk+AAAA0gAAABEzl/S+1tXEAAADSAAAAEnHU3YIrjEHFeZSqOalTxozts+8/AUBuvH+6R0OVPB+QatQWoom6DN0GSK6y+DSAwzapFq51KVqyMa45hmB+mGwHU01DOm/dC9VEsXLK6M7mpvsOIermDoRUaaKRKXWoSn56/oFW//EIjHGu2co6DkHbnn0UBBpcRKhZd/s3FYGmdKACjhyQRABWL6UQU+OBRABo2xbSWBzWiRpuoYj6BqEOxsIABicOIvDsTD02SgoeA2DxynRV2AKh/Lx0gu5sTNYvzabBOEklrf2tk0SDKYyAD4EgWnqMy31mSVIoFxFBbXRZl7W6qOohyRv51l6qRgf0H/WTz/9WYGKRk7qMGcsDGi4kVOZTgj8gJU2SY6ijczNQDv//7gGTuAPUmW9FzPG4wAAANIAAAAROdfVHsTPcAAAA0gAAABPLekap8rAKVGykCgsmX/ixkjA4emDDH+ss+Gu2pNFfACF3KjnW8VpDU+j4FVc165zmI2y1xvVe3iTnWkAiG1/N4M1o+PvN9xoGAJIxmrVN5/+ps6/iI34mToFwGziTXX5//tCFc2arUOrfV8Xfdbrqk3PHQdPfTFap+x6ijLSW66i9EjV/H/31J+Z5b9oD2DL+7x4HB9beCznJmVf68doBmbJgAFQ7ZELCgYSGiTCxABElphyBENlcrFQYARPg7lOLCraHm02PlO/Ymrbdpnf9h0cC1S9cW9SWnEWSLhTzYw+/3n+1sYwRsF9DQf3OHqGXjW5JEeBgWoLHzJNaimW/S50nDP6PW36dBedR/N+65eao+aN6lDrPvq+hnCsf3deZEcW12solTdHdKy+s8257TSA8JQAAESJ2i3QKDFnDFBwuKiYEBGCDt//uAZPGA9MZmVfsMjEIAAA0gAAABE5GBX+y9cegAADSAAAAELZ2hIJoNLNN1EhFlyk4Gaw20WhduvU1jHa3K0ogKKXmstZgHtJD6Hp7KOWdE6zTxqZJB+IBQwuraqmosmqB2gaJIsSwrYDhRgLRiIusyIqf/woLRq9SM5skpvq7FmV1Be/eIjrRWGrZUdXssFQ/r/nCRbzMF39Rhq+vf2IWSio5ZIKcKV1tGMqyhnYQPPg0YaTu5KJAVlmjS24CRthwGnQPDLrrNZs/XblO/FvXaVpcp19IULH0Km+6b1Ir1KTSSFcAsNPOj6jFJkqZfXUiOYBnWQXsJ9BB1fG3JFhNr2Tp8gj1Q1n0y/49apr+jgqX6f4+LU/qD1qfHjlWf+RbHD1wSACsLmdQyQVGzEqlBRCEQO9WSmMLiPzjWU3gc+Ltja9ColDsOzlmkfaJKZPZnnxiGc73XGWTLA33vXqdT6jemEAIZFW/Uceb/+3Bk+wD0k2bVe0+j4AAADSAAAAESlYFP7VD3AAAANIAAAAS5Mc3L4GOag4alqHx83iE4xqNSi/6q/POf1b6EX45/ER//x0jemqlGHGk2OisoGMZp3++XhGmOmAA5R8dfRksiAtgYsOZgaWxIC7scKgYCuVtfamBhU/XeXlZyY8687JflMfk119JQ7cno6VBZiOaeJQdyCNR+/91KDJi1ZN+tbqXUTzMs2GuBk0QqKCdRbPdr5A03O//mmGvZRA5mhZSy+g2TJGU8oITHZG19Qsl1SzpEYEF3Q0HA2NdVhKuv6hRV3qYACcI7O0RtESGohoQhgUSYIMtaeWIlBH2oZUKhtXGT0dLEnhmIvXmIBp5vkBwiU18tfzHdaGKj7I/z93l3DuGW6s2ng6ItIJnWddFToOtMgg7W//twZPIA9Adf1fs0PcAAAA0gAAABD+WBVexQ9wAAADSAAAAELJJFkDaMws25g6xdNqdF3UUjJ9e7V9Xd1o9KEAPEpIvLHVOqULBppE0D5pLggCR9XG9t8eKxUbzVUJRCAPG1yWCQSD/47u/y1c/7i3FoftIgSUnNJjAaATGAlgYgoSx5M+nKYsFQLcYMbuJGn33dSxWzjt+mpd34xSdpYZgiiva3zvaBaUh9oV/XN7x1+Wta3rDC8z8aPLal13Kbut5eNZ0kR0AY1ALkN1Otz3u+Pmj7/9/MUmeXc0oJYnY3Q0nX0bFJN1Poh4OG9E7aBunmMaJJk3qKAgXjonb2fO0xPD81oHSkZZg5IB2ikl3TCQQBJWMqBNnJi01NPCJGL3tmiteDaKt3dHhlIbsP5o3Xj7RHLFzH0//7cGT8gPRaYFV7ND3AAAANIAAAARQhmU/sURrAAAA0gAAABGWbPSRRbZEyQEhDqF1Vka3Jk+kk0mWrOD5Aq9Iekt6383joyqb/enicUIWQdIEQcvdTSYweOl46aNzuOb2wOLU/9BtdV6wczfcoD93rzvmpo1h+kQAQhNpvhIF+lyhyC+gSYJTwTFxgslUZO1VDoZgMslkHyf3YirfXt2c4N7KqsJiv2dLiAix8kJZle62vWcUVAUKlp97MTBuyLS+VGWUxlgArAKQyommpTf5g2HFo8891PjqcqEqKkscQOXxsOK90LF6IZT4U/bVNAz17wXEGq/JP8jv9cYwxM+YgAGCdk6QpB4kPxAoOi1gaFeERQo0obJqSJD06MuqeU0JoNE1WJvZVPjcsrecUkemYG4a4EjVAg6n/+3Bk8ID0iV/VexQ/EAAADSAAAAEQ/X9X7VD1QAAANIAAAATfQbLg/n1Z6q1pOpQdwPqqtkOXivdcihVZRFDwGzIgihkmgpZPp+UHTmwtiTVbOx2yTefrTqMzJOrmv0C+SbqRT/WRNv/eYGtn1WMThO0UrSGJG7xILS7/3tmTV58rIMtE79K8Ko0AhQUrPS3AgJflnpCQHUr/YU0cAFXdGKnD+Aj8pbjgZhSaOqmn0mmeZXFrFTOHU3PLqvVMD6i0EJCYbNvn9ObHqlMB4Ic4/rNH92zpfX+//RUgydRkbKUq6kVvVWXi9k+tvrJD9tlvL2rteYjbSR8i8ra3U9/Z0SDxG3ZBmxyQShqywqBuAwSGCGYgA8qC6g0HE2SMPqJg4RBj0nr1oNhyUzVmaqSfcB2KC1yrUp6X//twZO6A9ENgVXs0PcgAAA0gAAABEtGDVew+j2AAADSAAAAE6kzESAKr6Ryucpaez2EPTTM0kpaDohUUVqZrVJWWkVCWZIxOgZFOFAxq7pG79jiN1k8n11L1/F2D8Q+QOuuq4rn7cYEMCVlESEqLgFKV8tE1xeKzvMXVLAhhInHqAUXOvVEz04uvq3dQVjhQACcCPsdC6jkxpAjMWbB5ijD3xcHTKgGuOLBQ1bJkcPvPAb9w3Dc/apLF7DVFO28rfNfc1SMBpGFrcvc5yxaw7rXfxy+7SRRd+5+V509fDCcprHKlhukTibvtuiucgsNGmgUUbi9Pvfd3i6lmHzfpV16bXxuDZhtoQF3r6gk9nvt1SKDga+jRahYUr2bn3tzy3nLoa8MIw1MdcOHYqI92yppjAff9cQyu7//7gGTpgPQXYFV7LJPAAAANIAAAARQFg1PtURrIAAA0gAAABFFADvTggWHTQiVrAQqnQHEqDJSKHAYuZiUNlvlcuk2HOXw9iyiGZRYiDhSzKthbllB3XN/Gmx5Smcl3abuVqtyrzdLVpbMpdpBoaNd3Grjd5rK5az+/m+2dDDMdRVNnSQqf6DNRmK0X2frirFYYEQueaquuam/xq7XDkivd1sbcx4xD+mQf/HAhBDVSvHxF0hj1emsjAME+23qHZ2udscFQqu/NrXR6n3IAt4JBWgaEBwSAzAAhI+YEcIRssCoIAGQw9DkTYQRAYcfJ95+Ms1clLWRztivEaspt3Htu1e93lntFaVzba0k/ejXZba07UGNi2auGSDRZnbqRdTVEyfSrQA0hsMFpsyR8/SouflypU6l0f6eat6kHMc2hxenOF5exp534hbt98oYq0SZHgYCcx1YwUBfFCAAov9zHooic6UFJg6WZn6/a//uAZPyB9VNgUnsaRHIAAA0gAAABFN2BS+zpHEgAADSAAAAEiSVgQxbxAxB22oaCBJNsNnw1+bwtTmoCmeMSvpE7t1kogNKVX9yTFODZqa2yg/re7JOkJUSzqUetZFlJmKS0tA+BpzwLEn9/ZPIaTy1slfe9lPqMlmlSi8cPdd666yaQzE630yeft/UmcXMVJVORg5o5iNeocsbprXngbr/b23NHbywgSUpnBAuVutMESLbiowNNTUYKMrJkslfAqpGbR+ObSztbc0bh6/gNThHU6VV9ZocvkiNRyKwTt9E25/b/UaO31u32fMEYKo1HjmyNrmd8ySLebivga46DCbcsv3TVmDI/9V+ssERlVajcuOaPWko/RdaCJIk7UVjU12zEqs+v6PrVZ+cFxjmqWp5geI8Arsoz+nbgFa+UAACw8N5ABUKgLmEASxgAmQgP+IgRwozxW5MTnR6GcdiRTPzUQp679Q88zH3F5KX/+3Bk+AD0wF/T+1Q+oAAADSAAAAERWYFP7CaSwAAANIAAAATJUEqUVG6RkKGNReh7hrrZBJlLqU9JxrhtZiiRqKCp0Wkk3rPD+TyJwfYSAAGKWQCQCIeTCBuQw8+WhEagRCgKEKP85jH1OFyEVYmIonaqtLLe0bF3QVHvvoEYuff57R8jMRiFXG4bDTqWqgpKq4unEVXP2auDWH4KABLIwk+h2EiJbcRIJUDow8RBjZAKWGRQG0VFwvPNWXOkdmSxWkoO25K3ekUUxwJS9XbHXOCwskmtFeii6NkUy8KyIgXUTFPU5cJd0DSM6ikamQfqBm7YUmls2PrKaXSKc4GIMT3q2zH9TS7IyEhwVvUyhJOpUdJajb+IQ/ft80Nu62u5oGM21WB4ZU/BrvqqtyZ4qxIElOt5aooG//uAZPEA9Lpf0vsPo+AAAA0gAAABFN2BSezU9yAAADSAAAAETK0YgECgr0DUMyHBGAyEKQQ6FsemngrKB8sWIhEE9ceQwCP2up0NvJzv0JLsBqVjs6gOInnH2VzYqBdp5JkGqmRvTQdI/MimUgNIqBRIVCyfmbepPQJ9Nqtf/nComX2uSR59dRitDrSP0y+5ptx9n9C7vtnC8s/rVWdH2mmgm9RuVC16KHRUdf7NunSKbyIAB08Wy95e8yw3bIUyI8GoDgrcWqr4GiYLgh0SyEmgJdNV35C4bTZnWqDeUhl9ugt1ta7ljNM/pKN8KS1q/drY200bqpJHxIBDXWiy1U1pGJ9JAZ0l6jAoApyAUEllBKYmPw3iQIhLXFxN3Gz9+z3aTJl/34+/+Rahoh6m8IP6AQH8Lyl9RyITpEOPlECcAOAAmji+AakBrhTWbLGt79t6R3jukAFwXPDQocFBKgTH81DEhipndqsKRPb/+3Bk9gD0pGBS+zQ9WAAADSAAAAESyZlJ7LKPQAAAP8AAAAQ1BbRBQtEoCJWao1ghMRsRpmLMWWnt5n9vxaukD+p1G1ZVlNmqWcUKcN5TJ7a3W9Amys8i5VA1UgHCCfKqlnSR9zbTFsLupf7OvpFx01UjrtspbsuhTIoVDpiTpPPoITAptU7IWXVUWU1d1zUzKBPutdNYzhSPX198GJre+vpxhlxjADbOUJBwALFwgwAQgGSEDrwLWrIFzAqENJLeilYWWvg+FJwVOYMVcK5lZDw1xMv/k9lNdqWAbGjE5c880PlNjI45sWC0I6DwILRS7Fk+anloD+W0kR0C4QOnhBYKTzKXR8stlwqmr/+gts4mgbKTNjU81RrY2qdGkVs4iWD+impZPJ6lqV2671a2YYwiVaVJZsVj//uAZOsA9RxgU3s0RqoAAA/wAAABEwWDTewyj2gAAD/AAAAE0Y7CF0gAAH//5yt58T9fqOf/////////l9/Y/JF2XPMAK4FSCIUQpI4pSmES9owidoxkKgR5B8xinBa40et9M5sIksCSx87FWe5HMvmZbGrV/Pm6/4rbre/85vtBRwHVs2Jnta1/KnImgDkDq1ZDDZbVl02ZItDLgchKCw8qG6akj/mmoyNEv3bv8vvpusj/ZXvUXX8OG1nFtNHjsLTijXanxfqlkxX7jpAAdHHLfaZlsGp+ntPHu5RdGHWAAH8X//P6XGnq6HGElSxnjLv/////////oxgY3vvJcYds5AArR1q8wJ8OUI7KXp6BThyQpc0cugLJeasVKz4zxNUVTgrLw7slnGkvOXwd21S+i+Nz0IuHue97ZzBmnpSk19lWAZPVGFuTWncrsuXx+A0ugUgdUzoGnp8m0UPqdu3rL01rsWXS96rZEm3/+5Bk8YCU62BQ+yyj0BWgCXMAAAAUVZlF7NF8yHGLp7wQCZwC6u9ScfjxqtFtvrMZ5LqSMhO6zFfuXEWQMGwelzWUjNAAH//5JZyKkKn/vZ/////////+LoozvuJYXd+SgApTeqLgBiPYYUz8DdpfAALsCEpfYvW5MSaK3mzkLh9Kxk4aeK1Do8tLdUMLjid6uaO+NhlfY63+fSLyq6ykmQEKBDVzNbVLQNEzmRF504UAM5dFrQXUTB/zTkVJ82b6tqfyIrNE82QNDy7ztWgZoNQSSK636A+GdrVt9ZJHEVq2ojWQst1JmheImplJXataR5cTf///bO5byXPX//////////pq3vqaUHRqUgAnAIdHoLsBYRGI40LmChAgj5KTY+RCfD4YGmTjtO5KX+0jcQFIgmk03NcTICXPstmEIg6PzlVQu5JlFjsyMzaLQFrLIoOrWXro3IuW0DpPlMDGKCBgZQ5PnvL+omjxVb0zWrb0itZbLLRkY0qC0q6S1lw0dMtqKy/RLbWt9emfVUupSZQIIR71IqWZJkL6eP9YkgP/+4Bk9wDUfWHRew+jchegCdMAAAATFZtD7DKPQEmAJswAAAD8uv0tdur+n/+3///f////////f//////wiKBEVT/67ijaG/1ADmUADZh0jGqnEBxVqUyHy9lOmZpiJao7lQwweUUy/4Gjtp2XCmZrGpMZZbp601nTTUnl8rpG7tYSlRqkVNZnseY3reXbVqYkcOPIm4TFplKt0XSqclTJjpBFAZB6IGblB/IdB0/7f+40KNU2IE3YrMbUxiKKPDT1oLPt6Y7+zxAEIqeajQPNBp2FIqru/Pygi49jACdP1nNFXBQIkYEPSOM5Aio0hXahpOF+FKL6BPrO7UejTuUMzF4lS52J6rH93qanyubpt7h+AmE4OYSipak0tS3mB4rDBQZPVYjE0K1FI2RUWRKgTQQasM0ncmz3UZ6yPHpn9fUx/9IgVD97FiHbNO53RysoSF5UYP8fzUI/+6v3+5nx9qmw9B7JtTUTnQOLz//7gGTyAPTMYFB7CaxCHswocQQFTBJ5gUfsUPxAAAA/wAAABCm2WVVb0/sCjvnGADKShscLXr6RSMdS2BIwSADkQ4swiCEdJpW5RVP6Ln4NUDQdKR+PiaA+ZQcT0eO79bWaxA0LZsS8aPtdghfNdNFbJGhcEIyk9StiHHvW6RGlIQoBraIBxkhSaNkVlv21mhkZf/bzhepV1ky/qZfz6VExLBt9Etq11N0q2T1H1szRWxb82qIelW2Y0goXrdrKcohuCQAZTigVAlYovCJ56gCCJizfxggEJVZtfYaoLFnSWGisNRp2qOU9zApJGq3CPoxxLFrIlUtTrZm70HMibBwCSdaPWK+S3mCmI8ToFggNIEwHGMehlSXNES3452YhhIhi1/5gbJN3IGi5qjQGPHv0V1PrQMUDYyK5q3UbEaTOTTmS9aLLZWpzp5BAdIFgIRZ+jMiUPVmLrQyDxMxNUyEtXwAAAEdMw7Ped7PT//uAZPCA9N9g0vsVXkoAAA/wAAABEoWNQeyyj0AAADSAAAAE3xWsSBh4hdlCM6MMXJYHHPUCcxZanbQjme1u9/xOKg/EQYv/9jyRkN0BgIGpe9SxUCf1koLam5FRYwKgEDwIpAzGES4SJwxJsvNy66h/AoAxDCk/+pL6xCiS+XBXR3ff5h//F+Pf//+kkZh8Jl1KyBks9curpGB6vgAAEgQFDQI2M0vNgaQZMHRhEeUIeBoW9jbkBpNt2UscOpGgSV11iIDF1Oaj2xkG6GSwnQQXvfKT4BqihQ31N2XUh7KugXBeA4MstNI9UsixY1lALTxmIzgeELoAXdoGZQgOSaID8GqBvP+WRmSYGZf//oCZl3mBMFIdjOeQXTTN1KOHiYuyvnTg4RUv5go9pt/lMdxxvUXx9ksQs7P7ft4R8ruIAIIzkhHhBsUB1oePaXNHMT6KB7S03FV0Tm6khYAE5rBSbbu8liglDBS21tz/+3Bk/QD1AWHPe0asmgAADSAAAAEQaYMz7TKu4AAANIAAAAS1x1UYnGMY22z653scs/uvlZg0eAU2Vmhs2qe26qVImCySI3AzL1u26BxbqTFZK7FIZMOIA1KLwurNc4IXNP8QB5JDP+e2rgAjvQqJgK1MHxuw4UdB44IyNCf9hKL/0tmt+rCkSDSytZBEA0MtgVK1/9zrgHmf4yDLhP0mcOFkEMLVMckadC5gQyMhFrWRFATc2zS4mHvjudxmKxi5FKrhaO2oS++6tOIky8lHJ0VjkSQlXLP5fnXZJeplniLiopTB36TLQTmC2dhzwGMoacVE1qNF+d5mZLU327dblZbM6CJf662fugypugQj75meW/9dnV6c2YvlkZg+nag5PDXbpoJ6lpGL5/R3QbQ/bYADh4WpQKPL//uAZPWA9RZgTPsMrRgAAA0gAAABFFmBPe1U+qAAADSAAAAEShYadN8hSIGIEAjQ25P6BE2kOoqSJqwMmkYvKhvybSydvtHJKTlg4214ayJZwVAPI6fa2wUrX63tdl2oFVTtp7b8V3LbaBefWUCDjgAy2gA0Mmy4gmfNPKWsXo8l4yf1Pzb0zZV0JmXT+qu3rJpBEukwPZcrVZA1SPrT/PJInE9aCa3SUOlSNlLmBDjy9qF1qRMlnv/83pWZftoAGQIEArCUntdJHxr4YQeI5w4oxCGmv61pR9NWOOQwadpgwTBQVB5/ITUdoTRdueo2CKxYGwipPVpKf7JB4z7KbVJlOiyz7qOk0JeBhMo7ys06fP+XeaUkn/6Pyo11OtRX7LQVtlU8yzImzGtFSKh9G6Bg57/OGGunno701WZdjE81O0PI3tqrhYiOXAAFCcBeg1XYG5qM5fwu0BqyBcwwxB9o1tKVUFm64DuW4zL/+4Bk9wD0sWbQeyyj0AAADSAAAAEUXZ0/7DKv4AAANIAAAATpa9kEP1Ygi3TVdRGWxjWtb78SvvU0HDVvv7/liav6t8lk3SKKpoVTIvsqpRsbOfqIjnSkVAMF0DNl9CdIgVPDTYRA4EYcL+jZ5LrEs4+jlChJ+x66UJtRjy/Q84QDJtGP/uEpA+rGrCoAhyrdUHAfBypZTbueTFLv/tyCmJ7sACmPwF2I4XTWQh6FhQQQCCodUVbVJqG5FgvzjiQJWp8IvRQ/XkczAXL+fJy3La1aA5sXxuZm7zFlIuYuhUgxoQ0NJRWhX0U6CKBu9ZiQAB8cLqH6SfluPmkS3snRup5A5+a4x0lkbxubQjF3dUCI4vRmd6vlSJxf5AoNA5lM4jCAWt6MM7ULnezLpGZ+nAAXCMEZgILgdYlADQKHIVqvRBL7sIUMUfKggIG4YC8+JlR5jNC6408iUYvfXMbuTli00NwutZkkDndkDv/7cGT/APRgYFB7CaQ4AAANIAAAARQVlzvsUPxoAAA0gAAABCyJusKBaKXQSSXuw1UqhsE8A6wFpp56h0IeXuXSFT+kptNfU5ip9JJI91OasrzMvy8Zld+iswJmg6qk2pGaVlXWld0iwRcrPfkePpl2hFpq6r/8+4Gan1QAF0pUjgQSa4qsoiUABIAOARIBESMVXSwkUIpiYO2BdeBYvq0okiCUyycrTVenV/ZuPm1zHuWJ4iboVIXnkkboOZnxXw8OnZsp2umgiowJ4WaBi9IpM4uxb+vuSCf6m3S+bz+6ybXWgu1tlnTCfTJ79RJUqn0dmdJdbo6CJoOMuIoL0SdIEVX/h2yw/O286kep7tACdG0rEmRNKmG5tkAJmNVkmFCVhVtigAqgQuEpVKXFYbWBGD/FyO+CtMr/+3Bk8wD0cGDQ+zQ9ygAADSAAAAESaX897DKPKAAANIAAAAS/JAfJVnvu16+MqX6TQzED6y1RXF/LuRvzZf2/FC32r2MT7WpuxNE6ITAbxsCi4kXyia9ZtrPkVOK9TX0fMyMW+mXydK+jWm1lOogBa0CIn+ukaWW6VB/q1or7ojWMWUrOuMqp0VvVVc8by67t7qenjvQgLYfxPohxdjsLaGTJSpeNINEEak5zLknwhO2fUK6bxCssJFDB8RuJdaEcFav5+ItGBGvDKq9ikrqSRlgNjKyC38sG21NCyxzAYtE0WgqY/PcopOr7W0vY1RbdZw+2y0H7oGZVlUwJg3TpsVTw6SWPLTPIJIINy8W+rTQQHYk6Cm5Fjbj58oWTnu26tqZ+1QAXSeEpL7LiZsKIKImtglFsbRU7//uAZOyA9JRgT/sso8oAAA0gAAABE42ZPe0+j6gAADSAAAAEQABXMDqPsUpZuebjHsq243NS29Q35/K/2tlqXWOtzIbTtXrlUvH0k2Y+gJaFoSa0HbpJM1RdNZkTY6gOAVDYDXkq/jnEQ5N5ivXNzMmeWbKCYn6u2uSfoY9UuVGFR2NsjVmDQ2c/lAdpPLH1PIC/Y5DuaXWdjc7thZh+5AA3RvM6NCThUpc4HDGXCCjCWXN8jTEqaWB1LEQcCC45OwRFZdHKucc7Zu15ipPKSZ6yMdEaVJ6DnXUYu66JmXhehptSfqQSreT70j5sBxywLFTykjRip7X4hCcVHPSO99e3n1IcEiZehdw4n9Da+bkk+uRht/OPCclKaW36SOA9mlriuZC7rpyJcLefHZ+rIkje3NxbePLAC3CcFl54NbskiADIdG50QiIIhEp2utlScLk2qSJuO8dPj8IeqHqsoqmKBuVTt0WaounSyLf/+3Bk+YD0eGDP+wmkSgAADSAAAAER+Zk77FD3KAAANIAAAASa2SRTRQqTZKxgWx/ECKo9q3fYstOkkSoAWkRZCanjNf+VGimIqMRd3/oJyRDKFxuRJbFC2pepEPoQHDOah40Y83q6mubKfn6iQWPquOGjI7PPAAHVve3akoh/MyApiMa0lg8BrCNaU0ScColR1uiayVDBi3K+m2o1vQK5TpxSNv7J5uRYU2NNVrWpTiktkqifMDAZ4+ktnYvGS7spdZsQ0XKXkeiuZupZguifWVRqAaMwK1Jo1Pmraen6KKrL7/rykkjQUdMTrOgZej5JFlgFed9Q0DrJv/NmnheSt97tdwEAYa5S8HAMcxtLVdZBNRJVTmbua8zHeaATgnZRNUpIBgdKAEhBizFUtEZjIBTzRtSkTqjd//twZPSA9LxkTvsURcoAAA0gAAABEhmBPexQ9WAAADSAAAAExmsSh6MxeWvw9NqnsUsOfaiW7etKsmVDOENUqlU6kl1La7mwgd6t1oGh/OLNEjakOsDFNxvk4jqefnjFszX2636uniVnBig4+ha+xcCxuCD9I+FQtOVdeZi5bsWzDc00uY/n3uNr2nzMzJeYfyYgpwnxAic+EqeZkw48ug9zQ1DCZcggkkA/dBB8XbFPTFPKn1g2dqS+9XmMcJvNabNWOUZDqG+ktlrWyJdrNmMDjHg8oZAXSezqSTN6nKSZuo2JgAVkMUnkLmZotVE+uBUNyy7P03osf8kvHLFHOu9DviKgeP6uIGcz5dD/SLH8RsM9SarGWQH1zzLTqPxtFfTTJHbfbKU891gFyA+MPmtJzCBSjxo1IP/7gGTqgPThZ097VDXoAAANIAAAARFRgTns0HdoAAA0gAAABAUQHbFQqUsCkiXkAMfuOfFmnV7OFM+0VjNFEX8rYyyW1aRlV5MmZQGkkimmmmmumtN1zAzHWLbfQQX1IIIEwYHECGB6AGEXiNCLHqzqZu6CkP9KKKbM3O0INq2/71MOVA03E702b/L92OH+0iQcrHT3kTw3KR7x+2y2ff/315Qze93Jcf33f472t5uqqriav7MAJoLqBSggyl0EqlWFYizmnd1lKPqGqiiXznqYue5MtncvqtSuRrCyvPh8olc98aNbcJilYo2H1o1Yr1utv5rV6929i+uq6+a1g1xazEwsr1xD+CVDlJbXxM0YVa9qfVEr8b6XGbuX7MyowYC9tj+fQEVKqqpZkzAInM9b4YGn74lMlqtEsAU0tu9QZABJx9NT6LJBBCcRNfKSgoINFTqKM4NN4AaylrJ1ChHCX7rUs5UnJlM8v9zp//twZPuA9MVgTfsURcoAAA0gAAABE+2bOexQ1yAAADSAAAAEPx3spD/kZLBHDkTaW1+/reeZnTmhRSy5P3rtAAIAqUAJ//yE/qX/m8pW1Dpf0eUqWEg63qAoFUYBhYSgLDX//8sqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqv/7YGTqAPRdVEx7Dxx4AAANIAAAAQnA3R+lDTDIAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTtj/ExL0TIICuwAAANIAAAAQAAAf4AAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq]],
              ["MinecraftXP"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAHwAAGw8AICAgLS0tNzc3QUFBS0tLS1NTU15eXmhoaG9vb293d3eAgICHh4eOjo6cnJycpKSkrKyss7Ozubm5ub6+vsTExMnJyc7OztTU1NTc3Nzi4uLo6Ojs7Ozs8fHx9/f3+/v7////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQFAEEAAeAAABsPR8tBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70MQAAAbIA3H0EAAEUi2qfzPASf26qYljAF8JAYcEAQBAHwfB95wufLnygYg+DgY4If4IL+D58Tg+D4P//4P8uD4P/g4GP/wQBC8DO5CohkAAACAAAAAAACAt0Wavxz/Q6pDGm0I2BiNMV4EBUpCgLlGWoulYqwzBgEJDAgGhECGCTalUleY4xMqZUAIeQhQAAcHBFMA34RQ4WDQ0eQ4oIA4RDwMeQwYD3MlucrZdXwmYdcHv3Hczla5VFGQgQFtaf19kbktQoMl3M8ah9qKGRisIQSsyORF2YdNJng1CJGHtrj+zM4CMpg5WGe//kjclh5wFAcaCcOQ0DQNASpn7YSZSPQkmnd2mV/+SAYqFcmcTYO6JQ2CRENAOAGegwDmbgivuMSl/TAAZDpKXqSqaGFCaAvgXkd6taQ4msy8RAjlODBWPUkmFvf9pNNt0aal5cjXf//99YZsTMpsX8qkAD+zXUQBAAP//2EWwaAQhSkkGKry7P3EyKWUt7+sqegpqXOIo8l4TAGEN7DMBEDBKdSjrRHHsv/CcdU7YJFl//+rf6lVi1clUdr3ZC9c3///5ZZylZIjEicQOcfxIeDCaL1aXn9///////////WXa0NSIcHjKRclGBGTBAM40ph2U4/+NLZquChiCB83Y5KCxnL82csstd3HUbTBmk4p1R5ChTHbIKABu/lKqAB////9rVM11NJfb9uzLbLeymzNdoKaM1arWq0PsQh8w4cP4AKCFyBxnqyzdmd/5yHr////cy/98oLX0273azuf//+9XZpfJVJDeS0+UcBuAQcW////9YNTwHNTAZMQCnowToH39FEyIaGQQMG/Cx0qv+igTgJ/zg6FhweEq6dtKqgAM/v26UCAAAD////9u+miv5NxIGAsYAWa98DrlnKrzyHKL8qxx41VHjJEA5wZYhG15E4OUW/g3SMvxdCfG5nl1swHz+mgXxyADRWBj8bAaeHwlEFgJMLSX///6JwBDoDGhgtZAlGWq6P9ZwEIcDRnheEQX/OkYCesDShg6UFIhbAA3+6qRQKR+I1uUjVk7lBZ+kex/njeyNruaLdu3+2ZTHmxpSPiKZDCE4Kp44stlv1Dmg4L/+3DE8YBU1StF3P2ACholqHm6Z9EN6h1EVJPpVJNmRef7OakuFogGnBABhk1hzRikVMkX///9ZGAVGQGGwEF7BcS1aP+kFqQDiCCYOEwfq0zArgCDcDGYRE6gSAxtAAz/7piAOgAAP///gsRsKkmRTF7nLk0n9g/WRPtakabPVaniUhnFEBJeAs5yDLGsovn/hwg0VXWdYX5Q//9S1HSUFCgREAGcUSBm9EA3YHTC3Hnb//7+s4AvOA07gCyE2/+tRZHyBpxwAJ0LtMl6nQTNB1gIVgZUiG3gWSm6v+HkOJSx97FjSqOOhfiby00ph9/Io81u5KYddZfo0GloJKB+OjwuEkWfzIvP+ssN//9NAvjkAVNgbtsB9EIWjiGk4n////WDQgDb5Vf/+ofIYXEaETb+o6JCBhwB//tgxOyAUBkpQ+3WlsH0pSh8HVT4JqNlAAD++6eQHAAAIY4XFHDvlX5dmDO3Mx/QExHxBZU2VgPMqgGowZvFvNDAfJZb//KZPHv//s54rBtoF6oHnBiCg2yZSR////YGoYBgMfb/+oa4rwZeNv+omQtaNHAACruWRABxdeeXOO06It3hD/wdPTUeiMevd5amoLbgnumQYckp1ExIVuxgCgaEBRsP/+wuxwkibN/9kjIxKRDRjgsRAxCkAPP1MDdVwACDYUAwDAKFKkGJ02R//77pFEhgBqeAYT4NnyktV/9A+BAMgLisAAXjCKzV3QTNCDgVDQGCy2IKl5EJAAD+/6xQOgAA//tgxOWCT8krR+fWlSF9JSi4DVD4C4PSZsmNSqZGihTKbpaieLNrMoQmjUBDHCwBAUDFR49/+s8KRb//6kzApjoAifAzPQDLVwxOJIPB9n///+YBAWFyhm0P/8jwxkgVv9R0gAhhLsABV5e1LgfD+WUbiN6S91B8Yeq1Zh20wCL2qWmjT6siT1WUCMMXYIzlikQwtf/0aP//smXCLjMBiMBgUAdKOoG/VMBgYIBd4s8oHVL//9/lgCJEAw8IAYH0//1nBOAb2g7f7BkIDAwQLa0ADv7vvKAAOPYt6ujIfHxiy8uJGuUniegQm18zI0vQbpeCA+AyQJZ1qMG/////+yRqIRAc//tgxO6AS3EnReA+h4IiJSa8DlT9syA10FLpF5H////EiMSJf/6hyiS/+ojBOJ5wAFh3dTMDgAAD+cas52Zu9r7jvUODs08qs6u1pdBzQ0DBoDzForzxgfSIOE12lihAKgILKvVt2Zv/+5qUSUF+H4AmAUBwKgMDpYQMcSyAM5ZpQCgJAwLAIgqhtQtpEiqfZX/96kUS8MqAKAADDYJ4iBVS//SC1ABQFDVX+xNAOCQBheCSOeoAB5aIdVA/AAA/rLo9Vk+zXMSXICQ0mSQZRmo3IgJ3CwwLPgYEiRAaFALh+Auci5OBi4r/Qq/rr69X/7wzwp38YekIYBgOYgBodLLWZAMI//tQxPSAS20nR+Ayh6GlpOd8HdT8AQiAObgMBxcBPmiaCf//9AvgLNgOJZDzG6Cf/4SABRiSD/7mAQigByohxqsAADrEQ6f6jWsjTy5gR5MFUcoiBA2PFY1JkfQl4QAIJgkE64B3oLg3UFbkHHYGzDFb9utd////W8rU7IoS0IvSYSkodrk+arISBvzIDDYGzwypNGKS///qomxVAwqYAloIuWj6Cv+kYhgYCokrN/plwEIoDQBh0AwAAAaIhjA/AAA/cJ5z7Tkxu84lPKb+Mv/7YMTvgAnRJ0XAPoXCGiTlPB7Y/OpZTATdUniQBmCLgZGOaPUGz5IifhhN/69alr6tK3dExKRKjcETBoDAMDpkDGHCAPdQDgACI0AiDIsRETZF///+YiFQGjqSL//1jVCEDH/+ssBegEQcC6zgAAGfn/YIAVKHzEj5+fMtJJPFA5PUOep0/iehAkQhcDFm2im//////6BmOQB+aAogjiDldv///8dYov//0f/zIutVAAAAh6hwBwAALNSp38YAiDiVXbv4yqUw67y7UiocMHtQDrN3p24iKHK3//9W/9akjx8qDSC50DAWBQDQuGEJitAwEgTAsBYQsUTi1f//+gCQAwcBhP/7YMT9AM9lJy3rdpwp3ySleV7Thb//j8Iefb/rHQGqS2////8sAAAK0TCAcD9d5q1Xj0ttWmYy2D68c3Zn4EYO9pisNHzwuhG0yGCHhw0v2ZSn6//+6KJkUR9C0hEFAYIOYGYsUB2MjADAgAo2goCR3GqTf//9RZAwKFQJAFX/+ohwnp//kOE+D8PP/9fZ+0qqAAAIaZlABwAAP/lH5UM28IPrRmRTcQ3ynhxnb5GCRWcZEiNb8SgmxNpU//+r2W/+mYE2OQIXAWGAHElmBvgSCEgDQPEnKh9n///6lgAA0V8d///OEFNNZp+ooFAolf/+z/qAAANDP6wQAq4P/Ul9RiOQV//7QMT7gA3tJyvgcqmhBySovAfNKEBrJGZcdRNjKBjdAGqEESpNC6Lf/7nhc4LfwMCHICM0c////zIQjIuRT//qMm6f9I7RAAAAAIhAOAAALdXXzWPbOVaZjzRVOjEO0w8AYfKLBXIqQn12X///9FIxMiGhkIDABhA0MlgMzlwNoBEKQ40njVJv///huQwUJRP//6yua6jB/5qWTX/7/d+4A/sDAB3w2x1/9oNnzCfwwTgR0MYN//tQxPMATL0lLeByy2GtJSU8DlU00G//////UZiQAfGHGk4RM+3///+P4o4/P//rMG5z/QNnfqUAAAAIiGA4AAAzx1q1L//8qXKmjL/LCv8CIsNHU4WRwkVwdBV+t/b///s54titACAQBysiAZVG4AxJE9DiWr///+MwJkMq3//LPmf9Rh//+S7+tmpnBD//LOUiwXEC4XECKE+OQTAmApMCJTACngBQEBuYQ8b5FP003fU3//9amQGfDAYGJQ6BiwZAJAACgPExE+IIv///9f/7UMTngAxJJy3j8q7hCqRofUBTDQtQw03//1mXnX6yf//Z9+qryr+c+Z4UUAa7g0CMNpgyVxdINinfpJAY4oNXWimjbuACoeUUsRAp25kwAxJ9VAZBxtVNK7qgYCISmnKhI0QJt++LkC+kJoha4EAaGlqOg2iFDt9ixjVpgo5ESzg0uqyp+u/+EqWjf/5quwvL/ts9WuYRSTDI32/h0x45CBS9wGDNdZuZginjQxmIx6bu2pZIH7vyOksNu1xTMkFmVFrjjVSQSmpK0eTJAK//+0DE8oILOSUr4G6u4N8kqPwHydRe5Tcm7cXqcnKf72aDhaBYQMTw45YJBuVQtLeCmTCUedqX0LjW/q0v//e///////Nu667kONRc/////6XLfKuIAABvd80deEAB/9R1GEoA4DidIIO42rRLpOuXUAyEKGAiQCQVE0SBFiDE8bJeWqJo7mJixAUT7lbf/60UWH8Ap43CKnlJJf//30jIOKCDIlEcJq3/6JMikBM2SSC247kkkv/7QMT6AopRJSvgbq0hViIl+oNQBOQ8OLJJ1QAADe7csT0AADVhAnmQM1qfuiiWCPFcJoMHKSUiVEn9RNF2pKdRM1LUfmuTD//rUL0G2AeYtlVv///8RQBeBp//6AdCJxLazwgIO5vOiIi+HcwAABGQF4F4EAB/9QlCR0r55hhxo1B8EICyZCJYLT0lR8O/qHQOx1JVrLzqU9J1DOq/+tApg0BAaAiAuFEKCZE+h///v1BaoBfC//uAxPaAHVWHR/mdEgGapOi/jzAERX//onwLcAuBPKJoG2RVb0AiIH+FRaoAAArLuuD7AAAeAWWjdp2qaXSKjuFFDgmDHgoKPtNjV/USJO002WmYm36km//mAzAGpChc0SKD////0RLgDUxBjz//1GIzQgKecpCMV/UOkA4OVXAAAICZmQ9x/6z3N+bPWR5r0y4QdARACeN2Riglc/5jI9ofp/fmj4ipAxlIo/1/WozJQAoEBrkgDVgZsTiVH///q0USkM8Bq4YbabN//U8vOisLADaboFMMXgY8GMNqAAAAAKmnvAAAM6/9f8fMje2G8KVFgvaLqK/bv2V9amousx7Xo3b//rUUw+oIyg2WTg9G///+v5uBKA4m///0xcz+o6I5DExJN//6wmplPwAID//4BsBG+SEGySH5NlxcKPo8XwsJVesrX+82ap9Zkb///OB7QCm8EyhbMEv//9XyYAyIMVH///0UH9IdQXP/+1DE+YAKPSdB4Bpo4X0k5rx6SrTEn//9H+kAAAAAubd+ACAEYJan8QxENQDSS0mdHhTvoqOl0mUjd7IvrLpt//61DrAHADASTJ1v///6kwbMkT/////F4J3Nv///6wiJgv4AEjPRLCfqkO8Q+dTLV/pGZfPGT0kD6qjA///6jMZwBCwXWI0JJ////9QjYhjf///+sXhDyX//+z+iAAAAiIaQ9wAAJFRseXM4RRKhR3WfL6/qZFAuJ5ycNai/6f/9h1gNQgDgAs8iCv///8wA//tAxP4ASnEnOeAaiKF4JOX9FNLUOCkF/////G4Pg9///3dABDOJyB0ur+8T0GnOpi4Z/UQEgSRROTNIvN/U//9ITyApoAgNBwozNX////WNwQcMh////9Q1iVJb///+mgAAAKAP0AAA//8QQEE8mDwIr3qQJcq1zUvoKq+kf/+tRmJABzmBxUIUJ4+3///8sAGLElb////41Bwmv///8mBgBeRN//F8Glbk2Zq7ydKhb9FBXr3/+0DE9YIJaSc14D5vYSck5jwX0pRv/+swIeA9gZQbaNlD////H0IDEt////+RwyCf/3K//J0AAACgC/AAAV//jUAv50gB3+TT66bNmCi4///uUACyg3GNMk1////6gyciL/////OE4l/66v/yoGHA+BAAmvnFymCw96Jqd/XUWmppm5faigTR72/+ibgNQwUBCxGSX////QIJ////+kTpr+p//9v//6f80SUAAAADjegAAUiHJv/7MMT7ggiBJTXgDk6g9ySmPAFNnMHp9EnT/Vso1VNloo+o8n//1C9A9A6VEiLf///6hQoyP////60T/Z/f/z3AgAAQN+AQBQTpxEwpPrM378oN/QsZmpb61/+mLwLhR3jgZ////8wRAj//1/9X60/7f+n//9f/EwAABgB3gf8RACf/J16kDqEVFGfL48Hn6qR88vQQfrWVUNq//v/7IMT+Akg1JS/gBosg86SlfAHRxF4FISkViIJf///8fY3v6/61+n7v+LdJQAAWjCifhEAf/Z/rp/9agho6Gpm4xbexjCYT06+Dir37ODweXnPr/5GgoBe04TrfqQ///UQ01ugh/7GBwkoZy5b/6/T286oAAW3XBfBIgf/FslzV/EH/+zDE9QJH7SUpoDZvYNkkpTQAycSwS0Whoksfio0zquNAeFcSgtmFGt4eXUjyAr6bgPlO6/x/8sgJxcY0SS/nCz//+oUmXRlCWJdv/egIIEHJNApjmEt+YEDKz/WYl9/X5nsXrWyqqWln4dxkaH/+1vVNadVIxj6BOlijUcExQtmmoK0gxm6apOaS+xg7//5FDsMOJmRm/cX3////+yDE/YIG7SUpoDZu4PSxpPQA0dTDCFsFMP4nOv/rJggoDa2CzPfkwwNG/Mk+t3/1VQAALhcH6AAB//pLb991tQWTAUTyStQ1qxnC6WnLqRiVPsyR09//cuAFItpBjf+tX//6g1GWRjiJf/ykLGJ5RcoCyUfqKRkV/U+vdp8Rd2oA//sgxPmCBu0lJ6AGMiDasaU8CBZsCjfmtEPMlkQLHoF5/YyWcszV0mvMkGKG3/ycDMMOXUkv///9Mly+NY2f/6ySKj9nELv//+7UAAAAAqvpTIFs/2yEsKWN7Rcb/98LFWBwzWSsJjME902mu//qGsKwZmPN////nQko5y6PFv/6yf/7MMT5AAdw5SvgCglhF6Bk9RXC1Bap2pJz/q6vyHEa2pbIEKItetF03ap00y+XkbrQRV7Lc9//WiDlHKYTf////hUbhn/CtTtU///V+zoqAAAAEE/4aCHb8MQe3y8ZOehOqkpyGHMah9JxARKTEu//0DpzHf///+VI///sTUTbfcO6d31AY7bCABxfjGBeegfWtkk0nZjV1IKVff/7QMT7ggxRTSegvhThPqak9NQ20JEwMmQb/X1qIoNwxR0/+J//r8izt6r+Xq5DDLoUAAAAXe1EAcPKgXk6ClqqNGQUbl40MkThfMXXXfSvdf/TMgDSaX4z1fXp6fb9X//++sCrK0QAOz+gdAcTrptdnRpOiS5mbmCZoqtFD11v/8fAhz6fqjJ//t7G///9v/f7/K3//o5/8ObzCwAAABb7s0AB93X/ZuDUSe6h9v+3H2tdJ2ph//swxPKCCeEnJagaFmDboWS0ALZAlPiqv0V/b6AvgKOPW7+Ub/+3v/+n/t5TTq1avyvsxM5GQABhKIw2DSTDSDSK5QXJYhS2PPOIiRsTOkJ///iKC1TPq/gujfX/RX9vt5/TTTJ+ZS/S38H4/p/hQDDVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVckIAAmoi//swxPMDCDUJH6A9ssC+nKQMBp6gGENmeAhMwoPHRNvI//EL9efv5r/Nf+vf8/v9f+39fb//EkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqq//sQxP2CBqzjI6A1UIDJlGOoALYAqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+yDE8wIGSKUhoIGlwOMw4ygGijCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//swxPQDBy0bI6AtUWD1L2JMBAqgqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQxOoDxP17GGAEVcAAAD/AAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xDE1gPAAAH+AAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==]],
              ["moan1"] = [[T2dnUwACAAAAAAAAAACnA6NUAAAAAHM6QVYBHgF2b3JiaXMAAAAAAoC7AAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAApwOjVAEAAAAO3C4hEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAAMAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAFwB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAEx28AAAAAAACnA6NUAgAAAJBkP/4hOz88NtfW0dPJzb+nsaSvtKvBuL+9yMa9u6yyx767vKoB5ExW0YlvOZNVdOLbujqVImAYLmCCKtba169fRxLVdrvdbttWkS9eaAJ7HXcQicTExCWI69FpEsn9QkvkTuix8/F97oQeOx/f3zqRkVgKLWUQK1hpO5VqOmwLRxJVnRYlbUfbaQVyaaTbtCIOFEQq3eo2PTs9OyltUxskXaq1UjluSZdqrVSO27bB0pFDrNViiB2LVLeaVNOGkpHje6aTKiAkJk5WwEqFtG1H0VQ3PapEVbc6iRYcY6sdnWN2jK12dI7ZJtIUyiyo3cGCqUenqtqOCjrpVtNpEaWjFYUcJdWzou12Ot3qfn5rJje6+M2oi9Qxk0rg7cNbiPUXkFJe/GbUReqYSSXw9uEtxPoLSCm/YNoyAQCsgoGVtQkFmsqxqnIVHMVUB8NqGOJgs1ogywBgsVpUVFRMwWIgep2pmbmq1SiqQFGFtshy8T8BZkae9wIsf42b5eIhTxtmRuqdCV79dA2E6mhbAGDEyYVvFSf63R2hTUmbpCsdpRql1XQbNN0LgALWRXDfBCB26UyXrzcB1N0tIStnBA2Ao4GyTDoOwFF4X/xGftxw82Sq18BYbWc5IL5pr9EwZNbFT53xaWwVBX4pVtQuWQqTvw8/y0fz8Q/rdMPb+VKsqF2yFCZ/H36Wj+bjH9bphrfzCgCAVaDvYgDMbUJWLmblWJUjoBIABiAgYHUQB1FQVQRARQAJHCRwaCQsJdJMtZAmGoEQQhmtaQKg07MtAOaVAYB+dfOaDbytru3p1ni1r4elqtG0TXUFICDfT8EVYFMNB0ToVmloWy4DxC0UBkhC3qZ2/9fsn2FK4hOSuDdWst9pjEdHJ63CUCD4Yv/iLotdDhNYX9LV8eWuRSHUYUPfAJjW7gUUhC0B3lQBwh9eWSYCt0vp/H34v1ypO1jfFlNNQmWZCNwupfP34f9ype5gfVtMNQkTAABYCbA2Wa0sDLkQZmW5CKlAtQQw1DQAEFVVm0P1bDqS6KQpDUCaSmFhphUIFPqDBADFJhIYDABA0W0bBTR0BSgAVHRaSTvEnj872p9lX/dEICopL3R13blulbRwhVwoKA4UipY5LnZ6etN4U5wBs8mCAADX66DBose/6gXO7bbdT8wbIyijRenhXEGWb6JnfLKwC0+jne6ZY8AAgjbTDbHHCocYCAbAAN5pBpbZ0OTnEe7SsKUmsdMMLLOhyc8j3KVhS03iCgCAlQAbA3PsJMlVxSyTAJAjoBIA6mAxAQBV7JJ4fJi4UGgkYUsQBin1lgKkEOo6g3cAejZAUUUI6UqwCfwq7qr4NvP14IeMQKwhXolfD07tGfoa9yPbJp7ASCHsWu6sfhgba6XSaUmlqtL23UTfjnhTO3O4OizU+KuTh/LvPVtyy3qdNjUhDE/eI+e34mCw16wMPg+p469ntRV6PsjunE+kUpLRm5EVC0LPlQmTcsX7j7aFA2xeasaELgYt8c7+LY9Un9TVIpSaMaGLQUu8s3/LI9UndbUILxYAALBZLMlZuawYcxFCimxiGmpXBQfDMAGoCoBAoFVMpSUSIVQZjQMbydjxiVFQUV2NhMyjDewCo+Gd5kGvqDWZL1MWhj/Lh8Xe3LNRhEiXhugTgq1DB1Ly+gLo4AvYxCkQXHxi46Ah7AOfcANJQuUpXYwMHy18D3b0q7/kyVJRRQIVUtO6Q9nJmn6fbWtic5dT/p95IOYEAdzWP8B1FpJc6eKABgAeKsY2TpYZp/q6xGKrh1AxtnGyzDjV1yUWWz1MBFnUlglsVpYziWOOVcxVVUEUjIooRkSISWgSgIMYhDCxYWBhAU6QsKqlQZNuBRQHAh9LE4rgkEK3UfGOPxTZeXuZnRpEFGiWYNUi8PHFIynOOShkWn7l/RlQGojmaQYVIB4ZavSC98lVF29KoRoXGzh8w/9HPVOHfSANqzXRi8xiUX6qjx7ZnW0m/6+5tN5Ossc6OiIMP/3ZvQctDh97STinDrGgYQ/1xX88Yp9sMJEYHgs2DBS5MVLv9I/k9Mx2HAs2DBS5MVLv9I/k9Mx2PBEoolaClQCGtWLOSVUmcVVVIwBi1Ig1qmqqKWIxBcAQwxJEIdHYiBSfwCYIyjiOR7lgRMT5rvJRHqz/FHJb+B0k2kpHhd/PKVN6HiZMx4ZJ/496W0DkwQYaiTdtA2rTEKSLKCbCTwPIYAg4fIwogkIUJC6RlgZo+I4IFhmcFjsAoae7USwgg4BtqA2faS5V2J1m7Y65OCcXf10pCg0mswA++xWa5tIKrQuGSyxEG2a/QtNcWqF1wXCJhWjD1QYAsqYKOJjzgByrCmEuQiLVwRS7gVhxALGaaq2qiAEQDBHHRgOBQ0HguARYCIxDRGi6NM4wEHxuANMuT1+7hqe8zMuFUgCQUoCU6vB3wBkHpXYYdLtJHOeQEODbDhoANJib6WxDIOAAJVCwvwDMzRgYAqgATRBwAQPQcoTADZQYTADAXZaxzAYFAJ7bNUYUG5jd+28Vh69lcrvGiGIDs3v/reLwtczDAgxjYJZj+eCQqqoipDasVsMAmxggVtOCYJhiWlQMR6xVqpqmVYqe3R5UkIpq2gKCqjUJLR+YEOATAtk2cJ3v9NiJLAC07t9RB6x/G5D9hJYmu6BUp0XptN0OTaPbpkrL26JAC1DtPYecZ214cGA2RLdEDAaAA6EFSiKuR0wAJ7Cf5B3LCLPCxuCCsAHAtQZcSBfMBr7bLQ5mI5W2+OsWvtFutziYjVTa4q9b+EZzzBqTWB5QUhhykapIhAxAREQd1BRHK4qNJOpoNDYSGxOikGg0jIQIBIFjEhXw8b2R2wCDsHpvGG5aebcCWI2PQDdNXCahJI3S4VQAO2AcYIxAeqVSOl2dliSusynLAI3In6iShM0WdoPbQf0MNJxrZYaXwrJQSgkCqGlKwQOCAzyc5RpdAAxcGQwKntutTRSjCFxBD1kJ5HZrE8UoAlfQQ1YCZ2PMA1yWSbICWSGRSMVFE4knNnAoxzgSOAyFEiYUCRKEgWOjTqCIZRECiUtplKINHV4gfjzvINTtuRZm4NJSZXR9Zepl3HpncjLfbTWpVKrapm2qsxu/pJh2xrE3wm26+YOQQFc9+ksjqKHYdeTqiqMFA+gA3pAhA1GhSugQ4I9QO3oAFFCMADj30xQC7IAD7Nk3QFjDBr56jdUkGaF9+tHLpuozwqvXWE2SEdqnH71sqj4jfIFlN8t5gIuRXGQTEilCjnbBbmAYBqjaHJDq9Gybbo8e3Y4iPhIbBNEwGkRxEIRVjUhpSNspgCIO12UYt1II1cyBFvro/CLSnQs2q/6m21QkSUXbtDRcIOTWDkVzwKacmTW6EV9sxGH6MOdr0AGCMglszh54HQBnzJWThWqKdFNBCiPPS8MMGzgbQJo6AwiwAeC0rjxRAB46XZaYXBbWYOkVUQMSOl2WmFwW1mDpFVEDcgaWY25AzHIgi5CKUIJI4sTEIkfiI4SEEcKIw0CxcYk6CMIwadP26HZ6Nul22kobmkK6Hd2mtgDx0gMMLBa3R7Mn+n+VL2m6aG9BAP4wwPC8LHBtEYANhA40lKbbIERpBwFYDDwvXxqAfiVA6AAQ/Q9AVQC2wKINQc/Mf/yvDgBeEiCACltgtmEGwGslQKBiAB4pNftoC8Sqmab/XfFNhJK9S0Ck1OyjLRCrZpr+d8U3EUr2LgHvojZAEJlsFrOVSbKVhRRjhICyyKgaEREVY41REgQKIhAXRTHEOuoAo6hj4iIKoyZUlXSaaltAL/D2dvRpCeGStwoNJO8zklv6NA0AkjSdJm19OQTT79feg/iQ4RYMEJkQ727bkjSBBEMgMoRbOXlHA3WRTBUA2VrLBkDp041A++u0vAXaEv78WAMUIAa0OGJjcUQi7L7e0AQg4AA+uQRAA9mHGqrDdbx6bRg8uQRAA9mHGqrDdbx6bRh8BivHnGPOqphVlUXx0dgwSJAAm0CEsWEIjsZGg7ggTDTR+JC2upXqSNs2TdJRSNN0AoBshMJ1KxAZsvbwDVW0VlMILx6Iqh39XY4INphzHYDmkgayA3M2VWvxQkED1CBIOkOCFw3wXhbTKGzAkKFrATQByNAq60sW3gZ4nQltBqw9KkBgGMGBAJBxAAzBAj4uY3bJ+1CZAiIAHilVQEJ49hn9R7CPXg2isw2lI6UKSAjPPqP/CPbRq0F0tqH0HJAbsyzmHPOKsBDnCEJQE4EFEBPE6iAqiSoSjRAS79BBTDSRmLiYgBCwwVY3Gko16dk0wHNgNIlqks+7EQIIqwjwRlLiaoKgxYKyc7kRuWmvrAMk8pZ3o9u5LJg4P5RLIRQlTFPbjlSa6kIpZNRkNkCORRySN0HVAQGisfH+EyE0NBnko6WJzkALGz1AAwQa0RTVBe2GhsQZShUeWbVlQmzky0P4Ur1QOdlAOrJqy4TYyJeH8KV6oXKygfS50ApgMWarmHOxmEUKoAASNRwdTUfDQBWFhIEJHRckDAw4UUCRIAGxEBAKSOimpALgetEgWw7luu7YqNBESG/1+g41wg3AhKjAxpuiVCmFboQCXTuN/dvlDFH6irjpBKRR6FD11XUZoVsnE2ixDWdASNxvLzp0jgxgAzgvpAOsdHO20BXC53AgQJPs2AqgVCevk6qKVDdSJazYiQL+aLWlQY7m41WDtffxXZympI9WWxrkaD5eNVh7H9/FaUp6Jpssy1YDtYkUkyIRCiDk2BASV+JRIkEMYTSIVyRKhBgFCjAhCRONIWJCI0ysHCsAdJWCxLEjqB1EHD8A9EubLPgUIljGV9ECQXfoz52gUNVJCeAq0ZV0lWAAgr5SUkqjG1S6lRYq0Urw2VpJJyWq2mp1ohPAAPvQdgx8PxsDgGtkf4gHaR0A1W1FaZVjEUAdyHcO+73QBNjQUc8lDArppjpp25y4Br7YtIED6BC+Lp6xrOYtNm3gADqEr4tnLKt5ZwfYJstZOStmEsZCIggbKkEQn6jiYuyYMEGYwIEhcKxsFBcokmh8YhSNBPGyAqFu0/SUJqqlaQDlPEmajqombdpIAY2szim0SrSJFJUK3YigGIG2B6WzeTntFV2tli1DI4Z8SycQLwvJx3VJ7KIarQFFlOMIkKFMKwEAOIbHKSqAGqr4WziqJw10jWTCxUhNDkLMgW9c0yNkwLGxkmDXBRQIKIQaUtydoWYBAJ645ClDc70NIXK9rLoz/sQlTxma620Iketl1Z3xn81yjjknOVeOWSEIASw4jjA+QTSMCZTQQWiFgVEYG6doTMJEEg0gjEDUKDTQNNpKJbolgJC6HNhZXOonFMUb+Fwm9Iio2yVtIR/u+e+USC5cAHNVW3G12QXMcXboplIikjrmA6DEIfFpAV2/CAprAW9bFC9Sv6T58aKphAR2PXlrGj4luf5saak/PEr0nUTJ4Bwwl4RJgNYS+IFxJGELAH64xI021wRE8Lf2zlvXfbjEjTbXBETwt/bOW9d9NsuKK8vlYoRJkQgo8Y4hSnxcGCQMogHExhJLoPjYCNHQURIkioNoTOAgGtiITjVCm4o0AHH0NTLZEUhk9EE0nvnTw7NtSdAQ1vA90ZGk0I20CgdshFHopuUXQsUWhMZ1nEGAYEqtPvIdyyJsBpxjBshEAcd4B+8CsH9ouPQJiTkKaTtRSRsqV2AuwAANZtq9ciqkIDD/lN70YizhZgPe92SmZNTACHaXcyvT92SmZNTACHaXcytzBstilovlKuZMAhACoqjjiI8hcDyhg9hE4jERxQcRCB2JQVuqG+nZ6VGpVKcAhbYhmI78gh8hVEZgDgKgX7G9CPFYJVpGAcIwIfEd0vKoOkagGVLF9Ty3vfBCvaTqiytXdAM5TM/jXwDMcjEJhi2NsPfU3sEszgEwF/2/omd4LNUz7eLbzjEDsoUta+AJag79RZoCXreUZc/ojhKVk31qROuWsuwZ3VGicrJPjegdBEyyWDnHcuVYVVWwYlqsdiymGFYhjGBicRyJR4hECZGxCOPihUxH6dOP3gJkfRO3WoT+8IJNP5SVHrhaXtvr5wx71oG7zlMOPdYAGI7qEdgmpTYI1f+IIQpnjx4IvRSAe3tZG1wghNmGfnVwAzSdG3lcVftesrQHNCWeB2VwAUUQ51oU6COFA5k5M7BQAVDYHUJ1GHIGBZ62nMYxyRnFU1CFGpO05TSOSc4onoIq1Ji8awgECDGwLCvGWGWxqqoYY8VisUatWoiEMTZhRAmDSIhaTc+ObpK2IxXpVjXVaDuFOKzD/+p6qRbIon20uo8v40TUcufB1e6305LC0Yvq+uT6Th3PEcS7K0Dy/V8c9PDHT7lXfodetQNFBGjV0MmB0tt9+Kl1FJenhdJNHbZ0nu210FFzTkcToeRAQpmuXq4OA1T9qrSvhmIZgZz3vGmdnJhCDkIcgYc6kIEiUATet/y8liKHHABqQPqWn9dS5JADQA3ILYDBNgMqlhWrqqqDg2kxUAMQQawmJohEEoSEisTExahpOqTRaLuFSLdtq1vVRZXeEqIqUufH0FSFpKiorgud/iyhGnc4kuqokgT9nqsgd1w/GZPz8fx2ralxCXOMquvWCUD20pO7ygtAiIqxhK1FmrF1mOdjMHD4CgEvY4HQEg5fFhyzuxrLoX1qWJNdQizuQHClYiDTST84yYHdSLYQ2I0GGhMh7AYA3rd8pN5IQWb6NJEVorFv+Ui9kYLM9GkiK0TjO+sGgMTgcpbkYs5VrqqqUYuqGMEKxgSxxEStaJBIEGsIu922kratngkQSulUt1tBA9HvSZn4142bfPe74ZTX7e2SFL8SSUW2F+hQSJC2JR2FUKJBcDytam1wjpV3rRIONGo00P5wfAaaHiCENNYNPWtxxGoRis5UTWAE5jblYzEfYjbB6twIB3u3gRzCuQAZQA+0DQHYvkLOEg8ojqZsAP633I5LbDDj5SmoSg3I33I7LrHBjJenoCo1ILcAtizLYiyXq6oqZBWsiqPpgGCKIQkdQwgCiMZEwmgkLhovRa1IbGBQ1WmoIt1OU9f26Q9jfg6en01QbMExTKFL/QwMsUpDvkGa4bG4q1m65QtD+xlFFbolUOd1p3S2tDIO2ORYWtuoWdRWXApdBfI6ScSEFYH76GRfcWPTtIQfobmByh2iSiHBCWTjRs/tSNi4cCiwj0k2FEjo285sNgBkPra8XU7kNm48fD1VqBXHlrfLidzGjYevpwq14tksxqxcVSEhFQIAOy7RBFEHdiQMopGQSGxMbFysRBgJUTQmPi4qLMuy3HQ7rbRRaaMa3QOU+5U8OvR6+iDx6C3VUmK36levpOiBmdL7iCp6WLwltZwBmvIrsb0tzBWA21smBu7pQ6vwXNrM9/IGGw/grutzevEpNiwBjEddARxPgaen9UoKD8Nd3wAJQAYO]],
              ["moan2"] = [[T2dnUwACAAAAAAAAAAC4orJeAAAAAAQG28sBHgF2b3JiaXMAAAAAAoC7AAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAAuKKyXgEAAACubu1rEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAAMAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAFwB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAEwF0AAAAAAAC4orJeAgAAAGMhZAghNjQ2zsLKy7y/zq6qu626r7exu9fUxMfWJyYlJic0OJ8nzFSS0NkEuWcqSehsgtwfIFNUlgBToVM1Oqk0nSaKttsmyN3Xl5a8oG0M2q5Gm7Tdtgo9iWcD5F7fgnPgx557fQvOgR/7raeCiKAMi62ixlo6grbr5P3yFff4/doeYnX3u6qjOk1Q4lVpDNxixT3n5DFuseKec/IYuyUhCUgshaM4qjpIDDbEBSH65v7R+uw2lWiKdKUNETsulFMq6XbEANoIVlmXair699vg3a26fyTHOjY2glXWpZqK/v02eHer7h/JsY6NV7LXjn5PQpBZVuvWOhgH5MMqVojFCECKUBEH0+pgFTtiM20qoqoWCwJi44IwSoSohQGDAMLQTpgIIUdianLez7hQMJ9fv+QVAgD9PqWJtltNqkQdjzr2fhKvzt1E2wEgSRJE6bSd6jbVAIgADpooCCrdBGvCbX5HPMfJQMx6ZTndAZoBaPOB/vgGaOExRiWQswEAI4FuKuFviALdi8mvEifDMGxbNiAAfhgmbf1pNtx+c+rlkc2DAyhTPgyTtv40G26/OfXyyObBAZQprwAAaGEbgK28iSGWVQTxJkJAIQBCbUmwmVZRUQAETOhAiXEkDIKEkQgoAEiJTiNNCB2VCAkAdiTRRDFg2DQDwKECQACInp0K2RmIDwEIQ0l6UCkAAOY6AMLn1rvJu0V7KuJ8of3KxLz4oXihftq0eDU5ffWwOjY+PNIuo3HAfrWrYIBQm4PgnyERgKbzIbTTPnw0qNPJxHAu22QHQAD+KCZCuqlM37Q6ruEuLgysZcqPYiKkm8r0TavjGu7iwsBaprwCAODAOQ+w2ICKIJYzCSERAiAqiWh8bNQAgeJDIhYSAQhhIjEzkQBYjrcxEoDD+GgioUCAKkGJREMAwAACwAtDH+j3pUKg+N68LGigFCCdPhoBAFJ9pWzSnik5+kYNRBhG9wLt8Zzn1e1oENVSqfL09VUsnAefh4mxR/EFt5XcUuP9cHK9IaYQcb/VFy9DjKwRuf9HhHNogQ5AA9jg9rCpGTESLPEBfikGKh5Gy52qEdZ6XRRzanJsuBQDFQ+j5U7VCGu9Loo5NTk2TARQqbdugTkLSJbFbEAWK5MgLkKII2QUFMUYsVYBEcMiogCgxCYMIw4UcXwkjjAuBggkxRFaALXpjPcMAEX5wxm7skRIKUGLEAqsYPk6J8XqoGWOUK9j17CbbzJ8R855+euGplKatkSC77zCdoRAgRoI0io4oOn4hAWpDj56tHh8WKmWx4vR1iqIA3CICh/9zkBriJGrjxIeA80BHTS3VNlmZCNfFwD+KQYErYNIc0bHqovitYZPMSBoHUSaMzpWXRSvNUyUIIo69RYJphWzuMmyAS4S4ipShIggYlGLApEgEp84MQ4NRByGyKvXQBCJSSQKADaQiBIkPSoQl3NX9kmAEPky1jP+uj+kutCKj27pkd0tVdIpSVVFeNpwsm+j6iX+BOA1AABBbCgR6usAmqbT0hQalUAgoLaNMRCJsAFDhqZA1AoKrQSEEnAqHmBA/U2j6P6VBj6QbNOJCkZGUcBMAx76hRDXjTV7PhwPcY1OHYd+IcR1Y82eD8dDXKNTx1ctQAaorZMRiB9AU1aWxSzmCkNWkSINwy5qWK2CgoiDihXBoqpYwMBiGigAAD3anm1Xi5JAaVKi26YFVCAiRpFgQs56Sir+UutPkfQsaFkCqOofDWwsGgoMGqCEthtBPwOAilz94gR+pRtAaWHTQICqXkMAxO/oVdU/3JO9UQQSACBUCIMIlxJtAwJwJgDZCJyEwBbAuX56+MhAAVz6UaEDPpv1hqujMdpL8xIXVqTMZr3h6miM9tK8xIUVKXPoYXCW82YTcyxCrKyqqh0Aq5oOagEBEgniEknEUUdtuwdtNV2dlEjaTts2ACWdb6Oo6X7yleWeDJFoFv8JTWs78jrWo4kATNwbv6AtGolKZ6PehTS6JVVIFc3ril2JhMc5av9LWo8dVz62R/4mPDpOKt6Kzi7u0aoVwwPDBgBEgZBw67m7xU31Uoe1bEne0qe3Zxd564wQIys7ZZxPEeRSBtPOBsnuUncjAKNbymN+1NY+25URllaK4ZfjE3ma7coISyvF8MvxiTydZhXLsmRluQgziRUhJDYE0UTjiElEQayjjnUghbYUKC5IxFpNEZ2mquk00pjLFkkHKaqs39uIk42ftcmuRfqOFmGbIbp9vst7jWkRTuhYMbx0KGi1kSEfhYa2dKsahEroQJAtdgBc8EahsIkTANp+kgULMgpgZhjgQ0oJBOaA5uKDmQUHsw0MCLQAuMYdA9CcbgKoBADe+00NxmZGetk+ndLQ+00NxmZGetk+ndJwmizLSbZiOReScyRCahITE8YROD4SVbxiAEUsYsJEE4LQbbslPUR0ukRB2OoYeWEHVP80dFMp+3pmqfBb6TDFiOqhIQdVqhOglIDjy9al2QKQ0IXGEzAEiBbD5cQdEzEgXBbr3vxnCSo/KgbYYUYAMC04BZALagQLIUMrE98jHOZtmEUBhB0gAAUFFC9+rR3BKb7r9Y1GGscvtxdyZrzr9Y1GGscvtxdyZnxGFctyUpYjCGOuKnc0jE8McUEkEisLWWEQEJsgGh8kEsbg6JHqUG26Tdqm0qUKlYhSOkhLJG5Zc+ZglLpLhfWUK+JqgarJxF+dD9utjlyU4WtZ9eCqLnqkGHCAVKQbkFLZWSAHVBGBIMxDw2+EAIdgHBsTuDMQAJp0wlmAfoWgKPAKIT/yAEMAVQBrzss03dZuXjcfWuYA3cn90tW9JlsaAQCe260Nllmmhl+OB1rCOLdbGyyzTA2/HA+0hPGZZFlsZTGTAhxBYq4IiYiNSxAGio0LAsWGxESsUA5iwwQREXGsrbjQ2EgBEdRCUBVC4dG/QAsXQpxIWwAoniYhkV8sprMd7kzOUdVpE4BUSNgccLUqpwHgOnMHRCRqgIGvA7r7lhbV6Uak6kEAQHAYB3IbaFiZ5i4wIhCfbpBHjIGHljEC2ABkmirbAAEbcpCUAh5rrRUijPm962+m3pYkNNZaK0QY83vX30y9LUnoaWKWVaakASFI3FSRyLFx8TFxCR0JSRCGshUIgGhiEiYIFN9NOtH21KFtKt0S30gsX4Yd0oN6gYRJfZXMzapWsGML6YiwimGd3TE+e4nLB9NXnUEO7jAIZaFoHIBsrJyhFEV1qhrIE4z0LwAEUqEaXe+o7AQUQABsvtnGqcOGUXDSjRQUKEA2Iy5Vzpt4sQMM2LehADiaQDsDcPsqGR46jT0GtwKerw/bKQUZOo09BrcCnq8P2ykFeWsDkyxnsZzjgAgpRyLVwSKOmIZYRExQm4khjImPhHY0Tgrjg2gAAlBsIPfVwTGeQwDgqSoAfBm6de4I8EEDVL00s14BK3N9uGm7siE6gueVgjs3dqR0AO4tSeACAlKH4J8JolRKR1mqs3dgu0LgBsBUSjl62wvq5XZ+dcjADOoykYaHRwOkhBcAYafA0OzFQwpmJQMe2Ry3U5upmy5n6X14Us8mkc1xO7WZuulylt6HJ/Vscm8QZBOznOWsmFUEcY5UpN0mdlXUUTFNw0FsQZRYCBNGiI10q0fbSHXa6JE0gSgK38++PHdcbENeQGCHdKm6rVaKdFM8KDiei/aDaBrx/XQDsM803NoY+2uey5gRgEgP9QMgoAip/G2EjzgUEEBpFTKBYaCRMU1aSCZ+tyESNImngEzgqj5rLQANBHZp47k6Qdw2YNFtGWi+yERTK7cJIvi/rr4pZwMuMtHUym2CCP6vq2/K2YBnksUsy7ksVyapSKQmJt5RE5IwnqiISoSxgawwcEITgu34+NDxsSHRqE10OzUBQYKvpCRuySEx1rBatsSVAl1fgUkwyNvRGy8EQnEvAC4uO/Z8zV0XqmCJD03eBsBJJLdGZO/ZTAHAQFXCxn2OGIQmmIStfvsUJMMejTOZ6lpBQTQGTlAADLD1bwLERv/Gxrc6vir+98zJAtfsh+1v7Zc/yxTbUOjfMycLXLMftr+1X/4sU2xDoWeS5SxmEpflirAikaQRxcthBDCJRIjERwmQCRMkCIJQMQqwUBgh8cRjbQ+IXzQoGFpeTrUqyOAWzraDe4b2B2QSyt1TLV3pIJzvIOPoM4AQ3lY8/mAUQl4XhfoLEpaOdze8M+6/Vc5wAAQg1IGdDe4DoOoIIpXS9qj27GJH8DXjwFegAHSMTwYXU8DRutW3UJGETmBDwUMBXlgdiM0A5BDPyG71prILdspQWB2IzQDkEM/IbvWmsgt2ynBjkVOWN0krDlRVMVJEckebFTVMB8NmcbQjFuIJw0BxYbyNZSKA5FBE4xJNNBqNxMn+YP4wM5QmLpqNpzDYr0slVSmq6EGJhVa0I45o2uigVLOLG/JeU6E0FR2pnhDnkGi66QsL7Yunq9JU0laqKpV0u6k0adpOVRMqA2SoNdGtCTrh5Pn9D0xxeaM0F+itO0tbNOjXOBS6IQAqCDQyGxbcAUA5KKhpEZKQtm3b0qPhDdDSRhA+eB3uejYS0u5Qv3gD+xBzyjB4He56NhLS7lC/eAP7EHPKcFaBXrK8iZnUxGxTlYuw4moxRRAx1AJ2B7slUUQkdBiNwZFEAmIViSgOYuIdOHRcPuTbcQWhNWthlQYTo9Jp3KGSottIxbcllmWd3IcwDyUxisgEUKQj1QrU+DwSEGsZLJ2fIeJeOSszspRommrSidJNtNQwALBbBvpZGLx81S0vsQxA21nWK0hHwNXF+rqTMt2mKArQABpRWbEWlA1dANhfgBAhVbatHtpuWymtSrlpAD44zYgoCBDzEL7+LdfyZ+nHlD04zYgoCBDzEL7+LdfyZ+nHlH0m2YCkHGMu5mJFCOEaK6wIMU6MkBO1HQ0IDQmD2AgKkBGEUeISJIyx8KimxbTzbS9aK42ZwPSFFER1cL9NLRb9mnTEWSnRTSlJG/aosQBD0frLFR0LEhzd9psaQjYTi18igmkFZ2YAyNvkVdKcya1hD/WtkvVOAQ4BYPepAVoQnwIxhGEh3tkCZIxCo219mgwoG5j4LU+ladJ2opIKdQR+yAySh2vysOxgX/2WKIZsD5CHzCB5uCYPyw721W+JYsj2AHlD35pkWdbKYsxlVVVEVlMwFHU0LAg2MaORSBgGkRjFB6EJApBjIzGJx4QxCMjmsRbMQsz7n1b6Q6ifhk5oWpTCyNWg0qiSfbBXuXDSu06KTqroEsBPFxkHupHXMLJL1QgYFBsnd1gFgxLwGvoGIAMIIAp0xLWJuToWpDXIba8POR2ZuDPTO3s2OWHZfGiQIQMBTOOIC66jYAAAFN3QpnRUQSgAFsfMCIlv7Qe+fe83WHgyxcYxM0LiW/uBb9/7DRaeTLGfCIWotyirkUKJXNobsyzmrJiLFasCGFejajBijLFqsRarOqrF4mgYNpuJgz2aSIRIGGtCogGWHi0NbVNo/Ryiz7+u4m8RAz5mW5BBVwGQmlfpKlhdZk+NMvFc0T8vn7mLzBkwXc8WnPIpdkHvC9NtSXLIqYIJ+RQ/8x2rEGDrlNaM7i0VcJlXhtygKTTX2Hf3VNbd3+JG8eBVUyAsyc4B0BKXMthHGooS0jNtp5pS0aGiOHrGAdxCf7NSsIRb6G9WCpawrk5BBDIUoBWDKvrh+a5dShhlZihcJgIhAdREf2Mnck30N3Yib32pCFWLFYuDAbqKQIdqZNlyEA8gwCtsBWEL5ER6GqtDzYn0NFaHuq4aZUhUAVrBKgIviFw3x550M7/rxoc7DtxGWhqb2N9GWhqb2N+6JQJZ2YK1INKpUJkkhBJvw20Nfz4U4KsCxEZldJlDjo3K6DKHfGvLFIDKqlGMCjqkVOc8wpPcji7/blXYsG0A3ErW2Vmmt5J1dpbprj2QFBGrzUEd7WoIQVzggNBG67RFpR79/n/VPVLSKdVWz6YnIXFDBdxOL0vZ2+llKbsnQLVQWgMwMUWj1Wg1ar86NN1Om8rpS9PttNHtER8TDUKZVIXnpe/5+mVm/kMA2rbc/JyA2AFfqCm2LTc/JyB2wBdqis/2er1er9fr9XoBFXM5i7lCCqkKADBsYnewGypqmIZpWA1TRMXuaDFVTJvV0m16RoNKpZp6mcydmbBFaYAy2bQyic3kV2cfXUQnKEuqrVJp5olGAOqhRaLNY46W8ACPCjMnp3KrB5nMKWjhCXiHtbcBMtCuSYCQAwJc02zIocQA0GzI4G0JALABHrb87yw81A7UL9QUw5b/nYWH2oH6hZoiAAAAAAAAAAAAAAAAAAAA]],
              ["moan3"] = [[T2dnUwACAAAAAAAAAAAdXQ7cAAAAAHcJS/wBHgF2b3JiaXMAAAAAAoC7AAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAAHV0O3AEAAAC2ev8OEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAAMAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAFwB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAEIpEAAAAAAAAdXQ7cAgAAAFf4ptknOTXp4d7s6uHY1+Ti4tny3tPf29jO0tbM2uLm8evg1NnOzLuqu706vErabZ1h9Sppt3WG1UoHyEVSWgBMBAadMNf/p7WtptOoVbWz6ZFuV0KT0DY9OkqsX3xqW9b5nbQBDFuf3TuxHbY+u3diuyqXnMlOR7E72NVmxB2pWjo9KuRZ1VWSEwGuQDfa1mCCBNE48/dfawC6V+X5ScJrGyH88netTXgLIuG8V+X5ScJrGyH88netTXgLIuH8Qm8nQg8A4MIYBAZmWRzATQ5xjFWRimkXi4PaDbVbLabdJlWrBQCGKXa71dG02wxQMLPQKxaWeoSUCKmobaimVEPbdISjZVqprhABqJBOA0BBK9VtUQD5Q16Sdt8Jl8NKvLyRgolCAaT7Qiyptz8SEcpIZl+hkZCE9BAXA86FODJNUdXtRkhdlp5VI6nWuMUHHADE1z4j1TbwD0PzYQC4wtyHGmSAbSKDLKMnxfrYQBRg+3/gzHqid7Pn0wzBS5xyLPbJJR6IBUr/XY6m2w9/H6/QF+ehIRALlP67HE23H/4+XqEvzkPDBAAA3oAs6k0QaA3gGuBNLmcSVgiryEoRAKxaVCxWREVEOtV2aSqdJoC0MDOYWgpAShUQIABLicbEaA0d0LRNpwEUoDTdKgADAgXROMKQOHAE70zPa7KJlJRON02nAVqyIExcbSdVEkpR/crRJ5lQWU0ogup0o1kAqA8unEhJ6VQAUZNuO16veiMCXUAR2NJqA/4JBxRAjDR5JaEJKQMwZuqhJ5YdHFacYjLmvUvCsxWF2laSIQPsfG6jZ4NjFN6XVYL6bFJSPnyvl+Ova9KXVYL6bFJSPnyvl+OvazIRUW+1JgBu0OIEeBOz2ACHOOIqV8GqWFHBgIiihsUUREwRi0AgC5RQcYGQHYZgIwA5iE8QFwAAgAQgK0FEyAYM8l8NIpUKFZ3zhQAAg1epdErTNqVp28o1LxMuv/UnES5fELHxoPnFLcZE9C/+B1uirOCqYf83U4PQ14RUOlVFp6pB0F84M6VZAK058pKeF9GYHHcGQm5sJZoeZfOdxN19hkPJBmAXc5nDP2t0wmu/Jsflb91UdgPaIReLHTaOLn6opbz/X46pG6v39YqudHBLq0oOtZT3/8sxdWP1vl7RlQ5uaVXJCgCAlUYkkJUKbgHwOjDLOqpYlkWYVUE9AKjFCAJGjBURO6aIoKCioKDYIJoIdiSMWEJgrjUDAQihKsRLmsYgFE08wBggAC7ZOXWm2zOpoMAjvFRTVW0rEW2PIKWrKoVCKBsTr87aqOWS+BZTENS50l2VxXV6Ax5clQhdSVSpNJpqdbRpeibpIZVCgBNgAyR7UNUSeb9NkAEgGrcSimUuAAMN5pZsfjEeuiO8X8beNGVhat4eMYqbMZMLMvB3FgVaRDGoa8AGPrglFP+5yMIyL+9+HX4RBVWGwS2h+M9FFpZ5effr8IsoqDKsAAB4HRmAUg3uBWC2aYC15ZDatMmRItUBsMYaKyJGESOCGg4qgIAA2FYYxChhxPEASGmht9QLgUAihK6WFIUqELYSDzEgSes8oKTw2P0tAQj0a0ClSNoq2p4d+jqCi6Hd3R3XKaZwPjOkRwsBKhJzqyEhYiFvB+ABFxVEOj2jVJcwNARYjiVU/D8S0MSkv7fjUHd51d8cBegDXbMQATo0oaSrSdK09YwrDUMEoAGqqOoql/lsVepUTQbFTdi5hQYQi4NWH0IdnudVMv68GE3/XD3jOtzSqqI8r5Lx58Vo+ufqGdfhllYVrQAAWBkpILNuYHM2wHJWOIeGsnJVUC0BWIxYi4gYQUWImDAiKUEYCCSQ5hZ6E60EgUTknwMx8SECsGUAFT2abqqCYPttJEf1XV4GsmDLHyMOPBUckTadJtooKbcSQHf3toJkKHs+altf5wRQJmnD+t0ofFkS37zdtchBfBgbGohKfpBFyfkBejYNpVQFVR3V1S2qAjA033xdsaF1uzEGrGr7/vRpOh0OoO9ge/SgsS6LRWTuNDCqDdgB2BDyfZkDHqjlVbFvR2UufkBbBmp5VezbUZmLH9CWKwAAXhOAmoTBspjl3ACXFIYsDqhCoQoAY8UqGGOMFTHRKMZhEJsohFECBWEww0yjClBBaulKQOlWj5aCUIiiJyXIjxCY7ko+n62QAYD7aMK0+Zt869MifAQgNPE3XROl3Q5+9lzfW2nB7nB1ugH6+U+ilYmtVBOkS6tNrXIAE13aBvb13C3uaDirjgoAgmA2mxDMfGpoJd8nJak0ykhjQ0S5L84RRWnpRJOSJEpRu+CICpAYOASchCKla1YyZ34A/vdVbXNmgzN7T91o0fH3VW1zZoMze0/daNGxAgDgtQCom7AxG7AOWS7XKlZFqAWAWkGstYoVQYmRA6wwDhlFJYWwlFIYQIAUaCLVCFK6iQgwGEAoknR6hgKzmJHg2bX8UQVKRRPqRCdiQvIuJY0mXYRBcBI//VVbiSpJR8iFWtIpqbSClFajmh6tiEJxuVrOLf4+k/kOlKhXavyODURcAQJIkSIi4r69qoAQbcHDA2iHJp02VVpJSc390oEA0tJHvuYmfwEKAcmQMcgH13GHluD2PJwRnAdeyAW2OLcbssyXGy0G8biQC2xxbjdkmS83Wgzi8QQAAC6ww+AsiZvDgHKMWYxVoSwDgIgVDENNbFZUzB5tqkqnR3q22qJIVatX9SoAAk2DCgmq7faoUFFCJaWqZ5qUFOJuQilis9vEiZCEb8RJkd54GqV0K1Al3QytKOQQ1YnSbRtNQlJGjbNSkKI6mrbVSbV0qyFFu367HdAE9KWkg6Y6qaqEPZB2zGzAuMYYenT/MQpwPDSiQYUN2xJEKnfH61ZOkFcvo8YRgHZEp/qlvapQ6oh4+BcwsCaHIkx0EEhoDNg2fBk+yCUteY05WdviyXatLga5pCWvMSdrWzzZrtXFCgCAN0DWVgBTzJJsk5UVxmoTN1WhJgAQUVBRYxCDGIUxAWFcqLhorBAIE0VKoyKkFKBVZGMAjILERIUO+JHDhBKAgYCWfejXSIpL5AsPvDdSxU2pR7RVnUolFAIurgSBh0qpSqketBGHRRqcKPsrj7UkGwVRYipdEl7ua1VR/+uteFN/ASCIblWikKT8SQQFQiYIZgME4qsjPat6trSVlEduR1GErzuIL/+oRKU6JMUgip2gbWS1YSgBMu4g0VlVD9JKuE0DfsiFFt3HgfXn5Q3a+JALLbqPA+vPyxu08QoAgDcJol4JsAWAWclmkwdkubK4qiKqJQBWjIAo1hpUQU1RUEAASUioOEgQOCoDAr1eMZEqIKVUAWwcgFBiYt3Z3qkZ1wM04TMkmsrXe0pHDXC5XcW36/EDuySt0KIjRdI2bYeqauVMuaZbotpqq9J02mpwmz6QrwKAmSIIZIuSou1UIWkVOxIIDQDgp4NRJeLDTUCDxkLemawAGOk8nr2EVpV/FSSBgkBP6E9pmvRsSqWEwpaziIsVoA/0we8Uph2u7oo9Sr2KAj64BTa9Lka2joeNRRsPboFNr4uRreNhY9HGKwAAPgCVOgAwAixncbMaEIYqa1VFlgUAqlZVDYoVAFVVAQEVwRQ5EFZMAsdZAlDNLRRVAQAhEbfjEz10q0CiRKM2tJAWqzEUocrXeMav83KAxDRnWqryE8hOK52K6kSq0xaY64nWdGkjRM9qhO2picKGtgdHmDvVFG3Sleq0FS0gGcOsGp8nDOTsABA6xi0YyMZMzkveM5fU1qfFNCR1Z171U6qTUBFSfsMfd0J7+BGPcIAvbDKNdjDB2bk7uc+eyKWc/l4ObBmrTaj7+mUil3L6ezmwZaw2oe7rlxMAAPggoF4VAAzYEgjASbZWh2RAvGVVCbUSACNWRUBEBSMghqAgKIbFtKpiAUAAhWo6uj2q6dmjU6QEpmCmAEiQKtmOiPSongKg0+nZFpf3Mg4DABAg6sOGqqYq2p6lKhoANGA4XKXbNumWlAh713zVKimkOlLlXAbPFSC0RiGVbiop0SOloE00LcA2GzDQkVKlAEZU6TO6CgD4Hi135TcQQrKPRUAghY4GKB5V09E2olspMcA277YZ/zbeZJaoZDloK62sol27qWTlmiwZeGoZEpPKJ/7nVYLqHSCxvnwq/Wo/nfLnVYLqHSCxvnwq/Wo/nTIBAIDXEkRNAoGAAXZwA8ihLOaQEIsiAWANgEGtUURMt+2kSqutFhE6CzOjpSJQhJQSgQRVbc+ePQqmIV/o2UgCEAmlgqAkkiZVnUrS6E8dsq5m/wigSKpn07aUCmK4rg0g7/dFJxUFRTRVVV0U6ImsdxJwDD1205DTG0poXanqKaKqKskZqmQ4ilUqCNHo0XbaJFVKkYD8E4D6B9Kc3OBE/yzvFRqELpjkBT8t4g7HGRoApvG5RiSLYDEP075+BH74Ja3xvJ6U8nKuNVQqh1/SGs/rSSkv51pDpRJ0WdZbBwBuOwGVZUlc5QGhIWdVxUYRaxRERQ1GsTrY7epoKCgineq0KdWUonpKQgpi4sKoAEIoknRB16y8EjCQVsZemDpEQGbzU+CcVnBAk45oW4rVnqI4JTW+VI+SDqlOoianvYNadqVqyF8HDcB5Mp6W6L06iVTaiigJADGFmcVSibZpNEq3k25DSwEFTRvQfAKAA9T0Rsy/Z70nhCI0SDt1RowXWgfIADsAbVYFA3B/KQZx7QNeyCW57gK9deIv+7GEPxusjRRySa67QG+d+Mt+LOHPBmsjX5kJIMvaGhJARHHZHsCSnMVcziGbHLGqCKPGCAiACihijAKAqFhHu81iMwUAVdPas2m6TQVUVV3fIWCkGlKTKTBU1dE21WiSaK3o3b1RGOhYJepIA/FKPzu1vhfWTCnpRd75jWqh2kxswkPVxDKOVrcAjk2Ze1hu/6IqZMjDQDPeeFWTttpS1TTdtDVq9fFud2jSBtw+2MOqdItc9Pf2ISxug4FzjppXtRu7W6S7A02PAHRT7DPKvFdJdbwEfriFfNmuXznll/fjisQk11PxcAv5sl2/csov78cViUmup+JXZACIOnUBIGpq4wYixxiYrSzLQrIcY1UhVWMBAIxVo2pAEBBjVaxpQUUBMMTiYDM2BhwmjAgjIOmqSEDS6ZZUADophCBNpwsRkB7apgDopE0BOpXd1yuZRuQcRCJHdwTcnbZSSlFVldTegyDE/T2OhPgw7Pse6aadL4Um31mREde7bXBQdXSEzdXpuuiXLRD5sdCkA7akTylFAMhwFKhovwMPgGHx8COZjHdSaM4CRfg+ALQ5+HEkHsjlgu4CcmmUD8+rC39tOJUDuVzQXUAujfLheXXhrw2n8hXQri0lgMi49ANgWZbFtY4msqqqCIYmNkxBVBCrzUHUWKMKgFgrBhxtBiggpqH06HYlgUrF8xkokCWu6D8bgD70xNs/nTQj0dmLIgGkHM0f4+cKR9MR/FV/ko6oqDahxGT+SDRFuoXyr26KSkV1G20VAK10S6K0jSbaNt22ipY4ai8BcKehmB1QpCiday/Msm672/XDKN9AWkr0DUiYwy9hvofynsrWmUxWAwTANYoZIvUCAGz8Xoe1sskd4FKpD9++2hpSqsNa2eQOcKnUh29fbQ0pTYyyplq3TACbZTnLVl6bSOVcEYSQYgURqwCgkUgktOIlCwSKxiVMTKKRSDS0DZBKpe3RbTsNRTBzXHsLIvTxbAgRVXtY221ciCr9TP2SACB19LAZ5emnK+gOU/hC0W1UpZQcKasdpSLR5GMiqaS0nTZtRWbTaqrpVqPbNFVNzvr7+sR1AA6J5uwyRyDcCE9+3eGXDf5laEzqb1FC3GwIzcYVF+z+rBrIAGVTyL9KBxheZ1UyZb+WJ+0V1HvasNqTOquSKfu1PGmvoN7ThtWeXAMARbVSjwROAHPMNtkaQBjJqqqmXQQVMTHUbkVVsIogWBDFisTECVlYSugECQIBCBxi6Z4QAJEKaTW6sCx6rr0KwhUtD9GXdW9dORxiDzPfr9TTcbVMi9JRqabSkwoRGmyUfvRqIeIgX8Y1LelGU0kk8chI6Q4Zt22r2xaq6LIcbBdw0H0VZUS5aUuissTqxJYeSfZBfCEpkjUIuLhIE/xCCDQAC7o01wwEMUCSUQibtoe+V6V2Kq6LMkb2v+sTPVrDZKyV7FWpnYrrooyR/e/6RI/WMBlrJdc+AMhK3ZpIiN8AKkvaZHFQQyxuKlKBaXVEAFOsFqvNFBUFMVbUWosYwwG7HUNEQVQQ1XSbNgUpAOl2tLRFzfIqgAoDETrHZpOCTlUK8QKUO7UsadNWj54aFQKhhV+rHgZBpQDg5mUPPWx1CqXRTaoikLaDSinp0CJtp5QHQgusafo0yAhhwKRgg9KoahSmEhXapqua1AQPLXzohhTspiuLTdJmBXYmAwETct8PG8AA/rc8GVsXNj1L9ez75OictKb4tzwZWxc2PUv17Pvk6Jy0pvjJmjIBAaDNYDELNTnmTVVWkaoVwaqIiCgAqKGGo4NpGI5WsVj16PboKU0QqSbdptpOVdNSQUdE8fDoJdBTo/mARE8eyQN0UN3Syksmab2Vkur0lFRU/oEhQp1J9alOVRB2s0exQOkwUvWyEHYKolJNN01XeWyZqvwCaIBd38zXMvO8gC1AAm7Lp1Q9evW8EhjQSXuD1wDntcUZAAwEOnkXEoXM3pgcFKABPrgsk7EEmsIR/C3V0/qagMFlmYwl0BSO4G+pntbXBLwrVZEByMzNYu7ATbFYmwhCijWq1lhFVVRETehovKxIQoUKIjFxcQniIjExUhAEgRQESdOjaVTbtpWEX0Dvzvv1OmXXp3YoISl7Rt7SpGztYNx4Ww9a7H8F1Xa7PXu2VVVVVW23rSqh6n9v3ssuQBKqUG23a/pcWI2FWguAuP6LFy/ECQ1oFjHAR4gXCd8/YDl8oI2fqGorSVRJ02nyfpEC/HeANiYWG7CIGxfY//pXCz5xH8StCYzDVmiet0RM5jITdP4/qsNbmiPOWyImc5kJOv8f1eEtzRHfyQo2i1m2WTFXUvikqmQ1LIooDmI6WsRqNWOjUVsOo2GsnIgdxia0jYzCqKym03Y63YpKUgQJn5o2qje7GMdlwJ4d5daaxihKEhprFIJGGuw3KtLS6oQ4EviMakka3VLcUKhykIo70wKvo4e54iyothjdAQSI6fiJH6ulUUCnU1BdsR5GLaEPPkI2MoAUF0QJ4iKJxNgOw0ChHnkLvcQDOHIGkWwU2DlAO3a2ggNTRGPjVSeiikjSSSdtVbdUhYTyB/oAXgdVCJEro4LF36sv2iaTpzqoQohcGRUs/l590TaZPJ3XRWZNTZAAFrN8VM4qZnETqWLBGiMYo4IoEh9AJGEkNhp1jMMg0XgcKEoQjRBGJJW0RTeVKkC8UHpVsvGgtTnIL9BEbjfycktiJ+TAxInp2PtPJ9W2mkp00knodCkRVUKlulJt0rRtFXGvo9RcqAk59K2f9MRyAkDb+c/EBYAtXPMWJOMV4+vFe+t1acrVpbRgoBFoOQ49VGmkLZ22rLxfe9MdFdDcgEEDnerb6KYYB7q+VJUNLTKsV3vMecX9SjP/x0F9EwB+R1WZtAJYZsn+X739ZB7dUVUmrQCWWbL/V28/mUc3FvGarNQhAKa86bQZYIUh5ngIybJkRSwWu0UcrKbVit00jIpVNaqogCVhVDGxilNoRQgCOvRAOk0BQA5IABKOSse5+zVwme76U1RB0pZulwv+NSubBlGHHUQSRAmikmQRqiNVmkqbrja0VFKFi2o4QapERQvVLbjgvXI3YggKSiO22yBWJW6y2wGRUPZ1XLbUm5OiacAfbQTdmp4qLQF00lRVVVGCAGgOoL+quR+BJkzQ74uSCNHckG36U+n4eBPXt7pQ1TSdJKqqo4hUJSlN1zgAfidVsanXrKD3c61ekOUc8Z1UxaZes4Lez7V6QZZzxIfCDQDAcpbXGlBxkxyqiskyABAQRkJLCRKPj0YdG42Jt00kkBMSODaw1OqEiZRSSpAIkW/9egMR+VaCwIsStlolOK99Dm/0eebxI2Bf7lhCl3E4/aso2qi01W2qoOZdUukmRFoiTv2nhEGiemibKqVo27qlY6X5oO5YM25lJRhCiOz+bAUiSjFqNR1VTTptqVYbVzINOKYmpFNCFSidSqVVSro6hFSLCs4G2ODa3sRTKBhZceoVbUFtvSJr77Od3dHRpjWM6U9pkVUCAF73tJCcrhkxRD+PxaqcI6p7WkhO14wYop/HYlXOEd1gcl4OAMCyrM2mXDGLA0i5eJhqqINhKiJ2wzDNMgAAYxAmdGzgMFFMhYpW0UiERCBaSTUd0iIafum5ccwvWJ4B0+LAPbr0IQI4py6H2tEp7odQ1FabptO01QlFZKBL16JSDTqqZr5xw77PfGHq7LO/UYSrBwKwfhUT2MC9adXCkIEc9eIqRXWFHnMbCDvPdhSf1sJb1KlAiepSSvPeC4BpKC5fC4h9bVJ0sM4sQLMxYWvDfMRCpY2QpFLVqZ5KVSEFnrfkkKwDpNXqb+ntq1PekkOyDpBWq7+lt69Oc6DV3izHvCmuXMxxAKmYcyymiQCmVdVuszpCCAniIgmixELCeMsgE8qhiVZ1kWp7SqoAoeJVV3F39IEjibPevChz9jjUIAxEXwWzp4OqaaXRVlWnaSNvoGfy8esGOSb1uAgcT4vV6EY3QiraJp7tAEDqVdEBqQ/gO+wXD8WEfKke1YZIiyl5VkOI4LwcvFKETiM6RUpT0RCADecjO6Ksic851WNCh2CWGlNtHfqBbrMjq9cHWNp3MQB+t+RQ7LkrxFw7PaOWLu6WHIo9d4WYa6dn1NLFHPRCizmLmxyzrLJuBCnnXEwQVTEdHQy7KqFjiSphQiUiBZEwbNumpIeqptUGUoxExIkAAvvX9LAf3bDRcwzgq479MGrwKSIZ79ZCuCdHXUALqZdq9IxCm9RXykNEuJjWJj0tK5RyOCpFVT/0bks09woAALGjnC9ZS8ERIpClSu5rsx0iqYqijgDgCHknK9eEBgjiJQFqk6qm1Y1Q2A4ywc7YGBKirsZuews0K+rey2HVAQVdZ1a63P8/ZfMJfrbkQMpWndL798i28vlsyYGUrTql9++RbeXzOSzL3Sw2IK9iBMmxJiQuSBCJDwNZxCZQSMRBGCYIFBMfxDpUHJZiAwiFFBDn0IHlMJBDECQ6f3e8blwx3UD/pqf/AHpEFGF48Twe9n3MdxqAQmQchBCXbopSDdUU5QGReJ6dYWagv6XM8YdFUzYIQF9qrq6EAlC4xgXHY5AGzI2k6aZKKhUDeMbQg4Zn9H796tWgNDgBxaTue00DxBCtQIIzdtvS6X41nOu6PdzdbAYcRw/etmRltAAiHMVfTU75Wg2wbcnKaAFEOIq/mpzytRrgGWxAHuABzipXJKQaOJHYkATxckw0jIQRRBiJOjFhNGFI6LDb9qAppSLV6dlp0rORqihqVvTqy70KTDeKyAaVUinVaKXtlKHTgutcop8jgN0Wailf9Y3otFSqaZM2iV/SdstFs0+BYtArkkqrqnq08SsP9MQSoApe1k761QxAx2bPCpRALxEqR4+nwG4Ygn3fpIp7aQdHsWE6MEO5OM/6JADSRRUCiBo9e54YyAC+tixtLa4VIxsXC41ry9LW4loxsnGx0DiHRIsxt8lZsSoXqWoIFrUgBmoaVsOMJEhIEMbHYQehI/ToNhU9RdN2qjiMiyJwxIEBXu7CJ3OEZ0SYr7i6B8r9tZu7dJKTrGKvj5JENa1OG+UqeoIH4pd+xfQWkSoQvmMK/iPafBBgB7z5ASqMs0gdruv/cdfLykb2/OOKM3QNSSGYvmsEFNoZQlUaBY+Ckx0EMrg+dwSNNwB72+A8FGhAxmYDnrZcS0sOOwlAY9pyLS057CQAjWc05XKxqqqqKEFMIjEOYlAYRCTi42IUBoYgGpOoAsXqNCqpTlejTVWPnm2radMmQYHStEjbw78vE/HVVfJ0bxEIlLQ3dBSPUtLYf1SAwyBVm7af9TNwV/lGCEt6HULdwfZCWLxnrE7VtLeYtwhKa2R12603WoW8cZLVPAF7Ng4OXsvIgQLKZwwtG1gH7QOjGQSHo9BihAx+tjzHmhzSQIQa4dnyHGtySAMRaoRns7XKsRgrVrmqkSBIPIw66jB0GBdGIvGRGCnOAQlig2gkdGy8Y5EUCEHQ9qi0QKXoKwqhGuDrqwiidIKDZdKg1YUmZB21jpNrl8+RHhUVRFGcqCxDdDss6guxtDx41yum7jk1zivNuv11n9vSNOc6VnanRTqm2JP9GTUv0gfxxxqO1478WeBtlFJwsbZb8yEQHMA0g+kas46IEAPIWJobnDMK4AADXra8zaUi0YFSoFYsW97mUpHoQClQK55JlleMZTFXVVVRNJGEAQaFkdAxsQpiI9G4+MCOxMfFxsRGiI0hPi4UDgyylA+pgu9ohQ6kDP8cLYTe05ouqk6batqmDaq5pl0f19M2MEdUF9pihZbnZeGmwXuWzvXxqFLVAsNT8MJzpF7qxcwreQlVyR5QnsbtaZtD3Rmvg/3Ea7bhhlRTKKcVu35jIBzuJcAS7+BVblkgVdKwW4XdFDVKBcBDJQAbHrb87yzc1A74Qk0xbPnfWbipHfCFmiJASCEggABAAAAIAAAAwAHMlEACT4EnkACL4JVPYFa46zYoAA==]],
              ["moan4"] = [[T2dnUwACAAAAAAAAAAA8IHZGAAAAACXEqLYBHgF2b3JiaXMAAAAAAoC7AAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAAPCB2RgEAAADRufgvEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAAMAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAFwB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAEx28AAAAAAAA8IHZGAgAAAGCDbfofMzjOxMG2yMjGtbGxwri/tL21trG2wbq8ucS5ub+2AexW35rnzvDsVt+a587wrJogQ+OKAyY2m3m9rSbS6TR19ob1vU/WJ1orORofG5q8hSlDANzc4cpS8PH+5g5XloKP91tryBR2ZSB2U9TsVDWl0DZ6NIVc+n8EItdjw+2OhAliA0JpVIqqjrsBetgdYJO0K1NO/PT/EfVSvlPdTA67A2ySdmXKiZ/+P6Jeyneqm8kVTLYziFRUKkXAqDaxTZtcBCBWgUBgUbWrFcOwqungYGDVKlhjUGMEVNNt0o1KVdK23ZCiooIU0e1JmgRQiP37/Ezw36uqFESVHr1q3pleP/bXXU2XpnZXRseH7aepKqluk3QrpR9pV8a0Fa2OJmk5VEGqqtENUUtS6XgtK21f1vT6zoRwBDaAAnC2Ub/QtN0+B2uj35QpcaNxYoY/wKc7xzlMUYZSqxneCEaoSdkO4d0uz0c33sX9+/OpjksawQg1KdshvNvl+ejGu7h/fz7VcckEAAAGG1SA5SzGrAhYVSERAGUJVHpq2+rZVhodAECYm2mw1IOqEp0mQKrp9ujZLQCAf2htDWCkgnSbBsTzrkRINZVKSSVdbQkkgp6ZZ68XycxQlYkdoeeYOS5VAABC9AMAODUAQB8XAACE/gn7v9bcP5XyMjIzECBIFwBER6PMhE02qShoZEY51gKAgUjimiYE08JkHuuhOQwAPgmGwEveUJ5x8b9LsfW6eIqauhKZBEPgJW8oz7j436XYel08RU1diawAAGjJ2mQHKdsUQRCqIoCsAFQiASgSEo1PEB84EoQAADozqWg00JBKzybdpgCwE4+JAEjGay6k07MpAAJAVc9AAKCqRwVcoIQx3y9gAODTO90UABAonaYCSqSI6nSDKqrOJLcAANoCiHoBhdLpRgQ0VmnfFDIZvgPsA2SAP78ESHUKHJg8IlW2hqAAMfZgHSLsppOiRCjoCJ7YRRyTMBdN6b0FXVwCElQJE7uIYxLmoim9t6CLS0CCKuEKAICgQW0AIHkAY45hzEUCriIxAqB2AqCqagVAAQiDGEg08XgZQAJCYK7oFUCRqJ7VpE0osWjrdksAKkqguYEYwFsBUCWajgAlAICCZR9mc48CCDwIbd39tsWA0gBUoluq0DZl1ZdfKN+1CaDN0C7BABAcEJZRII5ssgvZbuZndLj4vBW2AgYUIAM4AiCRP8ykD1YNvtilPP4NlNKyJ2G7aHuNOC92KY9/A6W07EnYLtpeI84rAADiaYFA5TwQYEkWIxVCSBVARgGIqKkqgAkgEzg2iHfCWMcBAhUhJFhqUEGi23TaEhVIY4i7GyhIUhIRpANgMIMCECy29xcAZAxHRvS2PhP7KE01UW11Uik6jnbSqdKGVJuoQtJ3Hp+cW9KLmKtdTaqqTZRutcZu2Vd/l+yZneXo9PLawAAioCAKMcjQgH1mm70FkK4FRUxCALTYqgB56IZC6fMhEgDep7UCds/dCJ0/Sbe4M4s+rRWwe+5G6PxJusWdWbzAAgBAvAF4JXEzYIAVCbAqR0gBsalhMdQUAEAWCQLqYBUARUAgpYLUm6JYGKSU2iTd6lZbFAXArQdyLJqqqqbTBpUVa1FfA1S6qFYVefVqV1YC0ftOoiRdTbVJtbCH2kYoSS1TjQpNCN0d9nstLSFwc3WVEpGmLZ3m9BdHiauVPnbpC8R2gA2OzLsFEIYgHwQBABrKjl3hDEgp/JViSht+rGSECMDmHNUZAN53zdl+v+rMTw6hpyyjvmvO9vtVZ35yCD1lGV0hAYiaapHQcs6yzQCLuUC5kJirCqBWu+GIiGEBBBFjjaoaazRp03YFqDY+jIkKALAUNM1tIMNXrwTYHDNNkWgDWNSSGX0IFgIARVpKR6BoQg24Tmecj7qxlahSVVXdqo7uTXm/mPwtma6Bv3q341395ESXGro68RPVjgy+1ulVNjtjrgALgIBAUpwzO2AcZALUgACgkD1AEgXpwZoN5VkOOiKNc3NE072cAd43zfJuXTbkhChBA59E1DfN8m5dNuSEKEEDn0T0YHPA9LE5x1a24qlAiBQhRYpYLSiGxVBHFERAxG6aFruoYolTNJRkI+xIrE6q2xaBIioJveQ7qBkg7cMRYuvfwPQH6nCnQqZFUVI92jYI1BnH5uQqqUTQL6XRQ0mqmlJVsiqxHB+yU1IvG0BgQBDGPTFCHRd5whnAAwy5bKdAUm2qk7ZoKEAGcglUI1JhxkXeTsQAeA1AoAEet8woblgBFTmkavqLE3DcMqO4YQVU5JCq6S9OwA96AL0eg1eMK8lxFQixSDkWiRiC2g0cEIsaKIYpCmK12mymUKH06EZXq9o0baeFtiklR8svRIW7D9UpIERIShABKhpVNgDQWiPVlLZHoXBIEpuGiApBVLotIH8Yozfb8UBBrBJNpVUNXVVJGn1clw0CAYBIC8N3gYlHCGYMBC4EQKCh9CEYJNMUWHb9GZ6BXJJhCADetkTCFRvS9ArqVZOc25ZIuGJDml5BvWqS8xy2x+Asi6viKqRcSFUAQ1HEajgAKNGoIEg8gRyJKtBBt0m0HdJtupoSUpo2INz0Hc1UBi6dsN1ozfarQ3TSQ4YO5JsNoAiQqh49OwWitdu7X2Tg5nw03AUqYlcklL9AUbqKCmk7Lcpg4CqFyQDMxSdkm+2163V4qYfSCwAwAwo0hRQQCHUMLN4JLMFrUAKHCIASbiHVXQR+t9SudyvSO9RIhAjVELlbate7FekdaiRChGqInMGyrCwerCqERaookfhEFZiogyAmCCTFBbYhLpp4fIxDNYqmIz2aaquqjabpCVVtFaCC1/T7DIDuDQ1JYZmPyOgS9gROtxkHNob30u8FMLcmBKrvkfPeVKa63bZtq9utUlolTdNpGimJmD0jsl+fJZHT/fQ/+6ReE/t/1uP8T+d6XVsujp+0rRRpQIPR9dh3AggBNgoEARrBsC8RhQ0YlwEyAGrhAL62DHFP7qSpMdfFVIDlYm0Z4p7cSVNjroupAMvF3YZgYJbFlXOsJLeJAFa52AUMVTHsNhumaUMAxMZHY8MoKq1K27Nnt9ttq6o0DQqluiAutO3+lgsAJ6wKayzkB2keuBJiDiD620D07KaAapZgOxRzmBwTfw4CEAE4fichKf2HFgWMAJABo0CiRHW1O7QX0AeAHr5rG9JBW02jLYAvZBUAHNzfdij+WKiuABuaABiAtR+ZcGUIwQcettwIS4IAnT/ljvXgvMoattwIS4IAnT/ljvXgvMp6A2mSxZjzJsccySTMkSSTlKspppgWi4NiN8BUbCCIC8O4MBoTyJJCIAyiQRCfaGjDDV0qQPYqTataSlxCqAuiTSQED/h33umQJxtoDydcr/rNiQOAdEIlKJEA3XwOGgyZj3VL3C8uB2G1W+6w0SEABtKi+LsMApgNQKsiZHcoEo1ehTEBMtDAEXJI6YgqFSKoTmEXY7EAOIByNL9hagUCAr7W3MAlA1iIE/PR+Vi45gBrzQ1cMoCFODEfnY+Faw5wphhzXDFnOSKZhDGkCqFIIClMGCE+EiRIgAiD+IAgQpgYAMIgDLEd4DBImFBJTyGdHIquuVGFUGK66FZBCoKPLCqd5hAMWIlKqgdVVFFMcEfXwyNPQDyANMSOlKAssLfIuJXuG3BbdgCGQCAAdNIA8n8gBBwg68+mJ5zziwkQQIHWYgbA3SezFAAQBoU3H4DYoVPbBX7WHHTOEkQgdtSrd65FOfFZc9A5SxCB2FGv3rkW5cRnVUDCvOmU5SyLMOIcKaTIZndU00QRHMVBCYNIGAZxBFGiiUSD2DDEsWGoqOItBcFAzx0D87tsUY5mAJSWO0qdagE6Fc1/ECmGx9rFmrYcKB4QGAs8mo9Wg1AaBSAirAi5gAGkuSbeZRRHXxhoBQAYgDXw3sOna5ZYOeIBQOgw4IRwxL+PTs8oAA110kbjYQOSt10dG33oAmSA5jy7Gb62zBkvqMD7Rz6Rn73L77PXljnjBRV4/8gn8rN3+X32DYJJFmNWLKucSbIAQlaErAqCBbuD2rE7aAyBsR3GxAUKLBtFIkGsE0kYAVTII4egIh1W2v8x87fLDAqBOgh0rZary8OlGgQ/AqSoA7VRDwyuuqb3CQlunxbdNhAg9Vih6U9pA1dkB5CpAgCMQnYfc9D5Fqikk+sGmJu0tkYMmEy1Yw8JKgyGvqSSRFLVKXpVAg1/VgBetszqMsYOkSJ/6+w7U7bM6jLGDpEif+vsO3Mmm7IsizHLxZxDCOKyEAiDuCBwEEYjQRBasYkQAAgcr5ioE0ZiEsZAbEDUhijcIfoeFQSoDh+hSlcs4e9tobPltrHES/QWoAtLoLD0oLwMvleagzD0hMIPAXRdBotLboAPAKDnUwiqJqrDQnyyAeUs4MgmEYhrqW5EbtUIAPQRLfR10rWsgOFMPTNAJDjIzAidueymppWXTQCOAN61VHVJOoEc/OAZNHQtVV2STiAHP3gGDWezWMzKWS5mkqqqig9iQdEEKIgG8RHFK7RCJYwhNqJIFKJxOEJgiShI021aTdu0TaMFxGOHUV+oD78MeARXxz9Spa+v7KW+fnp2PBiHx+KXGwNGvkOShiuJ3sdTDhAahOFxw9PSvOynL4dh0QSABAMw9zKYmoOeOQJgrjA3O9NsARJAAWALkFLoqiIA0BbtgRaSIDgEqCNgAJ62LOtYbpqC88FW2iRtWdax3DQF54OttMndB0yynMVsAHMuFquqCAc7IqbdqjYsWAwHCgIljDMiJhCKj4slJipCIhClpyFeGlqoePfnQeChp+PD656kSxOvbIkn/xD8PiJXfwB0RXyP5VG5VIKmhQCOBOgGxISjEwaVbgRQfETaIYUuMmUTA7cpKK0LOw9qgTu7XpCQhaMA7rthCdwvhDoMcQSOZBx7CyCAkoOIDeChBPhCICoAnrbsfcqg4g4vB1lpmqQte58yqLjDy0FWmianiVlWzA4uxqqqSmJigygoGgYOndBxQaAAiE8UB8TGtpROKm316DQoLBEvslWtdysjKblo32nEARolTWktjFNOjwPWZ3Pt+JtShil3xUqAcEs3YGlVhGrSaZt0Kj1TTaIo0qjSIWzhsZYMeJ3pYiafmAQhFdJiPg66Zwf0AdqaLWEbwzMCbR8EwoS2ogHNgDKfdHE0mPcGAxjYzSTtSAGqNHSTANGMAR62FHGNLaY93LjuL41hSxHX2GLaw43r/tJ4s2DLsgZYrphVVRWJVRVDVe1YEQtBjCCWBFGikThHQ8VHghgHQcREw1isiqpEo1vCeiWEWrUklTDSF5axiRXcoliEn53QYIR9bPS+rzsETSlIx4p8qEPMt6+lJUTmQ/TgOA0cWs7NmFaY7Muz2Ay5X7BAX0R0dAiGVomLQKPAzvPdFLDhuOkaDFGiGOHMCWCEZDgjkDdhYxwMYW+KGKBgAN611HpJKsHDxGnTpGup9ZJUgoeJ06bJHDLD4KyyAY7lqqoi7ahpsWI6iIOqRYmJJSZMEISxMkQUih6lJW010nRT3aaN0ilNxQhKw1KTi+AmIgwCWgSt82P6uAJVOlW0RwSpr6RD/lfPS1uObiOlR1eilAvjKDrFCAn6hUBrTf9hbuG7HAgxrTVOY7mBCFpNos7khh7CTzts67guS4Oj7dbqcrotJ2yb7aJJa1EikHdxVxvEAmT4hECjNSEDPrYc+5gBxgLKNB1bjn3MAGMBZZqegbmyqpgrVlUThNFEw3iiYTRBFEwkUGwQxoVBXIwSKM6aptrqdKXtVHXaplR1NBqajq5nksBT4Ebez37ItOnr0QEjX4pd37E6Ph8UolbkEGMunL7aT9c6zjNOn0pp8qfrMO+R6oPRMVdod/QOQWIMafwF1tUUM2aOC0LUjmUjo2uXZ4SUDf54P5seidCw1VbXaNu8m6ssS3A4BQqfgBN2NgCYgAIettyXlA1M+4WgRI1I2HJfUjYw7ReCEjUiZ7BNzjmXi7FYVUUQjYuPcaIO4+0gjBANg0hMXDQ2YSQ2CKPq6KZH6bYEaHRTqYROtzEAotj7hCsSUE1VOq2E8IzWlH311r1IbcAink96I9PqapXure6zfo0kZCevfV9rP0wwMIqB+56jMcrRtAerSrXABPQV/CrWp2lHf9yuMe025hzuMggNKo+ZIHvBFTHqas3U2TE0rhHsAPoOcgwF+u5ZDxgMOwY+eAYyfrZcxlIYF3swgaZny2UshXGxBxNoegbmLMZNuVwuV1UokXjiY4kqEjiMi1EQhI7KChOEMZEwwKnQaUqbShcl1U1Fq1vRv/oUG/hi/mCtovWd/pqGkI555uslNRz9Wy6hP0nJmMYIIrzTQUGUMFxpQaZEhsDcEX9DKwTJQd68Ty+EDulOXwiGY0eNWQm6VaAam9QmtIYIdH8EzNEMQz5zZ66SNQ7I0YM4ZZgphNrgHCDNsV3DSeNiiwBetjzmmA1CAkJoWrY85pgNQgJCaHoGxyxmuVyMVVU1McSHkTA+IBKDBY4Jo9Go4qKRSCIRoCp6ppOmOgENuiVttVIR1XENYr7UyyIdpfet7B2KIvJ+yVAG0Yh0I3Wr4Y4mgrOiDVXCPfVFh7RjPcna2FhuWC+ALu2OBSrSDnfIw8QtK2t6T0HAVYeoEQWudesIvXwmK6sVvE4IvEF40NJNM71zyCaEgCGoKLR2ZAPUIRIF10wDw96QAR62HFsdBBtoCtQIw5Zjq4NgA02BGuFNgMNylmUxy1WuqqphiqMJolZRHDDiAkXsMBJRLPGRaCDiHBDFlixBoBCIj2AJhbOVc3U+yDbp1cC6fborA5cuCZSouB+ltQgBjHwiNIiCVOOvkHW1ocsCuPkSEVXogGiudjwuST9QgIWwyyHKTDR7RCU440W3B1NydWi1zGGUKQcIIeke7rxaFUOAXLMelUCgelHABA8/mhzXeZ4eRteI0IHO8WjA4AAKvrXc7gudeECxoTbcWm73hU48oNhQG57JJiblWMViroogCOAgNiY2YoUx8XHxMdEgFHIQCsKY+AQJ46IBDkwQjUQjoUy4Xx1RpO10mwqAeqkjUSwuAszMHC8pElQq1bSdblMp4H558V7+idKrqpLi+dIWoeplAV4Jcr+Uz3UKoC3e0/aLt6hLrcx6AWVY1LnSFrc8vUWghflfzasBIMV+eWkK98uLADDrfiEFgLwIzIfU7UEONAAO]],
              ["Neverlose"] = [[SUQzAwAAAAAARVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAYAAABPdGhlclRYWFgAAAAXAAAAU29mdHdhcmUATGF2ZjU4LjEyLjEwMP/7kMQAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAHwAAKxgAERERICAgKSkpMjIyOzs7O0JCQktLS1RUVFtbW1tjY2NqampycnJ7e3uCgoKCioqKk5OTmZmZoqKioqmpqbGxsbi4uMDAwMjIyMjPz8/X19fe3t7k5OTk7Ozs9PT0+/v7////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAAVICQDckEAAeAAACsYW4NiIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7wMQAAAZQAVu0AAADsrFsvzOAALJ7dqxq7WrcoEDiygIHKg/Lny7ygY84JDnKHPwfBAMfIQQDGXf/8mCDv+f6gQghyhzh9TJ0W/1SV1NVWIEgAEAAMhIIBAIdBoQFEDAYsQClDJRDoTRFbAlSBAB/YBCmqac88cXnSt3AowTtMJHpTssijO7QPEtYcC678dhtRmaqvW/y7oJVkUDkeMiaw7bz50TB2SRZ+JdAFi3vkvhvrn3aZmL/tfy3Hl0tYn4xGL1PbwyZmxfVHNvEzt6lbYPghpawb0QjO39P3du23OB7+4wwuRyhYFTmklFl/o49T22N526lj8OZUmLaVoGfqW26+FT3+fqHGDO1K+fm7nbONTF+JRSW/////b2xK4Bk1fff////fmWUMGSZ/Jui///2KgAGAAASLmixBMgzM8QHgSfApQGA0rxokKBQUKNAACAjBHrLuJjptpihUYIBJnSIKHglmbWKgPKKzODBkQqBQDAUOnO7bDwKBkQkpDhRdkDB0OAXAkoIdHFyTKkEpQg0EGBUIGHCqKEh4GUD0QaAoAAACLkJMluxABQYCwkOJFvRCILQgImUJRpgZcKMHjPlzMHkIzHADDHR0QYYWDjxmi6ERnERu45yQJE7VtHS7VDOLiBiaUiNIhImY8GaAMBhQYjNwcMvJELIxz80IwimGHIxsKAkTGXqWFsAEYDhIcFBJQhHFrjDLDHDzgqwcIGkhhSEcLBkLnjgPjTAC/YZEHlY8RGgAFJpfFgeRBk+C0+IcHBoWXK7UmtgEixACiiFDBVziTccCoJ2siEKk6LA1QTxZd/F2L9HgamohCDwZIQDAxgILDwuAFjKjjAXhfZrqrlchwNFRh4EEDwpiiQ6+kkEe2vK4m1byQAPARoGWsCoFtpov4u5hKl6wBbRBxfpcdRRA+UKHmBAprsgYioWYIMl8piv5BxnDJAqFDAbjwTI09y7bL3o//uwxNMANb3tUR2tAAJDJfB9hin4S8L0Knct/LF73Zuy5vc5Aw2CPBW4I0C3BZZ1ErgeMluRaEQnaHiuU8s/E3zXnZyyXUGEgCkljoWDOFQoun69oKccf39P/mut/EguHtXDd3Wfzdst62xX6Wpr7BUO8RhP7GEoqnHTlnGstjTyWh6OB515pER/T/R3c0hZoAacEAKmYdchgBDobMFyAUHCFZ10NNLAZue/8cDVi8/Wp3B5kWIEguJS4ZAnkhKLWJdqBiRAIBRZ9bC1mfXXdnYjC7lPVhdI1F/HYfF76ezI89R3PliK9mqXscf1H55nHKo2qKDJM9PNmQu2Yqf1CNmtBoYAhqe5uYqQutals7KNh9NEVE9IaRyIq6kw5yvV9v3DTGrBOkGWj7FPs7t+b6PLdlK0u7o+m3//6S/hVcrLtrdQUxAigkmCIBlqks2oAIKqxKIt8W1THSZWOhiz+syamsUcnh5LRcTGgw4PEkPwbWgUW3TdpLkLRxDB+Wnsao9nh9eLUIlztvnWpFRsqufv0kg0k+tk2CMDNLQ0SaMTRFFNaJ11JutZMl04o1WQELkoJ6KZGjBZ9S1+jZ9FaKWo2pNqWj1s6rLrVVbRr9Kk77M71qnDyp3/zq4dus2jhwAVUCMURAIBCS9S7mWDIhZou+z5E9RWfXU1qegNyV261nBBLU+hfcT+beVxGc5i1/L5SxbUSp7MeYLZzdkVsy6CkQ7LZDw6ZNNBq0UTVTaLz2+6gLiKy0UTAIfBaUijSJciJZUx0mlkiXjBydPGaywVkCiRji6D3UndlLNBHpotq2RUiyVTtYKPKrZpNXJSNk3/+4DE4gASIeF57DRZSngzbb2GRmDWsf/9/8/c2n60j+iS5Zaumhb2NWZZCaJu6kXYAAYACAk1AIamBRgWAVtXFjI3s4QOXI1dS2Wz1hscSpqk83hE7hjgDYk0kkWHi7NVOJdBbGNeshey5ZuQ4MiJgSVtZ//x12/jjdfYIC5FS0zAQMcSaek2OGs12bUitHLpgKRB50lj5qZkwAbiDbCsgigbmzMkbLLqJ4xLqBNKcul0ukBHSYhjw4Csal1VhrCHpKXSy7raU3ZSToo6KNz+Yom7pVUWUcO+LCaCsWKciuvFHfNY7/ly+LkdCbNf50yX36XnABHAAQDOZVOcSEjgyOLDvmSkLaWGEazLguSpqAhXLfR79fQMLCnNmYpjAYCQ8dRjs/UWrSbYxQMpiVes2UiG57///W8rPLjZUyq9aVpKGOCxitI6fHt62n61IFIohbYDblRZS1lYigGDWAtQIuaomjnW+k+oyTrorf/7gMT2gBWZl2PszHlDDKsqfY3RuZAPyE+LRVpFcCwJbeot+sjW/+tJWgo//Of1P/NfWWWZ93FtwAAgOJkKDg4KtwJkiElcMoQCKLrKU4aBOqmon+ZTjWjLDjNj4SPgAoh545kcZ5Cdy4iA7eCTzHH9fuTRlKUiAe6+kYpoGRAAUWlUvGgjoC4MYZPuftW32u7ukdQBMGBh1RBzyzYgoBJMCWkrGlFbpfW/kvZ0S6YGxTFtQ61D7J5SXrV9A9/+jonDV/6R7etM5Qe7LLBXpVSKldR/InB9Wr60uAABwAEIwUEISjEgFHhV4iAwoGAkDRkYm7jUOrEltE375Z0FdQwz2CDigs6A6Vlj+KLU+nxRsoslHCgC1ZPAs0VCp45f///3KOj3QkIjKWHpTUKjxHqnttWilpCttLa3LKBNCNQOsJDzFspFgdITngScmR42c2X+tDUdMvdUSsW1uspEDGB/KvyUNX/+vUmdNm7a//uAxOqAk4mJV+zqjeKJsWp9jdE82/U38/84kTlrigAAA4MBHKSvBwMBhUt87QOEF7pnBcASxSqUi6M1DrpZSmAhQBMZwTGAcUWDoh1Yj+KBN/x9AUOxTFkRQMSyCJM+5IEt7rv//61lGJ+dQzDpJv6SnX4AsFXkAU+eC1L69HamiWCZBqKA3pEkiqZID7AEqiE5cWkir/PeWv1jOjt0tEjRkUPqT9RSP//21lZv5eNtdqMmM3a0DJTlXQUpx/TS3EJne6K3AAHAAAkEQVDYZFo/F2BYKj8HClSUeLHES1oL/am8FerNw4sc60MBiyruNWpblJmLMWswEHL4vei5EVe2dr1CoDwsb///laUQLTRIRGTMHmsxqhISBpUM/ac6Btu3oVN+ZkWDCYGPTEBJg+iVgDC4UZjyk9v6EdUN/U0j8pMT8XfKgkai82lcYSyh3uq/p/pGNald603JZKbrVDLAAC0RYQPkl+2qKZb/+3DE9wCTfYdP7eKTIpwxaX26G6WAKkQhGQL7c1PVkcNNde9vZTKoJGWAiQGKwgYHBhODxYHrzfWGpavkwIFKXo6BRoEpgQEzR50XYP/ff/91JuXzUaEAONPBdERibWBkFmYRguuPuZDmXN2P/8ua7///9sVodMqB1WmXXvcJBARF51cOf/oD3VAf/PpsMBx31BPcImKQzJUroyhQrWMLkpdmS+adjK7UKrOQ5R9hN5oIhDYneZOoAAHAAAbJgiJAINFgkSDYsWRUnLRYGUVaCVg6rGG2k14am5RDaCAze2N2EhCsmIsyabXyIEVZLmeGCDc5sgBw4HCApkLU3yYXA/bX//9pHeeaJv6DRY4k/Tih2XIYgrkYpEIBjuClmvXm/7phxQU7k8XWNSHAmWBRkYs//UDWqJf4//uAxOeA022HSe1Q/Gq5seh5jhY9N+gsX8R+Iiqy9GVqoD8gPsn8+62fWguS+j5FshXGrLM7h5QAIC2EhRXyKJMEkwbBBiYSFANYrKmi4p7QhTuG2kzerNp/TCRkmyQoACcQHCjALcNzFowsCv7fUoE0us4cpIJtVK///45SCxWmiAFBKBQ00dYUYqM02MDX9zFuutX9Z0BtGtOBnwb0zf/Knnv8/r3dBvy8/xNufb9yZcZYWeFJKlLXt+ZvvtpZu+1rhZxkY+kWEpWqClrd9sgAAcACPYOCwSBQxbFDstIx4MLkSUKBiSO8phxdC6IIcNk2W6Z0QrhDSoVRHbvq+m1EYGs4goblm3RnTOYlQwiU5ai35D3ojmAbZmRAvnB8hMwVDg4UM797f8LlnukJEMV/09AP6CX/mup7q6jrfkfoWRzGfCxZ7qEjPNGGek1/RqpU/dEZjJ2WfdN89LPk5bXZgAoEFv5ogaBxcwH/+4DE7oCUfZ1D7dC8amS0aT25I5yEy1bqjwxgiO6XCMs+3inr8NRNqG7F+MljOGZBGPOfiYfL0gJB2oWiw7HkWBbUC061V/WUNEgQG1UHnWWQFiJIGA0mtM6rJIF1Sl/OiPXbj6G+/1JU3uK2VyU6rt2os6i0u/8Y/MbW94yPw12d37CEKBY3WvM15iPufcysZu3/zWjYbe2ZG0URAEuKu/mrUCHAQlvDAwHDYcFo/EoAKggcEq9buo+pShczpgTZWmsGjVms/rvDjCJSDiHKIaSDSAMDv/hsLAtvkBsraVKZdYu0/b35ZRrGqBpFpE0pmAuINXJZtXqTYt1o/iMleZEv6q063xzV8xSR8ze40MruyKYLE0VG6C3tZHh7aYU40d0c5kFYk1ZHO75iK50bOLGYabJ7o2iA5tuCqL3KkAKUeEqiAxvMWIJ9vWs9WBmzXqkNQdytZphA3B8yAD/nMaoICX7MwSBLlfBdTv/7cMT8ABIVi0vtUPjqZTLpvaoa7fy6pMRuUdx/U6Kx9AAtBzFqMQQBVzdtXqeabdaCIZDFQN7nTcYS7TCdRdZk8VsluTRcTetMzbsooE/Va0xl5KkU1231erNd07ILPsz40y5xwNlDRIiLKmic6KkgMcBOf8wAGUuAAHAyYaagYPpytiRojCtVpWGXyN/Goc7ekakRMQYibMTqjf8LhMgqXke5bawShgWjoLVJly79Rw1dIY0DBqRYUkTgJAjZZp1IPqenX6rh7JurRKaXWP5Z/8DU0lav51+EGBWg6tktUS+9IWfnuv9mq4D5KlmueA8lme+Fif0MsFPJzYJO7ShrRd/OUAFnpisArlQcUAKSBQoWIIoluGXryViIgLcXggtyGHau1H3EEA+AtLw6cwt45CJk/lNomvP/+3DE+QCSmZlN7dC5Kj2n6f2NUTzSStK9d1LL903916p00mBbAPSF3lQ+UwEhRUvqbqeh+mamAgIIez3HSMBlOtO3ih2NnJVz2M0UlQiyhQu9Ru69W5+9vnm+zUMKvtLvuRJwz/1dXRDLNqqazPq6ACGIkv3A4EYFINF6AUMUODBjAgsDL9KqItr7pliRprLl5XcnpIXxnyc+ZqW8N9WOitViwApuVFbBolQ1SXWr63NmTGsCFYQwxmYYwLaa3stfRN2TqX14pz+su+0SYXfg7s6jToxhQhEZIEE0SwkHBaY1q5FRsY8THdxUS9zKJii++PM/jaxhnu09HsPyXh5/HyAABwDXLTRggmIA4RpGflUDIQli5ZAAASBUXVA8igrxNddatZnntMBEgmLQqGVBLKJubfuylV7H//twxPiAkpVTT+3RGOo6qmm9qZ8dPnyqAwZKI1du7p7frUYFl1EFA6zB1Tc1PBYsOw8UF9VdZ+3YvpomhdE9DYS3OGb3jGVp9QFHViBXM5o9qxINEGpi7qp9pCFA+26tdHEgmhReTjTgTS3S7FQZhcEQwkGqFkeUpgABwAAASIDalk0iC5KoQ5S7DIKCU0rCN7BGHWds47HGBiAhhtpnSUMYHAJhcQjw4ghU0bkDRwASXbljNDB4oeGLMTd6khcCv1z/3zKAXklT6INmMmiED9hkHyswcP25yOG5ZqTZijiscUvx1ncsaVGL5xzmfyRmBjyiitjs8bKp+YUH6KyM7KZn0VjnjjV/jjTvy1c7fPXISpIIOaLih7//IEzwzOwABJECUuiBZJegQjPhEBE9cTpNguW2XKsZW//7cMT4gBI5Y0/tULcqayppPbmXHFpoMMyRpIjAYRjnwLxgwGIQ9GmGm8iVFUMGEkY4Ec4xwdSEfd9LEutWXx///7rZX+paUvsZ9GA5CcWTsYCxs5UdeXfJNrge46PSer6wyJneqg+zkr/4H1h+12xBd8FiDdVaFK/UNUwmvt9t79c/6VsP/rfElesdtd2/aR6wxPFHFRWMsfSiJcMARnu2qAABwCkVDCwEeVJQWBybCHAvgSgVAJEUeH4TgmobibDGU40dE6wcFQGHR4AjJHIh8Gv3QdsAEo6kviplwhMDaBPUW/lE93//fzErzp3ANjAGlkjvYGFEw7Y7v5v5H1VPFxRKpahKiw/nWpH8sKXPg1ClrnmxcVFjCCpe/jmpGK131/I1pTGDRbqR96zHtVDBbSo/77n9eK//+4DE9ACUvVU77HDxYpyzZ72Noi2lviuosbydvGQ6LFxVOAGOAmUYJVFsBwZGcRgQSFCgJ2FMkym5J4KHMTwgmWvN2rcZmDMR9D5fQ0mIgCNogJee1ExUrFaaJBy0SCsui1P+pV////+rNakYyQ73RiFPTCQGD7fNfdNHygS0PfRR7GJtAcVbIVXW4SfjkMZuhRWz01iJWYhu8SKoyktb8v+mWFftt9+z/S/rKF0yhVOCVQiJp6gAAcBRNNFmbFQBgwKbTHS9S60ZcllsFb9oS9nSbyBtZ0D0jvA2o+KnbNlCjsLBRm/dQGPPZmxrMaGXTemYv+Mk///9x2axpXaOjAiKkNqIAkaWYZf8mLESlU6dWz2QNFo5Mr9Td5ZxcgY9hOlQ9PStmUW7U15aRN2lcuPcu3R7KSLsi1v8bN/0a0Ek0FKb71LFZU4PeOWJ3JqiABwDElAVVTgGApgiIjAJGJtLIAgovOu9HxcY0P/7cMT5gBSVo0HuaRMiTiRofaGXhRTzgJcsXtUvWsiGAL73GOw/SbgNaeq8qLncydAFDEcYGiv0mf0P///81dyvzBqRyTFPYlZUCy3uf+++/Rk3nYxnyjQNs7geeOYZmMXnfUdBLxnk3Jg99ef2/1EXEVEQ1HlUae6Z/m//eBhk/tP/d/6rfePNunLl1Rpph3gAAcAEAIB0rzMsYIDEKKtAqCCxmNCQSRbYEqIpJH4YLAnN5w6Fx4GiKHjXbuYJYAQI3uPiIS14ASLGBGCgMuVu0At2r2s+///Xg2cysKPmRj248xXmAIGItvC/5pYF4QoWyMtyPAXOlcsKZKGeIkjgZaHFRpWYQKOZ4AR+wR4ZEo0IDZdRz4ojiDBRJ/T/EFmfz3/pEURPyKNkEMBICCASfv/vSHv7ymD/+3DE7wATMU1D7WUTIl8qKL2jD5URwHGpQhg6gUApql52Rlv070BqN6lrUU7WnoS4S3j/V8ZTVUaI1TYDiSXsqJ1296T0yuywSFBpYuFnSU/9DWWAF0RkusQXaloysdhK5LZlU9USjGMzitmkMyOoJmkVlSVZ2qYu2pK2NKZWUYilecRH0UowqPkysPpeYrpqhlWW7JZVZmuzdDjlWK3v7GAR4LrbhahyxQBfgBETsT2DijKFaW5afK9WkMwZXCZDV1hTJuEaTpnyc0OVv5hvTl8+SK8EakWNTLZSPz6LnFhOzXjgevzMUJQMiB1ygna09zxfZVC2YJDbYXD61ZKRhiYYpKn5oV5mDt9iJL6hFKdElY97xmhFuPRhpHaYVLSJYEWtmnAAHICJKBwxgBgpShzkMZwueXfS//uAxOgAFOGPO+zwbeIyNGk9qhbUrWqqm/zmsEquU0XGtSw0YE2AsWAgeeMFJMwQ4sO5Zg4Ap5QnuAiFRCAW8vfhNxOk6LLKqkkSOAAjEveFi65eqYm3aoTHvnTZGqGU3dyGfF9NQJRCxQ/Py/AglAiy+C2LMxyZyXgf1L6/Ac+2hgzGfr7Pszffr/kdKVhTqUo4mu2oAAHYccVHltlrg0WQVQSKHoPgwAmIhS7UfkLHIac53efjEhFaHpQwSBBuAKRvpHzJe/ONVGgaNTWYGx72bjmtHMlrUwC9zRVYjxdHO5v2ByN8UbFXJxCudkgViIdDKyAaeQZjZqEYwsQDNjASaUW4YXlZlCRv87ecIj2V0R/OBGU//tkfz1Wsr3uMeIA2iXdQABwAAARoosrQnl9jAQCZ6hIL5hgDLPOOo65SsKgrU7TXbNBHVHATHCUDGBQkHc4mAbW4Dd6UxgMEmMnTkBRiDhWmle29bTr/+2DE+gAQkWNP7Mh2olCnZ/26Dw0m7P/+NzkR1rUdMEFCH/+OFo62su/j3YZQdWhblpEC4PF9ilFYgagqZG37kJPBM1MS4qtuLm0UzIumVFMMXc46eO2GM7d26ecnPpCQTqucxyZdKACFlN0/3sSuSZzcujAhyLpJhbh2hYcIOIgEZhklUbllgFQKy0mHmCRWzC/1NxgR4CzA6ODlnLp4TIMtNP37ZH8D4SsaTRJ/6T6gQ6WshlXd3k5KzoxPZ2rhKLYZs97c4uvjYM136nq4zCr7Pe5vZ3f97ame8mo/zM3zr0bv+Qv/ydjFonJpoFD1rl871GAjaEqSXGKu7uCARwGylBL/+4DE5YAR8VtH7Ux4apkqJz3Bm5wp5pAxZkywklPg0KJB0qBgChsxtm6+IGXY5EzhWlcUEbANIDhk3gRtcnEgWtmpC3g+xMdQhbaxYhig1l+avpgOsb6hupT+818SejPRhtPSPct8gkzxLLV5b9830201l/dmK/FleanH2X8bX2bfb1ta9/7fWfGzek+ZjtLePj5ren7/flPL557vubyXAUEPbfYgDgAgBApInS7osAjxCWuQ7s0UeYcoAz7Nvk02gQy8eUpvykwEYE70AEx5Q6JBjDGTMHqVQ4jtvAIw0xIFXcnS2KMT8ufS3+/7/J6k/sZMRS5y/+SDVvdj/6nzsKk69u/ZmIGAemmziLXbHgzAVGZDaRxjS/VJ4+s4wvTKfe9FLbrfvHpjIZP2OqUs3Pg5h4jYYGcKsfxNSz1MV2yaL1EuO5tkstBUKffdC5yNW7/+22BBwHG3xaxroqaqUHDJJowhDIgKQQjQy//7cMT2gBFZS0vswNaqXLNofambDb6JcjB2mT9FP08qjLxldSbxoismm2LvNxxeSjOBjgpTH2njI0/RbSAdnkj+zU+bm0fUlhLzhoMRdXHIlnDpxjyXp/yH8IjNy/9GsIiad1alzpZnW7J/KntP6bHVMoC0yXWbGFmFOqiZmlARyGyUxZi4AiJBYyQjQ4GzsMCtuoG3Zg9Oke37PI1FqSpZjS8RuAQgzdoGXxtfkgtVFNrFdpAQCTry+85FvPFWtOcRVRABzz1DlaGYoyEOEXWhGcyh0VTCMjAgNgRrGOCMWpfsxQUDIjKd38yYs5Z+q+CER7hLR+YPw1AZvv/+9Xfu/eDMtLDU0JJvNvpQCHYukmIpIfA05fcmPR4RmARiHiXKNTpMeaY/cdbNCs+1IfbgV3RQryHgnEX/+3DE94AV4Z03rZkc4gIzKX2WjpzeS5fb0XQRAjKbl3Bnu9xj/Hl368Yk//bf//T5+Lw6UcYGfiJmWJEra8tYGnKsCPzpnjqUP4XHugQhMUnU6G2PKF8L/hqsFGCtNhTJbaX0IbITnXTXydSueyaYKeWbO5BNlRepmXoAEcBoAIWLIFJjMQCoKLkamBFQE8tAjwrcuCzLmcO8w/6+NOIDoPHWqHSoqeb7onU3ygqAmVRYMYCUHmmtYeF2JXM3ra0jidy4ArQ8H8WrbZkjrnWSMSsyJmyERizIUkXI0XTzYKZ9LOJspejrM2B9OVulShYffITqiZZXF5ZQq3Ku5Epg0vsf5mlL2pOUc+CcRV3UCBRFwIstyBygwwQoDJgMuGALTi5xcxvEmFrQQ57887ukgMcdA67OHceN//twxPGAEcknQ+1AeGpJM+l9l451MjCAXDLaldm3OhxJKOM2p6LyiOZ+1eozAWSfQyP3/bTV+6IYX3S3EdY9NMu4jmPu/VY21rVGcrb7X+3by2/znzK+62a/zDdxt0NT+lPePtme7ZmKPh2fja/KqpDMWYtCQrMqOam9ySBB4LU3StR+TJDQ8UmPNKaM/aslMwJJxMCH6KmrsSy+pHSV5FOofLajEqBoUtt/CaP5pIBSNqtf/U5Mskpaa0TNa1AfFcw/XBB2NCcDIw4t2pKbhg4tTMjRtzO9+l/zpaIUB8nUvt3h7nv02MrB+HlT3rHu5UqCFwORwn//Tv8pNd7t+YIwV3yYcAAchMAoWDHASyLuF5AwFaGW5UiMgCdbLp1mrywU7Llfjaf0KmAK01/HHBBQBvuqjW3cQ//7cMTzAJKFYz3tyHiqQCrofagbDZUnumYCBoVSl+pbP1bkGvQeoy3RBv48vltFWtTpMYzhOmJh1MlGCkHMVUNArgnI2nM+fSfIc7xie0clNH1vlpm64LoZw7sh6kTETERSYwcEA8NlKfLvLE7FGhBVBVicl0AByCQAgyqTJehLEiGvIZEkmMlXMIyuIsG2CK4PHhahFp1Eixsed45dCFgCGEyM+UoqCzubuCMKTLZ9D04/UOO7Zy1v9fdw/l0uLC+b5Gc/z/fTMbBPHPRVJ1rBRt4TZkcOMp5Evo07DPp75tkapsp641vD2FpBqEbocjpyfEnA3BIPlhGw4sjRdSuHHh27+/pBYmbpwAh0EiQwUVTEFiT1iIGvUeDCQ9tBoKpg3RAIpZKqR+X97hnAAjZm9CK3nowpfxv/+3DE8oARMaFJ7LR4YkqqZ/24DxQuHZx6vyR2JGAhqkIJi0YlL7w7Pzi6bIPRKQNckuolNT6NSB5IvpEMdJFHNudh6G3elKaL6pVNWI1b/RYp0ICExubnUal/fyTdCypQ//Jz9BgdkR9+k5O5auwvYbFVJXmrySAx2ZElANayloyfkCCQZbZXSFDLTCDelQeqhPhLXoJzwks0SPl0MDn0HVDDkd1gDmiZegegt1A7fPIaaf6zun8lLSQQ41nfw3/5/1cgSkLUG5iACGLNSZXC4A7jCRzlWz9g5jvPr5ex03XUMRnoHq4ek33s6xEc7dn/HBQ+bakzjUu/+ZFM9sjydebQGCLcxUGBDgJklFCW2LCX+R4XAhaNC3+SQlDCXvUyYbEnoitmXPq1oQHRso4psl5MMdha87Wm//twxPYAEqlbPexsbeJDK2f9qI8VUEdL14A4Ilay9rMcib4TdP+ihQWBRSHuXOtuQRtjunhiXzUiYjPT4YSayuatvr/y5T5/bxkdqd9VGM/no2U2X9/eX9Yz+pufGT9wt4LlRU3rUhpTYB7i6AAKkkoVermXMEHITIDForByZmCgZfVlBcOjXIYoElHcQkrXfdrcExSvYiMudQfOwCEbg4G5bENapmWSOkhtLdE53aWrKnSnOqd9JKy1ANY5oJt44EZzchKugyB4FeaI66GGxJkO7j2+RYo3MncZ86G86p+u7w/Mr+SXyUpc16dIHf6d6m35/mnziFPYzU3dyQEKyBJhnmCA8HJpX9JkVTpqCRK8CaJhUiV/ed9K+DoFhiJZW7MXGGg+WBD6KA4HYQm9ngQLEdgAQhb1Wv/7cMT1ABIVo0XsvHMiRCgn/aabDBEVaM4tlKazn7xX2qGO449Iv/+AxQ3EjExgmDOnuisACiISpmKFdKFS9aXxblTzO3OIqTNCWHx//U6cf2dvVzi1G1cE8sMkQ7SNfn0s8oc/TjMMeio4qsu6QFHstadH2PAMHfhoiG6M7Yku0BLes+YjTK6uNjYJ/a1CSKUjNG1Iz1yIFCxk7/8EQPFyg276+qUpSupcf2CsadbvC/x8wOIQcJQTMKMDGPYzIhUOESHVy41bBof+VIdkI28bBEUOGxb4XQM/qaXKmcDmS7lwcN5+3pDymlnl37+ZbFoSyEIGGiopyAB2UySiJ4pWPRizqGIkIYWkc4CbKOKM8VTnQya3EpR3mEdKrRXbwmcgWdNB53JYlrB40e0UoFlUGOFVem3pqQb/+3DE9gCR2Z8/7TR4ajY0Z/mXjmQydKwF8WOzHdfVlDamQUHsgqPgagyUGRzhLWYlwY0b82a3uIaq/58JzC00SQVDkF75p7SFwg1l3e9lP7/6fL5v3QvVtuoCaJiGMBHQJABBzhlxdxXIWIiEKW6YinAPAk906n8WGXRKttao6GgfEqTBqGtoZywBKCsDR90qKQV38BQZWNxopXiOclhVnU6a0HUdAdq9zitNkd9jI1mppB9GMOWRpFJiJc11LSQta5G4MEZgmhamrlp4HipU+SsGZV6r6BAX74fMPT/z3bHKa1T5h////f9CzVmXcAY9dqagsx3yRKoGNZluRkJfktw0NFtgrNFhKRsE9hZnqAsSKywWZ8O/K1mXu7fX9XFwMt7jW5Wq/juzaw/PvPrKoZb7yvj/f+2v//tgxPmAEUmhSew8cyInJOf9po8Nm4cxwa9xFo0GaCamTvYnDoYiI/T6d3KfXRWVjN4K0nVJ+VH/6vuXJZ8yfOT/DFnSXXtqd+ZjqZfqvqkEnJuJQEHjkKTFlHmLNL3CIlAzRNVVSkcctGDgl5tycx+XFYhfyxnipYVstwPp8CwWwAzVb2xAsaSZdybG7BkR0FcYi0vSuLW+pQgc1vjG8WxYghjdBKw4ZlfU0gCJcK+riFVdd082MzM6ja0grEZZGxj2twj7UfOosIIPfJmNrDHZlFAmNMIKjOX7n0XK4HsZS0wDM9XbIBDxpElEzlLpAIHHmVg4AoOWsW8osh2QCtxZopzB//twxOeAEgz3O+00eGomq2j9gw+NbUpTq9NP4WIBNCgcF3kS3TZBKK82qvjnOCwYWo6y3qS8E8mjerw97h7vTgSkeaR7fdbV0Q6IISiZgrD6b7AzucvvCNZDM0SzYvweOLGMhaINxnrOWQtWhGWksEeevqXUi0GNdNBRIfWu5ZZYlHiSEEgY59sFasp4QBHbcILEkkPCEq5FIVQKe5hgAhAF3y5ySrV1gGty1kkKm/xlRYZEypmJzihWtRcXHVScT9MC0C0l+NHL098K23zP60+NRBtzQ6d5EvjGgPgyqFcGQNTOAwwN0kCYw4sz2cw8PwblA7kY0s+OfuWSMkI5a5JWppz4STvKlzKZizMLm1nRCpSjwCNnYPuaJTxP/1NdTVu5AI+uzcouKLNEUYY8YIhfhoqgbRy46P/7cMTsgBJlR0HsvHMqVymnvaeO1OaGDyVWHw86DLKksuu2MgJxqKI7gEQSssrdUso2TRHP4CZyVfJ2uoshfhWLFzABVeLOX/r+UcbXsOPMdiujbEK5FGfsIuX6/HVi8LVdiY6Wjl5wqaWoqPpybgiJzf+H/pXkrKq7NAry4Ypux7uuurzFZphMt3C7uk7MqpcyBWTXTYvMkkwchWDmoIgEJOdALA6cqdLdlTQOCJFAU60WiSw2Uh+JLZ7lozl1p5o2ZW9a2rdSjVeLAKiSY1aqQYUFExS21LbZqJjUKalG/ikGOqsaCjCiQwpSwpS/CyKmjTZuPNJHEjuPmGxYvwr/ll/7v/f/3fiiJUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+3DE6gAStU8/7TxzIkkpaX2WDnVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tAxOgBz6DxRewwbWgDgCIAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=]],
              ["orthodox"] = [[T2dnUwACAAAAAAAAAAC/nLHRAAAAAMjipB8BHgF2b3JiaXMAAAAAAkSsAAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAAv5yx0QEAAABoJ8ugEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAANAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAGQB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAAQK4AAAAAAAC/nLHRAgAAADQ66mo9AQEBAQF6LTc2MjZDOED/Gf8C/wj/C/z/Cv8L8P8C8f8D/wDw5N/e29/Z1dzc2Nbg6N3h1dHf19jg2+X86wAKDg4ONpb876xfugI2MJb876xfugA2AIMIBtSIGlEAgCpACAAAAAAA+L/zJK8hM4E6VVX3PfnTWQMArP3/R/d7AOD9fr/f7/cMAAAZyAYARg8aivf7/X6DSwptV1UVAFWTCXDf7/f7/X6/30ArAGNbgZaBD8jAECyAoeDDNgB8yMnWVYccd725XoQpAAA01R7995vHzs7Be8c9XV7OqM5X0l6mQO3x076cbAeExvqQeCNScjvu4PvT2/ZxIwUqAIN3FjmcP7//3PucT5mikuvhYf1zq3vcQkBnMrr/O+PrA5sGzMQMZ2BEpu7K/B+AKFABuNob3Gv1yGmeZ9dP+fbB/RS534IiO8vr1tMY4V/f27stv6OnWUAB3MKobSAlps/Cgde6hQIRxlAArPn1lNa+3ctvPGPYOrHP/kdB1YDg4eeOtmlXUd7VAgLcRLvpOjWm9ax9ACJMFoCnhwGsbPRG2dzu5+7RV9yYfd9f0tfvi8xMpuGm7Oc9Lsv223JfCjjEQvseiZho3wunuVNfvhNxjNG2TCEAasd/3ml/nNl+LF4fvtz+neN+OTSnyvFevqZKWz8JJFvPokidTJ7hjU+dOnwqHEMOh3RJZvQRurXVcQiyKcgCwJ9WvTVXRrubajPa7TKeNtHcYvbjc1KSdixM+nhW9D9e/UxPXgMMx+TtppgW7Ld1/OD2/Ru5+xKShACEb64/96jlsX9f981z3+6L58u38fm/v8dt+pFBitY4Set3rJdoV5WqAqwC2geNcM9IE4EQvIvQYs4MNCCA9x8ACAAAE8HZBpj3TkcRNcLMXDGkchFAgE709djDrwSgCcSjPsRBAf/9P3ZrX/3Gea88Haupnop/Nd+hUg6L0I5oGz2tpHRb5qKoTMkrO6+8dueVHGypnvueYvm42GM99mLMSCdl6in8Eee3cRaN1/W479zPvPm/Fpk7R5FnetbPHWs/0lvnzJ9xU7yb0/U1h6rpmdoPfW7r2PM2fwUkdNO7stdyvoWPfOjD7nN7YHlpWZwuuvvu7OmBBI7NejJzoU2v7iYoIgjWAMcqCxAgFiPRKDIOkO1gXT5fTPHlXNEXNSYolmhjAI6DDgMeFIuzUguwNbl/xZeuw97dMWv9VwvABjICAF4pnfAZ2YoJYQ6Efyj09GdgMhZEyBo/DLI6i6vj4cVrcC64pQqWKDPKxDiVhJSYAgAAwAdy26YRxi22VT4XwS1vbZKvTejeZWNSqsSp5jQYRLitkar+XydbAjdnA2i4+oZCb0DVZsJ43XOFlFfV7iq6eTKdjUi/yug8V92V+61KDcz+dTeV5zqZ+OvstTf45AZ2w2Q+7Mmplx5eWjBENQycD8y17ckEOp8DxaFoNDCwm/Nxk1MzNLzeTVc+PXUbABl5ut0xpBNQliEC7Ho+MUhgsD8ABhAAwLqCEql7DGZQ6kvgLPLUBECrD6T0BiCdAJ+BsRIBAABAr7+NAMAyBoUUPhkd4SVaRQJrGJ+d0dFdQmuQZDPG55dOVE5w9fz82v05IF6lwI0WLIxslGxUrlVCoiIAAADwd+Vt9Jx7DhqPBqDOVS+l34lyyHG3bCZLxbgQWldymk8uRTX1eRKtZ9i9RimtgLJ6aqL041O4Xr5FrWp/OHPezOdx7KGO1H75HQ9UDgzFLp6WMo15n9v5ebkfc+7ftVGQxxQAeZH3l3Zlctjn1/ZGxu0MqFJcHXX1NMDpvICbL0SeB9s+txr3Xx5Zw8oYwWU1UalKimr6odMT2rBG8smOej1+5+jHbbutIcZuq6wSCiQ44A93BW2VHG0ZEckAAMwOgKNCBAAgCddTqZJKgZjwPQA+CZ3wHmIyUOB2vox2vY2JSSPI1oSKPwCABTieAg9qYEBmzyiTYA5VxSEJAAAASNCaOzHkIGkbE5AdUm8glsv4GfNibM1RyAUJWEiouZr7hGDCWdShFkcEq5z2VsK64ZhRLJGVTV2KAHa8FNVL17UuElRmLb2p+DT76wk4Nyhrmuc748uc49izld1g2sXbU920APrXHRdUcv8228V0v4Oajueru8h+Puzhfvj74L/TwPuSKL9IwTTDzKLW7oZd7SnWU4mvG4wgRLvCqZHlxRJgq8OOVcHIRLZACFsABgys56drslKExv2MKtCULTQL+BT9Gd0/gAGad+iIBkA7MggADF4wPAVA/ykAAN4IHdGepI0iyEiN/Yye8chAMyCD8b704J6XyDez/auAZUYQtL1HPaPkrKSqXAAAAIR8Ws83nm2vwZGE+KrTrmPjynze6T++9zhPT2/1XIMbiv29mGimy+ptj3ocj5/33iO5cmvlHLgSp+b0t1Vn4mzGz+MTq3L+8dUn1xPd/hqpmmRqWq5t56ftnzqzD4fj9ed+M55Jt3MYNjQwtWHoBTIBKGj4SjhVb8MA8+s5lIPByxwe6S7YEXFPFhSZhQRAiEw2xDue4JFXGyaeGhnHYo5d9Lq4Z7RWoxCeFQB/gxaYgaEAG4ZrEsJVEbiuxkD07wHhpoGWikAD5rRmAT4JbewSn42CDMa3TukSz9haClShcf0DAAAapvSO0zMzMzFhKMaiYAwAAADIhMWKzZnsX2iuHb9WYRem10STOa7Q7akwOfGtsOvW3qEMRkktbqxfGlF/voFRSs5NVp7qjN71Zt8vKhTPNPzvT3U2qhBoqMSMiJtiaBVzsqdaEdmnmqF7pruUFMz4yaKLWkVJ3rMpd2roY72TyxXtrENWVNbNdA5Z2XqyB7ofmJ4BdkFVNPXCV1bdPIy0feZbcX110zBDXmKRpRXqoV7bUTneq1iTxcaWQCGwmP0+Nc8eAAKQdAl6MLT+3WyYrDmFFPoClmorAB9iA3fME2mFJhYQAABA9A8MBQBSFQD+CJ3hkfCirchGGG9TOpsz2ppBEIzwvdG5t4J9efzK7IU3oWcvyaCSYsVYnRAAAABMraD7lHdluyJV6Xcfo7wsKxP12vVbyihZV5U3kLZZjLbblX3/cXl4++byoMYZpvP64tVtTHNRe0v+DCn7bZTFkM91o6u6Ey/ZnEzIuWvump8W9+/7vl//25M39PO2NqWB+Wzv6nnr9OyqTPg5ffYZn8c4w6nM1p78tjmepd7u5Nf7NRS9T17wt+Fkykc83CvnZGaKt4xtMH5XL2J8KMVVpagKV1Fqh5fHuPq/Nv+30CicwTNgducIe9qUguw3AOAN0OJuAKFlw1ceil5WAZoHuDjbIb+yAAMAAJ4JXfwlZhaDKCM2XqZ01GeoBgA+NEMcp7GvD6cvIHDh2ECPoqjQVFlVJJMgCAAAAP63bJOtzJ2v4adV6aBfXAf7tgr9ttfsYv7vWSe0A22XdrPeFourc67O0zy3MWfd65zrbmXPycl5stjNga5R3mTOszRVcFeUOWaU7NL1wql+x2T91n/q6ivHsutkR9e/z4Xernvhsbq5+606mTuhOGDPHG8fc/uUYfmw7LFN7ua3SHQDJSaN7ZS/ndMVKZMuf5hlZzJdVXFuZ9K31ZySdvqCeM0LxDOd8FxIoPr/PoNJwKN5fQNhXajCkSbtPCBOAV75nN0S0ycFGngzpXM6k7M0qOD9AwDYG7i70RvhRgM7MxsZYZnlKhEQAAAAoMAiVrnnxGt+/mvvnNlnd3xiDcZZaxDF4p7cjPuh5+D5fMTOk7P7Otca2wOVUyWXkskatwwtVbWEMgW2Nbfn9zGRMwrQfNzNqJksmFxObmBS2XdWH8h7AZhTmCtFQmL20DoRtQey6By/2bUFTL+/ctvGXhs3hzHfFSvDOWgAOJ5sfsqqbnpfu4eBHCB3gxB3WzWkz6Qwk7T8CnpZfYPaaR1Mtx4BEFqLbQDJpW90TkVVgBYHgpZrOMIWoDm+LwY42EIcAAAA0vI2AHhomgJYv1PC8Csqngk94p6MJUEGX6j07EcymgYZfF8MEbXSPhzbswB3seHCD7JHVCodiVkshrQZAgAAQKwzuxZvX2dnyBP1Po/PT1GLGsW9frZMRyGufY3qUQ8/rjWOSh5rT4/6y7WyyEXmaOBSaEHf/zY+2PeHs8/FfBDNV5DUvMA743yu6XPzjCBvWK/huHeFNYvcPztb25/7X6vZydGis3nWpmyH2Tp9NrBYKiEPQ0TRzbjJVZluqP4hLQAshuqa6l2NF5uO7g6riUVKBSVKCuQ5PdXXzAArtGr7DeAApwpgCQULBIRxMQtwLKVKgGVOC1COhQFAxBLYAJ4Jnd0Z0xs0Efw7pXs6krGACr4vOpM1wuVhnF4C3ErgLI3MzEhCIlSJUAAAAD68qH/oPuFWlGdSWB/11o2/W3xP1dq6vmqdLVrJA815oI2XTtFqFJFrubVckvRTHBR6Z4LiiIoSRerurlLO+DLPHoxTO072xWN3U/XFrUedkV3sJfttMDD965pW956npykoYKDd9WSSx8VLV53s3j1VjE8m2Xt4q6EbT5EAhN/2DDSougr8FAWUhl1uxUy6JLfpsba+pxw6NgBIkiJhJPmiw14/uD8xAvYFAABAJAAAG2z2A8Mb3xHYOkDwsAwAJTFdAgAAEGHLAtkGxZLC/kl/7TcPAB4JLega2oIB0CkdxRnaBCQI85v5YPYE/bD6viAgG5mZySxWRcKYAAAAgD9N2nZL4s9GT3xAx1OHN1oa+5EWxbfa1lZEy1ZxvsjjpMNtmY/rW3eMxYuLelQrHmau5hQF/TwdadbVyYHKGOMMsn++jqb/cKy4D50aiMn3n1tMkePqhDqHzswceIo6neScPaY+8XsOk1XFR8lmV83pyugzk7MPfT0P7f+bU1l9DjCvXycl4KV5QDmZm3tq3MetgdnFrx9tbB4AZ9QTyhqwWQCMzMgog2d/cjJDTwXRWLnmr1caALcAZL7oTax49BQWFhVg4EeBPgBJfS00OwO6BZIEAL6JZcrv5CLA9rVAJ1byn8m1wPED2gedyUNIqwjYxBlZGlEOPAyDEgEEwQgAAACheuhn4qPKHJo6F1PV4sRAzAWraZJMX4qmV05v6eFGUhA0GK0UaUiSYNCsO9eMbCPUnHNm91azyX0XzYBf5ZDbAZM7oYDqp3DFKGFmKnb0ea7es96mASOvQy1623H/upiGIRmRo9oBxVDZUHq4dzyG3VtGGi0P1F7iySmAU3EBdGfq6m1guxzseT9nPAVUVak7FkqCMV9UtaTqa4nmhabaSoRSwDBdoAEAAriwqgkA4Kf6H2gVYKkAbdGGOQ0AuG4EAN7Zxcr/BCFgd4el5KlXEv8MqqReqU/bjCNXfCEWhKhfJmgvvGDQfZTkY0IwIQAAAAAAAADavjGV+KyIpbaoG9lApdSnn13tSgZN5dmEOkqpPKXb1UnPZr3aLmd/dk/rRK7XcbSWodcKx5T1yrbGxqw9MJ8vNRRq2PNmMuvy8cXBNfmU5TnxLlcBAJk51ezM2+4D0IkZ1EQH2CGrW91uDov2S8a+1xzjZFwAptaTmQUgG/6/Tex9OpwIyKW4V9HkTQKALeh+q2vob4lSEQWJZf5aP/XXBAAAAIyPXt0rAADxy1/IAD7qlcT/js0Yi2lTJ0JKvQ79ik1GWDVPsrH8g4HagaJiAQB4hAAG7B71EmUzBBMiAAAAAAAAAPrEfieK0m8dBaAMAHNVY0W9paomPSwCkdidcs7eS6RA1SVdMnTsEm9bEYodAi0VqbqOSk4W6Mvktn5+cnCGBsz5vvLHQIIoc88yxQQnp2EaelY6da7d/TLsA/PjaZ39iio5JmFNB6cROt3KTPKmCB9fXh93G+4A0KmHz05AYP8DKhO1IGt34k//BvZjEJLtb2qpICkBqt194gC+ZACA3+kAAMD4xYsAAAHeyUXq/xUkg7RMjpR2JflfklSgu8mMRV+IPNdCccg+TyCn2gkeprcJC9aRsHP0KIdgQgAAAAAAAACArX3no5NaMx0BOPFu2YQWMpVlKuvO4o3zyfcUb5ZSCE2LJReDlEkBPMVLk6keIjeDoSB47gZ2Qmhg7rWeIM8ws9hGXt3HZvYagAXAgmQ/dQF+EyDZ29grb2figBeO27jNs3/sI1vd3+d3d2cvFr2SBSTjxEnB++Q1+TtAWkuDKaDfcUpdkBmXgDUlMJZdlSZ5FgCkKqlUfqs8ALcHAADe+713OxQeupXE/5VtYixyvyU1MtqVxP+awTKYyzZ+EPqCfjaJyjrmAJGmp4Cb6UvWkXAaIzMNIggKAAAAAAAAACDQ/+C19S7bRAH1Q/O/R9+Byl4qJsZ8LZovJpQCuHruowC9uGLE6MpLDYKURR4lQHR300PnXBqwVfqtJ2NDy4t0MB1K07HN3XMfZg7O0i4VFqsAdc/KvDpP5yEHVH+Yxp6vT3ufDV0zwdkfgPaS64buzmQSAPLluuZtAAR7P5UmAeqpOB90AlEJVFoCO7RkiUALKYJQlrUIAABU5cuXNAH+2WXk/2SwCvTHSGa0y4jvJE8w/YH6Be5PYXbk/QDCxHSCTwTUBcCAZQ4os2eU4QR5AZgQAAAAAAAAAGD7sj4jBEy3pVk049+JCYKkpCY/g41JxPvSjBs7boC4GkwA1a6HBzKZk887BeT0XkQMUQGgcwM3EElRSqoG5EASPQlMNzlaMuD2SlV1AKh5rslkZN1DKrX85mEY+vuOJ5/3qJr2HsDcSYe6o4iu6QY/zcmGcfSrwztkA4CgWDrK7D0gfZPJ2/6jSfbMLJaBArgTZCMEgFgl2wC8H14AAPs7RwsA/ukVxP9kTAJSt6WFUS5D/1dyQyhCv2XSiS+I52nyUM77EYzcZX3gnVCelzvAhQWDzpIZQCAoAAAAAAAAAIDj1R5ttDf3EyYed84UiKESTbB6OUZmJ+IzAItbjRK8lgrcUZVPrLCgLtxhDbzQ1DSprfZg9dTieSOPyxyvd7bH5b8r4fCmxhQX5XXvBqCaakfbWroBdQ1OCHq1AKiBhzPAzP1pPPL8Y95um2nQ0167d9KVdAFM3sSnAWogmwnUB2pIKlIIBizU9EQCktQ7cqn+Y+pQA+Txy9cHAP4JpsT/zigYxGVKrfLpZcT/Tq4MQndIWPIFuepjTe6TBUG07gDvSJyvjUxgtyV7lgwKAAAAAAAAAAAA72u4pzZ1nx8xWUk+p3JaUvB2sF63a41rRAIClO0hA+1qnVanAJBvIBKoUIIIODD7K48UzBZ12eX/DiVt1MUqyQJu9zMepmAF6F+iaRpm+W8N81C54wxCViU8kAAZz7enacDD+55M9biYfzvvMJsEKFSo5uHUalJFgb9UDALwT6L0GljIOSo1epVKUQAWGK8SACBZPDK+X1AFAJ4ZRuT/kkEZwey31AJKvQb/l0wKaG7gC6K/hquT44dbIMjbwE8AgL3QpWc0gggBAAAAAAAAAIBw/GhCT3L5a1cDn5wZ0kzeqyBQCgBRQWOM9Lm0YbkcXR0ZyyInr6OmUqsXaAD508TSRNOwToF56fYFStiUUaTl9sdlhpqwyMpRL8TfFmxe4p+b7KiBZtQwlWxfb/ztCtMUjwPst/FlA2fx1sHY81hQkPf7URdOKECKn5rsgWZIKOoMtSNO7V0r9aUkX837zoAs5unSRqWiCvCpIJVfjQEA0HVhVADeCcb0n81WhSWZjhQnSr0S/QnhoHmD9gE5WcE4rtkOD+KdmdyjJgJwRqyNRYlDGAMAAAAAAAAAAInp+ctX6fev14oGDZKfW1SVgsw5dOmOj/KSSFQgr8dX+h4IzERvkPP3vKUXeq5vFaAB/crQAZyB1AO0xtv/74fhMffD4nLb2+sSAArIWsfOvE6dUkpjag3Kth76/l6nzCGdUjrQ8/oFAGDWoChQwa3HP9vo9ZwzAJCko5yiq4CD/bJTmwN59pPj3PPpqQGgUqDQsk0TG0QFAQAAEFrQAShfHgEA3unF+P+0GxjF7LbUA6dbQf+v5M5IzrKlCh9gqkT7RfFcwoVfAAAGPEwCBEaWQiccCQAAAAAAAAAAwpGWRk247XbxFC0NUR506wJ4kHMAQNEX1wYm/TTk7AHI18eaZDR48ABwshOhQE4mWSp9GXRx61G2DpjVR5bO998GHt82xjiL4vTeNIAzizrvNS7/f5WTCaWhkheKjr/SA1zcT39Ps+rt2wkArxBAJef+qy+LHeAOPPUXrYHiVaMvAHK2neynBlACGYYCv7KNOQCA9Qu2a9ahBLAEtpcC/rkF5P8dlMHpt2klNMuI/yuogFlv4APMOKB83nXncA6vMzI156QAb9DvAChllMwYBwAAAAAAAAAAYMWevUIgRHdHqHf34lV8PlV8caPuJ739ll7zKTYAX5cmyPEgs/Y8PVdYPu/Hmw2g4Ud3NjBQioDY0voK6E8FTLt9/l4MEBVQdGPhhXPuZ5Y92SYxF579nExyDPebea4CQK+TM72r1J3PRRbDARjHUN+nzx6GZDOjO9M+XYkMLmY5DHYOkyMh9LMtvOgfRAAAgOyPCm1zyKuXAADsWr6ZRdz/K9IZ7H7KmYLRLIP/hXAw41vqWfoBajpOdvmywjiJZ709EgseJECgLYMxSiGZBAAAAAAAAAAAfDKh2Zx9v1wbUyg0uSQ2mECQaLi15WeLrQx0ZdBrznhWnV56zGY/AACl7AQ3AvpkAICTiQgKxJ7cVsetW4HHgg5AJhh+3ABqgKd7fXL58hrk64HUGTXH7eH93XHUUJmgefy4nWm4dLD9Xf/9jNf91mwbcxiP89/Jeb6Bvfcxnt8MoMnakM90nJ1Q5e0pIZViYzsCAIDo/vzjGyogAADyj/yz3gAA/qkF4P+K7UxMZn/mbNGS1q2R/0tEKLjjE/gDAIBE7VOAhzcHnE142ARMYPdB2UsTHhQAAAAAAAAAACAhI4o0eN6pEH+qJV56trwerd03DCcMVEWAQP78cHq8Nwmh5wEofLabKtAMQAYvQ58MZBQAtyuWf1opYrkf7Xzaj/bTSobSRRVhCN1zPwkoncvfgwBv5r49613uCygMVJ6B+X3ltSf7gD3bhsz33R0Y7rfBsv4sQIMpCwD308z7tP4135QbYMXNTFIomiQBikw49/2cQCnPFEXpqwLY8Lo+Dr4WyuLcQpYXXwoAAB7KlcT/lUwwJWhhT5lwA6tcL/53MhcUrT+s/AEAJGxuPye48jYA/XRFAua4CmgpNzWKiBYCAAAAAAAAAABEIEWZTT0yI2PyAMSLdTicDw72Gl1qgoIX3aZfsADwGXL1ddSQMwC4CMqFVJBZrvZI2UUOQHtySoVGnpSBYY8sfXMgxRgAsuu6d5zgTd5e8g2d+wQAQG6Z7PhEM0Fu4DMeL46UOd6bAR4OurK6m+XvA6ogB54dNZ0z/TP1iLb0xJXC0c+8u6CxkMLLR60WAC8hBpCt8F4FIMvIe18VAMQAPtqV4H9N5kxi2JogOO0a+DuyOY0W3yR49Qsc2zgWtXVPAVk7C3xlwf2f9xYAJs8CwIMEbIXNyBKNQ1YAAAAAAAAAAJBQGToptPxCJQGePtONAOy4MSfteU6VAgQG13TNXjIAlJzUA7IPAyBkwD7/iagL0ADoXurlm1Kg8lzHGduYVV+aEnu4/B1e2vaYxcYkwlPq+JkQCLeqMgHXRAnA8ML01Awe7xv/fdoAaPweBLQQw7l/JnfodMixb74Pr/vX2eecr+OpClK175HCLyUEAABYBnjkIwYAAOq5AJC2/uEB/ukV5P+OVSYw7HkApV4D/xlbQqA5xuEPACAAUyXwyGmAXsIc20IsextlSCAAAAAAAAAAAICAyEo4QCaG+/fuAZrbhNxfdSzxgioBqA/0R6miouIBBQg+3VkAALC2RcmYAnmWDs5z2IRAp8r4wKYtaoYUIBp/KkF9sEbDvRX8MFnlAgAAkzPT1z4/MqkCYA+G1/Pjo6BOZipm5lyxMGBudZg+vZcvpdPXJAEArCQ6czq7B/Q1NICGsyFrOmcxD+9sSQBgJEzoy0YY8wiiAJIEgG8b2fAE/vkV6J+xISSGg5TTr6b/jO1KSo57qQjzBwAAUK0AH4R+IQAm4ZzsdKORUFAAAAAAAAAAAAAJUUQpCvz07dmVCQJG+r+tTmWKeEAanRxF+hXqAYS2iMrJYCjJvOjKzZcC0IpxUIDLDgAw33vqLlIGmgAKJKsIUoVWlAQQKFVytdsAAMCbJe/ooWGgMu8u56B/f8JmJ8ibIkUQIME985d8frbLua9sADb7/P/uXvoDXISXpMevnz+VWtjefmXsULQHgBCrDSAjMLERAAAGCwBluQz++ZXgn8mCqdlOZy475hTs6b9JJWSaM4FfAIDEAbyJdFIbGcDZjCyZREEAAAAAAAAAAAABrMs0eEHM55tFgU5Dd/vOd0shUACKC3d3vRPE57/FW88EatE/hSLVg5ICAA/ZGQg6cwcA2oprMXmdAkwW5Mz+4B63gBPFXhh773n9obaWATrfvj++7GbeFed8f1PmfZglZk8/kL0CTU1U0MDckwWZLOH+/dOrPOw5gapSglnyzT0AlSr3x0DjfVZnounJE42KRnaIJEkLKQD5QgYAAAAg/gIA1PMLeS7Bv4oDvvnFaPNDmgpmepLgOAVH/BPTDShPVulPAIB3SM4rIHA2nUktAZgmBAAAAAAAAAAAREKUu0iKaD+jfSIdgKhIuM73AkofPfad6wMBA7n6a/7/kEzPAKndK1dXT9W1LAkAbUVcSClFSVqhAYpJcCwpAAAQitvKW4DZwvZ25ultv6NA19+vyeDrBRAJ5JzaDjMcDAAGBG9+nXeK5Cs/exoA+BNSCNh5N0n/nxc1mPWB/VFJu2QRvZ+9zQSgCFS9N6XqqAWAqOfHAAAAwkrKJ5YH3+vD/UASAAAe+hXEPyO6EDnO5DEKFuAn5g40w3fxtF8AAPgEX1CtCQBYZ5kANxq4gCSXjJKEYQUAAAAAAAAAACREqMnEAqqUm593zgokYzr/OdIpD3gIOziNIhEAgI+TAmhUoQD4jOZRXjeSgZxLRtP82YL0o8ecGKQDeNX3HWIAZs2g8Opx/r4nAeh0f033XIFPU4UAZlNyL33oac59AAD1nAKykKFLKt6BGR6HUEC+ADBdWXd0yyCGAZhdCUDe+7B/IHJY/1HZlsJYQh2aTxbPVQQAqJ4/6U2kKRU4KgB+6aXW5rGlBEa556HL51dw/0WWUJjpXnPlDwAAoJ/PhK/ErkkAiKkE8KABSJzMqPdKTgEAAAAAAAAAAAEh1tIGkE61vEzwwKDebJMbSlcUKDcnQUQtAGAc7noCk3asCALk00UH1QMFbI8rtKJRIWRfR/jQfwag5x4+Vh/ZGyq5AKKVzuHOizkpAKBhlkN8b8FUAszJk898Pef0LoDMng3kFUUBzaTofzPNMAtjP4YQjBrnnyh7Zz86RYKa/joNcCWRM++n3LwMWBYAKAqAvFhnA3FARW8lAQBg/cHGYLwEAJ7plcHfUAq4gdCu4/5GulFI5UbKF0EVDlmtWwMw6gh4uPpAO+BGCW2sRHTDQFAAAAAAAAAAAKCs9emIZ4jvRCuABHuFlgCMDWeVF78cRDQgAMUvtm8XFe/bAADVm98thSJuEArQgud6wQD70cSZX/NCsyk2AM3e5FcOebKhCgBo089eZy4UoENedO2c3u+zESDsxff79rD3Q2/QzP9ppg7lyV6IDk8D7Cd7Mf1igY6ea6OnOrOH+clM7X2+GK9TUQIEhPjwnk/m+gMAUNVWbzXfJMTVv1XVVlWqAJ7pFermwRVsxzBkciX/GdsCtPFjfGv/AAAAAA/awAac0/ZOUwmYwWkEBQAAAAAAAAAACAjZCCBKwDqVVM39frqwFBQpHkCvb+7XEUwVAEDFlO1zDzKkCpFqHW3sFQl7dFR6j9BEAEGvnVbYWgAA/3WVtQx5imTAGaZVrwwAlF5aa825drgqoDQ2GfKaib44rMb4nQHQxOn97HhqphSATLlz+p+e6hjWmxqKf7f26etpNmPs23Df0Lu/EpKvBoBq+tfvY/t7GID2XVwUSWpdvP11tP/8zQAwoFiRARkQ1NcKviaVJgD+2Y3cn1AKWnoad8RnVqN/Y8JA8wSlF+ibdh8A4BNlhBeHggR0BV6D56kNBpsyRyZvg4KCAgAAAAAAAEAnJbb8XA7MGQPDAwBZAOcNKZ3gUhsLQNHHttL5bVYhAIDv0wf1J3tsgChKmnORRByAgV0v/3CB3jNQKLl+w0iQ4W0zTW9jzM9XBqB2PO73s74uTb23DrN4YyrPuohZAGhqErou9ZQ9h+O+jfFovo9ffecm7rk9DjOppnrm5lxJD92dIibbKmrK1bC68866v8/X1BYoNBBM57S24fM4Pv2Ahy+q/q43CUD4/Opt+0ZSqTT/SP/x4etTAQEA1Nd/fi2+mZXc78gVoPhDTGeVws9wN7QQCL5IWUwgqqoB0Dof4CO05TlzAMWEhwtgYTNKJh1oVlIAAAAAAAAA5ChNLy3yqClagC6morWArx2eSaZtCTkU2RPCVUMouZa9Bw+UbH2960HjzUABtD4ekAIAnQZ5LsnFtepufbhiTntw2lu/oj4v6tunf1fegY19w2yRBcKm3IdBXd4Xfz4GVTynIDdUn5cByP4CyPu6qQMq7Wl48Mz9esi9swYr/jn1TjvT111dBgChp11THV9eJanSqCZVEQCp+meW4hbp8vVrVasAGMAAoOpL2gKEAQUAT2dnUwAEgD8BAAAAAAC/nLHRAwAAAMWd1wAr6ujc4Oni8Ofg6vXw8ffr7vT09P3r/P8C+ef89fnw9Pfu/wH1/xpGOTj/SX5ZxegnWS8yI/0TPDZssyrxR1IUoe8YNDYy7EtD7Fp4la0AmXnn/gaPeXtAx4Q5btiMzIxkOgkBAAAAAAAAAOEbIIXsdbolsUCij1caCpAE1zzNx3x2w5QG7QAgHd9kjE1vSFEAANtnkY/GAADrnUvLoJdayTQ60Nu4reqX404ffWGfSo351uM3+lYDeHv+Y9pzF3OTNeRkULvn7qtJBKcmy2vTWXsaM/Pb0Hm1XSwM3QMAAJUN+SbTOZ5Hf5jKAs6dXzfFRu+BYzUJArnQ5zz92ozfiUCEJcCAJH7P2zoyOE3sMgAvAACWAL5JZfBv5Aow0w8JJ12o1bCvpFVA+s/C0BcpRwX7JIoBQk4VC1w33gQoaxLAvkFAZyw7LkEBAAAAAAAAAACJwfzIIj2xvQDJLdrL2SiEaUe7NH4NPhl9XA+gcZ4m0poEQAEQ7ZflqZjPAK2//njPrXUiznDmNFZr1cbMuQDQezt69Gq5+aqV4REMt9k7xWwATU+0NJX49K6coZhmcYkC2l13Dd2TWY7Xe5/KNHU0rxu973vT0zVE1dTsyhWAvRNQt4fzdQK78/3lYrBtQxc6Dy3d0oGkWAAYS3mXVlVR1eYv0rSeq36mTQH+iTXgJ2YG4Ad0p9civ5L3BPwZw+AXxESJnevuBLTMSPAJGU6vZQCcBXMIbEbPhWrIDAAAAAAAAAAAgoj9PSinB+8oVSr5Dv0Fin3afYuN3a/gpSqA1OZGHyPNqRYA0QJzJzd4AArAiooVVlFcuktGDQBo6b96oOSpMsGemTpzURSA3+l9TvN8ptsE9jHr/dN+u4zJGIDJ7mevvz1AFEa6a+jKuz7NAfQBTDN0cgYA+KZMFFDM6YsDUNN93v0OcQ8iEFnau/ubYQUhZCRAq7xK4uMqV61GYgUGAAAAnrmV5O+kbnRZ8RSqVP7MGvQ7phy95C20SP0SUu0BL7R7BZDVewb4gppdDQAc34sAmOMPbDoLNR1BIQAAAAAAAACAY6sfB9j6WHiP5O5mCQ1Ao/F6ie89ew0AlDu2RBZfAATQ6vmFDgAPmGpE06AxANABSudt5d07DRdjM/c8ay9drS2qNv06nJg+0AAAHrSDoDKOO/Mm6swugJDzkJWnhzNN0dGW1VNjsvl09vfbIR2H5WANvOWmTEXvzLh7iiIWNJaFLLt+V08lrENqdTWphIBSqaA8p6qp1Nd8LwH49wHeuXXgd7Jp1Kx4Cw2hW0d8R7Qg9IovqD9I1GwcV9QfAABfI3l61UQAcFXbSoATY3Q6c2RQCAIAAAAAAADANnHtqDlLnP8GiBUQtIJ16vW7VwIAbLFLggGwHSAU8TfKqAkAoGi4uyOCYMsgIG9WD1v0YsCmEhi+3mgF8hgyQCs5WXuumGnesI3sq9fhzDm3AxlHjf3yGM7a3g2T+xrXfU8CK3Q3BmCa7F3z+VEAQ8Hcn5ei44e6CsDVmoIvX0l/7QSg6KZCgwRAylVBVUhp4q+/2qJKhWUDeLGF7cWhAQAEJfVXVJEkmAh/AL65leTmYTdQHARsZiX5O3I6geFNQlL9EqjbxnG17rQBai8g4IqOAP3uEsCNgNMLHSUmpwDGAAAAAAAAADi5+2FVDnuL0QAgvV8OKQPuRu2QD8emo33waCmocUgE/3RlADBWFLeQ1j0AgOL2dxYAkq0DdJZdS4ad3sFkF0qSTYtP+/bhcABnj57yAB0VkKMErP1/0xeJ8Yp9O77ac7M49nuz2g9ruaup8aEBhsarG9iDOrSbNG4CUAtM5W7DkLcEANB/l7bJBvwM/V0qTeqF56/LQmGnDi0B0isYhkT+/5pKAQDemdXgT0w5GOGLj1CsA39iy0GLbyHOfIHTCeRhtFuAuGct8BMA4GxGpzOJEoIBAAAAAAAAAH0m4fE6OpWCCqCmu/8lwANNAEXxuDbULNjmCgsUZAiU1LA9VyPNbUD1DkAOTzppe9yY3DIUgLD2PMQGBAClN1Z6K61jFhxHXP142hnVA/eO9a9ZgM24W4w9LF6YZzCPkjQ5zjUaaCeN6SA+76oL506+djMNPKTQzCB1g+95nqw5w0BdhxqYnC+yxgz9WpIEaEIjW3ptYYRByPxFYMnGeqjHF5JKQfzzsmNHoUIQmJh5DJCfPxOAJA++PgIeijXiM2YVouGfAqnWidXgM6yCDgR+gDj5IBR5EQDAR2Y4vDwGgDLhDdwWgJGDTiq3QhUAAAAAAAAAFXpof6WczDBEgGcAH9zQh+FYIQQA3PKJvbEtiDcBKMJOlTwavMeOADUlunQvt40NGKA/+vkjaQVwgYmeJwMq4xxnj9rnvd+UGHLYd1IzursYaKgctuG2vt/3r8WpOQ7uY+/X235s/+Jhapz6qtG482eT58rM1AAMeWfmABRkfZI+n4LeAKFaSeCM80HySbb0XG13lHIpc4H/1n8k6a2qRJRTgc9lAerd7wIsVgB+iZXcr7AcNH+gtIk16CvaAtXwIxHqF+TTTFDpxQIR7jkb4DokwPv7BMAZdEZ0xMMKBQUBAAAAAAAA3lf435uKHW+lwKduh1oiwWNsulqx2FHN7UIpmUBgGF4+SKAAIKz677ZlSrJDaVA6u0bcBIDAPlm8vryomHMDp+r22vPoRVX8358151ClKjRk73Z2sCxL2BtAXflLdt/q3cOaBoYqYB97sKinsdCqP+xUX1vvUzA5B8grr2ngoqhMW9Bx5lMivJabgj2eZcASYKx1gTIVpFJ5jgvJHmwhHqlfAfAAAH651dxPUjciO02hAxzf0qynP5HHwRBYGL35BdF6HeIQTwmI8/VK+CTyVfESgMcJNwsGnXRmNaigAAAVAAAAAABS8KNv0hmHopEho+GH0PAwq0Js00YJXgrAy0tr2ilZBQCwnJxlhRxXoEFxOaVpkAxwgHn/8/L2Mce8ZcJw+m8/3ntXaAUDPp7fihqGQ7WzKPH0ZD+9mSJnzMXc8XluQE3G9ulERyc3dPXsIqt/XcwpsqC5Ie/Jnvec082epCg1ANcFPA8DSJJNdKtBoU0TLLsORH743aq+iXhtUghAPbfLJZA0yyZQaZYCAL65jfxPzDJQ3CA5uvXwO7I7iVtCOPo/QE6/RMQqNwDAV+JYJwBg8q4IgL3ppDOJZlMoiFAFAAAAAIDo02WmvBCc8xNANIE4W/ZmuEtLsgJQ8lISRBWQADFRV/yDqBgHAMrAztwybGeAUQ/XL6uKSSUX2IhgemzTwcOxMWe7eOv/T+pEY8tru2tYLurTAphMapZw95wNOZj5nkmqduf03auI1SPaNXfv2anlAnp6fvsMkMB+6YHDuwvo5F7+NCSGzjupcgoACGSfqgrAshSuItBVSQqqqDopJyUlkncQZYF7gP3SxAdgg23wCwDAuEVFBWh+fPUAvrktyncoARxwj3Ir8RXTnQRP4Euyal4glCcBMD1zgK9I+hcpATAZAM6mO4OmiQwrFBSMARREAAAAAPYxa8+sLIn7UjIl1iRJFoA5ZsbpVgzVPYCv80+yTZoCACyW7VKnt9UNaA1W+/eXkYGJ1hswZvvz6QWmMRiw+L/f7sAQswN4nQByEobB7Vbrc3o3M9ssWvnCfPgFD7BH6fXB/mb2976PMwe2qhvmoKVusvPri52bIo8W9yXbz995fFXKCBAyhEnZNoBjW1gAJrYlW9ihTYQMAAAAIlxlUBrIrwKgAgD7HykAAMA/8wXQxh8BAAAA/qkt5O/IEEJvi5KwvlFuQj9hKaBIJvS+RKS6Dwh5GgD1axJMRO6aDeDs7HQm2xcAYIJgDCEAAACAcE5Tv0XCaj0ZASijbssNAB/moLtCUwqoDwuad57SDczIZAHQ/+hFTIqsIL0VsIG3+00AAEABNv0J045HJxqGOQajXm/vqhOgmb44dGfOMw1VBYW3u4yz+vaIvE0Y8kBOvePTlOpP2Nano/4wAFBZk9RUAmR1x2g2htr3payqhauhsiZBHyCHugUWQugAcbuM7GpVsShVKv8CLgAkSQAAEEoSbwYABBcGAOCVw7sMAMAG8uVLAIBSAF6Jpdyf+O5EtucC9XSb6Hf0OGg2xPYPAAAA8A7I2shE8iAAE1gHXVGyUIfNDhAEYAIAAAAAAOZARAKUCYRIJu57C5U3CtCc9ggZqQAA6DnqEAAgAIEx36PsKWBH7vrCuG8AL9fKFS9cDhAVxG2aWsgotIFM3B/dreHWe87UNAMMwBOHDOS1LTFAG3X5cic1uY0B9NU906rOrLT7vr9Sz9Mz5AyTF5tJ8u/0ayt7uJ09bveZ/kTyndX0R382pu1Zj/VHzbn3lPF1DPPXeb1JVRJRl7wX72XUV76IVpRihNYnM5JElaT+n7IlHBkDwCyw6zaAw1eMAAC+iXXgV+R0BtMXBKPaiL/CDFD8gOgPAACQM0nwaP4ENuAsdEZZhoQwFkAAAAAAAMAqQWT2LD705mqIFIF681kOr5ZCCYrp4vFBHPU7h1IKfQBsVRxpYZxohpr6ZTeAIU+XqiwAAAB5xx+sekEGjAB6Y/CkoY+2BpMzCT0/7zPxv6F3hHh0RasZpqhde6i4U30pXU1WQ00VG+d6dpEFALuKfjr4pr50kKp2jnZlM+m6msyiZ0igfp8Z76H6fOfXFNewz89PbRVxoUp9UCIKgFSSr1U090H159Qbct0gLwAAEOADAECTFw00AW4A/omN8jPsgc7wB5xqq/iJWE4ixa8Roi/Ir9Sgy7qRQNzpAa6KmwDxVQBudmANHCCTmknwoAhQBQAAAAAAQGh+GLIh610tAkIfh3H5ALobf+2p/HC0RZylB2RsDjm/FDJ4QINl4QWggMcDgM/u0srE+5wBnHpSYt0AMKtuFzNn4+zZsRJqyYHzxW2q6AEm94c2r/MgMf+hMmvTFdHP1xl/jrPf3KYM9zp91xrNumd4gc23ysyE37CLa5rOnbsnL/qlzQHObgZkwFrXtxveApkQkJGr78RG2eP6USlV9fCVIg0AHmwAAAAIHR9+pgEYAv6JTeYj+Uww0tswlGqT+46cQaR5CwBfEK9mRp9XiwmAX2ckeNgW8IKbLWHTPXPhYahgAAAAAAAAWP7TrtLgbndlIZBLuZyoeGVnsmLFvr6ZWouLErzP+ieb48jVGv0CUNJezcxkxqoA5D4Qf12UAgAANJIv64OeSh3MWTWbnHN1Dvc2RgcmS40SSCpzb+rczm2/7p/3Xdu4UfeVZ2Zo9u8DA7xsYPgDJ+vmJJMzk90wU99npmrPUGD30MBcmRNThgwH0832zqLh4xtAskUQqIjc6xHbWgQYJABHWwFCy4rBFoahOwLz9J3rAOx0sVpVAAAoHxW+edXid9JxanB7izXAqLayj5gZgPe8wBfkh7sAurgAgPtTCb7geO4AAM9fZgI83AmQ6JmMjHAgWJKEIQAAAAAAgBzWuA3G/5X2Mh7otQdt4vGhGZtpU03OWDyQw9CGZycEASDSv8XqQBe6AEDItamTVAHIxLbr9X/37h4DAIqz1CdRNs1xZg5Z0exd7wwAnZUUG833r+wSL61U9u4uNETC9WQ6Yb7hNd9/qsfhYI6qpqez8qqBT1Oc6a2/mU43mRuo/MozJ5vcJAVZnawuIeadDqDrznMCqFJlQAbMLUEAGQpAlQBAHAB8bVO+AIC3S/0EfRoQ3omt9CPbGQR4C4ZSbWGfsbuDaUB4XxCtC2EU1VqAs3aAD0G/9xgAWgk3m7CzLJnMwTIJRpIACAAAAECIftxVNuf1dlOg6GloOZGDfOPuIDmOeyoCkP2L9nEOIgQFQN2lSaSAVt4D0DjlOwUAdWegNzR+YkpgQG2xx15tgBRwi+Jmrt3P2wAUA5tMmj8UPeB+1Ndx5iw/p7fcy2ErP0yNfZjQ6ZnO2p1w6kTVfSqz3PPfb91Z898cqjeefRgOh6HLn9k3wN0YQAKeLlsKwyLLIMnCIIOxI8Dv0oG0uGN0rwQAHgMAAAitHgBB+VeIxy8FAPj3Ad55Tfgj6XEGxTGEL1U7sq/IZQyKMcHvC3b1XhjlhQVA/ecEVy4Auw4ANyrIKNtMArNIggAgBAAAAMCrHQb1DdX26UCWGOPgbKGKWRx9ccEuoriKgDcaSkBAAALN8eMPA6gYAgD4ifcPDACnAJLA7y8TZiDHkI9PT4r74co8fm1y7+/XWeNIPQXXPhuWTcOQ8Uxlz9n++czb/ZPxucrZv+Yo1dlv9dbL/sup79fJeEpnf8rzbMitzjSjPt9O56F3VSVkb79A3VTaCIGItdO8IAMiENj0cyiSutr7rLxN4F/rFaLWsG3+AQOfksMIAAAZYJUC2ACAeAwAAIAvbAD+eXXwK/omaP6WNZRmZ/xI6kmB9xp8QdQ/wVg5UwFwj0OAD8muzQTwScAp2aMoksskLBwCAAAAAIAgpi+P8kqvZwQgYWRoGiAunzPPmKZUAN9m+Xnhh0CtAADJkYn9n4ncpySUDOTcdzvdswCihGIY1t0k9jSGSX/1sl/TSRVOyrxl53hH5AUUWTUS9bT/X+oouphdAdUNLyAqd2/63d3Dk++V+WI2QHPydhXkzBSe62Gnd80pDMl5B+xQ4ANhpv47Un9jJkL6m/7TcHsx1UY1LXS8CuoAQPxxe2Hh0VcLDA1o5P4rNwYAADQB3olN8CvDdALMKSy+0WzFn8mPEWiKsFjUF1Ldg7mxKrO1APUT+BKcTc8mAI61AeBmwM7MpPIaksDCDCAAAAAAfDB6lE3VmL9oQTDPzQkhoLBoWjsoABDsbEm9+ioASNkdmRXwIRQACr7/NNigdTVDAZPy4xOZfWCYnLFvz9ZM5ZVFMRuYhRuok0NVnXP1RL3Ey/7TNA1qOuc8uUnuQtSMgusqnHfVgflqTtt7ZzLx1FXEv2JXFZpRjevJ4jB9a2XswnRJgZswuQ8QLfYCkHxNSY1usIW02gYgMcIvD+SpWhUoAeyLlwwAALYuAHn8VD8VyGcAAFAQh5JtgFoAXon1xEfScjA8EbhDsxV+JO9OYMqaxhjNPwCABExHgCt7EuBl+wjgZsAFvJSMoggzV0k0BDAEAAAAgDlgzYWol+R/W16BYqoj17efSFYIANLDG8iK9wQAqkWTKLmQWyghAzn4qLdc8yWAJO6c++hETO8Pj05BAspSwhSQae5vhznl5/fLPO4ib4qE7omv6p1jzmM75iPdLUWvD0rIPeADcRsSKnqfacqTk+zpSWdn7OlLP9JclRfMUKOa1T8mmT2PKAdmrWsnAOt/XCm8KMkNpEMNA4huELYvYQmDVL7Wg0qBpq3GBhwAZQrIm58B8Boo/1BKBElI1a+8BgMwz8qoAgD+ia34HTmDxPRjCEazE37FRpBIvsAXqNvGiJOJc0CoaQO/AACcmXDWwRLrmQwxVuEACAAAAIDPNpZKoI1cXQpyTsmOigcBCgAZHS+yaE00IgOQM3iEWu2FDIhqLFCcfaIYk3NsHAAY7COu5UZJFdx6g5L/6HbSHQAS3Zn41iTqzmQnG/V0vSXX3kuZAXpv9H30b49Xn+ZWt9tQXDtPDzPM9FNQwLuJ9/SZzggK2Bt60HRVck0xOUlnZ1dm8S/YzR/Uf2rS6XC2xGpVxMnJuZrgSg6LC7RU9wVhcP3aQPwRhff6mAWQggZ0gRhBFEZ//6YMWIABmp3EagHeeW3gHdMdFM+ZFohGs42+ErOwiL5zkSr0CwAAp/BJweGuBKCXcLMBSyY1qVzlIgBgDAAAAAARwDxrATJRsH8ZvngNL39dMzoxAwAU/ns3VRoCIADobd9LIGfI4OAqqu/btsMNTU12baADDLz+7bWBLlwAcs/X5UUDSEgMHRYLADt3iv0keSL4TxfjyqQTqr4ypUL819/5qvdP9bUbuDhO/6Wpqv6woD4BIPe+9J/qrIQqBEDmr/hFKXtg9/+eIBMJGNpxyHLQnqL7zVdJ2nsMiB8CA/rnQetTCOyuQFsFWRgEAHHVyRv+ae30kbEXKL5zaAGh2BE/kyIJBN+ZmD8AgATM3gE+EvceT7YAPAY3W8JC98ysVYsEAgAAAAAAMoEyDQGq1WsagNBiarG/8j4RAQ+p45s9exAXAgr52RskA+oBsJ3AwZlIduebL7CX3ABX23ImQ1m0iRlo60/uBnKyKWAZTtW3rd61f/64r9OFqeY/Z+d8u89p3vbzzd7ljMPo3jQzjkY99Mk8gPb8rrf2vZPBdMHsAaCfnafZTLVZ0xhNZerlqz9T02RBlKZmhtiXcGAIKap04Bz5v0hAKhUYzZoAVX6E6YnV5gCvSAAENkhU21tVAbQKXG4fAAAAIFgCBwDeaa30mWEVkeFnCoZR7MheGZqDIs3BGO8L8lBHGHHy4hTg5DbwCwBAl4B1NmBkJiOtWK4GEQAAAAB4D9Jd7cS5HaNeyTmvpiuqBxArAAAvmDe74oECAFz18eQgqmSDQeQljjk2ViQQNkADpXwLcFzHNo2z7l28KTL3bWCM+8Jfs2EOiYDlTla/w2RuVicD7sPR4QOZLy1SCexK3rzSrIIipzhMk9zzdnX2nMlKVf3JGm63Y/9yP8e4j9v0r2Lmmr45J2Plo68F2TKG4cE/xOBYz6EFlFjGhBj+B6sAUQCO8UC/AWhJyVb462tTADAKAEe4DQAAAJ5prfTRjLOIAf+XCoxiJ/FK6kGA9xr8AQAE4P6dOfiOjawXADgfCbDXwQvdM0quPORCCAAAAACAhDDXA0DI93VUPIx7vjOD6V5JAJBbGIzgQdUbWhS8L5PZCVkLyBDDrIAUhYOnZU8vIufiVtWVnJVbDTAN5/pe7MnEB0igknnwg0lI5Txu84czc0hqTqn7+bg1n85NPSbFlTvbd+5WzVTxfGo49J4T3NSpGiArs7JmKre0k+3zPo69GE6/HjtZOb2nXDU3nPp1FzJIxsrItFWATqy+9dLj0I/0ZZXNkcD3F5EVcBQKA4ClThw73gbo+in81QK4DCxWAL5prfo+XaxC0/wh4BS7uGeGnkR4z+ALsl2D1SqqZwDPE8DDtoEW2JvaMyNVMqgBEAAAAADw0evVVxmcw+Vqx1M5VQyEHLCcV6YmzDk29AgIAbLcuH8kBQwFgEZ5SleHECZY/e08HJihoPQCyf/jkVPDHoMztrff85DDDn/EEXrQ3naefx3X5wx+uhlvZ9wHcNT5a6IZeCbJLF/JnswGyILOTcxV80Wz1VSV8+4usjdnx1VZZJKVm+uG39epqWORpgwgO981F5GavNY2zefTfSveczXucDlXgQwNllTqI6iqiqoS+FmAtP8LAEBlmQJAFR5qnfQj2UxQTAOMPcUu/pFsOgEmRP8NTFUR13m++O4Wa0arA8DJ2wBwetKZmWI5kkkcAQAAAKBljNt9LzdobnM1OaotGA+hgPRs8yFnIFBhRn0w5z8eLujKzsrQ1n/WVErZrrEG1KmvX0nSAfJo3Ezz9dvKhElVDVNR7CWmumC+yA0mk8KcZjNfnAbnbOGZpv+Sw6c/Ky4VeU2fr4OHpDe9C749DQA4zj2wafYXQ8POhipgN3UPNeyi6utssnTtns/GYIdGwmBhh14AQICE/pLUzrs1/OhD1foDDb2IzkybC8AuhCpAVgDw/c8HVAAAIG4HAA4+ap3iPdmdaIotIYz9xE76Po3NAU8I3geoPSBa5b0HOIjPykiT9QWAHojNMqNM5qZCaCCOAAAAAIhY/YaWh3Wtk4aCqPrRXveLKNjUo3lDfMF7cgHQ3rg+CxUThQwwObfFLCRMZJiCG1xDAxhnwOTyeNoaZWvMd83WrlSZJxmmphk9M099cSArtTuzyZng6UMd78+hRp8Z5GFms2sfgKk8N9H+r/j16r1psjIrX5J372fOuUsJuDtTlad3VvqtN3MomnNsv4BFDxjFgFYCBASgFKjQJr0ifZCd5z4R9QjdFclHAMpbEQBI/dUGpXyjAHvUBwAuGwBo/mnt7hE7E0wD/E+xq3skLwfJAd8HuMBG63IVRzgD3zgk6gsAOAXg9MyMIg3mqkEkIQAAAKDHrDWk4G0zprv4nNZiPG/z4CEN5X3lpIoqGgAJwcbQEfBkMBrhSqEpLQM0gPvsFhYwxbzBNH97jiklmiFzAkVMU3t3us1A/SeLfQ+HLY66f/VW1qb7Ajh5V/b84JmeAms3pxi4BmrgGdiTBbC/hkFXDbsEHzXye1kgB8iEJxOyqm2cvPCxeov1pYUfl5GfcR/CwCABjk0qQJD7AA23XYAPeIObB38uAOSOD1EFaIKsBwAAAGj1EQAACt5p7eaRtBcRtiA8jGJn84itBNM2wsMXUr0D1zu+mgDlu8And4TKhC0BHwJuNLBkySgKlWPODCkMAQAAQJxG/m9C4470IJWX1DhEi0LYjNGJun0MFQHwzu835+yrkEVzgZ7kExeB2UAHCPJUKRwsAOSGXYD8Y5szWEWfgVtLtwGqF9x55mJ6T2dOFbfPUXKqzqV8gan+A+f7uI/7/fPj/nnz3TTlPgM8SlVVcUEDwDRQF8Ocf1H0doLpWCszW6by3FmgO9QsIWOLBSGQQaFI6wQDQ4l+U3dSvnIuU/SlggNhflO4AAITFzd8cbSB3rcWAQAAUMQCqCHOhw+UE5+rLQa+ae3mnrwn0Aq4R7G7vIYI4ooC3i9wzwqux7H9BMjiO+AdA1NGAnaPStKJxUi5hgIAAAAtY7c7BbmdPimhtNpyAj+v4I6qIVdfqMxCU9B/O6Kd5FQfLDkXoJXg00CtlFQGWPDXr30ws+jNZNz4n/vcdk6mk2FloZZrU+kmETTQ1bZx/GUxJDcl0Fuc3G6Tx7v7rF/fXzdJ7g+mN6c6yaoaTeWV5Wmb7yyKW1BPMjCXs+rAVCdTQRVAWYmkN5AN09cg0OjfPh6BneNZ9XOdJF1WYGhufl/OClShxwOq4A4NvE8BxmhKFRL6CgCsAgAIo2lPBdpiBZZYpfFdXpxknYaC5ovERnovxxZgaOD/BwCAfFg5//7PeyWeMX3gc6DtJaMoCpvKDQOKIAABAGJtDT3z7YwlznHc6nfY4VTVfxj2vdNkE9WAaiBHD8epuKXkMCH3b1AGEt+1eOaLrvLGCetz35xxzt0/Pj2cUwxAd+6Pb5oaLBZlPDBP+Rj9vR2KoZJmK6YoTn1lrsPWkMacbm5q3s48Xw+Vwzbl+Q0Tz+zpXLv4RjKzycO51FVnDsvpsva6c71FbyZJiAff3lrSwfGUM5l0d8+blXvsQLoiAmwJkLC815YJKiR6q6qIuSoq+gXPXWqB7AHQqqZCB+btORRfnQIAyJEFSgAAQAeFgud4EBIFgoSWIqqw2/j4PxsAPNU2v3BtlJ2z9O/GPVc0IiZxQQBMiuf7bOtxPf336cft4R/35/3X5+9fx9seb5+fWHJo/0OlCbx4cSVTUPUzORmLvOYFADTNpDD8RBND6ramD0JmFKKUAqBzfc/W+zjLpq/C2CgIhL0aKUoc2tzZJ3f2+s4+65b363gh7zMUANw+XwKuxpynaINTcS/mvSlSxAwhAHJODNn73TZlPDf/+r2yg1BmsSbKf/105NGf06ep8nfMh1cD+pV89uIXiDTCFdijWJgv5LgdP9uj7I+AwNlqxYMH7Q+PPu+8887r9b777lHFkRkN6gixnOCqGEEKABSppu8ffi43hptcJyKL4/zRWz/f/OyxyyvX1293329zLJre5coVK1esXNHtdDvd1av3y/pt3+bDot8GYWQVjNZlXdbFMnD22efztc+urKx99tnn//ufffbZJ88+n69v3799//Z9nw2wzz77AB/ff9+xGQ4ql9e39WV9WX+8X61erV417bpSYaZS+3AAiAZBEARBYBlzPD58/vTnj+///fvrf79+/vr59nr27X67AwBZWbRlxVFlv8is+2X+VzMzdf3y8vLy8uLVo1dVlQ0AL7Isy3qfV7bqpV5VVYuV/eK1RQXaorbFCtjK8+WlLS4uLi7aBIDlYj0vX77UqxYVni8vLy8vLy8pAJaLi4uLAA==]],
              ["OSU"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAACgAAFc8AKSkpKSkpKSkpUlJSUlJSUlJSUnZ2dnZ2dnZ2dnaQkJCQkJCQkJCQqqqqqqqqqqqqqsTExMTExMTExMTe3t7e3t7e3t7e8/Pz8/Pz8/Pz8/r6+vr6+vr6+vr/////////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQETU0AAeAAABXPzd7+NAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70GQAAAAAAH+FAAAIAAAP8KAAASW91UP53aQC4ifpvze0QFjFh2YkAVMDUpYWQEAgEBG8f8wvNMFJ+aPoUccB7pj5hsFRmGZJmOQZlsLi9GXmbp+kxtLzMAAWrv+a6ZpBiE8N0oH7aE3hj4WXsMbMTcCwxY0BTJF2nzF4RkBjI4IjE08rMxISsBBQI4byRvTT75mqGRBTHnMKw0xICbu9K80I/z78s2W8LrlQOGiAOCTCQO2oPA7DGLo759sYfhyGGRKYJcAIHQ3i4OIzIgpZLjsodx18MOa5njrjO2HuOiop2tdChlbX7FJfWPA7tqAWHu5X7h/2P7/tlYm24YAOrD6u7UOP/cctMeFsr7WkcES1rF78P/XPw/////bOGuSxpl6w4+7au4bft+LsCQ+sO7auIqy9BxuCABVZMByEU6T//////////////////7c4+G7C7JAgwhBDqIioAkHAE89g0iKMwjVRoc4vwBFYc1qdBgVG7YCKDBQEwINLVNPUMRTTuNJPzPT1kigD2hgIlw1s0EfOEQC4rL5Owx1Kz8X7CI6uKLcgyll2fnZxr+orIKekl7t/et4WJt+4na5hYkTr4P+7jOLcvz7/++mVTsLsUk6ppLMH0kHe/+///+L77u5hL+/Uz1G88opzv///////f3nh///9+np+7/v59t5/+QP9AYPh/SqZLZKCAAAAAQBAAJLN63Vg0RVMoQkjKiacdAmlQgCIZcGasYicgiBMAcCuKRIFliEYKATFFUzjBZgsKMGINxVHmhpBpvEJ21hlTpgDYmmM8DEQoCiBADBwM4XMwAYiDGRLEpBSIkbCgkQhUu3KfdyRgWYoMwuYnmxhwGC7cul0qnp6utF9amn191W+pZNKKtwvyslQFpsMv7CXvlURhmpuzNO7elMpgiGsc616mf7HKW5ZROapu/jNW9xnHP/+5ZoG5UENZQZas2bU9SQFO0kk5GotlajE9TR+xD1rlLr6arytLZihlUvjMar6oHW/////8aWWa8Qa0JoAEAAQBESoa3dNXgsMOjREKsp2iD0tuWByQsvoZnxrC0Y80rQDlTADFpwcbJVC/TvrAqFNVCNAhN7oNTxZaGP/+9BEnAAHpVxVfmtAkOfLmo/M6ABTsTVF/YyAKownKf+xQAQDOQxDMMsRMQCMKcBpoAj1cHLUigKKPCAhBgwru3U4kW2jOyhk3NTOF4XWH2JPq8/ssd5ynBkM9Sas/MWcLM1YhpcygLUJrc5J597G9v8rSJ/qSSa/+Rx9dSa3FsZdIYpaduSS7u8ZJF8oTZ//+SS2OPtk/2D4T1m9LqazhYiFSzLpF/aKXZV6kPZcpbnyqrhTUtSZppfS01fVyRf/93//VlOgorNo0KYAAAAEx8FAmrNxLJJkjyAAdDkGWXI09PmJMqZwyG3AcDsQRuUyKzQCSYRYtojcOApxAbAACmsKPoF/jIEDClltNZCn0gBfJ3lSwGptTU7+uJ2mzpsKlvmuY9x72rjbzv75SzV+tY3e/ud3HD//PH9/+X/rtapcv//5VOXcab////////ud7+2eZ2efurhl/8y5drXud/6t/JLh0qymYAAABCx/ihhJDNUPmoIdxMrDkiFcNRWg+y2qePs1ZkREOnDZABiwvAFyQCggFlIGRXAYAKBhAINqBjYEQEMtAJGAalEAQDBQUJ2JgToQIrpqJ8dJwfJVHCTxWQzpYKZkx01RrNb6aTNs1bF0pjoImakFNTFf7EwT6kjaqZIoonVpf/ucPJy6XaLVl1SVSSzUzMjxq9MxNknMTH6/+nSd161oliMAAAFy3hqgskZOmDDJKARnW49wQZc6Eh3oKYayhgNC/0By9sTSAMFAChGvsZSrCyxQFMiGUcF4wc7pCLJJBEeheWTs7o6PVau9MsXaiTP9F3wPZUSOYoB3MwzqalezJSyjeHEhirRwSUFl/fv9CiWPAhTn5n58UGdJ6YKZzn9t9b8Lt1NTAAAAByTgQhMEbEUFNJIpU1hYNXy6VN1Nkg18v3TSxq5expy6BocEEtJC+BkhoJDf0EhDqpB5IXLGhzBOM8tUSpc2MLyZeyeGmJPfQxR2Ydvaq1bfljeMI8yodtK2VaBo+5mKrMO2Inu8fGjThZYd6uiKMt116iJDO7lV9x+6GKIuIjhca4UcVKxL6o+pXxDehlZUAAACV14NdkIgShBUQmZ6q0SAypTAvvLGCK5dmlZz//vARJ0ABCxL0fsMHaqSirpPZMXVENFPRewkdyoaqel9hI7dHITXg6BmqLBt3FDoDQ4LwAEDZEAqw7FAVZ4JwaERUYYMEZgVVEhS8d/vLZ+NLJLqHztpXGUs2/cKuCA4vtpXm+NS1CAmyoDLjmrPS0yOKSIjJMgt3+8ItKfogQqhZcP4YPBrGU25V2MgAAApt+BEZgBKRIRJURISmkCstMochmxxnUONrH1r7clEAtksMXzWGSJMQ0TDOYhS4Yc5EJEpHgodCBZcOlSYUTKtlRo9kem7wR5sqQwhKuynRbq5+x2UWgK+22iPDp9E1QI9eOas6/5GwVERBQwbIBpAZRdlG0c/iBCqeXD+HcGuSirvlqo0MAAL324IAJDi2wxiZaXipcS96E8RATTo2C3nRom4uU/FPGqZ8YjOKVpXOQDhRl8WdTsCxW8ogBcY+sqDQ4l967penqS4T0Hh7WtSeIo5h1sDIMLWM1t8lG9Cuct4UaMXnnSmX6GT6f5zM5C3o5/Cu8OGfgrJ/Q1IZAAABT3YEvivIcsoahxXq4AEAwsHCfYqBWjfaZI4ZfhxZG1dlKtzWXxJaN0RqfcQDRtS6Q4BQgienM8hkig4BoLZH2DUXCqifhaOY6mvia0qoHZ1vSnsw2BFxtKZLVXkfmT0iOW85Ixf0wZTLuho+I9N5mPIW9HP4V3hwz8Fcf+nmVQgAF3fXAv8ZWKCg2w4NMb0hhkcDoqq132NyZsbKJFD0V3AsNQ6uh+l4olF6oaaW1bsNwzEpwRZoTmxOsgiNJGw+wXKMgpxzZnR+m3pG60us2CSKxuupfTsRLxKhGOUhDaqd3sNIVN9yLYvy3of8FfS+GEKapmP2YeUMAAASfbgZIJWUvLUJ8oAWwA0bUVNWKjQWpyps7+KNsMijbto3R1H2f1DYdM0BrgNSnIvUdAw1Scy68mrUs/RPrY7EApofX8haKGbjdCylWhlxaT/+6BE5YADx1RSewgduoIqij9hA7lPMSVH7Bh26gMk6T2EDx3Sda4nGnUity77oPi0tqlIjMvxul3ew0hU33IqxfrXof6IfsknAIEWlCRq/8mYhQAAC7rcIcDjYqPBjCAaqXdTWQia00AaBehXaOjUG6vdVjEshtmLv2Z5hzQ0ZY5YaXIn5damqDX4hs1PvI68zP1eJnZyf6B3DNmvPqlzRGRkUFpjppddv2lEGw4x3yxhrmKci44Ldybp7UwxmCdwYu2BCFIjU+yBDe3/SzKpgAAPb7cAIBcIVUSigwjGk6lMqHFpSwLZH2Yzm3adlEagp9HviDxwChObkKgTlU0b59mWoFyGqtVrruqF35G2JIfwUd7n9OHC4nTQu/a0GaGBLYJEimIXm7DZ+vU3wWIvJpsOR/+RXM3IuOC3Mj6e1MMZyuDF2wIo6I1OWQIb29/qunUQAF7e2htx0gNAsxQAUgDhJ0FugxCthaKkYcp9gMteG5Lpc1pukjeSPr6QxgGCosMBoeDiCVP7C0ZReiJzIutLfUe8SkJrTW7CQhypsYvISMPKHUh7MkQUapnC3yhKXxQZXGSBVtCxJmlxNC/ySsC40aECEAqQVilzah3VQAAFd9aELSqAhIqQqTEIy/gQF1l+obJKXGurOZ4+7ZYfrxR92/iEDMKiBdRQVgzFVhXneZx4MlZUzhf/+6BE3YAD6VPQ+yYduoLqej9hg7VPiOND7CR06gsdaH2EjuVhGUyluflGG/jrRKWTPK1krvZ3CKTLhSul2W6tdNGSp5ftPM220T2oQqR8UG1wsCBVtC6TNLiaV/JKSFxsoQIQhSCscf64qXUgAN66yhI4SsNALJwMCusBL0CTUmVbEapMwx4nrjEXf6URaBo7qC2wuSxOdc+szJql547MmSgosWqeQD1HEry8s0R4qZlOe++TIoU3ElEQ/CiW426wDVkrrn7xkdzPNQ4OK/dz51SwSpzJN4+JM2balWFi1TSDkIJ0DsindUEABW/1wCEFtoIAIC9qugAmRzaWz3MUgR8mmvlaj1+pPQ5AL3ParTeZQzVkrUXuhtiUjeWK29ROknaWm/nYLBc9dyNM/p8SpkSRW2ZJ6ANbibRKlDM+9eiOqrftGJ3M81Dg4t7ufOqWCVOaJvHxI5s21KsLA1TSDkIIbgd2XmXLAAd/+2APYuhuAhDMBZAchG1iIUMknPqrsRZw+7FGtDorBt1lQmXQhoKxbMpjohJsUjg8o2m4IBIDrdIyAKFBg3PRBT4HSw3YKWrqVUanCImYv80bbPJNLD6SRBfFPJTKcZuwlJrDBDWcpST93iwMpnzUQ6iAAO/20CTGICgVES9iAtn48hMFucCF6EhnjXe2ruQJT14Npb7MWCrbmUtmr5P/+6BE0QAD7FNP+wkdqn8qih9gw8VOgSlF7CRvKeilKD2EDt2k1O9Q0m8WmAhRzdTg/CcUWuLFQ9i6Syh08BOcxrEdkGq5BQnJkEe/vwrCO5yZ5JEsfUkhC+KeSmU4zfFUmsMENY1Skn/2FgZS3+/tq4EA5/7Yj4dHN2EWDvw7wKnhBcwjKpX5OB4ELJKmDTIIS2xcYGNvJHbjM/GHxgKPOnLar8x2U0WTC0QEJUNjaSJETf2lFkbwlCObqDCpKhGkGL8oKKhop8z/Xdu8ZEHfN+zlckVpk/EU1JpViTQmf9kgZjX7VhiHduYejaPBoAgSI/XO1nXEKABrbsAWrZVCQBAFwxJ+ucaAk5bCImsSRSZakQUlSCGMQAIH6Xj23EbKjjix1wIsqKwfDisfUG8BARmJ9HJMlVr//uktkCJtuUULORkH9yZ9i0VNrK2gRxU1yNp8lGdrfcE8c3cuLuQFPXaSECePMQFWn+PkdgMZxptPBpso7iNgAEegpE4ScftbNsA6mp8xuMjEhSNm30l3FAqgl8NrSDGU+RS9qvucX2KOSsyFYvvBKtycPSZKm6fMvlwj8eyX4cQWlHNK2lWy0npP1WYZfOhOFwnbx5F5RrwZt5JXEcS/ANOqczMzacgb3tQAnMusmE11EEoCrcsArahGDmJmlsV8ILJjvNB6npFU4eWs60JRafb/+6BkzoAEMVHQewYV6Gcmad9hiaNQEVc555i3oW+XJzwcMD3AKtIa932qpl+PO1eMnY51rmoyqpzb5W9Ksw5vV6Fv9dy3Q15/MpTHjWMrlOWHdpeXgRbvaQIDHbfeuYKgI1iQl4XNGQAxYSAkM2mi6aHK2i7D4GxF5Q8m9aYyVbRqlx8qdd61naMt4ctsr16KjjaQ7gIn0slLZjNT129SdAzUqAlx4FwA2KZuuVjHqX+vGDGeYRmFO4s6lb7IEuv/opF1yP08WpZ3iJhoEDbqyAPbEFrqpXFRMQ/i/O1ayz3Q05i4s5fJFjRFMjMKuRowkknpRtCSkePgI6VEuNWxCM6ezaI0itqm2U145LX2/Huiuq1W8+QEpN1+QAAW6Fz6RoAz/+U5cMKSEKgqJSImRAyN8kWiS1LD4tRwCs0GkpFAoUVaR0HVy5vegydc0q6oRPAtYircNuUHQ64AsEDGG1hPeOxF0fU39n/sAAwu7Cv0YACByEISOAGBossiIn9VDlEQmKkvoRCag1KrMl0NmtalFFic9ppWOerVg0WTTZF564oLi9jB/3iqAnMAANxevX+wtZQsUWFRorRSKVsrMVqoss3//7zGp//Z/T7KUun6aPSU35qPmNzFytqb8qW+7J/mAYNlYNaxgr3/9npANIAAeYVa2cFzf5mcdE4klQVIg089/+vbU/7/+5Bk3IADvGRK+YMvOFKmCV89I41KHIUhoSTOQPmRJLQApN3c8d/oTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+zBk7g/yIlvDsAgq0B7CWHYEBjYAAAH+AAAAIAAAP8AAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==]],
              ["RustHeadshot"] = [[SUQzAwAAAAABXVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAEAAABUWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OC4xMi4xMDBUSVQyAAAAFgAAAHB1YmcgcGFuIHNvdW5kIGVmZmVjdENPTU0AAAAfAAAAAAAAAEF1ZGlvIHJlY29yZGVkIGJ5IFlvdXQuY29tQ09NTQAAAB8AAABYWFgAQXVkaW8gcmVjb3JkZWQgYnkgWW91dC5jb21UWFhYAAAAIQAAAFRYWFgAMjAxNy0xMC0xM1QxMzo0NzoyMS4wMDAwMDBa//uQxAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAApAAA5rwANDRMTGhoaHx8lJSUpKS8vLzQ0ODg9PT1DQ0dHR1RUXl5eY2NpaWltbXNzeXl5goKNjY2WlqCgoKmpsLC2tra8vMDAwMXFysrKzs7T09PY2N3d4+Pj5+fu7u7z8/j4+P7+//8AAABQTEFNRTMuMTAwBLkAAAAAAAAAABUgJASnQQAB4AAAOa/we9MrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vAxAAAB1wBT7QAAAOosu2/NYIASRbUSIMbkbgPh8oCDhACEoH1AhKO4IO5Q5h/EAJ4nP6wfNeH5cP8QOicH3o8H+UOfwcBDlwf/ghwICBpW2yQ8ObObEEJTjjUUauhyjyq59gazgWwLBIgNGvRApWFT46EVKyBAYBRjJUdh4UX6L7xgUG8SpnLBQ1VCtKylnJ3uVAb+qlUHyky+3w3JMI09LkUVI5cHyelp38XIz74rJHw+gjEY+MLMdF0o3G42pesqNM7jT5uJG43Rxii9ZjoxqMPhQ0dFRurGKGhorks+9/0lFfjDpxiNxiijFFGPp4td+7S3rv/Yvf8v+xfonIvU8G0zkX6S/SU967/0sC0v01z7cvufQ3716xY//lF2jdejjFHQUP0Ebjf/Q0dymvfS/Frlym/7t0Fq8mHEUAACLdGBJhkTJSoIylXboLAJhqTW41OC4Mexw3zfMB8RsogQzLsz3HmJY5eNaEI1DBo6omGHi5rjn/vgaQNRef9pcQiYmbl6VSLMav++8fPf/zLdm1XowuM0Sf/HSOmffjmT6BvaETXFDqiiGwGbc3pLA9TTvCmqJCSVyHIMcYkpbEqR7JZJx0JrD3VXUghaYpciauUEMHQIEfpLZG5pJyiCQno3Gs4e1oDhusTdnu2mM4Q4bg/eR4tYTW8Z3F9WFjOLw4DlVsgP671eb+NiNaNWd7bF6brattfF/vO4u703X7rfNvjW/v4rmuq/5/////xW2r/tcUyLYuGuaBqWXdelveGnomZlbgkIkICIGwmAQUJT/TZyNdx05AAg45tPMuCDEgYvkY0DOKDQYwkJBoKYEHGIhqMxdkwYLRziqw7kpkkgWlLwR4YOw9NBuL6p4u4yh/HutQapkpYkksKW5Ah5+FsvUEqMDXsyuQw4nszeUwhL2URJYj2U8Nt2k8jf6Hn2ct12TolR1h03MvvG61Lbm8b9h/mk09XFkP/+4DE0IAO3TNz/YQAAkwmbn6w8AAta6+0PSOVP5A1JGMr1+HrMFwmtKKaUSpwdxeRv1JZRSxFgGPxWfg2ixp6SrRUkQfyD7s9I5bbj0Y+Co7J5LRYbr1KP8KOYvbtY4XZuZschX/J7tFu//8u3P+FalL3z07jR5doLk91f/bllUxASKTvEBR45yCZVl92Fl/yw1QcqgWFR0oWhtHg+H1hzUBh+Xj1BdVa3devhf+rGxut5rXXO0BHViiHRg1jNI6L3LQUbfinrZsLX5K+7dGjoHYCbT6nEkhsuJohQwoQW0+KjigQMKl0tbYlJxnYtQDL+5aqSurXVyIQiSiXUxyI4RGkUsAti5QkIwBgNUqElL1UrJXiaE8Y8giAkGpipi46Kqi2EgodQMimDAxVycYgAFjyGOJw8sUPPwCTTatJAI5vNo4jKOMcRIvjbRVZJpqKIKxUFdxEeJQ2sNCwdalJUFniWWBUNh080KM/i//7gMT3gB+5l2n5vABB3xSuv7DAANT2GC7ndNtT5szCIYkAEmlMduBIj8BRFIUWGpeDAMlSjUbTzbi58NzDD3AfpyZ5ncSeYPicAhUdBPUbDyTNQQ59j4kwQLwUMSdaWy8SwfYBCQkOAgcMLRVouRhucEBAPPi6dC1IMrVbcdvl983KwyEEAgECbTQDi8YmJz5RAHfBxp7OTVCUBRhd85MbuxWaqJdlMQJJBimASwAsGrQOXMIIg0rqiTGntOJAKpP8/0niK7ozO5QmZs1/VtZabmkPkmgJjKpZs4jXUK5axCslFJnq7ko5LGkWrInyZSheOj2ZsKqJwX8oylNz0+hQPQJJIUhP+hS7knof5/FJmiGk7ST/zfqfajfYX1XMyN34iFoNHH6p88Qx0+/bh8uzSyoQiSAAC6QXUoCAo3khWzl1HEBSxgBMBGxSEUicScP2SAGXmSe0baRIbBg1MNSjLIhYoify0TMCEiIE//twxOiAEBTBbewwzoIZHG49hJowXd1ZiJUTRQzggYuHQMcqFEUyHM/ZmwZAe4ekT7mQe9GpwyobvuFrPmvz0ye7rs4EhWa7F3fztNUQQJlSu3/Yrs5OOXtRkEiGGESkwg1pCyx6aIlKos/T+6B5kmIMWs0EGaFol3dkMRVFQ2XmoLIx5KTrgCpS6r4JRI5J5zCjrgubDsfm4Ykc3ay7VnA0pUYkopmm4jDpgx8ZA0JRQTF+SMkxlTuuMTlJs8K/JCb98yvK8o3ShKFDkWM2Wp8uDys8necpOrayQ956gRS/UJczcj8iYj/y7Dl2TIHLaejH5PjkV86P43KN1qqdqHZDbQbbcuA6iB4CWXnQDiikAgjOleDSBygGAsACYxALHQwPDhMgEpJa9f9DUMnjLx9+wv05wGHgmP/7cMT3ABGFZXPsJHPKfrRuPYSZ0AEGVjtnCT8mcXCDhwruPXEsB4MYYl2UDDgYgkMyKbC4INmGT7JtH67jBiicIHg8PJsMJMLZc8UFVoD8xVCdct59aihoajQwAAQCIQkwWdB1EEQOUWvZsm8nOzItTGX0Xm0Fm78M1jkZdijt00oROYL80hflObOCPkhhhCQMBsuTg4VNttMI0TlUfFagkbWKSDZQuGQ0KdGQkCA6fqMyOaBNEe5tC/zmZNVDW7XUyrRsoLqdRaYyBsB0y3TdbVfLXLQuJEc6yVzeWEOm221ZHaZEG1HX4+OOe7CVa9xcxUwzKX6F2KXZyJBSOVhGlCxaNAou2NDS9RyVjckWRhIKAnmMVFcJlrN34RKO7r7qFiF+QwOD2ueefucL/Y1eJWi0UUQlTCj/+2DE8wAQsY93zBhzyfef772GDXDzAjLmOFSZsWvg/wUnwcSShxnCjOBYrueuyQxQkifPjxMKC2bPG1SyWixUNJdS+NRoG4tpqoyYmXVEFVVHFIM7IQhUCc4RUIojegBTnL/CQZAmMw9w6F/XmeSkf677+RI8sah3PTpjXQYGPISnZ5yJApzJllEUMBJE6olXtr1L75ZW8rG2CoJNYKLgoVXazVYldpp5xrdfACqJ4SQ69qSyKoqjQ5s7c1LOqA20m04o2BjBUKiKywrFyCUqKokNXMgcFWx8nWb5lL15TtLlAcalOb0lweUbdlLCDinmCKBNMlKZwjgabja8I7I5NM/5tFL/+3DE6QATNXVzzCRzyfSfL/mGDbBLgo60aGGOxHMC9KREx27650iYnGFSymoaoaHGvyKkH0vIIpzPLJh9iUvUxERH2rq4q7yXUQJIJJUQDg7g0hmZnMJPNRA5Ba9BGQEVIsVmL8hxo4liOTBpTk7FgxqQAMPscTI2FtahoIRwgUavC4ORPWt05cmc5bJxiTP517QGDCRhBiRailRYmx/DYpuvbXWUC7a5bF9sim+X/+9Pd8u1lrzst3V+p4j1Pd/FYvKuIlRBFR1xmOaolrg5YCoXBJlg5iklmJzo2rEZY/JkS9Wu5kasWLWidcEEQoGcisglJZFKGWLI09ruCJeF84nUnJXNEq9bvs68mtgy2KZqyXlWakJdp2LHQTF1E0F5oqyxVnin4IdPGfvyH8M1EEsRe5xHzf21//tgxO+ADfy9fcwYcsHqnO/9gw5o7FfWfq3ZpjIQSSSXRIQnshgLLZeEKAJQaQykQRiyi9UbS1ZUA4+Ba5kQNlOSL2WNQJJaSXUEvhhM+WrAkws7knfMI5816rWxv8xkm7ZKDbumuFVEhQ4s6PItCah77jDFD3X7XzCSS4QRZiJSGCgiQl/F2UNuXcTCGDTbKbpaUFWISGtRakQLR7MhVSiyVYWYrZZc3QTgEnqCQ1IiLksFsZatAEZLYVMvAVpsamBLMTcjgaSJL2dx0EiU0RLR3K1pczZRe0a/+Fv3Zv8f6dEWiXF5k5jKyrNc0REDofHIg04XDQhBYXFBfPPmvYGBcrNm//tgxPIAT4ibeew8zEnrGK75h5mJ0/oOw1VOqriHQgSKKaUBL4wBEmMTlDQmyBA05SYaTylzOURomH4KmtiKdnr0Ur5Zy8A7lIjmEHrWCnCyt6BAvmkdZbrll50fbz9esbfm9qcv3DVVOgnUGvPqEy8ONXmeYY+tMFoo2940h/6gzkIbuxZYta3Qaizt8V334xxG4nxfr2Z0fmr71ku7l5dhAApop4wDlDcAIEWoomcCGQrViJLlJL0cZXo3V92fO3GYMfeo6CFpVbQITG3sYwm29K3rDQQ2wc8gT2ygzVjgYCCgBNd4gpz2Z8CEMAMCEAYCDAWoUwAwFyxIllonQGRHwEdn//tgxO6ADhStdewwzIIDHe49hhmgFyMuPnS0eZoxDs4zrf23/rvXKGBTTRLUVMdv5K3bSln6ZXVAApKpSYG5lIclSokKZAgkiOOlbmyt6mI4UMQEz94RUAoIiHllsQiEOD2CQEVkTnkRq/JoN0Ocv6VW3KyluUaxfrSJ4ZMhi0WIC0NdDUWvc3lTuNjfmLYisxvWHaX+37eylJwnG91OUZqji5zat5ctg66mqtupg2/EbMLRKP/ivHsQ3uz5FRVtLoYgpJFLALprGDQFqoknKmYmWk6tdYZrbbrXLeLqh5+lRo6AVWPAyoufohnumk0R1gVRTUyNNeMJkkMZghjSuQyVW6L8//twxO2AEGEFcewwzWobpi29hI4dzG9ximIPXUdl63CNN0xCXxVubbG9Bd1ndGe+4dsTh442NgkVr1J7s7fl5rulPUUPjq60aLv5RZvxpmtnZ5xnhGpkIjETEey0Ww2NX9DHw4wsXOFLDEiow8SLQKlMAGiApATEk+MgoGIAYAAohBA4YgBgkKS1BQnpQCMSFhKVJAPOnmtNRNRRMhpUMKCKaQ4/BQt2YBbxDBdNQIIr4WICjk00blBptujEXTWqyyMyGH3nhdLUsLGcnTB2X4x9xV0wZRvvddicf2XwJCH1aAsO+rSm+Shk9rGkjME1IccC8/lyDbt2mSufJxXcluMxLYedCGpXubyxy69Mri8giVyVyeQ0enaUEcuERN/4FadXhymmINvxaIX5RFKW5VuTvXjj8zyN0//7YMT6gBEdJWnsJM7KFB3tfrCQBdNDcjl+eNV4X3eJiE9CpqFxC01yIQxL7lPRT1acmJRL4jahmvT1iiP/2o//CIZqapHgmYCEAMAQEAYKJymlNFGFMmAjNcgNNaCrOAlwNfBxMJStMdlQMWyrKwDMJClNLz+MXA/MGCeMJh1CgFmNARGfQvmukGxEAS6PkjkHDxgwcpAScIZmSFAH8DXwqTBjkxKAwolAEDQ5mBJtWhhDam4k4MKPM2dMQPHjibChhe5KMIDLTMGIDDZCYMCHGn6KpcJCcQgQoDW2oSWAbro5hilXBjAgOLSAwgAGCDBAxATQde0KDWXNNSpMWADAi5TKC//7wMTrgCKpmV/5vAAGZ0Ip/zugSCgcFgpgA40UIiAkAZyXLDh7XhJCRIQIFMYBAI5yhoQwZgzU2FUE02NA5JIvou5HddCNAEHrSQrAxcZAloC2LKBocFiZQKKD7ECz7rLelTrwdBAjABi4wohOJFZeSnN1oD/XWRgVAZVQzcMRF8k5ocL9vRKyYHAzTJNDTAYJa3NJBrAt6kUFhpKGgZrLOXMVCXkb5/WQF651FBOlOIaFMVKoNbwgEtqhKzoVtAgCicjOj4igjwwzHDuX///////////////8Jy69////////////////8J+7CvV2avgSA0GAgAAQWzpDakzFiA6Uj4YQENQSEIOmAYMARRToxpcGBSIiBQYoJPbfNaxJgKkakMDA7DxpVZir7o4JdLAkTTKc6zXYs9k7eDRUbEI4QiOaCImLIcmA3vZm9FE6StC/WkqAF2HVc16nfkkviMTgRy4m05PScVmeF16SMyl032sRqS5UsobV+WGwihdayvdIhR5mE3F2tO7FJVKu15RNxl4HffyQOM2sH0dHFYrL6VfCxGVu3In9pIW+1ekuasY3HF91X4fZtKtzUdiVexFaenfd3MKOduOszJ/crNurar2ox2zjxw51l+4GjUgcrmeLz385p3mqNrFpJD7v/M0T8S/Cnof/8Af/2DczJanWIKIFmRKa0kFVM97xcEIAE5JSNEMDNVtlcVMxBAoJOaIRYwgZMbCA4uBAKFwIwsQBoYasiZs4mKj0YkgYk0aJaXXOMrYkzIVBmBCAIMmSQjQYABBwFIAEKTQUrZ8XOhDhqNgUGukiApjqby7Bu8kZU/jKGgMxhrOlgSBXmdaBnekESl7u2pTcoYNfx5pTOwc09+5fQxZoceuUmpdTuY/zrWNwJEnwquS/NHGKOzhG5XQQu/STl92n1d2SRV9aalquPI4ciFFSWa7uSyXUtNSbsTe8YzuQ97JJTQQ9//ugxPcAIdmZV7msAkREMuv/N6AALabGcnc6td+JZzCc5T179JyUy5xLUzuQUktpZqgoKtXT9QU0WmjUARmkuRnPVZ//9aF7vZiHQgBSTl3ENGWFs1bE1SzwREEkRxY88yRqWkFNs3rwMMOBSCnHmZPAsUoqptwwqOQWGDA6a3JxUaSUSSx2TrA4022u7vbeGlVGnRJJs25JSRd/iC1teiFFVpK1EVSMw6ameLufT5pbqemjtTIX7qo/4Upou9IqLdYaJOYkdEAo8v5RKY26vmZEBFIlt8hLAJa4yLLVJrqLkS0eAckvMWCQZcZs3q7mm3XZpoF058glzvFaiBaQKw5HE8s3eifPLSS6bElaVinKQVpeJqou+60KZmSIZGdpPNdIaChWSEQtsSrcDijBi4VERbzNm9npGSlg+N8k79+HfhP46SeANj3CtIrAnDLf0Qp6ioaHQyQQSlvGFF2lYgoFQWhFCs6IDp0MqRTYHPsdfluiwoDAybJyLUQhPqztEhg0rI4tvixbMnjJBIw1g03vqW/8louRY+DnltO3nPNHWj3VmGz+265EikfHIkjTCACNUiYkRMNIwcW6+ek3paktdpNu9+ZPW+dvO/GzG/9f8vP/p49EAVnuiVZefFJv/RaMzJd2URIBJMmFIrmDnp1mQpK8yEAVg8CpljJvUijbVGBLub5rzIHb//twxOGAEMFvX/2EAAIRq2w9gw5tysOnpSbKPB1SjpCyDKKJXZILBpBfJ7UyR4RqOZFOHxDpS08jz8jjw1y/OZFrnNS9LsYRSjkpKJDKR+xs3Wbbyk+6lc71CkUY0KGvXsKp+vTD7vxBar/LpmVTMIokN4PEmiEAWWrGRCLVA1Y6BhTerRakyidzsNbEZICgJlEJosKQiKyybdXGCSABw8SAOgEIbmTEiz2dRRmYQE46l1TjTCNiJMzhZEjvvTuUztFqeDPL0o6atC4kjOcp/5B2EuOIfBCK4gkYEwDAbwE+EwuXjbWLroUxp8uD7QQwQY2u+O2paGQiYSalvAyHES4CgBEFxxEFWIv+nUiEzNnCOrjsTlE+DgE5NVPCBUmQOSedQLnRjL5J1HXZCyBiSddMN8NJyZ4L9//7cMTuABIBXVvsJM9J8Stq/YQOGYpUXz/OG6qe3rbbc7a1M20g8yntGQjNu6peI5PGSNr7BJpX7vd2IfL+oCKLvoYslYeKtB2YecNjl6+pY2pvh2ZVQhAKSkuJjQcSFMJHyL2LAiwWcIKCQn9YkkywRqTQp1cDIXVek4UocVNksGXPRITa8IIElVlmzKIlOF1GjYhFR8ED4ZFQKnSAnHQoFOWEYFOQTVZaXc3l9PN5GFMVujxARUFJozZsKa0fsFRnRUrNRimVy0Xu3+Vn10GmFN/n/ndvcUtZRJcTtNuAYnB8wVi3rrspnZGMgQAAlhuI0lTcmKClKRJAwPPKJv4lmk7Ar5EUcKA0Ih0BI+UOomCasvotqOYVCAMCMagqEBwx7OPiVY1iTDlQfI1I41a+e5UZcSkE1OX/+2DE+YARMQld7CRv4gckq32EmdhjagldUa6qf+BSOqpHtqUP3HzRT+UZF1edvFRztS7226z8fKV8xVXjjBtRoGoCm0XUe/f2Kb7bxndDNkFu7cxc06xEKJFOUTACwynKANTlkTL2XNfU8+rZ3UH7Bc9VyDxpFqhx5Kga4m7Hc0kxqu0G2znu0PbbaGYnCBMkEeSeol9T+2Zs18pXTp3fEujm7NlUz6yVxOVSL4UdRtUkeaRN2jZvfW+P988zGfa3cRYWRYti277fzrl+f+43IuHdVJEBvbcEkh4AEXIoIZCthbKpiGDa+x1MSD5DBK53VBoCACYjgW4eB5Jknj3S33pEu4H/+3DE64ASmUlX7CTPghyr672GIZ2FRTlMyH2fbDKu5S4mRp5omPSJrl7SeHmIua6+RrxcNrjBlmUqrTWrF1Q86krpImpLm5hJrn5MXE2QMCqKrgq9xqVsDiRpNkn4qVVolUWVQVUDIBAEAkIIF53UzoAAw+coHmFBwNSzCxcSAjC1VRMLCZiQIZYUGKg5kRsYqCGFApMPg4mSXS8M4QaAgocSO4xxN8tcosowMFU5S1fAWUWYXmqqylsyylTpnDxQw6hJdtIR/ncZpGGgMsXYgLLyNHQxT8hlxH9UvZi999lDbXZbLW1QAqmTgZrKVcLqZLD87G4bklNEohFolEY0zFqnGutTcSnZU2kqlEboaSUUMzMP33XeYQc/bLGUPu+kGPrTRqil0uoL8uoZfSy9/GzyVpcn9/JM//twxO+AEJlBXeykzsoDJet+sIAA/skkzdF3wYqZYqObL2ASmM00Tb9/71+mpL9Jcv0n3fbNcaS/v0tz7tNdpb1LdlkC/foL0roZdLJVLI3LL7Hf///6A/VayysqZsKGBCKU023q3v6EhxIUmuiCTZxYEGECa4OOioAkAqIRQDDAUCBURGgQGhyyCABZwAUsGYyXLZQsO3Nr6ttCIhtVSpV0+rB2hsNYK4LRVSvy3qSYMBDa/IKiDqXEVVLngXSgKR5QrL1lqI5CXYkluJtijFSZuS1WUuiy5tIFaHec9ynkfqleVruNlnO6u1hH2Y3B7nPZG3ioH3eaCW69ma8AQLTU8Hy+9AF5qtNSvJEqd5X/eCpBMHTN7KltWqDudat9LvG3lzGmcly4F/4Mp/+9GXxUao/o6GMUVP/7oMT+gCONmUf5vAAD7jApfzeAARQxijjUZpIEuQDS3Pu0tLf+ivXbssuludDfQqmmhEZGVWVDMgxGonI95dTVhYRBZyxOieaUJjAqIwwYETDwQdD2nGLBSbwhAisdEYMg4YIBg5aT6qSFxCoEEVItyNv2IgtyHoOyRNkzYGVuA8jV2lJYw+lY5iBPGVMBeGBXdUrTubO8CvIbUvZZMqXQxL7kuaSnQz5dK64y6zbtWh973dg2OTDpVoVAkCMQbZQDF5IJhuNu2/zWs36dGnoIRA0AOhA2cka3ZwhMVfdu7L4pfmIxP0kZv1Yy/8sl0uitN8FVKTUXWXLXfhp/HKhiWRCW4VqtDhSSmP8qX6+FP/P7y/nfyy59C7r7yLm6ftNZv26vf1Gqai79mzd79e1B2rqbeZVWQzMVa0FpvttqKOnU1NEkSNVQoMJC4NSw6MQwrMwSKNIj5MHRfMq1GMTSlMtxxKpKmJxTmSBUmG4QGGwJGGpMmBkGTmGmYmAJGlKG8ZGvlKKgQkCiwJMGJElDNT4UBjB4xAxWEy6ULAUtSI6CShAOCARkhphyQGNGjTGHVDAIZMGFHAEAWVBQoAHSASY4gMgUOAUGDS5lwONNKjS6UjEHUbke0AS8QADaejrBKVohADQMwxdD8mKr+doDB1oKApKJfts12oydIcBDrEvJgKpAaEQOFv/7sMTtACAhlUf5vAANbTrnfzugAAQcFIiqijQyISIgicq5lAFIKxLJbx3I4gGks62Jpsia0tZ0JSlWzqXO4/Ksb6y1xIYcVPIvBInLaQPASUA5MZsrKRSbu8rsRNy37fWCZvPGzhrWtdvd7uvlR9u55a1nlzmeGs6nLd3DX6y3nc3zu+Z/////////////////jjc//KLqm9qauGdkNmEQJSZlnr3dtMVAzHAgaaDRUY7g9MgOyqSmPABghuZInmFG7+mVtplY8F0AzVCGBAwUGTtMcEdPOVRRN/ZxCNsJdpYI1zEJSOhd590r7kQUUdYBLGKW0ZhstnFJJ0OI/ipBCkrcWRSKQvZivVyaKheUt43sDuRLDKhUIAwKBrooIWRMpZbKctuXBDBW/aTGHLT5HgSIBuCsrX260cqfVcsTxgqEba3QzULnJO1ycxlucYdNVRpjy0s7KYer2ZmlpZxijfTtarEHpm6CUzCiqsCHVyV7RV9HvtuDNRyHrO6m5jlWrrO9rfP1rKrZ/f2oc1dmMLFyz+WH/81ZpZDylndW71Q/VkQ7WbOjwJGAEAkI0o1VVEcgjGhFhW1A0EE0FdpYOTREQAAphY2YkxmJCQYWSYxYBBoADloycEHjTHlBBJXw+JjqBy66TFFBg7SiwCzoOUfFdZiomiWuoGIs6FCxZWDkG1Y4MNVUOjTUARbNi1q6QAq6aAVWCDVVVG0I0Ag8cDBlIKJCRj+RFuz/XG+fF8WdpJlyy5cQL4MVae0yL315X2nNOpLz+N+vds9K3Wmpadv4o3eLUsTafcf2StJk8mf35PJInJ4u0+lpohS34238//ugxO0AIXWRR/m8gAQ0L6f/N5ABapH7gdmv0tPfiUnvRG9Txanpr1Ooy/r/v+/snkz+fJJJzXN6x/DHuf6/4w/MujMZ/792UU1FTfS3I4ViFP/dypunepdlRTVQkZTkMz2u/OAKTCgE4sdKwUbShIDMYDzCi0IEzAxcFDhpRQYKOFpxI1Xea6xmOFAhKWlbul0nUZQsbxexSh51TJeKWiywqJAtZTOlOHRdBS57E6SsIQCLs5ZwyWILnZ44DjRIFAErmog0ArK4VK/rxPDFP+k+BPBVFuQNBqq6WiK1DGnWjVD74OpR0T5fRLTXyz5sbcW6Nz+85VNfpbv+6kajEYdeg+hjClK2GRuLTOOr9dCp6GDIP+mp4Gfql+86tDGKKi+iof/1UU0Gcrpf6liN2nvX79nmXdf+8K2OX/epblLS3bt+9d+lpvpr7L2UUrZnLuUUBwe5dGsU8PEMzmSECGsJGlk9JqwYeAIAQdEGBgR9gaABscBTJU4GB4NDwqBmLERgpsjqVlwMAjGBgHAiI4GKBCAZQJDBjiuEl7G3TIivIgMcdRSamHgdNStnKTKdq34CLkU0XaozxxXLT7T6cly2UQWtddb4KXPh7quu+FFGIxGoyzmlUQcu5SN9FvZLJopciERiMlfFwote9yk9U+/chy4nJb9JSv7FaS65VympaVyaanpfclyI//ugxNsAIG2TS/m8AAOjLmi/N4AAOg74O//uuVT37ly5Tf8ajTrfR/GY1GaD/g+Dv/3Kg3/+hoIxQUFB//GfoqL/u3Ppf///7v/2qqyqqoijpxRwBw8nJbJdu4DfhFMXEUZAQOD4Ggb+mbhycdPTkDAYQIGDBsa6EZiIiA0BlgHlYZTGMIIz2BGaWSf5IFAeyMQuwbAKKrZ12NkAhiA05TDENdJ/nGdEsDqfDDlPBQMDIipAqsEDxp0aJSl1F3tmbIu9dgtCKBrNCBi7Trut9BR0D5xr439HQpAIDX9f2TP9JXVoI3GIzRUdBGfoaL6FkLV2SsjZA/jVH9ap9FGo18Z+ijX0H/Q0P/6p2RNVkzV2qKkZH7+SSNfR/GqH4xR0H0LqOp/0cYoKD/u09ylvXfvf/3b8rDeytu95Zw3sWcDUbK6fT5egAxIqjVRpPyEo1ifDe4BKxCc8dBz1IGfliaxv5qtVFbuNMFAwwBgximYwOYKaBjIFCNuAqBrkYwPMuXMtJaoBhA6NDByYoXMBYwmOGDUA5rlxpBxWOLTICgMaMKUXcIhq7V3GCBGiHA5g5Y0EU+ZgOZkMmMZgMmKVmDDmCsMmOJGF2tmXau1s5ftd/+X5XeX1bMgS8v2X5QJIE13IE13iRov2X3XYJG2y+2VshfYsigSXcX18vz/gAaX3QJl+13l+y/a7//ugxN8AHXlZT/nMkARvLGf/OaIAECTZkCRfksiuxszZfXau30CK7V2rtbK/j+/JJM/6O6O8nfyTOVB6AaDU9XJUSg9AN8HUL5vlQxmNxug/6L///////////u///qrbi7ZodWNEEzCoxlx6u2IU5AuNOAzfBExwJCAExUFAQyAlAsDJw58ZIKFhGMPAisCDA4rBzPiUOKi+pfpAmgSFRFYmrMlZGns5SjLlCQi5Pxp1GdoFqlkz/hBwiYEEXXZG1RkHv6s2NRiMRogGQCSXLSrOjVD75fG2cUVFQRijoXTUoRDRBRWoPooxQRuidSioaONf6A0DJLTByE2Eg2SRiN0NHGqKioaN84xG43Qf/xqSsmLSI6IFtXTZfx//+i/6J8KOi/6L43Q/8Zof/6Gg+h+NxuMRigotd7//////////////////9HQRij///4xGKGiz91pp2UgVA0ngrhRpAGEVSAUuCBIrMSaKlyneX9cNh7pvPYHmggKK5YSrQ01jmFRUVHioqbqtqOkabNU121WdEjLYOTb24+JXqNhQswXHWIIstQI/I1Eoda1NPR10VZVxJtSutX/5c1KTxcfrwaVLhQ83tblUIWKHb1uAwiInjukOVVuohmMyIFJSy4KjhRCovUngQlEgLsEJBpAgE19xWCpiqBKA8PuksksqCy8TwcnhGPulkji4//uQxNWAHmmXR/m8AAIHpKr/sIAEmV0BHvKSNN08Tw9Judrs3/ct252/Ha6ZdQTQBzEieU+IjCCwSZZnRetBE1vRNk82dzJVZhSJ5cProlP3x2H1y0lhMILcFwLmgOKqUukDWS9EiTm1q3RVRCEgJySUxqEdmbhVkskKiCRDKeLYTHfBck2KwhDEpiseHzHkT688E4wlWotGQuhiIjFlzSvEUOqpNDY0ooYo/uMswoUkWxSLkaaWNmxwug60c/eGPISWaln7aeVqYpP77i6PJKkbost1M1Q06YUTR19ke/UpbSPCXVCnudjm6T/93pmKmIMzUgJTbadCBkwGXGFalopAaEMBJhBApenIpo3iw8uvNgV04jowwdNCgu0XkQTLJtsFSsjM1pPlhYrIQwmssiOChEbnIgRVFZRau3HJsPJ71B5QQwUJnHKlZiUUa9UYghVjvM0lDVRND4xSCPf3RmBEdB0ORDQg8Lw6LybwwggBLyldSJ5r1TqqoZEQm2nKbRqbJbDQQSAygTaGCpAww4SIDnOMpkXSUAYER9Mh5ZMi//twxOCAEREtSewwzIIZJaj9l6FZqei1u4020TRq20vPi+O0pNCmXBuqi8MLOb8p/WL5hvx2aEXOTKYq0u/yNZ1XjXHaNa879vkZym7dodhNMbtt/9z9iiy+y9OktpuUXB1gMipSpg28U3KEzCB5mWJDIDAAAScJQDylQmSIOoZVFhai6aCBJRtv0rFO0r3Cg58X7gb261YxOymS01PfijOeYx4CC1FGYRwrOQYexcNQpHDIhTlmRo2QQ6a54aLNj5rb1idPKT9IsI+nI6gMNlHlnujdA9uLRVI/JubHN7PUsUirmuDiVuJZiQwDTxFd/kiyQ6AQGOK4mUqpyyCA9Lx7bTc4KddmMulkBygWpVAdmrskjhcdYkqD2ZMx3hL2gcc4l079Y1UyVtI54VfBAWDwIYYDwYB/3v/7cMTrABD1LUfsJLGCDSXovYYZkMgakZzKp7kpfekf4WeP8MreLkCDpcVHTlP8w8c2LqQOTUnIVVNAMECJOU3SvLpMkCRSaReYhUIwt8yZfzNFk0MHOW34Aw6mAjbkE0SXOeGe9SdcUKj4PuFytOWzrMSqsqvLwSRJpokCBAgcI3PejIiCKWlayoqtpnddKb0ZUPujucDHoDsLnwFUDkOC6WMpLKipv7elIoKIMqFByW8OhkgGUwIjKcyxUGnB71DRaokESUWtBhRAQHUHAzwj8JYxPUMMGa8O8AhrxTP5NXiQ6urYyVRopgkbYSwm70pjQRDGzu3aod3ciZreiqH5MYBAwY8BBxoLgp07FZyNZmW1K/vGIgJ//zs1FJVtHJWsPXa3b/96rUeb1h2A1V963SSqrHlQHV//+2DE94CPKS8/7Ay1gcmhp7mDDiDtUgcv8IyjQGykoVgUgWeNDUqZy4LP5mkyhIEPugrA6RhIkSsFOOxHYOPXUFkRpgUaqp1BGXtpb01V11U0j1K+7TX7eMut1s7sWZ1SInZJ0ILopbUy6Brxg+nNoEwtrDqdrZP/a4001rDVCTOQ6mZCCSSU4cpxZ/R0yKohMIzg5wNKXoFCoIUrmyN9Gm5fIMoLny06W4xMqyzZ5swFI6cjR9oqdyJ+LTE+KZLkRLnurZ4E+aCYBMpCjVqJLb/b7V2Er6rDVukf8LUR4Yc0ySY4SiUad+4WDT0gJ+owxzqgI3cSchUsc4UTIRIJJrKAQmz/+2DE+YAPTQ9B7CSvwfixaD2HiXnmAapmdCixQzJS8pxULiLVMyYnL5SzCMTDkuP0rwDGAwEbCSfNpI5iouDSagAiTTJhdkSIOKtYIQsp0Kqdl+23vp5gpaPVnUsx7QQCDjwQIcYBwEaDGGAQcjutEPQ8xtmeq7J7//N/922bv/39HubCnkEzTvDMZmYE1waEs5Bpl3tugBbmMlASUA6pEAy70qETmX0TaLscqhgwa2JVCiQCX1bd1mosVSQU99IkSTc01YKEAEFK5IoipSjwPtW4UU0T0ySXGSzkqYpb0UkjBRziDQCfCo9D2LiVVCqf+/9GfsSqu7updDUyg3G2xLQCEiT/+2DE9QAOjQs9jBixweOhZz2DDiASgbECQJFCsSYOK/lcLqcVMETCeSZGJ1CtXrhLTsO3fu/ds7MBIBoIA4AgFAHCYc6IEINaIQQZUQ5zIQIxARinTudZVL5NdqEbvWa/e3dT56aJ0PnzSdttfVkvZXT+n+qWp1+zSscLard3LuaclBlzckO9toIl3FgqTpjQRHg1bklfGSLnicaXA6B4Lzxe9bQVYrBfHADmzCu9fl6nFmfjeMo7j7eIappZEOQ1SIepDxUxQkiUqoVSpPheQ9DGktDyPFVKl6+f/zeaRq6dPW6/u23ei58111mYur0a+91a7WTvvzdC36XbZ7/fP/ZlYfD/+2DE9gAPzZ8x7BhRgbsQ5fmEmgjdqsmryHU0C1ZJAIWTts6IJAKAXsRBXaMASWdRM9gS3WcP9TRKIUjwzCDJFuYdJGQpJNq0ijWpFwdX7s0JHHMGraKO2WgrlZv1m+alHm7MqZj+fiKmTYtHcxrGPvTkKY7kOZJ3MpKMeqSSLbVmRnRJmsyOdBBlS1udrtsjHo6sYzPkDTvHpd1LyyqSEGRttrEQIICRBWBiRQIKl6gEBw0VzCVk6mCcllYdt3AjEps3p3G4+GExR0xoYgDM0PiOVrr9Afdue6YpglEg8KLjD7xq5Vm1HrU1V0IjmJRE1Raa0xutymVbyoeiuzrYktLp1fP/+2DE9wAOyZ017DBNSiGz5v2HiflbSbWxHq7od5LJZGRbbWd7t/xgaru6hGZVhUBUkkjBIYWTv/D6xQrKFgstTkQHpgmKKoRteGQ0YVXGAiFzTX/UeZE5Eld8hQl3J1k56vMVyxIKIFGkDgoNml0agnMgbRbBCiRMZkXKCKymdilVqnKqlKzPKRiWuszyo8a4R1W+1bs7pmlQ0hHsRaa3ojZX2fTqXovmZ5uiNf2vq0Ma89VMujqZogXG22npBqWyqgwtL4u0JhLqKQXM0VyS7SWjgtPcF9b8a84UCiUsKRcos13ObLIomEliYKLoniAn3iMq0xykGecSj/Z20fVoyupXZlr/+3DE74AQlakz7Bixwf2z5j2DFqEc7UeyZ6ptEEkvRNKGSdaaPryVmS3aiWMrr3aVWoV+y01pTWVbOjNhAdyZqqiIMjIYL/4CoLlqxIWjhwAddoZWB0VxCRUMEMLZQ/cIae48C51wigNi53JTBCUKUQpsbWv01blztsuEDDyZZqicgIWREU4ZAjdUNcnlNydllW2OXoe6pFfLQ70uXZTzM3PzLP/ye/ZvFThqpbdmWfK3c7seZcrVfzp/hFkv/rh4dndUEVVVQWkTNaupNK5RdFFv1tvs2rKlDExYmgm5FBUxDU5YsyY5Ah1YjUoTS9g/jjTOtH0PbCpi4kJcwNTBZ0vZwfnsXyg1HXmHaMqPqJUmlSxs1XpDQy1vMJN3rQ7qZHUltPek0kX/08zW6/39XfpaTERcJCQ7//tgxP+AESWfM+0kUwnys+Y9gxYxrURcTXNGTz8dfcJxCd0Jty0SmkpHlDC1h3hnRUMSapVAIDvOwyBcpIQRQYO3ifLxJEQEzHUiayxJ8Pk0NQTYmJnRMmRppxbkV2mC3qcmoJjBaEopihpQUSSlSyScZTu6G7pDIIk2hkKXyVYauh1HFeTtCYSZpEu1trkc/tqERqQWR3Zi8/kVPptOEDzIjv+k/Rv1+ll2lCq4sRFYSde9NHa5D1w0O7w6mJVSqDHJ7UDc2/UvCQv+jc5bjMicdMBc7OodZ3AsgtSmtqgtTE3f5YpLGEY/6an+P2L+s8YPQMFA7AYHkqs47IeIIPT9L8cn//twxPSAD/GfLcwYcUJENSR5hiGoKGxmbmUdnOQjymjdkJicjqZ536ZIkzzqJsTrireSExlYUq5Z34Uy1ypZ2UpL2oVGdiFmSrAqQpwYHDEIRoJ2D9qZiIl5dxaCibhYgODV/GnGeJc75wNBiq6Mul/tbZOr5p96neClvslkFLn9IqB4+bfDuihVxyFt83zuVRgdJ9bRrt9tNHa5CjjlPwgTtiagcczz5G8xXu7UwZNp8hFYeLM+aMykRSIfP/JeB7QtLZ3BhnejGQYVPhfT9XHU1uVIW/9bxEO70rBf7UtMdVnatjJWrPIkPUikff1uLiqEmPKObKS4OaXBoFw+OcRBR9aZsRcmSEPkUHoRwdIGJQCy8APgQADEDIAD6ArwssEaFkLEBIQ9MQlDVwygss4LwWEb5iQhPv/7YMT+ABF1pyPMGHMCNTSkeYGXMGZgUy4O0vyuajnlsZQeCgVDNBNaakGrNDRFZm7NUXEEUzNbHqCCDGKVe7oMm6dl6SaaSWupTq3ag6tFe9WgpbpLXfqW6FarLQ031Ve/adJihuQ6b52yulqZiqu5qnqHdmh6dbIwUAMvCIrMVhisQk124s19aB1GJqXgipsi+DfCQYjTf0AjN80fSEo7iQVGI0RaModfNS9MNbZhgiQANDIt4edKRpGvywVrsjxQAIOKWGiGg/ASyizUdVK4zxQIyF83hByY0I3Ng7LJQwW5D1qt81axoJ+T1MOdsYY5Q1f3vnL+Hamret9/CpYpw+KhNv/7gMTpgBA1RSnsJHNC37Ok+rEQABI6z/pqXnv/9lX9//55//4vl5lXl1CZhX//kSIy5VVz3RjboXqSLU7ZadoMIpZasKY8kRVuWTmprSx1znqtY6WqWjtjmknnDqh41UPHYXjp0zVova7jXO+olMbLqrZNrJ2j09sxzUfFb9vfMQ9007u/9SKj/Y6vrdt7q4qJv6dNMjq7p0NZE1PENq3OibmWNdpveCpK1cl20CrVQBAVmmDMVwxTcBdr67RK0XZSrSoT64UFIrBbbqtQ02CjDnhUJFLOTOBuEE3FMkltmQXRmsKFEEZ+IkMiWamGJfBlPp75vwPCjkLJ/KfSgKEWUoNL753KkxebkWyjYSCZAMjCxrI4pclz3PRA6CZkTOcpDYjATye0usCaWW6+vWvoDwxSzuEXs8JrZFeuEPRTC3NpOVWaCfY3bxd7JhKzB5A8Mhm2rGw11NcxRFTHokpJV7m7IiK3ak2Jfdxz//twxPiAFTzhM/mMgAIOsqb/sLABLXZ+Mpqn+5dWIvnYppws7GzE6Ryz/KuHVSe563vDKG5fuikfy2rsSwpl9+H3Pv///Dcjnexj+r9s6cX6X9r/VmgJNZLJbs0o0m2gRN6Q5GW2M1mg5ku1RYUqlVSb0EUkfAOTc82rsx1YgmQKAEUmfJuc4tWGqCcku2lY4dM2QkmdU/4Rg6ybnxQ7LmpUuDxsWjavD4FWCLwwDkq1vc+KmZUx/Rp2vahRpIAvu2igXOAMXASDw+JBNuQytIAN1SVlvX5xaNT1fS2eqa65UMqzpb6lalrFdEkcK2asiprSovM6KV3hwMnjaXuP8EoPev8ZZzYwFDCku0zDM2KPhmZFbntTWEpz7eL8OUikFN+sSpn7f53WkeaZGa55GRH6+fO+CK8vFP/7YMTzgBANOx+HmHMCFDvj8PMOeLeUEdNRMoYtD2NaaHVyHKpQQgcDkGRMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAMQAADQd/+Cw8FXKO9eIgL/+7////////+SI/+Ik5U7dgqDQlTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7cMTogA5JBSGnmHECEzwi8PMOoVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xDE6IPEoAEQwAAAAAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==]],
              ["skeet"] = [[T2dnUwACAAAAAAAAAAD3WA3kAAAAAHGDUmoBHgF2b3JiaXMAAAAAAkSsAAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAA91gN5AEAAABiiCZ6EUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAANAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAGQB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAEJCYAAAAAAAD3WA3kAgAAABsvmqYUODbcKyctLi0sND034cnZ0dHV6M4ES39vd8HS39vdB8i5GAKrCZiamSsaIZS03ZbqdkuSeM1uW5pOkzoXqtpuK6mOc2sZ59dWybdbBgRFppahgyJTy9C3rBORIEkKGSiiVkSk2yhp6v43VbcabZRPWjdt06TuhPO8u5iv+6t8qOnzEbKYpLvLYBAYWPQWk3R3GQwCA4veJ4qoW6lWslCpVpJYNmTLyuIAy23FKperqqoYa9RiFQWx2yyYDhZH02ZFDAdLtY1uR7pNp21bwXY0NDjEThiRWM0dgkYDsjK8Ftcz+soI9uPBzP5uqZNjsBc0LJHbSiVtkqITqrLnYTVxs828aCsM3evlFJwJSXe6rSRVVJWU0k0QSAIAZFRkPdddzGz2NvgZ/KmRkOWcB0IR+iRsFInAqESBhj6ScXGG6DeNu0SLIt4KDUyDjTu6omldNVuPNCEYnJMGjdNMRDAEPWUQrw96yiBev05tCQmRUKC1qLWYKi0vf3yZy2Oqo8Sxtef1WgG7Do4ABEv02ARL9NjsCQChAoFVgKWFOSiqFr3jYYI1k0NoyVrwJLM7pzsA5EKpW6bIhVK3TPEBIKkC6wDVQuqMipBdEWm9BA3c87qtHhUSotn4gfAlbpINBE1Q6sQ1aIJSJ64vQEGhwHoCihCKTipaiyAuAujRVqMkUwqTC1awRSVcbWY7ABxVT0j+UfWE5H8AkZwBKAPQC1OhCKHpqkoV620uXMSSDjDZ3oovM/foEFUKAARR5JgLosgx9wEokjIAtROwNOhUhEZEB9WoSPGRUpQOYd/Dst/+fXSTKgcADE+mlhLDk6mlxAegJKUMrA0w0ej1KHqlo9Czaz91vKwxBzpNSaJV8qsQz2C/VJFVB/yuAAxFIc5uh6IQZ7fr6tYhpIURYjDFWlFrrDrzOj42tJGSpml6dJoXLzQJ+vcvSdNpYn1tt61qq06vx/5L+g3kUljWJkQuhWVtQtx6UxBBUqaCaVCjqlSJrp5a/S/TbSNNXfG+lTW/486XIbyW9/OeUG/ICyUA+qjMNw4MBj3IYfrdozLfODAY9CCH6XefiqxL3cwiIzIQ/cCWrAGMxVwVi1WVG6xaBaNGFaxaHawqiFpVxBFbbJggQWAitmIUBjRpqlFNp6lS6ZirtKi2qFxpaapSTQrVUV2FFJ0iFQNLQi+egyxQja6mgbssrAKGQREnnnTn64FKbnYhky+mp+99wQoTzi9KRK7OV/1XHuya7b3Mr+S+3i8m3G89BBP9CSZ+4uIhnD7zs2KG61paPC7A4USg6QuadlbKsIoBvWFDqJoXGjwTOrPBBAQohCOWyIskbFjoH7wSvsr0JwFy47g8RjYZVk3vV5n+JEBuHJfHyCbDqun92ZgUY1Y5FmCkqiqxjomLRCNhgoSRBAGORB2JiyiqMBpG4hSSaBCDlCBwQChHmzZtkrQUPXoCMtBuKzY1L1ECNN2EVpd5qr9exUns1WVHhYidqLVEftX4eUOIeRgQkHO3SPhFtdek9QLMxCvisZ0nsV3s3YUjpvbW46UIgPcrBiAAIJNZ6XCeyAADVlXYwhboksUxfAZidwmQgCJK+EbXaVYadqNpS99ZS5cBntp0WwQ+TLxo5GLTP1KbbovAh4kXjVxs+sdNsmwcYANYlg2oqqqqoKY42K0WqzhYUEJHQwWRIEwYJep4YoNIJJEwiIi4mIhDIm2lUqGqZw/bXIrr3S86ijZJaEhbUd2m0hZNoW0XvakBoEBkFwlVJd1oPYNBkOp++/nrhKlrbcTdnJfW7u6Udb5qAku3b95O5c1NV6WJtiRRFcRwoW68NvxHHL7FlkZu75jY7yC7qwaM6F/EiTPcEEKxFZsDNMyYbFrRYw9aKviAEaACHWCnKokAuoX6zqw1AJ7qTCuFzstcQYV+SHWmlULnZa6gQj/cDNicxANjHGBVlqsqUjXFwSqGaVhNq6liguONE8hBqJBIDGF81LJjglgHobXpRjQFPVoAYVR7Xlad9CQlgrRtm7bphi7uezWSGKm0KqWarkpVVEKpdHVhixH6i0G39PDKwFZeJPA/k+UP6Em6qVQqpZpKIcQo19nlGSIomSope47hyoPA1RyhNMjlIrrF9Byk9FUNEQN6xFkEaNitLM/nvTTE2CVNlSJAFtjeFkIh8ciTYamwArizg4QjHrqsI4LQn/nS4zSiz9BlHRGE/syXHqcRfZ6NA2JMaitXVVWNjVFcGDhBFCIEQQBKNDCBo1EIRYwShLFRKwwTGqOqKpUqVapbjVA8YqLc7SdGCFJJJaqHJpHBWFTPOsLb+hNHRB1Pd3tOUtWDrkxNOdZzKdFtNEisVQwNTFxUO16NEUhJqaRnQhkAMNgOjUlgg6wCJH4NgWT3Od+UDCIGi6I3lz+RTlprBlw9VJmLdO1G7RAzuzDdRQEct9m7nr8tkZ+EB+ib1vLepsHonHBgiwLeaewrApNuwoffUBL1Q6exrwhMugkffkNJ1A97Y5azeHC2iVRVVY0oSsLY2EgYBNEA4pv07Gq6bdtW2ymJi4SJhIEFDhQNwop0tZUK1SPC/Z9WGTosW/4zA+HT/ym1AXD99+G1LYBYDP4xFJSJ8istSBsV0aVn01QnbartqNKov1+iSICVm7BnR2KLVgsKVCOFni9awGDw7JZ4R0/fvkmqAQpBFnbRAE/I4E2r57WQy91c51jYO+aVkjSgRRzbNCVTb43ddDudsxLexBDoKACyoqaWrBG+aawzBZF1rGLmMwKLfts01pmCyDpWMfMZgUW/nc0GMMsOOeeY5Yq5qjgaxMcncCxxsUE0CIIQE4/DKIRhNIxzgkgskSDAEDo+NmiAtKqtpmcLBblqlI7EiozoOxWKSlWnulHpFAPVtkSjuF9FwTaP3vJJGcTEM4ISxipVqZS0nWp7dNumgGqqUtMbMpI9//XSPfUKqQCL8HmBANUSpadMg3rlniw9VuJ62YoQxZim9BVUpADyswTogIk6PSTVoii0iKv/Q4ru2Uryq9DHQUKOpkoQNmy06T1fpxYPnmEDzKRmntN6Dx0A3micKs6OY9Ej00m+RuNUcXYcix6ZTvKdSTaAMWaVlZSrQpBIHYmNi4+LDXAQijAmNiYqEKAwJmGCWCkMjKIx8REjeHTm1at4WQU8L6uAKL3oGYGnbdpU2qbb6TalYnvLe0agntovKYB6aWKRpT0z9H9QVS/1fnWMPLqJOvV4me3UHlisAMyPbmBevRLomXnxYF5kXgRUimq6nW5TYYb9IgAQz8s6pOAlxS2LsF9Sd2q5aENbrNAqL6LMNuwXD3ihLQL7pa4CdwqAeRGAFwA=]],
              ["SpanishMoan"] = [[SUQzAwAAAAABXVRQRTEAAAAKAAAAU2FsdmF0b3JlVENPTgAAAAEAAABUWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OC4xMi4xMDBDT01NAAAAHwAAAAAAAABBdWRpbyByZWNvcmRlZCBieSBZb3V0LmNvbUNPTU0AAAAfAAAAWFhYAEF1ZGlvIHJlY29yZGVkIGJ5IFlvdXQuY29tVElUMgAAABYAAABwdWJnIHBhbiBzb3VuZCBlZmZlY3RUWFhYAAAAIQAAAFRYWFgAMjAxNy0xMC0xM1QxMzo0NzoyMS4wMDAwMDBa//uQxAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAlAAAqlwAUFBoaGh8fHyYmLCwsMjIyOTk/Pz9GRkZMTExSUllZWWBgYGdnbW1tc3Nze3uBgYGJiYmPj4+WlpycnKGhoaiorq6utLS0u7vAwMDGxsbLy8vS0tfX193d3eLi6enp/f39//8AAABQTEFNRTMuMTAwBLkAAAAAAAAAABUgJAYuQQAB4AAAKpeDRMwZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vQxAAADPjNZHTDACN7pe6/N6QAAAAAfXmZmZmb+HAkA3AmAGAGAcD5PjYAYWm0fsYTJkyYDAYWmxMLJk73xF3d3f/72eTTv+7smTvYgmTJkyYDC02PT3/34Jk7u7u7IEIBAEAw/rB8H3wQ4jB8/ggGP/lwfB8Hw+CAIaQSAQwJwZwNAQA4GA0GhLgDVxg0xeQbEAsBhYKtxXLmXWoKATBghSAylD4WLmYGNgCBmdiZlJQcN4ZQuRTW5CREQBTDjgcEBI9nzgSuEKHtFMiiJEIGhBgwvySBkx2zUDdoafQMApNBicyQ9iUMQUzt721Z3EXUmWUq6T1JAA0jThEQV2aZ+YcsVsuQNTVqcBEi0xUAlUA+6p6OWujFJVNSiWzeMhhNLUiAKAqvTwIgbXkxEArFkx9z0BTcjvZ5WZZYytZy3d2xBTaQV9/X///J7Ebvd////oJmCjfYuxdirHZyRaYkq7AFeLdGPAiEzwCkHqt1TTSGfYtURJlrdGXQ8WaGcLQGrZnZfl693j1cUzr0zjcXTXTFtbxv5z4N/Cpi+Ke+r3gtVNX1bf9/TdYO8Q3VM21nFIFhvx+MGLio4v7I5UOkDu73MiwhqpmU23AAJABJCoRgCCEiGTYglK4kVthZe2D2cNXjSDrIW+eyG3eHSpgQJP0NpdNeOjYDZljMJl4/sY+1yUXJGyxmPGKiE5oKCNMkKQtIlSKLZGVb6+Jau+xEPpJwYpmLFneIf+aXTXL9BBF10RVoinNzQ0MmQmpQAdYuiBlLCkozXBGCsjOIh5oGgAzQJeXhaPIFOebmoWZ6jVHSDAkjKxlknfD9adVs8pFvbMT/y2MlJG0VJBL6rQ5a1WOd4unTOrGyN3MuHa6Y3UCTi5G60mIZT1hC/qFl43xAEKyp6cOatVqUFMxXVYBIY88lMTKlJVGRVaWNDbK6adStM5hB0KUrVmlMvz0hYQ77eSjdKMJihfNm8HV5xQLggHw7dKm6SEYMR/HuA7AAsc/AYZvi6Le8FSJhQhhCgmWCNh3vjBTm3K9cELW1weWKq2aDISBumrA7oBhBk485JolUX3ZcNJTRdkvqXrn+2Lzsjo1eSrtrumBZXA5UVsvou//7YMTzgA0Iv3/dh4AJyyEwvYWahY+jJlqzxNVaztRNVGdptwhxzHlE55OTYGMeoQVmMvpVpeycDtSJss8lunGR42k8363aP2idz2xf2GTKIYurd1FMTgbRpFOAFU8CBjgIFMlJAnGleW4UovpVF+Hu9xQ4fpgo3X8FhM9HQnNUGgrlrTdIsFWs63jv0ZumcMIzYV8eCkDbtvFkyp/8O6Mf+bV49YAJ+1t7/vJq12OjZnsSxN6rD5/0rFv/RTcvLAg95lq/1/YbhojSCSAP0wQkGIMIYjFQARY1M0IsmF0K6LwNSWZml4z6cLYjQktkVmWXCoIPNKIYoRhDfe08mTtAiRbZzP/7UMT+AA45DX3sPM1JpSJv+YSOJK1uGsbocyxr/yl6n/zUonla+rx9kinXwD5lduOP+IUXH85RQe/lFMZa5SNP4hze0URH+Q3H1OIDkcQgIAgAeMu6JWNeDhDCbEAA1Il6Yw7pDAIFZKyJ5wXvfWSiQss/VuOlQUsswh3o8RBK801VPMnVYAys031owGXePo/nWv8NaUfa/zGLTf0oBRsIPUDYyXbMmp3q3JEAevibDrPheT3zJ87/k4/f0gCQ135tOz4leq+msggGdAQgOsj/+2DE7gAN3Q17zDDRScOhb72HmbkkEByRAijWLYm8A4LHBwGPKPilrB6RStRxTDbN98ykrVxoUaXdl9ZppkERSpzmz4FG86HY0S1nBltqOpH2qUgUV63Bum16hDjkeitMnv0SIbJ61i+3WPxq3R+kUX/ILlI/9QxLK0vG/k9kHV2Z6ABAOay8IWISATVRmFV1xpaSTQRJ6mpNeiZevxoAocKIffCri1g8yudQITQBuBNxZvlShBXf/gBRCAH62sYkpBwFsce2qzwFwj97w3Q0vP/nBZM+a4q2qmb6zoEC9+oUBOv2kw7fmpaRv3KrT6psBENDPYiZLWyySfuplUkvWo+zugn/+2DE9gAOpQ157L0TCfGiLf2Xrpg4gtIBwBGKmLZMUEjpUktLAQpiS7QbIYcTOsrGbujM7A+1/O0k0uUEfIvtZjcqfQ3APz/KgCmRXWkBDBYJbqBTCU6QKJ20FCYM3H62qW/k3bf6htP+VLXLHuLPmMmJfKKo0nOUsHbfXw+iDvbcjdU/Q6wKJxwAgAb+WJekpyto6AIk7y9jJEckRgDmyZ2MugZYZ4gMXPcy5KhAYPXMZf9mcBJ+hQTeu5aUreTuG8WjA1NU8E7KPRFwz+PfWqNR9nXUJQl3Coy+pQatRTQJhjzRb2QDi1UPKh5uZGj5jw09TI3Sn4H3CBJ3ZYmgAWXPL8D/+2DE9QAOGQ9xzLU3QhQibn2HrjRS8MEIJc7YyADEKFHghUbTeC4G9mVguf/6Q7CTkck9BE30ImZBnrVQXLH92qzkhja9IYApKelJYIuxXz+D5SCOGfrmwJd7vOWo8olfysZz+oPl/cgqt8dGK/zREIT22YnmVbYX/dsSrVvLbb4DaBwIicAAPFwMYUGEB5SFARigeAGBo0tVHh4qgIjmZwAO6bwAUzb1uCEOBKNUbwTuA07f+ED1JvP6ZOwdVq/yAumnebOJfxLYxiPs0jgpXKgfjr6BIGvQMij0VjtS3j+WfL29Zsi9U6Mj5MT8wM6kXktVf8L7DDqXXGQwA+qUIZkoxfT/+2DE8gAOXRNz7DV1AcuibbmWnxBEsFHdQ6FALzDSrCksesRBoCj1CGZvnyG6hICITQ61WSCpSyjYkVP638EISVNtd36HgWwovSYAgid9MNID3oIuBdkHoDgA5m7qk4epQ9zH8Ab1CMn6k38fP/3aIxZWoOGPVkDDD7BrgwCQAAAGP7aKIMgouGKMGiJy8zotKSHxoGSBhM5bcgGD1WszMceuf/1xg4eSLXdSShCIO5n/wYtgSHT67pfQOr3v/KoBKDU/54tjHASbOzjQpkxvuH1IeApmh4f/xtndv9XY6oxT5frJP+WTWGq8MqYFjp1QVH97+w+gYJ8VqSlnfTLI5owD8fT/+2DE9wAPGRN17L12wc2iLbmntbjNkrPHJT5j+QcUKgDQKJ4un2TESoKhHG1DSnyZtkoIIQ5FKNmGhUJ2XBM0Ol+9hm3ZNWXZ/bqjy9Jb17UjglSq+cQQg0H/4Och1vnwRRxfr8utt69nobcTX+D5Q6N/9HNbf+lay1/+C5tdIVYLKwUz5alKtRps0STLFv5ONVtwkPd5pzYTfJfQMDNYAgGmJIwV0ylpJkrmUvRP0aYOYKSEBw/bliOAwzgNKPNyX8eBZqWrevNQzDPy5NJl/9YisBK9fXZ2AQm3UK6XXtLIX1Ps04OsTonywFwhdbSICLb1qFIlZtEfA4E9RQGiMVcgGjT/+2DE+IAOpRN37LT4gkKirLmsLjjFTABwsb+civ40f19FAu69z5V/gdkIBlwAECqOzdHEzQ4SAgCz0IMslUjEwAsMiEaltfqAZNasUBU/It7YmsoeP1Yp6xBQThsutZkH8EMP6yKgSiFvUXyCNzAWo866RBRbe4+BOpt1lMdnUQABPx8Li2jwUKNTEoYvkALepCzPEgpjk8bHqmWL3+HthJqkmJBQB3kzMWLFFkA1YoOTFY0JKlzyScrp2MtRXDE1ZNZY6rQaumv3WU2hxk28srKriKt/HLFhCO3LVjWDIURZz9Ah0qCYt6AoVOfNFItTjhvqLk8QGr1EUsugUb1Z63gUDWb/+2DE7YAP9RNtzL0XSfOirXmYIxgfJFe75EBfhvkIECmBoDRBtARFpMEBWs4zoWXFCEWVBBoyWTW9nUA7tShYtH+sOWCzRVQRBrLW1AFKKD6icAkCg+VCWFiSqyodfOh1N+eFgTbqhjcRgLndBqejYRFXPd5Ag/CIWu2hC84wShImPUfPfU0WIPoGqDAAgAAA1GyCCBkw+Q4DNARauaIEsBtFoKRRdhOP8ZELzmj3hzL/P2KJH7y2d/8ywCWZfjbQ6hzJ3/7kCTtv39bQRVtfeM/IhXzV78M0f27Z01h+OWtbbVY91/JGB9GRT6y+UzJ/0kJsZGNfS+eEff+zeZL7+U6abTv/+2DE5wAOxRNtzMD1AbeiLn2Do1jw6sc0u65o/tb5hR6KP5HLBwJoQABACOdkrCYgKqgjBjxLC/ZGIXAmMiCJgISnnA6mslGDr95b+4rKYg87S9ZdJTUUsCytU6sLYqzMuB7Ib2rnBA6dWLUOPzorUvvsShW6kB1ldtiaID7E2VOjHNZ+mrtRU+sdJMFWeWPugaaA5I4irMjg6BmWH1DEAwMAAAAea6MYEjCRByBkhHEuIgAWGgqUAITAh8c8DrcYGX1YMwIyxEGgaUxa9Ay5AfmX7/O4n6zXLv0OQc6mx1Bt1BkflzLGtfCKPx29vkND0q37wvJtN9Pt7g+BQzb8pzA0D7v/+2DE7QANtRVxzLTxQiMirHmsPbD8QTcAtLXpriRl5v9dhDVOsfTePtY18VUodb7/DCT8Q2b2rBLfP/4kAYs2NSUiVT9w5wUAJQAABU1gBArANnGRyAiTo8ltaULCkmhObRRIlEktgSmfK1/7dJX8WtY/ksSBO//WILMq4/ylCxTQuf+1gE4J3VrwiCJu//lP+Fn/BII2P5XgRaq+yEx+Z8pk0jR+Lzd/wI8rfuJo7m/BqWtrhB6kfw9aPs3lPgOuoAAEAMrokMxCE/YwCSh5PEiU/BgiEERRjuUMZ3MCzM7//p/Bs00IoQE6PBgtjMPiGm+wy4XNpLyyLOIqlSdhORx9Q5D/+3DE6YAPYRdr7GoLAliiq/m8Pig7l7kwXyv0hSAfZPnUE18mypVkeUk31i1ptqkWNj/MTRxHIAZfR4xruIgvgaUGAG0gABYKuRLOc7gNHICukQC+LqaBLwTyX5pVZS50iY+x3v3FFgqHRSSUSGGChyL8z5cGYQ+mcZQgA2i7/yqFuN/Z+actYWMC3s+NeyuCVz5teQvyD15aUjtXZF6iNzKorH45FVaBH4rYSXt9tpul2kWMV7xtdVcGp2Rt09gUgABBIReXgDCrPyUWOj02E8DEHWLAwIKshcDInsokzEn0x4Ot/q6kes7eu9ghr2/7nHBgoyfLP5hRogqa38KcI2kvarY0F+Qd6ZoLAL51LbSgjHM10rhkoj+zJJYVVy/E0yvA3oKmLk7J2OVaTNzNlqPrLViy8+4l//tgxPKBDzkVacy9ekHEoq29mI54RV27mQJ6W5eqZltFxwpRapgAIALluMBnQUnLBGCFUWDHUGZwrfBxIJNYjTJgruTEbMciCpZdj3SmCX76x292TixEGvd3Bui6alnLVddxpt7A6ACWvz0+JDt7ngOASu+4NPiuwxE39Hf5Zw+90J8GNd4h8Yhm2c7I5Boqs9Ka5ScbHCGmAbYUPp0LFaKFAxpilLNO1EEfwESUBYPMzJZzYBoXXaKfhgbHBwg84gCvMkTBqVXB6GAWp3cDJGS2oTwUy0/lSpHxYS8VfQaX1EsijpGoudqDocxujmaygbbdx/zC5VanHEjugPig6o9itAYz//tgxPUAT7kVacy9dsIYIiz5p7MJdpAAPK4GI/jomYjigKGXF0gKR0R0RBCa1SuxB6oiQohbNY/8kLWCwyJNduMzFQL82st3UESP9N9rtcRhlp5OAaheToRnDImiykSmYNxBjR1ZUJmbPnR6lNeokzO2kSqOxwfzHQkwjs+dSPqpLPJKtNEFK1EjQfmDCAAIAAYsZQWUL7ZYGCxcY6YNTRRDgFmw8Gi30LhCeUCwE/QNLgcVPJnKH3IAwWBRYBjEi7TmFBKe1+klNgLg4Cu4lCL8ExkwAhFn2NZ7EPFzMdymr1gsqxK3c+LGwKJ85hhIRwzTYcs0lZ/wVJX8gq3lQDOZnNyx//tgxOsADi0RdeyguMG8oe89lp6RYFyCvFhlwuT9VRvs2WdPAGpHnbZuqG0P1ZR1ZS6IFBQd5Zy/r7jGfPzCLRTQdQ34szOdcSPej5TVCDSYqWigBuVzUAYYPLC34BBtMsL6xAVDJJY7g67WGbocB4Cd/W5cNDiFP0vCHKBJsOovbgpx/Z1eh8h2p6B8MpKxestp6zJeyhGikzKMRFB5XqMR0RbTSdTzA0MOtYrPrc+bK1HKT6Bx9ccBS7jjNlP8FLP8LrgyG6YgAVSQwAAEEI7tiWoQ8jEIwAdsuUdENChxrMuiSiwy4cRbU8d+6YKIMkeWwLeWwLaeUWlF8JOtb/kI2FYL//twxPKAT1UPbcxpq4LAous5vD8QU47qpgXoudP8G++m1nLehEfPw1AtVbj+8c84tfAYYLRykqWX6IZlt/JoSqr0oqL42HKfCBMn9QofuvjjO3V/ZJUBQhCAADIBTGAQ6aCRLVhwsHPUIC2pgiKexQIAcciKyKdjzImdjimzzO4bYi0FwrNN9tXUzXj+4DJklF/z5WXijS30hqajxaZyrHztZusTscq3W4DRLWepTmCKNbP/XcfWHjdZAXfYhZA4Q7fbKQj2/zg4XHW8NhiNVN5wLnAgYllM+jzeIcJR+JXGWfWLTBj3SeIOCmkBNWigGqszcowxgSTKal6jIAaRd5xJKTc430PrSWzOY33YkxIBLNblmVCtlMnVWG6aPDiZr2/z62N1YIwt0khUXvTt/O24T3Zb/TMCsP/7YMTvAA7VA3PsvbLKAyKtuZeuoFe3rKtHlC38/KWhYiXeE1xr82B461ayYe4+/ZwWyEqPkMsvBGCmSnPAxkL80i13NxIICi86v6fXCGencUUwCZNoBWWoY+4MiAaj2LWDq4LGBhClLNyxac9DgcPb29tSSEwEvlTJYNUUTEw+53ACjERlPdv5uimI62N6rGFNJbf1TuBBt4KAjuzBYg/AROQpChXqMNvQPN0CBUZHIBj6qCtqRW3wWRDjIpDdfD7AS1Rpk0oAepMXNUhE6PlVwwBaQ0x3EmBk0RiyH4izNXaCAmil8aZ85IxBAMB5HWzAAM0p4T1JkHGbm+2wTwEC+mZ37P/7cMTrAFJdE2PNYe3KHyFsuaeniaCuk3/rrd7B43thQeBFOMmDgqXuHMN6/pA//Bp1xaCBds9i9+ocvj2OuYcnCTqV5JzeUYyDpgglXZEwBZo6BDGA04WDExpgDYd93EPUqLeDgIqNzJRS+n7IyEaEDR6nOeMhi6i51RJsTJNu9kPVDyJ4ZM3dN5wHAj6bjCU0kYifA0Bc2bRThGeVgaS2zhIIiuzocRc6EN/Vqm6WODoWFRdRXcPx41hqqWKCjtTprC5IASJRgCPyNBWoAEZ8BYg7UROYxEB1SEQKC0DF/WtIeBcbSPnH9qF5Fiv0i0uFKPbwobJrB9zsDz8FGFp0Y4rePHjf/+EzPPdv+Wjr17oO1+0wzSblBKCEXrkEOjy0LwztMY0SX8/6LmGyJaUs+lg67IGSomv/+2DE74AOlQ137Jy6QeUhr32XrlmI5RgCNREQMIY6giQ5KrAY4Aw7QfZXUbFRET+bbZjDKSoRdtBAvG/y15KQ7UlaF5zRybjybxRmowM3vQxk8yww3t+tBshCkO8nb7VNimvSrLdc1cN59K1T42s5P9o1iW676GLMfaV/KsHqioHYjCZmwN8JTQyHC4gVfOFcigxDL09PZmpc+atEDy5CWQEwLK7daOL0bab2cDuA/faiAIeXrzSLl7DvfHHuwNMLmK1yNT99ugaeR3+N6GNtu1/DBTHpsdIG7PRlGgIhYpjtDFCBUM8N4MQQrngkJ6qMdJA1IyTJKcACJqsEggICY5ysDi3/+2DE8IAO/RV7zD0RId8iLz2GGmlEfXywaOAjW6OvAimIQKesXKGGH3g+WZ3KGIxWvd11kYEsGGAsBsdRX8IiTdhQyM2MkFp/usSb1tpZvmSEx6Y5FCGmM2fTEEEHRJkGiXR6nS0oyfhTlXivQHjvjdLaohKkgYhKFbwCD2VAYIilnhUozwRUgOKEy9rRGgKK60Z9W6IEs49EUSwJSRNJmQyTzGE4Km+vLlWOpOKo5lZcc8TRoR7tsG7r7Zkv7hHx9+662QondJyaEYy/kS0I3cPe4hlY5xK2imHbjW5pCqpVhjcSEoKwOWwEihYCDAtrYgSC0uVIIDFgmUl9hAFdihsKrqX/+2DE8IANORF9zDDPKcchLzmWDmlo/y/B/sJlRunshXKD0Xx9BgHrolHxYa69ck1Ny5LTCCn2EFU44ByOx8Hf0UzjSegfMpW0KFWtx3bkzb1CUwuiy3CjXPYYyXQ25UcO7HxVyMUjkgQlJJAGeMscwQhLJSw25BKO/QjwDIRUURgRufhtnsCEokp5V3TrEdbvPybJRvzRXqNeRnkX5phv5kA3plpqCfTZjU0dadc7cb2dsijt9uVGHFuOqYjUNOOnLNZvJKsdGae8aIVNMRrI7hhbslJbQIVlEiQZSUABw4aX8gZskCJGp1OEhIfR4B1Z5yad/VnoI5fhrToEFEsRrjgYUbb/+1DE+oAOaRN77CTWSbEh73mUmiEhLpvnU1CPZW1haMKfBmCjLCuojze4SiPkrwJklObNOi8Pz40c6olkz5lkubuqlEl43sc5pICiC+SootOkQOakO2FiRc0EnACMzy1i2cdGVhgOBCgNuPipSJc/k+sdXYQCpr0r0wBxoxR2ZIJBjaiG6yNTCQB5m1nxhLFZ6IzJlMXXjdgfmfzLpN3C7rsgInGaCP14dAmtOMdIZc9PCXyshC5ySC3cjHSWzgqYy4l3hgRBOppJQCGzIcoI//tgxOgADmUTec0tEsHGn689liLZluXtAQUy0MAcp6n9ChS0FFlA1RYZVKXyGVfa5ioomTF0czVIS1g9ARQ9tlkMYnkHsHyjqvHAfdbJgsD+I8FW9aOKjKxkqunAq73ZNO1P4lrgdKRcHK73HqeMUtCxFy6JO+ZT1TrUFCoiIJCgAO+sdDqLNdwLBJzPYB2NDc8QMBUxokigJHtCsgEW7a45ktwrKpgbOH1pfIoG3+uVgLBH9/thVE1fYsBAxegyIGPjvLd8YMJe3yg/MmuEsYkFFD6j7SuFUQnbmYuoS1tEuIDkLI7jKEKnaymFDOqqsqkGNTaKJUANWAhAQ4wOQAgQpMGw//tgxO2ADdETeewxEQG5nq99h5oZW9VAycy3KoUIIcSgdxnEBFVymnv41l/4aVflSbsRBRaWyavNpR53ZopNjquwgRDaT2uxaymTOivRmTk0hroopx95yf+xZaUF2xxvZrPx/Ru3MR/bWxCS+yTOuCTZZ9L5AwxIRjoz4H0jbIUhUBfUtkhy2WQZgIixYGBT2ToJgQtrLuLGhpqx6iDUelYOGjDIjAiHYGDwwxg6ZNI32ndtZ/3mLvwW2O6marzuGBcudrctcvVxLVrcvX3Xbc7PD6ZpaEoaknRW8sIKP8wxSMO0P6ZOESyrLfF7kIc0EhQEEBYYsoUeOgToLPsqEhjhAza6//tgxPcADiUJe+wxEQnaIe79hiJRWePQrmBQwEgtL2WBKE0lGjgslSbnYio89BNkDfm1eJklrk/cy9Tkk877QXFXLnopHX8lsUgrGJbnRj5hR7xleGbHPxTdvD1S9PuLZ4ZexY0RBKxIYhgtYArw7YYADRiAagrKRlYY9upaFWNPMeLdBENQcCg8Lg8mxEU24T2YrkxIAk3SpddEek1p75KdnnlnhbpJpqN1Lrlijm0s60I1yqxo1LfcU6JhdpLbZ1EX9/zL8d83S2NprLL0oNGeD5eEKTMiEgJFwBFMOaFRF3F2C0WSgDpXHStIVKtRRiPCIBwTzHyQYIQFgbn7zdzBK5G1//tgxPsADp0Peewk1kngoe85hhoxiJUzUOaiS7Mxp9LVbHKlGoTWkntg+jGDRpkVRrRbD4u7XRdNjGHycYx5cTnNFur6pdUL2TZHIRSWYdEgzUBJBacALbpBBhy+DADGCwVVmCC7gkhHFOS5NIQbqLViBP1eCSyQDHHpkEDBMWfqzUuLPNUpRBUOqJVD7sfe3KPRkSSIp+UKMKuiriJXkTrlmn21sMpNPK8dozzM6XJggVSVD+H1m7cIN0AolqBmwUmJMBg1NAJGDREZZdTSFjTV4w65TTHcEUmAfk1IkJ2EBIgBtP5Bi007vD1Eo4gAlUvFklWspfuompIKPTkb4XlNX9Rt//tQxPyADR0Le8wwzKm4IG95hhmhNbGHyjv36eHbBZZGXVHxjNN0mchHtGYENPdHn80pcVROyoIJEouAKsJTS5yeDmmW6e45xuiI9LgoLZGudUzSgGlkHi0eglUnIJBEQ7aDA6EprQJQigVcDkEnHF1Lg/ETcGP+kcQ2xw2BtUb9o+ikvE7fpk/9T+aSHnWMv/lSxRj3U4yX/y9zldvrmILqy6cahTAGiiVAEXDHCRlSVMYc7jQENJ19qtVMJBqoULMGlQ08LRsSq9ETUKK7vP/7YMTugA1Y+3vsMQ0Jox1vvYeZGOZUpiGKJnK7Ye86bPb39JjWd7CaGMnTRyWG7q+SIp+WaHlsZg2OAnQ4PAbG1mUouB5QBYYmIvVvlTLHTKolUCmsA9INWFQpUDJRGVTAuujopESAgunkux4HiqHyYmm5g5ap2bWyEstn46AXJH3S2KJ0NQPsc/h7mjXs1u7tanS8bkEsPJKujuVaQ3y/yXfLXeZjuvfGwzIF3/Tk0VnEdOwDkNDw7VWrqipIUjYTbmAC5wqsmmJTBqQAVBSVl7phpKb7FIhabIyORHixwVkcaPKPQB8sinzLHvfc9im4Gk4YztLSOEVhVvgRSCG67Xz7NP/7UMT8gA19C4HMJM9puiIvvZYZifTOB00BxkGtGJxtazn6QopbJJFepvcTqHX0gToyQID8QZCLtOUQipqDhEUjhCSUAKUj1BVRRUQCMoGyNhBBX9SubVGeXNapWH3iFMHxqDmRNGUiYSj6OoqERTHQxaswGqQCpwQOBiwCBwSOE0MjEgpYphcMoYwe2oXU06II6V9znlr2kRe5LTgZLcF5jmoqmqk4g2U6ginQAYstGCjIxu2VUJAmcRcaVqcJkjIEHltTj2zU83Ntm1hxTOH/+2DE7IAMzP9/7KRvibYgcD2GGaHH5jhP3Fgeqmj9bFLl3nqOOMbRm215uI4JR7kUGPK4+yvecgzcXLOcfMovljhVGMGz2DxkhNRGhCAolsxEPGjK1Ezbo6mIIyEyoAsCLFR1KB0RlZB4EAW1yCgGIoWO+wyQsGfwcmPkZYNG4qIxR1miaK5HHcuGt0hadDVl57bi3GHPklOEPLTqzcYrXJWSROj5WPmTVNMGiDmRM4KYtzUzYkX1BA0hkYtQQ0UMiWqLrjc1IQhCaTAIirmAwRpI6SBwchQVBI8Kwj3J3yKGYGoGohEwIQSJw09yl4wwLPiimTdP5TLLKGK05T1issUCle//+1DE+oAOEQ+D7CTPSZ6iMD2EjeFRSqa6yRVp3nc9ESWKI5Ui41M2+1oIt1hjQw1crEM4CZtmGQUORTR5h3RxMxFkAFQABGMIJaWWR4bst0VOOldJkUwnpyzgpOCwO56X7iQklRyZS41SwnM80HWSAJLkL1A1NpZoJz36Ewhu4zN2e9+Y3nTlvw07G5OeKj21Zs5eN6vJyFUp5MIMZBlaly1FVamVeWUhNglJ4ALjRrpjCBZKSTykgUQK6YiPCmazW4JBHFTfrxOUFB5QvhsW//tgxOuADaT9g+wwcwmwojA9hI35cp754btM2axcMFOyTSZOwYTu4xpy3h7f1p20/dr2b8xeq+x27tyk2bY6Vf//o/MlC0yAdU4VLPpLMg5K4h3WENCFgawR1GiFk5WiQ01MEA9GJuoqdE0v87rwxS43R84VFH+h5VlePhsEkNjaLS1E+STlGg7l6bdtsFB021WPOHqRNAhwyhCkR9xYKqamG9s8am45YIbQRxfUMWdBJnBBn/sMYDUqAAAAmIjcYSA4ccAKDDLwiW+ZbPJhwZnjVWYsNqBq1DsDjMinkiP5gAEjJIMaBoUFQ5PMKAzLSk0sqMIlQyOMkTDLRAzYhFEw3w+N//tQxPaADTD9gewkb8mboS/9hhmhXJzEQkIci9xhySYexmAE5QVmhK4BGzXBwwMdMKEg4vAYaPIpkZIBRI2QoNPZACPoumAopiQSae4myJ4BIDJ0QDSxjxcAiwDKpIBhUPNmLxlOMGCxJFMgPzRDEEgxmTKYiFGDk5pA0a+pmIABrAyEMJggiMFJhJ4ZibmwAoGEAEomDDBqbYYmOmMBZgYiDgwYFChlFQFFQeQhQeDkwcXTeg0yIeAA2Zkim2BIUPizQ6gqbl9xYTIR0BEKAf/7YMTrgA0JF4PsMM0Bn6Gv+YMOYYIBgIOCQuZmgGNDJgIAYkJGRkxkxUBlQwwTbUxIGAJuBhEWBi9hMSFY2YYCoOlgNY+9zOodF4PxBKOlIIfieD/Ln/5Q4EQEQEOCuDOEOPRYEgQAMAYAmAcGADAIBjpgPGan+1XJ7F8jARQONAcYlq4qmImibqZNUwIcAuBgE8av44zmfrFm0pjIqAGGAKgHxgXQJmYFCGANJgQrAGTADAA8wAUAWMWrGSjApwQ8w9oKRh52nRHQEYwAQAuMAPAIRGAVGWfq9hkPaAwZ6KRXGAXiVbdGlQfGQIAWGBAgFRgEgAQYAUAKGAogDBjG5BwYYv/70MT7AClVGUp1zYAnub1qfz/w0MSqmECFmxivZC4YXmKn/vm+F0C8oBAICUAALOAAAfMJ2BfDA8gmEwuADfMQXHIDB2RAIxIMLq/dLcrdliOqYoMABUMmvsmMCEBsRQALMAuAUTAcAIsKgCRgCYB+YHcC8////7TTYKYAEAEJmPNuDpYXPMA+AwzBBgJ8wLMGgMBLAqjArQHgwFsBmMALAVjAkQGwwDwDX//////WM8zB04muSypLNyzYEADTACACswH4DJMA8AiTAdgBkwDEBaYiYACAOGAVgGAVAEDAHQBL///////SvX6oG27A2/dxe7cGCO0xC8xCMong0AIGgAMwBAAjbCYAEAFmAFAA4WABwUAKiEAIVtTsMALAFEtjABQAL//////////Pmee+/nrDLD//////////2PF9lCgAAHysuaYAEABoIQgABRmYCvgwAMAKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xDE1gPAAAGkHAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==]],
              ["Steve"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAEAAAGkgAISEhISEhLi4uLi4uOzs7Ozs7SkpKSkpKWlpaWlpaWmtra2tra3h4eHh4eIeHh4eHh5SUlJSUlJSioqKioqKvr6+vr6++vr6+vr7T09PT09PT7Ozs7Ozs+/v7+/v7////////AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQGrU0AAeAAABpITgWtsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/70GQAAAHgAGF9AAAAAAANIKAAAR6dk3f5nIAIAAA0gwAAAJd3NFIRGkKybdQgDCyhyfE4IAgCDigY59YPvLn/Lg+/8QAg7BAMcHwfBwEHf4gBAMeUBAMcuD5//qBAEFZFWKiHWRRiEyElSkiW3bQ6AAinustEyE4BaCLWlgxZRUGDiRT00n0Mh08OKV66IhFGA2ZGBQ6CgMZpW4PIk8/zatEcZhrmo9NQm7ikG2hqWJbNEbabVLMMslcgb+KR6RwXmwGBqfFlkcpWYxmNPo/NOwqopg0aLzUljT9xR/4Ep5nCBZNUh+FyyLS2Zd2WSiJ4SG3BUVp567Ncs17Ts24f1ySUETp7mopfdi9hqlrwzRzU/O2JRIIlaf3svrxqWQ5J4/D0Pw1levyTGPxmep85LGZVO9wrUv5TkvnpdKpungJ+JPVkHdfSUVDciVmxWnYDsQwomP+6p2RYUGgU0bCEwcJggNM15YcFELzLkaekCnMv9zJc0l3sYB7POgxKGLLnk2QxNkcb3vVa4ktQhJ7GnePd7m7WOOuVKErlSonZt96KzpRprnPr+vb9Nu97J6t1yi2VHPdbqfcN6ut3Nw3b13dVXf6nXx8+6O4nq3K1+9BPIJy8PMMiEQEmSoQFQsvCdC4OJYw64JHEg04X3DCyIN31YG4ONBLcG2i14FmgFn0BuyGvxdVCe20nyvlnpxVVQ29k/QhIUKwmYdaVM5AxAxgxKxTeAh9RCBcEHC7IAucF6k1CqwcqJY0DVtAwphXTWUKJzOie9AQriQFl0AgIgwEpSk1ON/QoFijIYcOJZ09beARgIzDaSYiZRUIgSk03AW9hpiAy0hIayGsRdIcicxGsCPbY3VfmCmjNOlzQ523AgWKCBEvNSShAgQLxkmWkLqmTBUBIhmSBynQIHafOkCAQmfqb8ws0vbomaiYipHTkYpbzqJIuTnmIL1iytxBKMnfGFPO6ij6tADxp2YPapyV1ZcVurd9e+X55vjzOX4h+2oo1Qx8Xrm9pE1NO6mSRILcpsiNbZgGGLoEUAYdI0I2QgABRJrC0JLqKlc50x6EoXk0zoJNmm0NsxUrV5AYK6HaI9WQNJWrNUqwVlS61FHX/+3Bk9wDz+Vve/2FgAgAADSDgAAESjYdp7KRxSAAANIAAAAQ/JEp0ok3ecYlVZ2q6pJLWtsap87UFulM6ztkX+Xk1R8dIq8wmtIjDH5JrU14jP8PxNt0mZ/m5c8/drTs3DGn9YZm25evSTTrFOpVmq4d1IyCTbbuMwjO0nK14HlRLAhBgi9QCss+XnW2hwYO4LdGVymBBERAJFMmAu4Oi1qyNCBsvH5J5OKSQxbUnmUVxuLZ3YdLRbgULFJtq7b1zvOL44j6tamKCCEUzGD2A3YKWgNzhUPvLk4cUzEhJUJDGiE6Q1r2eM2ZE4deDAvEsYhJZK5E2wtLhykDEr0MeXo4b3NwzGYgEnJJOLiDgiVwRBJcWKUIN00xSY6pWhPu6QjCwBrbgjtCTGMzMT7MPfePZGplnWGZg//twZPeA9JNa1/sJNDIAAA0gAAABEkGFW+wwz0gAADSAAAAElUj9s3AXG4F26em53lsP6v2Bcs7KhrjlgTKiiPZ5HFSalw99a3YNp9geeuNQoc8BzhNCvhxVdDpHYVVEeR3U8SHJDhPm+FmF2bO63lgTPFPW/vfEmay4iOU2KX3fWt/4vj3zr4/3b1tEjzUgZ8SLiJbfxu2viuIycquvd8NpI2AGg+n10WhfeMZBh46MyIiyhu8qZWJGSFYCYwNVhclOIGwumBUFMJEDGhAwYKMkM1ejArSQlJB4SDCEC2qczAlQlwRIFfDPy5ywq9pE7LvF+BIkvqklHF/BZBU6nbpKHpboMLkbispSocALhGGEthg6zk+Hhd5xNhUAmJoXnYOycvGPCJcTKykkHLi8gfqNNBgYZLXOiv/7gGTvgPSdXlZ7DBvyAAANIAAAARXBiVv1h4AAAAA0goAABOoO2O+la9iY7rL/YYvJk0WkLrQ9EHofCJRtv4May5coj0uj8yyhN570ikoom0aH6KmeOzO25fS0UWrxulsRrKSSeBfn63J+ftQxHJA896ZchYR34LdR2cIEfeCKe3LJRh3+vNPQU67+PwyubjC77cxf9Eh0lDHEULTPae/TOn+pljOPpHvdqoRDSZTgDU4HtAbQVEWYGFgHAcgoWwdQgSU8iJqbsFsFpy0PIxGJPKB1SeOsVOrEAfKLN4MCasSk2Et7jejXcWnpVPKy1xtsa01ONcanTBSOrUPPNphUfS2ozp1GWvUZE3JtLonhr2+seVelujiP6by2ZhyR62tra+3e1b9zuTU1NXJGx6duxB19JHiUNw8nb9yCSf6CqnZ6iHVCNEVWBFmTGaazAhyNpoGDlPUHhL8joGiJRoiJ7Oo1kmmQ5sKlBDAq//uQZPMACQRl1H5vIIAAAA0gwAAAExltT/2FgAgAADSDgAAEHw+N8YKYyAZt2QP2hByQGPCSMDU5JlHi7x5unRm9LMQX8R0lg2a0tKw/1vumzmm29YrHzY/hsb7pb1B8c1WVcyRho3EYDMaXFK1ECP/6nRYpfNj/edcaSOu9aCtA0AqyS3k8q4tD5NMrIZITXNnJRFMLXB6SZacDUgB5IwDXTDZui2sOyhliPCcix2Bw/Lqaw/D+QItaYlkMJQYmqoJTDDDmwqimWiXhBsutAAnWYiM/K2Aj2+XgESVKMHk00CiRnSHdT3rSazxZcvMl+93EHRbda+0Ff6Dtt67xt27vFv4d6esmWN9PeQ2vW9+zfSgO1mg6PIHxfKcm8F2WWo2quDNEQNNxxwKPNJjQcqNMDUIWsgAYgitqGwYVhq5UvVqrtWFZ1csUpUGVAbsMiwLBfUT5NWq0mRekt8pIkn1TzxAwq0VHppz/1jeY7lactLwcCGry0v8skwLj22v89TuxrbNU1T7KkmAOkig+6ae5syttBCNu1W1395f0q7w8//uQZNSA9I1b0XMMM7IAAA0gAAABEuWFScwk1MgAADSAAAAExUPeWZ3RbW1AuhstR212fPOl3XE1dfDIZRiJElOiLPMMEKUqihoiinOJESxLVl8V2o3CECZTSKBCAwGgckC5WkCuJkpxANh52sjqAoUBwC4rU9HKMVZUCpgGRnTYi1lNYeqk89MkW7AVU2uc9Stoks9sdJ7v21xtd91tbI7x9RXMtb+VJmM6jm/tob+7378bGc7vmZj5bejP3ikMq36O95Dz3DaqhpqZQkMIkUSSzGbzLhV2BwgQmSYMYoGEF6QSHip4Rk25NBU5VsUfVjQlrQcltwoFx5SaPpaKYis+WIiFihV5i881ZAkQVzl1t2TZTzhXcpCqu0+GLp0G8NsM3d97s5kyYYXcK/tz+ACI9LoZndPXrr7xaEGf4zd82MP8Xp3QRtF69NDW1PceHsCQNmUSJJj9t63PCNOWrNCMpohqNNEhLdFnxdQ1aM2iQipm6inhoBhUiIgKcbBuZd4DK5pIwlHNABMmQMCgDi5kA5IGIjZkApiyxKPLgLMe//twZP6A9JthU/sJNFIAAA0gAAABEi2FR+wkz4AAADSAAAAE5ksPzq7m4vo1txmEqBRtuDvNdYM5IcvJoWlZMQURIcfWxwPLapUytAorNS8X3jmwjIZqVi2cnJ0fHJeu6mvbTlcfJVhaOUqh5lZrrLUwR9aXbdkrC02xOLOjW1jAinOJRzZNaZaFhf00ZZ4emiu45PGmM7lk0OadWKVVdDaKZWUtulI02R6RIBRSYt4qDTNHCFQgCOHZgNE9Yr8R5oMfZVD/AVLAepluImBKiPEkjkiUWil3+TM3wsaUmg4qQClt+qJpoEU5i6hRcooek30eC9YFNuPJNjCWuDUToLrsf7txyOoQqRTd5DYwpil2Daw/PNqK5JF/WEq1qBvhsc7WCbf497kpZl4ZnOJNJAo2ATVKEU4iPf/7gGT2gPSvYlH7STRAAAANIAAAARelc0ftMRkIAAA0gAAABBghChRgisWFQ4qiuholylusE/8egx0JyXz0+9lqaDLWCZGVYErr1HHbgLznjCdmGTsjbCqNZYURQIxcKXXlfi+bS4rZo93sQVqp8nY25pSymBmCFqsgfbyaamzaaSyn6H1jPBqDhG2lPXCDusqlhBDywcFciqwkFGonBAQ4pNWISOp7iJhmZnVM2QESgbEz9ITmUR36WzDGCQyqQ2hQTiMJQtJdiTQl2sXFSSlbjGFhBABBwtgyxH9lcPxlZEwrAvh8kq1wWZJAXJw+uGtXStDSA/5NlrJ7jS6ZO9wmTJp28lN9MQQMzLbx7e7rSWPqZxiAHAfUkdqWJl7uv57Oz+nj+ev1OXt7/+75T73q4VHeGy8IAUGTG2YQMYu2EWe09S8QZqpuMhJJmHaD1DFEB1SEs0AWIhBIGJZWjQZA7IV2spUFXSvVdT/P//twZPGA9EZfUHMJHGAAAA0gAAABEoVtQ+ykc8gAADSAAAAE9WT6YpOLpHkGyMuF8dTM1LSwCqRO4bpBCdMVy7FTJyzi+zMzXFrlCMMZcVqL2J+GGiouCkewxzVKD8gGyCxcO4qeSLm3aLA3U3QarSca37x1EkDxHMZyL5MTxipA6Gr6abi6PuH66Rt4aBarbI3PHGm4t2RySRwkIoDhAUSwlFo8gGWrIGloDAo1CcVBusjczNszzvuhdLb75sygNoRkRIRSTSQhoUIAoq5zl0JrKj0LCGBYs6c2kmPKGm/4XWR26n+5sqjpJGlBd+yZt1TVI3dCfIGw+I1PO4tQ1CInYDEAwQMrKL/mvuklNMfyh5FLOV0oOhBAIO6jhlL9vTo+1mU6sstaRIUqA5ppAtnQRAoZQFiSZ//7gGTtgPTfXFF7CTWCAAANIAAAARNBdUnssRLIAAA0gAAABAKFQQLDKYpItEd5VRgLO7n0rEGwkbQrgMPIUKyTyyZlOQWVUVNqFnd2iAie67yd18EGJx+8FVvTukzUIGHBkCBxtJvfZaJbP3Zo/e31/r/KfvCLnzffHy9LjdfGzt2mO3pv/mPu/b/7PZSsdXgKg6HVYsZ3ADpX24lnZklsTRCB6RpAYxT5qEX/QtDwytBoSMnW8iEpv1MXBlzYmhPo77sU0dlBwBI6JCSLEQORsoAZNBZGkpQQJEoOP7S+5p0gx0tdo2sUDoiyMUWHaoYSMIVyBclyjDVFpVz2EImVlW6Q+Lq1q42K1TzXSXqVeuOKbev/api/VVHa7tatOMkapGNi1Una2H2lXtWzMqSWpEBKNnMiR0gqtUxpjF6iogCBQuAHLKYMua+xdgq5ntGa2HYhEI/GGSBZygXtJVXXxaRbwy4jOWWpthx5//twZPcA9G1bUfsJHHIAAA0gAAABEZ1zReyk0QgAADSAAAAE59nM4YeQGS8fTNe8zh4WNWn9oUsWmYN6ZxHxrN62c4blhpjZe7pTW31bVlewbQdWrnGafcKutZxuvtb3rNrMu8W+Ikfer/XzjWfvWPv41bNNYpCxiBjNY0kazdH2EmyLCXIHmUaFdVVkQ5YlASAAAADJzceXDozlPs148pDCR0RgAtJGCH5g7KEBBgQagSMACRYqMQBgEjCFSVbAkOpZ5CMOIWdZHBxEN5k1lA1h0n01lBlRN4slrC2GbQMumAZ9vGaIYLXRWfZq6JC/UeG8l6SC3HjdJylix54pqVtdhxxZFSNdft3rzI4tDEbea66j6wO41mAKrZIan5ZKKV47cPp8rzjjftArwzDMOPBH1PVaCkhuZv/7gGT0APSBYlD7BkTAAAANIAAAARR9dzv1l4AIAAA0goAABDF3rtS6AIXuksJ9PK2OAZM7DYrUy8eD934beiD6kFXq1qceV1ovKsJ2FRR5H2fh+YlON+0Fv26Os1h68J7n/dfh+ofkl+Mx6Wy67vH9w7yVtm1ANBFrkEVKXAuMjePFLLvMu0FtNkkCgACgYIOssFJYBEZvIGoYQBBjASZgEmWlxk4KY+TmHDwYGGSlBp5EHFaFgVRHhwMAECgrM0sB0QWGSCEBKuGigXxJhkkGvgoswoQiLsThQSIZNBV27VArFDKmENxJqMsfxLpDqy+IOeQBRBrEGq1sQcpHqhikCsrfZTh/KjX13Qd2fnIEiS0HyxlmUem5xiUE34k1SCp1gkALEdSvNTjv1nYgWTS7reybsGwSyVsie9M11lSY7WIZZfEn4eeAGcQ07mNpplK125KX5oJnGtK5U2RpzcHSgCKuJQ0kMzeoxDkb//ugZP6ACHllSv5vAAIAAA0gwAAAI/GVNfm8gEAAADSDAAAAZZIX7e2Nv2+rL5HrbhSh3mVQxDVJahTSYeqxWztl71MogCBmZLNhp8YjHvqBP////30ySnmVyEmCeFn3UdBIEgIE0gOTVOGNR4TFk+HxkWFRIx4HMnPEyAakCIZMNDgsHjwaHYRcEaKoKX6HBqbtqgGA6SZTXVax5sPvwYwkzaGVsNUQRmZKj8AGNmL1KWonQTH2RhYyAxPpm5UOFSRpll1iKmcC0rPEiGUW49KbTxQh/3dV2LCvRVrFBAMaiL4tou+GH2ZTCqsC09WGKj8MPdeRNPThTPYM1mINmb5+IwxRactZQzeMrPjOD6U7252Ii+9G+roQupB0jf53X6lUrmmhPrE1qP/F41BbBbdaM24RnMPPlN90yx1GtqYOQrGrxlsuiroyyXdw6+1NDy/muVnrhfITlS59wuZzMgpK8vjFqnt+Av/9/B//+roqneDOJaHekXy6VhIBAoMx0kIl01sVNPETEjQKCj6mMhIcXGilpgAsatKBgkEChmIoQi4yfgZvBwEq0WZjByUDgZpxol5HlttZDjRwzOzcAEJIYO4WvfJVZcj+yFK4QhYQmmMgoACEr78XkVlrSAJdrfNgS6pi6CaiXWonNyudehNIWCmxO8j+/JigYAA4GiqBAt9LcJu7F39e//uwZNoACMplTP5vAIAAAA0gwAAAJH2VP/m9ggAAADSDAAAAV0aHCAIRdZQ5D+TMWaYzRiaX8NQA7VrGXxSM0t2sni5TsrpT7d5bygKYScBQEg4HQcbk0tYSilEGRO/KpNT54WK0BOHD7XVKbkNUkeiK+mNuUrpmq12nvBFWSv99l5XVrQfFpbA9mUUnP+cdCYnexViL4MSdqBJz8uvyibBUdcl2VK665GRxGl4qXrmHUkdZM4ASzKCIBGJzKaOCYkUKAIIACCOcFwAwECAIEisoMw6beFiIsSvelhRdFUwPVbK0TR9wpFdh8hzMxR2V7hVNUF1B1h8+iZxFzR8xPqQnzk+pFey2v5sxM4df51/ne/rHt9PYtt7tq0KFG9n1t5rHzbEKmdRaYrq+929Zf9a9bTfO65zX0jVxa1rXtj/0vTXm3Dj4pPnU1PCzqOyRg2VQYbd25MRMbeEAhpHAIQG9AwQZNFMUs6WpAoC5RZZiTDkEymz0uLm7MCuk07vzUNWYjOyqyKLEjSJEiRIoyREhP/l5o55rXmWYkS2fVf//1THTMzP7z5mZIkSJEkSSokSJAIBESIBIkUXNI14BClgYCJjVVJj6X0KVY2P4zKpf1V/1XUgxhRMOwCVV1ASGhVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+4Bk4gD1LV5Q/23gAgAADSDgAAERsXc97Bh1qAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV]],
              ["TF2Default"] = [[SUQzAwAAAAAAIVRYWFgAAAAXAAAAZW5jb2RlcgBMYXZjIGxpYnZvcmJpc//7kGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhpbmcAAAAPAAAAVAAAlz8ABgsRFxsfHyImKS0xMTU4Oz9DQ0dLT1NXW1tfY2dsb29zd3t+goKGio6RlZWZnKGlqayssLS4vL+/wsXHyMrKzM7Q0dPT1dfZ293e3uDi5Obo6Orr7e/x8fL09vf5+fv9/v//AAAAUExBTUUzLjEwMAS5AAAAAAAAAAA1ICQFAE0AAeAAAJc/TnZBXQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/74EQAAAGmAF99AAAIMiAb76CAACKOG3v5nABEGkKwPzUQCdhnM1QkAgIgpw+UEBwocLnygPwfPlwfB/B8Hw/Lh/+Xf/BMH//wff/0y7/5cPwQOf8EDn+uqh3dERCBgGklGD8EHBgXB8+XD5cH4PvygY4P/4fgh/qBB0QO+Xfwx/ygY/8oGPqcUDGVM1kVDMioSmWhDCISCITDIhEoASYcPAoSBLsg0VSYqmpeYdIsQJBFpQaWaWQFQTkd9gOK0S1IoJ8BAaGn9YOzF+ip1+ryKhMuHEpKrYFpLEDPq9S2iDJ2LtLcWSNMgatALwOfSxfLF38rFPdYs7wsCBn4gKKw0XlpHFjUopsoEi+EQuwxL4hILMpZzDUhV87sixqSitluF0tvcNTmGNaU0lNFGB24IpX9Z87T4Z2LUuq6+xh21BdXWWVjeGrN+CI3AFLJLsvgHbzSuv/53rmOe/yucxys56rYzXaPXe0Xebj8nqyKIW/leeFWkz5Z/mv3lvmv/nf///////////+//P3/6///////////PHCgn+8p8YdzcrarJqmZgJAbCAqDglEgRVBxIGk14AdojSp4VArDKPLSASJcAYGRUFjAiFgwiDecDvGiF0RaQvSJYITB+A9jmic1lYPbI0ZskS2OQLOHLHlNQesR5AES+bmoypESCHC4VzQZohpMEMEEiqQ8yRQGgdLyJ8XCK1IAG0CPyKjwQMiRNkwQNZuVyHl8mpDR4Iwckok2RAi5gYE4RZaJPlSSBQIgTxwvEKUDcqDdIeQctniKEmkaEwiTRmeUgeoEML7ltI2NSgxBDdRqRNJRemaJ0i5Hk2ZseOF0vrZzRaLnkS6iiUlHzZNIqJsZk2VzEniYN6SajE0djX/9///3////TWUCwbc9cb7/q4dyEAABR6EpgVaUZnMzZtEdYEVy46QzvPq1qXRJ2j+xoSvo9B0v+2hrjpdp/WFC+iWrIKMVahpdf1XNz8ZSs3v1Vy5Muj5npl0qVWsWWU/aZWJpzMlhx266yE2bM0mcp0w7tNn3e+7u/BNvzZ3fmYQKHrgan4aPsHCAs8TCYWAo1IYYpWDScY3uoPqt7u6s/8mXQxQAAQ/jbBWkAAckOEbGYUgRkpYTkYz1oQ86TLDZ2c0JxhHObIyRVfOvmFEVtJJghvnrE0cUaFXecIoJjTa6I0QHidDLLTblsaivvSW3dlaSuJxg1lNe2018xJRLNb8vK41K8+rXnv3f//2/L/+o/Gdr7k/X1aRwGwmFQqRDTQ6MsZLHn0BXfxPPL2o6JrNqpVQAC3wBUi3DviENOFRtMd5IFeKgkAxRGSrkz/lM41a/nLdw1y3juCYRAv+7PcX+nL0NYev57cKbGzqzhZPj2bQI6LBNMLCXC//7wES3AgSIRl13YYAAkUpbvuekABVljWvMMNrC1rctOYYLYMIwsegQ+gT0HpEdh6wcpfYew6PZGaHzcbDrS1Ecujd12ZmPpZPdrrLo5I31IFtLpvT52sN6c7Xbf2NV3zX2XnRSxTzmpCYr5xJ3wWijmzlHadT91gwVaKFWU4UQjLXdd3mvMI6CAABC3Vjm6oGoKjUOLJqDRhTEvS1daSMrNZmnaRNy9RmpArDGZUrK683O13pcSr/so5XfSTZQ7UoUxoE7PU0szjPXsPq/VIPK1QEj4UgFAKLDIbl6EPYFogVdIkKWMPegLe4tW8zpyohYctaiRob8om8BtbKG313l1rWbnGUnvH15z5mZ2szXFKXCsXXcsKzoGUKruHIZGhQ1jiRNysYzhhy4sxJbzSpaz5oIM8h1mOvJyqlUMQAAATCWISwgNrCqpCKuULijoY6Anmpi6j8Nxdiff2MxVkTsxa1FqyYLqz37bwiIp8sUypNH0n70toINlBVpfOSyarIYYyisNwWv9uULxfEdEqoSYt6jC1E0Z6IflqV1yqchOWFkNJOSLjWkmj4YcjHM2NdoEV/c+0MFWrXL/utfEm/5EI0Db4gzpX9AZ/6AYvUx7ZjtQ+WJtVs3ZN9SL51N9pqqWOJttzTT2R6pq6qlVTAAACL1P0vEaihmi8wwoGFzF5wcUONI3hYE0WeYM9Se7sKjlsOJVy1eEutfdiqLNHlpT8Qm2N45RbLAQ9lO7VaTfKrTJpN//cqvBFk6nVoZkiikCSWp+K0A6BUaicPqGvQi3FKiZRq/AlHiGlQmdHuhPXDfLytaQnI7qJmdGz46+IFJHf5jeq/+o49sUli0THyxUtUtQ2pZMvqRfOo6HbamljibcfNN6eqEuHUgAAAATGrOgqky3oyhoRdWXkgE5E0mht+1PdReV6GYrAj6zSQMiOoH4y96BEgLlElX4kBfxFQwHAX/LYCX2uU5//vQRNECJYxo2PMvPrCtjRsuYYfkGrWjV8xmOMNctGr5l6OYkicJ1XJdlzK0ib1dC+3E5zeLA3cRrAUbXl2Q45qGgsi0iWQw1iJN5SqUSAhNl8HNNlLpQ/hBbAad7AuKx6HaWlxImcLw/h0odYF0dNW0y1YltaJmeqLRvhkwcesusUi36x8DLpf9hZZJdZxCk06SRNlRZuVSuRA1otv1JKfW3Rmf0jI4eLJ3Ddp4sVKkNLxIDSzcLTqZAAAAIc4ydEgrDCgAqKSB7Wmjut1hLkNMZo2LsOzDzRuA8mtZv8FRVVqLBmYiACwcAROaMK0mDuoQqI1aRPdOUr2Ivn5S4dCQ46fYyC2DYfySRdtlbjQGMMALgj1jaY4rgdBCVOdhuEhE8b1MUh6r7MIaytQQpNyqlDm04I1n0MoEckS4lSA0ZDLdN1X1m45lU3Iv/5N5b/br/iDF7evdf//9XPf/4SD/8U/1SoarEENC5kniKGxMbqvDfwzX61frRdRfsUMHBkvhudBAsVKkO8SG1m1nimZCEAAAAEFw1Z4MyBTpVQdIX4YCxphyqyuFhmozj7PXPfUh63HkNqI4HooE00RJYH/TUh1sYdxtkCiEUCfTuw8Yhki2mTzbe3cGy1obSYeovuw3DcMPoXec9DCVYQWiTHH5YdjehnemvFQHEhd+4/K5bSXol7y0IFBIne/8CqemItQlQb186Wpw36iYN6i+frCGDStRMpLbkcHnP9ZQPeJ5LXlPzAxufWbHjxNn///6ez+mpJaBg+/1B/h2Ez06rxSKZgAAAATRSYcLAC/RdpureGBBSxZKoGQt1WFf+w8MauR5x4perOnMChZrcJyYSnINI1GJyHRA8ZRZFRlN9O9q2TB9i+E0yWPWf5SiMQpXmvCPtGkgA0ToL+TocSODvHAynwdpSm8XHRUqGY4lcWLWCVRtyJqAjJvD2niETWKQpEgFOWD1qbnB7PxPB1ya+ArC27fmhv6yIeVy+3mfmBIFhufWkeNSWLf//rdPRf0zheOsZJ03g3iN/eVyrRUKqmoAFnswV0JbL/G1SNCwMLTqWYtGGlBm/m4bZu4UgEkUGslowEdxPA9uadiR4LMnLSPCZ//70ETagyYHaFXzG4YwvY0azmnt1BaZnVfMZbjDFjPqeY1KOFPau8KvgW5QqOKrHnWLiv1S1ny7ANtmtiH7P7cx1nSWgrmTKKMXxZmrBcpZPe1W+Yi7SQxaFuxf+PXcbsXqAZXW/uRclmqALEQIOJvW1T6iGZH6kS2sA6AU9RSRZtRPCWfrMTXqDoZv0X7k8jK2Y+SX//7oK/qQzYQv/JHrC0JcsyCAgAAK6xERBL+AoySTdw4sDjAZoRigh1WwNKjEASifZvFoTlBDSQqhd29t9C3JowkdjyxjUyQ4DmOmWzX66iyWxy/YK2pzCQPKzl8NEpGil978HSUcY0raNFV8l4Wl0pKDKxFygf6XNycmRQWvxjCF1+lhrFud7CvdrF2+/Y7VLdAsAaGOcKkxk5KlrpHXzgxw36jI/hOhtcy+omyS8xGuQhk2aFX0T/LxkXS260Zsaf//pIK/qQplaT/WAjCodvcwwneqZkUxAAAARTOhEv0SgUJRsWiqiIgNcQ0dxxHAXU/0CvFCWZJYRekijSoueioc8cWRI9ogKukbRgt2G2KIKT26SLpUGEQYYB4Tly79BL3Ggib/9uu5UShha88wnUvWyr29Uhrfy/laFqKBSjcdJFJQMKBDlATYieZO1AhgN7D8Sam5MN9VRtl4/WGfBpXRqbUPscDdRGv1EkVv+syWv0SWdo+Md1Lej8tboZZxUIQMAAAALnmUIoaHGoClvoIigQlDlifsZg1ha6W4zLsy6kY9KYbkqpy+giwTqnNrYLqlrFa4Df0J9HkryZr9NAiDbGIEZVjiTW8JWF8/9ykCAkigGfwtJ1INq3QUFAGNMPeSkSpT5xsU8olSj0++s2QATjxuG4B02q36KhdqARQEs6jVNLT0oFgDDAdQt7aKPmT6hnh3aKFQRcXmzFvl0nG6AeyXzieOr6SudOJl/2/2/88cNf6lTpbW5jPCou650a4rFVVuhmgKYBEQFFJoFVZk5YttNYBGERWCVE7oU8cUabelLqUkIaamS9RoQDJbWODvlBxkn2TAGmTNKROot3MYNNBWBUqrZ5lzLruvtJu/QvVHL1dambok2XhExKLqLBJydcwLYRBPyyZJ+Rz/+8BE7YMlVlbV8xuVsMUs6o5nc8YUWYdXzGoNwq0wqrmNyqhP0xcJRBULn6iBhbsaxJJnudb+c5ifmAa4NK6X5iJK3M0D/WMah/1mhubeon/7/9S0z1WiutX/Q7dsOYioACkiCiEpFLwYAgRBJiIjsnSFwQ3Pp6wh8K2fKzzbWddL8PCVOyec2o8piUEDQJRETH0RPCsQg1hq+mxoumSQxmoE3VQiU5Y6lbB6KGJP8y4kWszD6V4eoos3WPzXzHIabjcyg5KSHKGkiVx6pHRyRtZgszY3QzN7KRJggkjh6//yOLecTqC2xJ/9R0q+kQQlzj5Tf/rNUzb/+f/6kXPWbhIJ7We73d3/uZl3BEEolw5i9N8mAieCYIZF5WOsybohLjSv3zaRIWAVLbBK8UpHAZ2tWr/122W7B2FZJuQx9nues4hbATQjR0/WZHmPiqysbPsI4stQ6c6OCIpcyUSVG5wFd6+pEAwPnX//fvh4H//lDfUg+Kjf+p31H2r8e7tjar+yodGIEAgE1jg0VB8TESFY0mmi8qcgC5IOJXUoaw3d82HduP3ahe23aKVERu98elTQZN2VDMa+n3q2a8MTxhohZKn57/540lHb+J0lIY4BI5GSrpOZSwZCiqzk3cNn/kQDhM//+j98GDP/T8ZfN///Ukb0mt/oTKS6+rVZS+7/3EOqgECYi4yMGkZAMjHQoI46QrRBZBHC9glzDVJ6q069VVF48yHkbBbQP2tRI9/eQIaeahRjT9MwygBUYlE+p/OnW1j6UtI/KCMsoN6HFODTGpoJnpgOUWQ/icy9ZUEDFj//qfvj8N//0iv6zIqdRef/6vrJ3jf/bu7P63plgQgUAnwCocIQnk5eNdKAalEYE0YZUPUhDUvbFLnT1Ugene6PrFQbKgYzb+5D0Lp90oEM+0OQd3LkaVmBNKuY1F7XP39pSrZhMce8QKRffqSypoVhRTXQ5QUf7P/7oETqAAPSVtn7ElYAfu0LH2DK0A9tW2PsPouB9qusfYyqyBfmP//o/fBEd/6H/PHPKf/O/Ix+WzRLxISnK4JAdyrP7dyZqCKDKTvU5QHEiVLgahfbYmAqaLGeVAfFkesnQ6l65r1NbW9F7zJBGEOTH+fBbEl43gghHIzFxjMBFqQAJFVM4a/z6X3r5OyuYSovGadW3p7E4XtGnyAgML/xKXb//V74shX/86UvWVlHx/S/9m+oy+trf86i+t7Cu5/7UOxCUBAEcbAF4nmByANV22lrML/jCWvIgPwirJGR00pnZU90Z//g1Gabtf73Kc1KCmDvJwu82Cxuo3d9ANpChEyO7ro16FzbRgRMFUfmeSHHlh8H2nyRAv/+Fh3//098Hm/+X+Vb3f//5UgbJEvWSvrfL7m/tOcCAACAMo+JHJk5VQXlaUCAONDiGxaxiCxV8vxrB8IHgJm64v+2+IZKV2Pgl3a0s1TBUrgHB2ea4ZAWiCgjxdbXevUWEHUiozQlM2LXtmhfHnVR0i+sdz/3HO//+3fH4VP/1mnrIaj5qe/9Tfmbev/9JfX5x6tzvumRjAEBAFx3hq4hAciogKGCwlglKi3K9YLa8tJ97NMzyF9nXNvc2o6QjktJ91/32nZuLGETq/ZizOzzs6xkCUlNnZaZZy/f1qvgwTtJYrBSMVHRp1NqQBPCzv/7oETjgAPjYFn7D20wdYrrH2JKwA8dl1/sJpYB5aurvY0qkL6nqEj/cKYx//+3fBg3/1T3Kv5C///49bb+22rI1bvPuKSlAAMgF4ClXS05ACXEZ0XdNIWWpzEtNgsYmAf9ZzTE2gF1MnUJZCWgWV2s9rLCUjfLUDyglK8j4hnongJ8DxK403bspLkuS04RJIkNZse9th9o31ay8seG/xZr////I4Vf/yr8oP5z/6n/M///rZb/zlBDN79mllABBADVLog4YcIIUYRqL4EwEe1kua0V1kH2cU1hnbEqV3qDd72El5pXIfoZe3lPx6wtQ17OKW9V26SIAswUaQIUqr1/GseqVJVGtz3+P6P9Etx//45qT///3xTkP/We+Uv//2/JP/yfVQR+97YtYgAQQArhUqARTJKwWXCGDiI4cRAh1qin1rMuoKdaK9c6aK0T2qrMADLVb38atCY1UqiFgsC4Fsu4ZhcEEcfJmZfUptZR1HqWt/+P5b/qLUg/+ajPf//6+Rggb/zifyab03/+b/Wl//+tn1ecbz2X31Mo6AAEADaCDp1I9jzgsR11PCMEjR3SbbHaZq0WriyFiu6j9Zb66ZCOAbP0MsfKmuPMc4qhjUFYZ4S9sAIZolEmhG6SNe/UCua6FiITH3b/BkT/TQkUF5/5KEo5////Csf//7BTiZ5RX/836ip/5v/7oETkAAO2ZVf7D5Jwborq/2MzTg41oV/sMpYB0CurvYorAHqdINvf67OUAERkOUaeGlbMXzGkwtBEr1KgVEjgxZ9V4oR55M8dduVe9h2qzwvS2Oi+abyX8+mEdTF8FabAF4KgDgBjSqN5n60D2dFOJ+Zk+dJ1J1kkf/rFZHvVtcurHMb9Sxr///69RSDtv/1D38ot5i3/rS+v///OPo+m3Ueve/NpLUAQQAzSRKrodA2AEd2C7aLSlYpMGQQVg9eRdCxpNxAHDzsuvbtV5CFwNzk3yWHHfwm5k9HHhsxaPRZ1G7v6C6ApsY0Usjr/UTC9D420O/4VQt+mg1QG3+h4Tb///3wYJ//28Y////1///lM7W6Qr9/JpIIAA0AtFfoUocQ9xldPoao3o0LApQvqxJKcvhqoydOq3NVP1k3QJFQ0W3ohloVPuUmgiFGCybpdOFGBGwICGRP616fjmkvRLzECVl4//WdIX+sl0iV/zYYz///XqLwgZ/+mbfOp+Pq61fzpprd/3315Csz7mElAAAICtWqSjayUcK0LqfIvczpDgGFeBsyTi+5uUpXgYz80yjfbOmUCObYYT8sZKt6Xww0kxt5QSCVz28Kd/FtkPxWSCRoJO5b33/Ustz6yVMqjY/+tZNFL1tOjekFk/6y8IJf//++LIt/+78xPEPrPl00/6zL50vf////7oETxgAPiaFf7DJ2Acswq72JqwA6xTV3sPpYCELQq/Y02kEm0vtzA9buvq4JQAAMAGUuUUBiQVAFAyskAiHAKDCA+PSCKlDP6z1ve6//9jAKa3Od22J95dCrlOAxKebo4V7V18H6PuR+MPN9a5vHvl3rCRDrUaojx9/6zApfyYVLHF/WYBy////4ev/WafV/M5p/8b6n///l/78ENV580wuAAAD5aFirXhCKaJDeCENt2vJpgsd9JS3IeH+6vEaJ52U6/SjgBYXnDvXqUFlXz6pjN7UcVHGedwrtEeY148aksCSFuY7q//xLi3RWWpspA/+tYxBOv5gOZEUG/WaBN1P///4zFv//yIl1oJJqQb+j9ZZ/7fyFS/zCAwAAoLWTKYaZQYgGgUuWtIMBULQEVpWwpkuFxBAqnTP7W1+hxIzKDmnvxt6hoNhwIbMjOvgwkhUV0omSwdTv4gnVsMLQ8xmEXJVJe3dq5Y1b36shAUY/2tD1qBzF1GJ/+sKAen1qHcEqeBst+gUAGwUv//6+dArf+gQfjwf0ecb+n9aX////36R78z5pxkAAEAEkjpUOvY1kAj22QkJPzKOoFJajTPQ4W9LwW2zalgvn9SUJZspmPjkVZpUaOqU3iBGq9XvdsP/AAgxoLxIWJz3M6v/5gCQinURCmMIi6kT/+IRD+ZFFATP/YSRL////7oETwAgOfaFb7DRbAegrqrmdNpBGloU3M8bMB7zQq/Y02kPfD4R//mp/uTD3WzMotb//O/////9R56Z/GYDAAAAAzeaGS1yCoAGEgsPGBBxARmBiBIAjRrKYYoY1uoPAwcHRG5jzeRYUgEiGFCY8K5FQAAQ2BQxlKXpgYGmYYMGCARBW3UoXwIAiAAqaqbRqMFAAEggCP7LoBs99uUgwUJnmSROlw+ShMmVvwjgKoa/YWsNXnQxsf/SGmDZ9v//6+Ug4L/zJFDug30yfPGLf0v1f///V/1FrZb7VwAAAQATgqeMIoEwgCQSBhkQuKhYHAlWAyKHV1wMieIAghXZ5IcK+H2u3B0BmaEWBAS+c0oqCg8umGEl1qm1gkPrjHFXsoreTosBMpqHnYUEGqMtpbwyv/5wL8o4+SND5rHSkVf8SsZN/Sl0d5SAbZt/Pj2///trbEtDTm/5kffmg1letE0Nkf82+onW//qyXfv5OgwACMQZYN2EroyCA4uGAkhR40AhcwHPAyhrPU1v2tkiBS2sP/RIwMmvGc1Tp1Ovr2cGDlpqpaf2xG1yJ7gY3cA0EUHNav+oL2A4k06O4YplOOe/qGeFU37ESk7/WTQzD//++vqED//N19AomZfdJCXVf9bfo////+r57tn76AUwCEADkDQ5kgKWg/8wCi51WVApACFZyWLDlT9P/7sGTngATwaFJzfJUgkurqLnNRsg/FoVnsapRBwquq/axQKMeRundb4eUDCkC8hFrJ4qJkwOkDPsgJACOPLUmQwrARECikWBQOfZO/1ien5ERvdL/olf/UsgH/V//9u2NcYf/rLaXTNzV6kFrNf//Ub///Qu6vubFwAEFAS0PuNnpDRQWu8qGqQDDB0YBFKowrlMr/YAuWLS3n/oqAD6s/pfYzAUD5S9ah0elG705vVVuzlGryLQwtoV/me+/8vkfqZJlJFn9RkUf6hskv/mhSb//+tsaQpv/Om3yKYjwc6kikl/7fpf//1f6m6z1/O7UjAACCwFMJkS9FqLSLmRpK5UjziABfZyYVA6EO9JyAgbJoy+3/olYO+W3G/mlXNTv1C3pnswcCn6TGtdaM8xk1YktUOXzWx7n/+oYYW+tJI2YnG46K/QKQZf6h4R+f+eHl//6n/Jz//ZXWPzkt6//W35f///q/0m1T2fX3FCQAAEADIHlCEU2EV1m0LZGqy6sGGsYTUQJksNTY1FTN9zW//yFYHNJHyzrCWCwVbiioTA0pIg3vCvKGBwKZrqGJ3BUs52rn3/g2BFqhOuTG/0PIf54xULj+igSv///8Rw//9S3xUEgY//9D/oNf//5Rv9tFLZlfbSJgAAaAJr1DxlUBkIteCzsoIelGPCIk2YceFL63UUGUlj9T/8lgYLu3KOvWuJ2q6+JIdMGRGZfS63UfeKmAqojyorIz3Ltvv+TgTkHM9aygdaSxB/qDuNv8zLqhy/1LEtf///5x//+ubJo///+sy///nG/21T3Nn7egQAABACsJwgFaWsGjTDCdh4BG//ugRP6AA8doVnsZbZB8jQqvY02kDxGhU+zpVIHkNCp9jTaQKjOIikU9T6e0i5tRNplm/v/0VAg8VZdX5lOFzbLRHgMXDU1W7R63WdFMkzGYMdPar2i7ja7/qGsdfSRdZkf/qJ5H/sHE40/4lwC0r//+tsXQzfU/YgecIRQSf//TJb3UU/9f/qPbevqOtmX9zIGAAABCOnEWUnLzHQiJBYdU6PRKIBSDJBpn5VtZ93aU7mY93/4EhhjFKrw7k2WLObSN2qG4lojsM/96glpJiFA0WWBVkq5fa7/rErHX0UXWZP/izHu/qk0Uz4yn/l4R3///5ENv16CfqTHan///9Rr/r/9TbevqnomPh6AgAAMAK4uGJFc0iMAGy8BBdUGEdkBOjbTmvqK4ZKYMtyx//0MsHVIzzHaxEAh3BmSpTXEhoUsq1upK2QNbNLgDnEPK/v81f//cFvCPrZRg65b/nRv/nBKERhv6zQK9v///k0j/v1J/JNv//X+svf7P/0j2f9b8zPTc/DyCAAQgIVoWIEODjgAIY6GEKgxAjCwsuNPNQXIzz+qALVl1LTf+iFh8mnbDmTRXQjPU7C6oVhgKAKidSvUia0FzmHoyZlEUENF3DL/XqEKB7gW3nUThg61Fv+I8Id/zgmCI2f1nhA2///+cf+1bfkgUv//X+oh/9/+ke39fzyqvr8aw//ugRP4AA/1oVfs6bSh7bQqfZ02kD3WhUexptIICNCo9jbaQIABEQN2DohpUt6ZD4joa6AszLNM1sAGEwFLBjKWb7wVual+v/+IFH0Ow2DtvQ1CL11FGtnG4rQ497v4ukm8Bk64EjJExYj7HHf6Ir4gbW0fNJSb/id/GYgUFn+hoFB///9sHwi+a/OHfWf//8k+hL9NH/0I2+t1n7FT+djUCAAAaDqqIhE8AhAEIeDKRQsoFhTQEAC5EpMR6FiML6iVSLeOtf/EPjWMUrcz3pX439dhSEo3NkWCwTFcvzjzPjKqxoymUrfWxrV//xDiThDa2l5pYR2/TEBDX/J48Zf/okACCf///kQp/mCdSX5O////mH1an/1HW1raq+6B6sn5igUAI4ynEgoACExJuVBchGtdBAgLhrtheJOX7qT7DJbX3/4QOSkiE/tqmLfbaUroAfrXWbRYV4gnuoAbG482/LQOdoMu/8MQt6sovYoLJJ/mi035CGzjv9Dw6W///2woRT/6l/QKUv//6L0oO/f/80h5izDSB6IVafrsjgZgBDAOlCwSYQiBMMkhCyRBbsiMx9G+PPe2jHf2tthkty/WdI1MzjVyuZ+LFYe1ab4H6jwTLLHO0j7swBl6v6w8lf5c33/EeHJF/WyztRdQ/zUPTfk0RbmD/qL4Lea////GYZSkS+X00x+V9//ugRPUBA+1hVPs0VhKCLQqPZ02kD2GhU8xlVIILtCr9lotsb1DOUVN///0Afv/+ULyLIVHo7DWdn8agEAABIKWDFyYsABgBEASWDILOZILkgpIOC24N5Qr+rUabl+f/dIRQkawmXbUaZPKMbySZjIiaye0gx/sMt1MVsDCT+P7ztTDv/DMbfNcpFH9CiN+UEQo8/y4BF////lS//r+Pv//361IvmsSP/zj3RXVzziJ5xhUtXxzNYqABBAHymJA0Ui+DCBYPRo0D4thFjfKnqRz51NQMTFse//GVnAywtXF8HVll19EuzT0hYglc1buOnpdwEKBoMwlSilyoMP/wZB0LXzXRS39BgIpvzBkhD/Vw+f///4eFiIekZ5ceIP+jTMZnu3///l/qzf/vvdZR/HKx/ldAgAERAy1IsukChiIQNHeW4TFhxbKQFlKR+gALdREJq/f3/4ki1tTsU3GmPQnHpQo/hQNa28t/CnXw1oDLogWMEGEnPso9q5wPxHvsoTR4bBn+hQg36iKg//kAAk///+Jy//qW9Qhb63yVVupn2pa1VpKpb8SwAAACSOjGBAoKCBnwgFXSkBjR4pZEWJJowvMDEzmAu5q/f1/0pUJzIhNW2czVmcxzJNCjGQQK26EkYA4Ftcp3AWkYunCwRDIkawd2Yov9XD6GkV9bKHw2MgvQiUvycCgC//ugROkAA99oU/s6VLB87QqPY0qkDqkpUexQ+EJpNCk9jbXowLH9RsJiTBGn/WUA3m//6Fb1IJkkcI5io8XVqS0FkdzdNRoUk6m/rfrbq1fqV//uuu5z57/6lY+MmMBAAAMhaRp9pSkZAREsPiLPTWEbBTOXGNCJupkLvTufmnqf3ghdhHgcIrM+PL+jswqiNBzpBhIUymRWe2YaJQxhd4clcJp9rG1Ff9XGcCFG7W0vMsYYu3+oahePfoi3UafziIHqv//pmBoaXZhijrWp0k1ZgizVZmbV3U31/Pfm////26nahRPP9E7H5dkBgCBEK2PY2dp/m3aGOPNXZEAnKAsKjbNJSyZCb+t8///t1kZnhtx7eMZWfEuU7vGNuqlT1l+W8JfJAhYkNERDBi87+WEfywxwjj/9YoUZf+HqA7/PPb//mD5MnZ3C4uorGmLj9Xrik+ll///kv/o27/l4BAAAgBkznSche4iIFwoZLJmAICnTHZFnpO0VPw0zdU6FqsOX5b1QjnIGJEBLQcZWTAlP307wCBOPiFoCRzyfnKFg0ZDfPRae7qTXPg2Td9XIoEaS3ZZFY6F2F9b/UZA5Sz8mCYMX/7i+BBj///JhNH4dhoPVFMQURSbGRutI1MWL6CiYotUkMIWrqU9vWe9H6zn9v/b6nonzS6kyRQi2+wgAAAACBCATDB3Y//uwZNeABGloU3saa9BzKtpfaofEFCmjTezptKIYq2f9pS9Y5I03j026GdMoMDlowEMCPx1DbxpAfqXXv/G7qupgd3IEH8aQZAsrUxlBCBTNP1qFrQUAL2nbeDY2WmqMD0pMAPMqeo7G+/4GBYb5NQkL/49BUX/KBeEoFrf3EJ//6aSJW9J0BW6rmoaei2TKcrSweF2czX/////+sp+PpeAwAAAAdMMHb9gRyoIAaAmxDvVSDCYOUxHBE9RqncwKrFBdrH/1QkiWYcEFUVS4vNlIgNe0YEJOAgIRVoOEUP21tWb8OykyiaBw04L8UuTwwj/8rFU17SRPlZEFdf6h7gsT31F8N1ZJfzpKAnv//kkMgYM3JpdmAQYQyRkaDiNDAimh0wJpRHIOMkKgejRNfpf/+ou/z//Ot9b5NW2Vo/dr/TeP6p4AQAAACgnbPm7CKamDMGcAQ0RGjFgaueGwUMS/CpL/r8/94Z3GEGONrKfL0C2SXJXOstOWuUgKhGKW8LcYfcEvm0JQAVA1t67/+BwZLfNdDy/+FATM/PB6YCX9Tg9v/+yWzxzMm40lGsPrb3Qr5rTythucTHGf+Xy29zwBAAMiZ5MdUSlGCggKVRo2hI9J8WBihwwAeHAsFXxF8n1Mq7RSdW3zOpAZBYmniINMQUIxQhB1XosUAgUTJAE47sCBoGA6nNLQPGMAha40NIFqBqQ0K5Ys/jP+lyKB/E41MoaC0mhcRbMh9YsxhW/GkE2mSqH6AyQ2n//4+nCWSJElxsWIOIsuGBifUZpzVMuk1NEcLIifkBJSdrbt/zlllqTfW/+j+m/R53qQW66lGQP/+7Bk6oIFK2hS+ztsSHspOk9o7NcXebc/7W2vQd+lKT2pmugCQDSfIGjyayPhLdgAEYI6owqQOXFUMYE0GK29JkwsmnKXPbCErWn2Kz2OzuV3v/a2gCKTClPtxTglumfq+BGElwmMZFWShDgM5wuKOIEZiXZzTQ2Mg2g1bUpX/5w+j+shZON/Ua///1z6QXxK7tsdv99FRyVUTCRc49/+z//01buv58NQAMVJd4BmcxiAsYAB6PIlDOFNygWUNpSR/WaPqrcsNf/oevWsuBPkrmznsZY6Z3K9GBSL+2IffABycZkzJjO/yPEYjzqaPMgSkP8qf/HAfSf9CYV//9RZ2oBoJep5jTP4iv/1b/rZQxb5j/Rv83zOV66/W4DAQAhDXRK1RQeHCDR45+gcGzROxyyYrMvYXBUz/NiKzcstf/kCINEHRVmfBrzPLtqquDvfHgZdzv/laIX1es+YfluS3//yADY585kFkz/D0BtvqYBcRiC/oPwXW//+omNJVzqHTB+UyE1QaR0Ba1rH6t/1Vhohb5H+jf5ehONLOV9RwOABCEnql24ioQhxM6rjvokSVMsuJKZcn6HA/SjSYcWocv/ZVCRKVTgX/ahS+2NOAQbau72OW9J/pTh1CgUsY5e7dv/68hB8NPqxQ0Y/x0n/KNT+pIQN//5v0ASJRQgPlypiFiJIaECPlH/f//4/8mIwqlrC54QF3Lrr+X4FAAAC37Qyh2Ax4yzgyV2y+QCpfwLBmQNLUAxdJHLdwqkMTi0dsf9chhAIpKewXB64Yu3FtiTh9Tg4zR2oFMU0D4w4MjwpR+WX/OE2WvpscLpU/yZEbv/7oETnAAOmZ9X7FD4Ygy0Kj2VF1w+VW1XsKPoiLDQpfZkW6H/yMK01/rJ4Z5v//qYTCAiOFVeNI7iszIKB8xYgFDDerat/6tEf6aujot1pnNQk7Y11i4+m0CAAAQBVDSBY4+FioE7FkHgfNDUGoA1dvmUPQmfVLvrWpdZ/9cYeDrli7QevQrTB995Rp6Y6AmdBs9vVtrgyDCtJwHqaX/8o//2AWHfWUHhb/QdJv+cCE3/LCv//5hjeaTZDXlnYdJuz1yn9///Ue/9ZpyvdCjR4wyhpYxti+5f03AIAACgt4YV4CwHpguKbqzgggwimcgwhAcbcYWw0HAfikO31nX/zYoabZAyP/Xpe2RW2uBy0yNx9Luv/+JThY47TdWUb1jf//FQVDvjseF4t/wqHv+gSX/qMAb//+YePMpQeVqJPzZhjnkUA5UAJf+e9ax7xzCxxQaRJxLfTSAAAABS8gdMnOrCkSQDUiVJgmDoQKKEs4GhhnqM+psty1H//v9Q6j9w6jSetiBcq5AAPMANNVrMMv/27KrmqmRKyNJq/y5f//EwrGPs8HQ/f6CkNP+JwVc7+ig4f//ZSBMmO1GB0uNSKFzakxwqo1CjmMIFjf9P+gnif/a4V0OYqFFzldzSpsKWuz9bQMAADQX1N4tEQnSGRzEda+tsQrAo4FCDU8DMJEIgCD1XQxRh7lv/7sETaAAQLaFJ7Gj0gfckKX2dHpBF9o0nsnFsCEStpfZoOsL/yIBTZBEJNztUUVKHkC1gDJzxBEvIvTIwN2DZ4PARgXahMD+vqHSMH7PHOO/6BJfzMo/9SJDH/6/xkYfIW0SsMth03VZHOmaLSyDc7//xfxvx8HhYTpMjlsQPVzp+n0IQAQwnVDyiEByTEEVHRLLGsQymiqpi1xYiVX6VQQDutMz2/j7Ym3T9nfgqjw9P5bhoOqOLXv3hK2EglsUuTJczh/8sEySH1Vl4t/1GZbf9hOTt/kuMkh/1daKjAhzQZzmUiMY6OZXApDvBt/2/9eK6N0pVmUEhuC7lQ2oTblfccCiAIkU/omQOq08v0MgwyB5BQJJMQEqjpBlKLm9JOLvi13L/6/oOcOplv1IFw9WZFk8OCqKrs50cYiYCeRUawuNKcP/k2OSQnzJRmOcSa3/Mjb+iLc//Jcn2/9d+MUGdVO0udvqLBIkw7mQZoIlAKurO3yGpYAFiNR0chSknlmflrAgAAEBVMMLqqiyBL01SRr62yZmkcAhgCot4nq9yJHbAODo5S25vv4iAIGpxQ+2/sKSjbNXFExhA5i8jSoB5++wSMBQs+ElT8lAyzlBEu7/lxEhZ+ewvh//QZl3/KBAxP/UeAUW/yqq1WDjOIvIc4vcpVOciHGiTkBHKU6//6P/9TCYxyD8hmKyPoxHMphruHCdP+Riq+UsBAAAQNnCZ0lAIokzxAjCVTAqeYLzCQtEzKZSt7ghutazr//Q4Mb5pKm+fGyNRkE2MLK5P+4cB9thRA9kew09YKo/LCT/LJmS302OmRL/1GSv5wdn+o//ugRPkABANi1PsTFkqBKWp/YiO6EumXQ+0ousI0suj9mJbosjkDALXzfu+xpQMZxrEJISPKwcEXVTi5DHKQf//0f9X6oJjHZ9Q5VkfRiOZTDXAQFCv/Ioz/pKAQAEAMcIcAkTUvw4ACLMLBi5DJRIoCzAxIOG7TSXUCAvUrBgioRy/z/uEIoCj4qkKffYKVFL7AyWA4qCsrAKcmPcJtUylJk6ElZE4Yz1BVB3/H0ujp8fZNEpFszfceQnDy/rQDlg3VMr+PEhf+pfk8YQYUeheE6JAkyQEuGsRkOQMIXyATh+HwtPDIIJJEjSGIbJv//v9TCYHCRhyVbo7Bq7HENwlEjE4UFxYFtH5eic78rCAQBCEdSDhggcBUq0nu+HAJejACVatEopIIbk9f753//v/HAcC+t/5tj3dwQz0z0kmXYw/U2+jtgG8FKLIJulV/cs/1f+dHU2p9ZcFOpD+bCafpdJFRgbrvEwwbSziJGl1f+tNILSTN3TBdkV/yH4p/7J/udaBAAAEA4EBCRMEGKDACRjkEUMEzAxEeOWrEgOIQqbblJgIBbkgWHkPXWfmj/9ChUBlsRGKF2UwUBV/MLkQklmkPBfqPQ5jlMqCppGfm40MzUm19BS8/yKSY26s0PmALaZM3zpJC9p9ZNDMfRUj84MsbH/bd6a1gwQCMWE4GxSCLkIdAtUHE//uwZNkABZxl0fttHth1iTpvZabJFzWjRe21OuHIo+k9pQ9YDZGVbeTggTFwQ2QDGNl/PL+f/////+ruE1o/JalKvLft7tQvV9lkY35NUxgPf0ORVOd8NZUABhB7QGlCMrMwDL1HwCvSSgjHA5K/fPdqVf+/ZPSu82n/t9wgkwST8g1+vwjzhCBKr9Uzmd+kg6GB0fSxtC6/zX//i8k/9v9ROz/KCEahv1IAD2+j5hqHnnkBGBZMWzMOeQ1ImdBYXUTYaNp/ppj/tMAQAAIG9sAg6zet0OLhiEpEhgwMnMLAjDAwSObKYVYWC86QoEy/VLNY63QEpomMIjMeG+Tar6aSjgkJPY1RpMtLgXLccReGAQB6UN/JQn8sFX9Evks3liUCKkh/OoEJ/MBZjOtL5mM0HTHn9NkaKR5Bltlyp5USyRqilp84mHkBSMEK2KkfwFzPrJfbq5+H/z5Tp3BOStVdbi0mmmobKqus3rXcPLz/ZQ7onzClXcetq313wAADAJtZIkbA+kx86sIviZAsVBOMLaRQIwA5wW5/8O/hzv+yEwQGHJPpjcondabqYpklcVArHebggKgYwNAVEVkroxy13/8rb6uph/+w7/PFXRPqwID/dzpxGYhIVBCByhEwEzop12aA3UM4qbhQXFhUJf7P/+ja/5bgIAAELvcHmsWFYOa8ZJShw0Oh5loIv8RiBjYLDyqLDTCQDU2FhNRCznV/6xKTCxOODZWA9eOFY0kHizMY8koXu7n/6cdNoJ4D3kSSzh7VygbjwcT1n2KRuQn9ZUGx+omw1a3+YjwGNT/q0rn0Tx0xT1FJlgoJyjwllPv/+7Bk1YAFlmdQ+3ROQHpJSh9pQ9YU2YlH7czZAb4haD2snXhSWtzFCys0Sv3uVrf1Dfvt18b3KDfvHTbvy/57tEutyxGJxgue9f6OXer9yYAAABAI0gVPdoRizIjjTQ1NC65gB2Mq32W/a/X3/3rv3JYYrUv16sq3J+7WacTbqcOTj/K7do+SyO9LB5G939c/whDyI2P95z/6P/ND/+qgn9M2VU6aXVz35p03IA8UGjwfCUoKljaf5D/1+qqNj5fQYAADBWLGingDl2fiMaUERxRK0YgFMUTGUxUmV+4MAIvtOh2Nf/kJyhJIW53Wis0x0Mij2xgVLqcrW9TbEUdjJEQJQE1/L7ljnpxkTjW71IaCGJa/QkHP5oFz/6FgHH9G1KnliarYcI0Z4OvUNHxoQStHogJR0iXPkLH/IGsrPX/jPxz5nnGWY/m4xn8xes/vz3ym/1Lal99pKEyFZ3zGAgAGKVdKCmVtmcAqwEGlYKCcS5ig6CaJkOvpEiYX7hfRfMWpcv/yoUjMVTXO7JYPx9Q8ebFei+kprb11cpCIBGEoM4liNR7VxqJU1N+sxqKRr/Uamv8rFs/+cPBtIf11oo9WE+7KyibxomGEUQFyiankCBmdO5FeVvOWzPdVezDUayzvMcfR3QyajGKIqOSPjaOgAAABAVBPEBkhtiGoSFUYBT0EaKS7dygiidp3hYLuCBzJscv/+EqyFRVdKB/hkeB5sgbHvjxPGhWMzuW8CEIRlCD9S2XDw1Hzr88898XFWndnIwaiereUHg5/FwWWM+xhQKcAGf3OKujDQlKqTQFEI0aaRLmxORAufIXrk7IjRP/7sETagAT9ZdJ7Kk66km0aT2WlyBT5j0PsqTrp+iUp/Zai7W3CsgHoQWAatvfX//vJe4b6lcNuUbvbrPn/lDbuPuV+4tYzIqJ/9o8AwAAVR1QxA2rCpqcplgMWZ8k+8LHGrcg1/U6vwacybHLX/6dywqSrnfQ2v4gRQiMGMFJSR4uBiGkbVhwtntXKjVzX2dMeSf84XT7/ieCfI/6h5iPb//viFpVWPuVOobUW8wPRyIUJvm/92rafur2+tyfzhlc8a8U6sQUqvK+p4GAABFZizzdLUCoxUJABmTjBh6yAqUaacDNzQFp4aroeiwktm8dQYYOACaiBpwVSzAJ+KWA+saSn2EZjOA8Q85MkMadPbH8yLr+osSVLxL7ecNjW//g3FqifBtyseKygBg9nlnHD1yaZ5RJmuiTR2mhkec0nMTWIxUofJa5gdOJGRN8ra/f////EzTeN7XI//Npzunl9p0JqeN9xys7vy9AQACO04mkwstBlDYUJdRtwc/L0GCydM3VZSvdV0PW8x3z/9P5ohACp/klqbuFQ+BjkAQus953FfaBQAIpuVDjedPZxsT8TE2Mm1ERQzjiG9dvKjM+/1OK3/OmQVn/+tFzGCahRYkECOhTbARgisDVlcDIib///+VSVgRupgP/0w77X3MOMJqHjdqnIr3Pp8BgAIZSeUPEtQKiFggUMnsIGXGel0qfKBVb/00hYsus/xnisHlG3MCrheIqIFeE+J9yEHKAoRkgQjTrZYP6ZdN1P0mOmpt/UbJ/0Btel1EBUF1drXPGhRqrIdk0YdiyGUI4fGbFDoEcOyTJctrBTc7t///4xWrr4//uwRNUABQFg0vsyXGqPLBpfZaPJUV1rUexJEepbLWj9lqNdEd5aox8mIBfkFwnRxiCu7U32yugoAEOUYUYxqqYwClens8bW0HGFiEUIKn2AFnwqL+i9iXr/UWf/6qSXpIamzyrJudKiZfE4cBYiR2O8yaag0DjJ6uxa/8lsf5k1YgIxR5/SYmkYhf1FMt/UMcN9L/kYS9vV6utZYNQmZhQTDxpNCQY1jmhhonQsk+HEEfrX///4xWq6+Bd5aox8mIBfkFwnRxiCu7WK/XKwAAAEEXLDgZZCZxds94UMrBXKHB1QFKkeFLKOylYNFs4gYaDJNY1uf+yqGAACKqGTG2mqNW3cJC0OXAK6hwLGrOXNioE4AXEBkNiviXs1JsjR/GK6S6ztYyKX9Mkhb1fTE8Bl4uv/OE+Llf1+ZNc0csGJMU8a4elZWjBNcbGWGByfHqGYsKUH7FR7N2cmZmZmZnOnerH+60srFlUktORNbM7V2nwS7BXmnflh1qz/uelgTRNomUNW/GU7GAYrXzAOLJUA4ewUH0JMhPSOkKFroR2HWVPJ+mvxD6Lm/+cQNX+5Hx57/7ONZAIgtPtuThmCThwibBy1VdXRNKn6602/qf/SE5/5UPMEnPOvJjs04pz5YPRg4sajiQwtxxBCg5h3JcW4wxMUztn7DUBAAAYB4b9y9/CQA0Qi/iOhR2nUKkCEugaW6ReHU2SHsQs1+f/qoKakDJQP81d+sKFkdpxXOVZ7zVVHd9QMUynXi7L7U2zpDyTOt0XKA5pU/lk2K10OpxVHnX7rTJ4Z6//fpHQTSUIEBcEAHYItmkCBHs2SEAHokjb/+7Bk04AFzWhP+3FmQHFJGi9po7pVMZ1H7M15IfAlJ72ZmuiNpqCIbiYlePS3u5///jvUl1ucgaLL1FO0EOZbD7OPWrTStrEFrOLPBb/dT60JNe8SbAAAQEiRlgq4BzaE010RI8SLO92A2Ct9K1cQc4f7Z6izha5v/gIwQGerFoo8oX3a6mkFi0W9JeovlAB0SfL4KGPs/84avf9v/e3zo73bbPmCliwJutBHU1Rs6lNHtps+bNXRhmypuSTeg6LsSYcGf8tTX/5z/R/9Sqt/o7AgAAIpdI1Icv8kmVAwkBsoETREEdQSTDjW2CrUCDX0xhBRcWXWLe/2Sgi5hC3JjXzD34W30GyJswyatrHvM1qJuhUgec1fFpIXX1kPJJm5YclDMhFfnTQnrJMjj7EppHjFu9ZUJVe6u310AugKqJILTIWSVGKaNEyIfRipwVOxvjbMslD////+/nWv9TWvUrz7m5kNpre0o6BgO4gDIWW/RZuXvihSMn7zgCyAHbmiG5P4BkrABBJMWVDDLzGnonMNBokTAM7U3J0W4X5HgBktjjnBtVjkHQDEO5vZERwViNIp/4qMF1/ef/1e++OAONv78ufsnf6I005RuNVGxo85wsMCQ0APCYCWQ1///y2bv42gIAAKXYoCWj63IGHGkjSVbABMHINGQkEVehVcBU3gkM0L/3/+nZBY7FFv9Sf9kACehkqC+rrGCDGA1CdNcxIed50QMV0mXpMZDqRv6yMSz1s9McgBbf3SJxKg6HRsm+a+mdSK2rOYmbdWv39VaTZW5TOCp7O+N9d6bPOvDRr6yFZ/5vOvbS/yc7n3hqmP7f/7sGTSAAVOYFB7U05AaCg6P2InbBKloUvsNNdh6iJoPZau4G3yz42f84clMIKvRE5QEEQtKBFTZJXKXXEnQOCd4mPXhmZvGSoob//yy2job4yzhoLKA3u/U055E+BiH21k43C9DYgDU3/UapfUfWs3qNfOGJ/2qMgXG77mojUBk+3s7+e/lhgq22RuhFBrJurlRdLgKFQ0gMGJP///6//+yo/Pl8BwAAVJ1RWqThighCCqMWAAQevA5YGCg+SwbVC1f0JVFAxDTZHY7/ovLoKhatXfg/VcsGBzJUoV9jr9XWkrzDlkFzbOELO8xBxivrZZmyYcRB38wIKX8dwMjf8biOe3bv6qQwYcPDgVJGmEGLSQL9jht91Pg4dw6NMXcrFpVa6jUlRpG94jYv0zwflxQ0cSw6D1e9hyULxtfx1VGAYZsbZPOHIFlTJRN4Nj5W0IgC8A2DjniS9CIatHMOrPY/8iTgVT9d9td/CnL4AASwxP/hkYAiSVJw/q/6i67f77+pMj/oC6EXV/rQLz637eyBkATCREgNICu80gsTJg0Lm/oo//61+f08AgAAR3aRY8GgpslkBxT/AI82BhqA0zSJajFiWUhw35AIRDWXWJr/wHGkfRmkim+bhWpKSTJcm2+3trn70oYoeArkNfFgR86+oFGGvW0kT4sxGjWv4/F1n+gFeB6nEf+Yj0BKdpQ4xqRks44dSOkttJufTKSrHZDYchCCTJQUs2a4lHNnUOnv/Z//HLT3L7o2s25KUbfmtXXNRsteW0xy4fSLLrkuHULkezQBGAAIUnAKnaCKElRsx0K4XAB7G6+6Z9onIf+rz///ugZOgABM1m0vstRkprZ3ofZe1OFUWdQ+y1eMG8J2f9lqbg3/7VKWafWD/j9T93mQhdoeCPUSaAckW50IZ6P+h+3f/d/6Irv//UTu5TWWs+EmIrRaSi/1nq+rCfv58m7I65q3kbJ9BzKINNzfv0f//11a6vdsAwAAWu+QRAMWSSFgy171goc5D6JMk0AJa7TDxITdQKgEQWdvPOBNgCjAnUFlyyfsEWAiGANkZI87WFlihRCYiSLY3DbRfUGfij62UWEheitD+VPLA4z360Q8b//gwH1fNtrEzMy9hxDCgrIgXJzGmqxpg84c56daiWuvrj79607r0lakrsYVdc2dzhfs5xooCB7ip7zwCYwDxW1DjekMgkHRBeGSvAgeD0Ih7+H0akQP1hv/33loVQcRLMWue3WDv+45RfcaKXOkXUDQJofJGIqd9fOkVX6lf/3/WLQIAI/9I5abNrF58FhckiLnlwdDa1ruqb/AH/f/Q/7broIAACJWtl+mVC5BVdOnJUeYCPmyQQyBYcRPSmByepKI2UHH5lF3/8daDNRykau5BuH5kqhGUY7xRR1GYE1DbAE4stiGNNB+Ath61tSY6Jw9SPqIZr/HwJB/xgwOwdql4xzvEzGiET2UI9sNyLLZqklRitDT4g/H6jfi0xzpaGjebs5MZbJoNXaretPd7G+aPq1dpHuM7H//uwZMuABK5aUfszRHJnZnoPYzCSE6GhQ+y1FwGsISh9tQ7kWf12t/6g1GWAA6CIBi4Gs0yIiBxwZjPGEg4WAcvw58OXmD4tEGgeBpHDjwUd2SmAFi3rFF+2rf+q6IiN1AsLjcOFQO99m1NEC/V2nnf5jfzxC/8F0WSCUbYW/eaqChmdc1LwZZgkCizkyAcHP4uqzqzD8DAABrdZTuAChLvgH4GXIh0KKxfQOUTD63UvwMB5mjgjTTZf/6JCC4Cw8Wf8yWqIcUCj4CqEg6XUJcSoYnNXN8sFTMH4TFjD1nlkeiRggVCcNvI8ei7+gRcMiof+IYJAJdD3RFXWzK3kze6W66fecm3faeZ8j/rjvkbljR6att9NpUDovMtGN4mj9zjTI+TwuQATf7l6tcfXb3tCIADnokbbKLJbBIQcbnUB40GWfYkvVY5eVO1rPx5228wtST/2VRD+RStcn38G3HxYAUh09RJkmHcxOFN9v9Xy6y0SNv9Rdf8xDfNv+cQkogjutKSLQzLk6m2q88fCUK8EAlABUwicVxF/Wz17vfDgCd7SGyQJCoRirZuTNbULBWjWSAUxkIiIhHhIRt1AuMi3u7v/0SiEXpAmNJduyb6kEk4RiAA5keiFvLomZCOq3I2rwP5s+0T0lwNgXUoIJEPxCmCP6zEIZ/8zNSTRUkpkEZmmkZJGTnjimoPPVlG1Jac2kQzZc3/+kkiGCz/jMRTn0UXcP5pRbZzgyxKsVV2zl/q29MAAVuzR+op/slAgQEYb0Ail01F2w/2VRtwPybAw21MwRvKlL/g9GiUsEtukGSr9RgdJA/Hrt/r/rTPf7FH/+6Bk74QE0WTR+xRFUHBIOg9lqaoSYY9H7LR3QaCgaL2YmnB/rHQOhf/JnDkzSDkKw8xEpzHYmap3YsgkcaedLnzwXDBUe5n//rq7zJTwUABEs2jNUotG8BAK37AX0Ih5cMDBhOAQO5AED1MiNEvs4tSZ/eCbw2oOqkS+9UX3BkEmuJliMfZ2cUDAE6PommdKOrwCcw7SYfEGDWQKZt5WMg634+A2EfW4fqQHoKB8tdMPkfc2aqsK2tQ13PMkmJ0YU71ezQIdVELf8mwNM3r3p4rel+33m44eBqBYMg08Ki5s0Dv+zRdOV6tqECgixW7gs5eYFKHpAaHXIC3zz/dWG34cnn71///+2VLRF/HNJzH/qTqNga+POC5Cqdf5q/eyafo39wKt+IpEJlynyxjkvV9yNTY3fvFyNHJBRUQjgEMH/el0v/8xZf272z+X/Izgtu8ln92NgGAACTfWG2ImOYDYULBbi6hoUChJBAEYOvi1l9AUHrNWhGm1r//BVcXFGAyIL7l79EIo8MBCT/wtxIBZFk1ys9q6gI8o9pkzhxHq29ZARf6A4wTn60LY0NiOPMPhxa3eiRiRbp1G8Tq9SNmKq9UlN8kf2/TVMTijzwfjiT6L5Hd31Hh0EV12depQOM3+37UAAALReN8dvjJVMIUxNA4scAZyEFQ0x1RZrw0I1VUE6xp/+4f/+7Bk34AE4V7Rey1FwGzMei9k47gRtUtJ7LUXChOx6H2Wmj3pEZQzpMPw35JGYE+aP5kolyxYtG0v63+1JTb/YvN+LoKWUNbnVx3c73M4Wa75cYmjjV8393tn9vrZNfPkXULOa0EWu5r5s/73/e3aa7O+di/mZu+vOIdxuK31C7Wv3qfgQAAF1/uXdA4sIwPS5ZxdFysFLDSwSlWImWAHbqDIES7VnL/2QlH4DJVEfuNhKSJBCRc9Y3SMFx/LLfqCYjQ1NM2GuHzEjo+UCIpP+YiBz//JWgjurm2xCEHw/Y7FY2+zy/GtMzijH2W5baBX3fW2fne3optTjKacjHgpNj84WanRT2Y29iC+2rxBkYTa573qYAAATZHDyu8IOoAwGOXgdI4QBJFQV827LwlNGoYCgAcF9ym9/9KHP20dj/KCRf8F0ifInt7MKqmCv/85/pZX/pIW+eIgAEPdUUWASMgCbM7ZrrGRXZbOBVE9feDK8ZRUgdhQg1awP//+qWr7+E8EAAAXnEwNXL8BYUZoYRXGtmLCGjbvsXMDHLyVgUABJHUdMCdAIJgr/Uv/VGH4utETcmXXo9b/RInEkBhSpEBtY5b6uReQay2bY0r/gxi01NJriHDkGtXycmmf+mA+A4CefMC4Wm6/lBksuvrHeH+5+eUcZjP88PTZGd0yzXRtt0Uh5fYZ2zV+3yNbW5bZeeaTYr/WplFZD0tpzW9zc8xrXTfv7bmTqeKuamWdqMr97wAAADbbMOkB3jHbCrItpBhFIY4COzkstGBY8ggDhPuXbf7/YyKQtI8rOEvWiSoIcW/pnSGO49PV/WnT2uySKf/7oGT4gASCZNL7EjVSbkkJ/2FDuBYBoz/tNNjJtiJn/ZiOOFbepbfqMhUUK02QTSUwSBMzSDvRybcqzd2WEzeZEOHAKFQ65Lf//+R6v+hu74TQIAAVttbjUEK2ECRokVSBMpHhaDQcPaau3IIjwlaA0aBtb1vWIrSGWjh5Qveyv/ocHHqBY0lm8ZoSoL/Fyex8m71+EtByITh5RcNh0hcwjS+cHp/0C8FxDzotV2nPE21RuuZjb/5mpzHa4aGW9WnTu3bPDOeCSQmOh0NChFbgkDDkINhwXNhou9Lc4uLW9PqoF4vP5sUAgALeRQJXaaArlLDdGyBgQsa3Vb3aj5pepd/HmWd///9sLAo6RgsJGhGCW4xySCbn/mp0qnTm9v3dXopE8o7N9Z79QV4IWQiiZH1LkulNbYwRDRYY8LvCITDQvXWZAM73f//u+uP/YfAIAAcmlbSufdM4wqo2kUuU1kMMN6VBJjTDjwEmeAlm5glMJnz1LlvVUZitiHTpMex3f/q2SaKARQqn6xLQ6xRGicRyVHdr8I0KR5xpHImAe4XnSb0yTT/QEjDkygmUlzVTajw3XjUYzOoKtSUnBIQkUMOSsNQWxqR3MBfMz7t0n5ZkunNvJaQutHXQkczR9y8sp0SBjr/9IpdGzO+i2AELaE1kxzlxYaOXGbBLTTAEUn+tZSC5Ef1a7//7oGTdgASoSdF7MjXAaUbqH2WjqhO9nUPtRHcBnB3ovZaO4P/vemGvPLLPzM9+24whfgkfksdH9zEgtRt+v+tk0WU3rU36Z4DyL7GOksmqRRzjG2E6ZGKkAgIpOrgqyfhM8bKiyOn/26PKyKrP3sTAEAArbtbNSDLAwMdGBIGbJCgNAImWsGRESJDYh9/ggv+IFFrGpa3P+qS1VIip0oJ/u/+bgEVUqiyCq8UgHeA5RlSabHSIueV8MlCgzjU2H4iB90n8slb+s0Ebf4pQHvYOQV2Ra2JosNqAqWWDdw9o9lNETKBDyit+ek8mYjkjdY7o/vGKHsRoORNqeGjwwElro3/uTdfd7TpQACZu/Tn+KguETgKc1Th4AiBTj/mNmMW9/+7/Lk/0wnBn22SG82fyROiDjeRCtqv9X+r//+VDIb/KKLpR5mJudMQwgSEWkjbgAfCaDAt437P+vP3ZfwIADc0cTDBlYTBBCFDBHRr8SKlQyEZIsSLhmQQnjquiaqHV3/1dKmMlFCUCf7t/skAFnQsE61nvO1UKxgYEaGUv6yJtX1h3QemcaM6XQ/weIhXNyt4zpIW+obgYwNX1UEFSwkUKrAw8Y3pavwUpwxjZRJmDYtI2AERBlOQ9yuWb8CFUaqDshyMne5Gzj04+Nj4K+jYain/9VffrVq7CCFqkadcQQOYyoREFlf/7sGTOgATDYND7UR3AVidqX2WjjhN9n0nsyHjhpCLovZaOrJCwKT/yPW37geGv1h385FzmCIaMbPpf9c9pHAU1XyWMimko//9m+UyxId5KHklei39AT8AqpdTIE8xBnbrSV/+C2eJ00kPUlMgwiAIQkBYuTITPZ/5JNe/+t+BAAFO5soDfAaxPUHGGy0kAwEIwXoSsmuNtXjQwAPuYKhidcWvZb1mIswUoIbCjTtSYQYFMDah586GrRKgLwSMw1Elr8TyFIacaaOUgUY2WdV50eS4aZmXzcwIODdEnGzhVPOAoOBrwGUtcTHKghONqFLjPVTrI4LJUrlh7/SZIaRhjeIquHvBUF9b3pMp4X7r4bhOETTue5xbADFK2Ji1/OWCUhjVSljJy2fKfWpfSwLhaZrb1Vu8XoI0HOGYmJI6xoheokEesZQ2HUemH/1fmLLW230/Q5iKMf6ma7Mxt5vrm38zb17Zz9zH91LfG2W2M3v0YF8/sbzjkBAkzY4Xv0yb7fyUgAAAVFGiJE2QlQENARQC1gKJAbJAAEwAUeMSFpzRxGE7LTJj0forTYZ4T4g6gNuCZI9Ow+i1dLC5G0QERJzz5wNYRwDeRopEtmA7mr6QpoVI0sZDjQWsLHkVrb0BkWWutJM2RGEmgupkQagwQzHaGAYwWXBDCYRICd6TH0ciZCRWHZ/MOP0t6u5oKKE9UtTXB87N0j6EDbKe052cMGaFwpMfoZbxWtXvsQyuPrvqwAAJSnsRDVgNGDphugcTv3V6sxEAEdvPe7zTP+o9fWNYHuRwsWOHtikFeQfjWdDllks1f6D/zBTf66NrBCfw4//ugZPuABMdW0fsyHOptCcoOakaPFcWZO+1Mdwm5oCg9lr34cMqgjl11K2QXKk2IdHtdWzuBDvZ4/tJT51vGP4HkEKhIERCk0EzId1v/dSrf3ZbQEACE12kN+R1StkiJMYpprSyKJUwqcFxZcOggwA0BcJsGEqt5d//uCJ0nbJEyY/mZrWEaDTwTQZJFLOiC45IXWqXnD/8ugzM5uaCKi+PbeShdZM3OoGqSJwXAtJbOtIqICQvHuqs7bZkp2Oc6pxmPpq7oVLEZ85Ub+Zvz+n/1tf5sfzN9s+fs115wqN3HZvsT8bpGpdeFARrr/rv87c0LAACHLIDrDPdQ2AB7AwKk8xELRJ3xJLRuCgizCY3/yHssgqYmvxdC7CbkF1HtJIgfmiRBqR//f+6l/63TNE2UpBMLE6y1KU+SmZ6NbHBibCQjY+RYZKGhxqWXV6dOKQQeOIn/up9E/30uAgAE5vK2NGd84eBggqVNIXEZKNTBswXJ705Gti590Ai0g205+N7+VClxcUMoShP+N79kIoaVCEHFb/O8rsUHRI8xs6y/TPLfP33/3EihzU3Qf+PG6oUWf1z//4Mo+dxlMZpKPUBpG0tPKMIalceyjnzu2dimhvu3aneJsedeTNx/u4h8g+Nhjpf9v/Gs81u78YzZ79tdkIxqNeIpnLTY+Imfm+aOWRFKfcnXXP3z//uwZN0ABPRm0XsyNVBqKWoPZaOOFeGZQexo04GMH6g9po44JbMAAMySInFEIYG3jix0wpN2pSwTDDu33gmE/ddmXY1reouk8QpvUvMDosm+ZF4S40SS1f90P6aX9P9T1hZ0E1um42Kw50tnCStYChucIGdDiICD3iMoReBRZ7WMQe//RX/PpbFSAKzWWRa8hR6KjAtKvwwyAoO5oIJDJLL6wSOGdsDS4Cif1+p3+T6wgamWGSJfWufxZRNWHAi3IvqEZBNIFojQXnAmQmP1h+AVAkiWH5MBdjsfqZbmQ70EFu0+s6GlGyK6CzA6QpruTdK+oI7MQrOFmwgiBloz27MqswMlQ6ZcN1QE5NDgVFwTh+aQITAzruY/IcdW2u6jrQ1Fdv96K7Ph6RgAFLdJoDTigudAtLAiCAxwQQHEdFE3OoOQAwPa2+svDKEOQqfSTI8/+ZkHPep/60XX/8yek0sbWdwWR+5wK7SGLmYJsoldSrIn9StNJu7MSnS4vemk4O/mT/nMpIyqKcmw4/iWyPs9U7/Q9ggADp9tIim4gcJAoEsHQtYOJXWJQCBL+TbDCVOpsRHJkY584IAgUnA0HhQPU2TYUPiAR/46w14FQZxFVQZ0Jg9XiWAwI849BYlgkhJumcNWPOmRJE8gtloR8BqgxUo2PXExggkSWlcGpF50tXIoSy1VqnDMips98Hdy+p13fRma4zTGlx/QyfVyn17160df/3GgACFZt6GbLvEbIuMGFuukCgGUskCCNKp9X3feu/4lgdx+M9+iLBL9F//+p//buVmda5ba74uL3BaJlauDsGr36nespENachDp6TH/+6Bk9oAFCmjQ+zMdwGwp2j9R4+MSGSlH7FBxyaon6H2WrbgZWp6zV7l8Sr2+Lc6UaOmyppUmLDpgdOXNxWxKqv/F0FAA7P//mnTtPBQjOyAQhFgQKX/HlZtkeMul9wRCTlfqiy3CMAf4M/Ch/YSMLuD8yu/cggNTgi2bsb4vhUE6vEQC4up7nhahpD0i6zVSpKlYsskZpopoEDDlVH9bsHzEkTZXDlesjnsjVEimCpIS3MU6moc7ghTFIx6OJEeKRGMQZuFOjHyA0N1TekOQ/8TzMkzQHsKa6zj8BAACXpWDWjYcUm8Thi0NhQauEcteBSNIR7/8P/P8wC3gTpRFtn9Syme/MC81Pt/3/ZJ7sjVsmUkSYgZIOLMEjlk4imZx08/Um1bItDl3Rwu6AIZwq0zhiSJRRDIauEO2X9j9+WwBAAlJNXEg5wPGC4BzjMHXWcBrmChJpBS1QxbY9J9IXqTOxz3reYx0P1jBpM133qCShdwXCESX4uYJKFaSWbZ8YKqvCRAxGnHnTxwUYt7+dQO7NdyiJq7dNaiMDA0zEsgIHMMagnAMkR+nfTB08pXN/uC/89p58OQv7SwZUi6CUF3Ss9h+LNsBAEjigh/p60R2//9XAACk3uAC6VKPkiwROezksuOFMnEYqkEK2CtdcFvMSEWFNLMJIDHag/h6RF/fsYv+kSVaWpP/+6Bk5QAEwmjSexMccGVJCf9ho45SZYdD7Mh1QbSnaH2WmjhD9SH9JtbfYnvSUo0NTQFuW+mfSHQe514imvXMs95Mur2/uU33u+M+zOeZ18VBi5ozu3pOzr+GwFABAnUQDDgm5A5kgNDg7xu0bMXCyQMYgTWQlssASvUfFDZlATq1Mct6FKQFhBDMFTvPzgQ5DnB64MAS7PI0E2gENBkUkeSpCavCQA2nU8xPEXD3i2t0vOkQHPIuV5bUcNR8Bfgul4iBcTKhZCkoIJWoJjqBQpSHzfIlMv790UJz2+n2GTT1y75Aw/MCglray1wm2qpStm1OyuNz2ewIAAKssoJ5MMFBCIB2anIjQawdzp8nZh18//L/13/oF8iwWCOvPJxFP9EJttf9G/kLZ5voPD1PMahhEEFirqYj30JBjI0KHaqNZm87cvhd6a8mTx1iBFFW737f09BAAYTNIpl7ZzHADCgzVnkcEdUxBAABRYoB32iqXmADfWBAYs7D0xc/8iWgmcQBSJN37X6KhMeAKKurc3rcFAJC5YOun41yrpNrCMguK84fmBcCIRKRJnTRGsvny6LYWXzZA+gVg+rJHUKi/SZS5mr1tFpRypN4ycF5N0i4zQUxm4OzO8LfirbavNTNmrlWMrn1KXbj1x4FxxwGlBX+vo5Wu75fAAABDligOc4RgGgkUKGC8vD/+7Bk2QAE6lLQe1Mc6FzJmg9hQ5wUeY1D7Ux44Y2nKL2TobxQFgtPTflHn0U/mP8oD8AwbCVUtnFB8/5yCS//9//meUr0RGilGTIg4CYHwOF5eCKbtvFaYg6mtzXJH21zV9R7Vwk+3DTNs3ZJNMsiGmjLVe7vqPAAEQzWxs41hQCASBUzz0+QKELCuyKEmMRIUMEJ4kZvBMZvv//35YmE4BMQq1b4aKHABqQqD6ygGAgFmBZvjdf9YRIYOp5YNBQofR1saTpmZGA4SiWzJZ83RYfYnd0HW12EjAwwklHEqDIXEAdhIvPush9dHXDcNBkOU418ukcSIxO5cfZS0hFYyEu5oRbJ2xtlwX2iAaPz/u8sAyC0sgGqkoExQ00wC5KtlhyTSR9Xktn41dWSglSasqQpP/J/2hyK3/vbzbis3LUh/zSpj+n+3/lmfT+e1k1bdzVQFmubqOUxqSj1rm7b9n5NOAP0e9/851VDW7/8NwMABK32yJr2Zt6xi5m5oOBo/o6AKWEIT0JA0PqhJVTIAYLHpbrOoO7DwKRpQt+9QloImCMRRUm1iKg0IFFesXZX1trBpAiqrn6TGIeB9e6zAtoj0pIixudLw4AxMcNkjUooG1xmOFfQEecLzzbph6aK0LfGdSQzthBNvu3w/NUO9mbIsI+HIbK1I4IdEQu4JKY1ChB31f64vfdPJQIoBRIgBplkAhqHQvIzowgk+e4/kvhlTDP/uWq+tYbADtA6jdUezIpBMil6ycTWb/+v/RfWrN7JMkp1oJnx2BuHaKzFRtm85WIxYAiox5ro9TJa+dZ2QQZB/h2TNBHq6tzutfAgAP/7oGT/AATKZ9J7MhzqX2Z6H2TotFNdmUPszHVBj6JoPZaOPSqOIo+ywYKoAKmpfoCEdwSkkMYJQtfPABF4gQXy0BgEBsuwy5nUGcDoAVVKIu75/ZSLisEvc//0/hUIMcJ2abHXREKRH4az/+CGS//39ZMAZsbyWk/9D7gO6Yxi2HwzIM8bWPhjjvU06a4ObQZTfWH3nhQW+G1ED3JWqaFmxA6KtRVVzXGQjkXiHiasoZDxzVEBkCFF+umXKcMiObygyQZQGP9Y7/NV+eqxFABAfjQB3ik2INkj46yr92igbPDvO8iepGyWzTRKH9hNwliwj1FmgZDW/yRY7+39f/kGZ3kijVyo7TvNJuScehMBFx9e480KCp0konQ1ygjUdmphCFb5p6irrt/SzEdnNU09EIgQOkQ63/8hef0NgEAAzbNto3L6VVGATkIWIUHIsuyQAkAFdsiT6CDcoC4ShXcf/+FUonNX2Vh9/n7eAeNVMQnqHKCAgOQz8pB4mlnrCXAu/Wf1huBnysZlswNWQQMxhlAdyJVKZkbIDrE9m6aZofTeszdIzamksbqaSkqK3S0rdY3TvsyTXO4meTossu0CBOU4Kr5Pc2fVyjNp5DzaTTp4q/++a8d9/Kr1koO9Oci+c187/7osAdJjiADlkTBIkFDGh0FyASGhuYASx2QCEFhSfpVFt0DjSv/7sGT2AAVjZ1B7Lx64b4kKD2WrixUto0XszNdh7iToPZaiPCxddHUI8OcO8l3Ua5TNAtBH8yCWGMHB+l/p/2L6SR5BBk1LTRYwRM0kqxTM51B16sQRcYHaYlhhcKiU0zcoaXpzRLWbbNUJHDrRcnDKgswgNjRn/6qvvqTQQACKuqBCP0KTnEL/iwrOnmMWFtxEILI2QUWloKE6oRCukY/MBVf/gqEU6Kqk0X6vftDoROMhIKrrDvhGwFmL8fA39fh3hU3rfRFnAschSqVyoQW6RGkWGOHeyy8tjMgIErESJw2JorFwrzAzL9I1IeRQmTonkkiKl0rEGUTxDyURA6uu5N4VQ9xBgnIzKRR31PP+f346R68jEMqT/EBQDiZKTVTYmX26/sXb3d0AAGB72gBM1U4LEyHX7amYALIjdQEZnMUkpnDfcbH/+tf1+10xFyv1vV2Co247fJgxI/5m35gM6KCK62bUkRhIjMBx4tglGPktkUIAKWFBkRJ8WUdRWGEASiDCPCSGWGEMoN/gfWme2dL5gY6NYYoahQWrk4rpHIDuq+vL1v7swPwbY0qvVVbPltSou+mu/9V7//6j3/7J7Pp+A1AQS6tNPuByK1PQSsmDMBRzWsKjALOVISUvDHJ/NUBfmmu/VyvJgE5FOVi/rH9ouJ8ssc693/rF3AqkCVr/+vT/53/gQYLffzv/rsLJbfxPbyuOZjsi5YYe4dEgFYy2vD3PjMCRmYGaC33tDcDKY4ns2vZZDsbt3Kesj88p/lbnParBsd81mu+fj++tBsp7e1fO334frNYz5/aEa+s975fLxl/9S3FyrtAAAOkA//uwZPyABWxc0HszHdiaCdnPYgy5FR2jRey82SJqriZ9l6KsAAxxYwDQnEoAhJ2CAQK+K7K1uGLzbRZ6lZ5BASxGV91dVSIp5e/tFcn/MEyyY7//6jNEsFP/2S/9640knEtGn3z/4cWGc5zNFt5ZYS3R+wuESaBmMIDK+zEizs8Eic4QDj1qCwLoTnjTzVIINFogiFeU5PaSxHkVUR8RrODk0P4UUYlsWON5v/xv/6X/P/nO/+t3/XiwEAFFmkbdeUy2IBygG0QHjUDqkAJpzOywB+wABnKAusozfs//eCpIPdiZFVvWsJYcYg8QOavlgEaCWCpS8fStn4W2B+edfj+O4+yLestDqLpPmJkfQJQdYapL5kbuYmxv6GyMgZU0GDmtGfuPnubYbr1y2dtE6O8UOukv7ukqN5T6hZjeKqKSEUpzYNOS8aVCoclAyJtRXLforbP3ZycAAB2yQDDBtHImGBg3ES4Y0xd/VhMoBalTvl9AIAq1oBHNa4MAVh+1C+pgXTfCqQir85/zwBwUH9WUehcDX77GFLTkiUAONdqu2ymtiVUlckR54WLchDCSEEQIkHAiPcBwkGDB43s1dnp+66joCAAw6m0jxrIMnBQABARAoBAXICiJF2HS7A8JZCzu2NAfUpAIpTedWm//pQuPwxQCgJJiVZ1wnAQOTIXmerQI8JDBtcHZfx+Pan4lwOO871CWiNCuZJN5iMRTU7zY6MNNbNu7H1JOtdo6DRSkKCKi4ADbi6OZtHDYE7DJgINlFngZz9TlzcrJwqDFYMkZCpnh6VUjpRd6CKEbMLfge5T+1a3faHR9/rThNZF4Vvr/+7Bk3gAE7lxP+zFFUG2Hif9lSI0VhZ857kx1ig6nJv2pGjwACOoAAfV8AQYkkC4saARtz0hVSI446d1mycl7ERgzEAEQUmSYW1AV8KsRZB1G1RdQF+j9j5ef1vr5RUTp6l6BeNDYZlvm500cnDAqsMqTIYmSLhPFcmTxViofpZbJaJD/dZ0bNNpMhPyvL+K8X7P2ymQOQA0XzW8lte2VW7+Tv8+m0DAC3rmywullwByISMCccWGTmk4ygHDpkpV0CQ+Zqwoi5b/WEcgtkshQzdYQiBEsRgO7zgW+BEYVIz8fRCJzDxeBSRvO+XQ8DnkkC4aNOF03NUzzn1mY1hPSBPF0oMsxptBLM+4gEFMnopW0CjPpuQaXFkWbHSHUl1y//uCIrS707k7NB1BiylBUr/CwyLWFYsaRv9/+ZMkA6m0hYLXEjshQwHKSbJJoTEJK7BGV3ptYNQ69pH1iv+/uoIEGpj2+ksdiHrl9vqf/QQ/U501EzTL5u9AwVWUzNakCoIVMumSObQlpx1zwIUppENzYmK2+REfNTKZajQj//5ySzr+n0EAAbK5Gx8MncIBQCXJJqomDJmSPOoITJnxjflxEhxo5uODJYWHwNLKb/rkrMHqKaD/a+JED2FCn/ilwaGB4JAkeRMOlJdauowDgkK/JgPqszNWOpm6zA2RZK6a1KGzTvQcyUil1IKMDcnVzA1QTZiErhiK5OSQyqH9j5Gx/17Tj5rG6LQyOpoa6cM49OtZSlyQ0Bk8JNBbXYc2eszn77rYEABmXyxnJDiwk0RQGhTBDUukE6XOH63H4bqaN+YDlP5h7fQ9/3/z1/6G9h//7oGTngASxW9F7Exx6aOkJ/2GjjhQNkz/tSHPBcKAofaOhuMiXzOPcwscsFgaHaHDCJVlq4nuZlCKb5m00lOabLMAsFFicwCBJAOtuY//5+su+w8BAAH1sAENPMsNq61lJujCBxVUoGVJhLysRf8BBfiCRwcM/Muvf90cvBEIkYM3exNAvaQ9L5mF0Qj4YUC0skXZYfiBdBtHVWyuDiN53vCopkkLWfUiXDlPpqTklCKA25VF5x1091fP8lJ2MzhanqE22i3dMet38VKOs6pq5odj5QG6WYb+ls2SyChPg3Vt3/7nfqMzmn0MALD1tzI3rpBCnyAIJO7j98zzvNfBxH52f8YAjtXlFhz/Qa///X6Q80eAEanNccu3fWeoEqmho60XhryYpUihrLs7booyYxtsn1jVtC++xqFjMaNlsixJ/9Xf3zHCgAFbO2mcc4PATAkQIBQ/T7QBBA5/hkIBRsoeNOBA3CbLuok5b3/+VC5VE8gwfjrBilZXqDuA0cEfl5fHWLA9VK5GipJ17R+FvPlIppt2K5mszQrOEGLgN4iCFY+QhSOE+yKRsZILWfRcsn0zi0+bCNMiFGWoSRlko3hkZ5TLzPvv868MsK+Wvagfy1yUyWBTO9hkZliVObua05GAB5/iTB6RoUBqziwoKD24R6K67C6dnsQU29u8tIgVJdgjj4Ji7V//7oGTcgASsN8/7MlzKXam6H2CobhNhm0XtSHPp3idoPaaaPM4O8hH380GF/V8uplpmdHM3LyBMKRKCWAeJIF81OGxSVZBOpTFQnB0+imap5132fXrD+hLx7KeMvzTbFtsY+0lG75fscEbF5pCZMXytz/220HAAz3GSxdNTIvGiADHH6fELAP8MhgqbrOEUxovdAVCgCavZ1MP+uVF0I3rJjuf/4Idx5JlM53/+qkWDESYrLn/9W9/yVew8EDG3Bnrr21HIve54v8WeVyhySwI9Z5GoUE2dYnx/muP7SSMGIMZgrd7StJexj2u/meZTTfhF32j7fWd7npCN5K4k6uzBKCEsHYkx3BkGw4xjpBnYNbv93tdAAAv765nAiYqBhQdMCASwJK7UYm25CwDvGH5S1qEyABn/JQdyf9a/0EUfrf9qiahf5oZDCQCYttFLkGWWY1CwZAAk3ZZakStQZQ6vYQTCGcl9H5X3umnucf1ENzFQVwhoWAgeC5LT/q3v6lsBACx3GigHIYGla/hBsGEGTCVWFgxYeC9GFBRUX4ly11Y2uf+xi48p6Si/P/9FiaMcegTf/qugBHTky9///Xs/9bn0frZd7vcefvDWLq1WdOodG1NKtz1vwcwfbWRIstGePSsXxyzfm4EHqYzDG60j1SAIEMHtEOgsjjQh1sNvczJTQkbPN2nmTP/7sGTMgAUDZ1B7Lx64bClaH24obBPljz/sMHyhpifoPZaOPDZ7HDUghK5jmpszK4eKFjJqj1Zu/yaEAAe9aSB8hgkAoVbwKppwOCX5VKjTzUAQ2gr/4Js7w3qGhmb9B39YmZKiVJex/56tbodbUDdgpk2OmZ42nE3Z1ozo6poVVKTj6EZkDBvisqcMnVHMWUK5WbVjLiVbOGCrPMgZf/Uqzd12wAAAh6igTgii3CFJbQIoy58BJU5RKAGBc0u9TQGEcJsEB2O/d1pBAsNDFDhWbdQTiJkM2Ki+soBCgYgMO3kqeek11DGifC4T5saFgsmYa8lCyZiimjGJoUy6OBI2TRWkykRPyTqSrMFW7e5zLoMD1gr4JejX5MGq7vwqPTrNUMHJNjOIr+t9Yjup21butn1WnquObmOax48w8cMNSiv/ex6vMeENAAPaAADQlFAECq8YEn1b1RsHZbIJbHYJjv1HRHqnMqAF2WnJL6iwVm9ZOk4pvUr1muMYXSHkkXB8Hi4o8wx4nBbmJOniydgcxTEBQ4kIiulEI5WNf38sm+zXLntF9ua0Zbl57bKc3Kpum07S8m5xI4Gvpo7/f+BLrvtOBgAVe2WRAMmc7TSi+YwQIMlBES+486eXa/4erdAOOCoWnRif3E2hSZwKj9QRGIAFUSVLdEA2IW0BRSvI8w7alCGImiBaSRcjRJGl9JNNamJGIZVtyAeFSGNdLqZbqOUm25eWS0bcqGjilR5i6SlmIPRLe9M7q1tIqBrq7TvrazM+Us0lxF9lzpCl3v0YeHh7//6p39ctACAD1Ikk6X1JCTwkmZrYAAYq4/OY+2Np//ugZOiABRphz3tTRHh8Sbm/ZiZ/EsGTP+xNEYGgo+e9lSG0aqmc9eoCpIMxCfoIN/lSwNb8jFsZv/5FzyR+OaNPFAILy0zFQ8N9CQPTYt+r5WamlibiGl15rubT+bSar+b7pDbCBOgOBQGf0fd/8Q3c/5bAMQDOkbTM4kHoFWwTIUmtoEDaCMDB1Ja6FIDqfxS9HKW/jqH8KMWQq7+EAgxh1DZfmQeAIUC80fH8+1246A7CjVFFakiMExNDc3NEGVMCdOzf3Rb67VtW8+alimVj4NymdtWft/32jNufnrI3U228qvnymzNyuztaa8m5NzfMNEv3tyvGseyzYICA4TcMDx0/6b/t5NiQAFeNM05SwwI0VDHJMQBx2qVy6qPHM13rtgP6F0YG5lV4ULiI36i4g/5U+T/8hoopxU1VUYKTARn0v68R+tfezTVczFVx3jE3n/mE0uzdU65WsasIpCTREg6pmrslueM8TfWAs++dNBCAOy1sojEiUWibcv3HgUQDro07ExbCaawhpfquIClCbOtf+noRqtlH+//5LZIsU7y5b1uUF/hhwdaKd//Q9Wve/6/58GrTWNfHGQXFgdXg7tNDT0akJrjxs3o+hZ7XXwYKtGKSHKFAY5q/SNzeqhKRz0yVmwe5+WSl/+/j7FSGITdN3R1wzUL9UWqg+2ZLm/yrwCQDuSxo//uwZMyABKhfUHsSNGhoSJoPZKiJElVTP+w8eqlwIOg9lRm8gNcEmBAwckUFp3wxAv91xljK3ozH/B4mQv+aeW//ztX5/Rv7CXOCktbLhB07m/Lxunt7aXzw1L3Lim06tbfcvUfezaVqHmw2kED5AeFJJPfs/9D//+bQYwC11jTKswXKLNJfCW5ilIfl9hYEWqJrpG4KU4yV9wUATbcaISrm7jIBhlUKS9zUHoHwa+dCZQgADei1bh1QWG1NuJYJgzqTWbHQ/wds0RWfLqJTJ0iQ7mRIZqY4QPXaUQMCu+GLCvRtlcYzwHqqRafws6xHnM4ZE/3vrSXudvkXOl9SEaDWWm4GQjg2lVv5v/0RV2IC3f7YHDGFugg8hPJlAcCgiR4Wt7lMdiOccUySi7KIH70H/T9Gv+bI/0inHoqoIPU2XEtjDAcPRtB/eCURw6c+wq+tgqouzWIsX32Eco+yhQOxU//d/O/vk+JRAOaZxxA9vFuCr4DSjs6EQwkcHXZtSxTMO1zsESYOKjOcl1ESG2Q4Kf9MNQBGkixfVzIG1ATUCIJFUuUA8TSVNeERB5nYyNlrRSDtMtMtroomZEguHAy9nIIEO4Ms9hR+Kvuu0HEqYr+x1WxTy1pj1m+Ek9ngrhVf/aIWdXTtbm6P1s2ZnuJpDvMJiyDGcjCyU1KO7m7uNcCpA+KuAFNSYTA4aQefxdNinnudlNE079M/eq+SqMgfc5/JMyFc/1iNjh1P1s7a+9TVbbiRV1cmo6VB6xUkepns5ThyqniIHPp4nKqtzc7FC+P//pSwAQDV+23BjRgDhwwAjKdmlwSJRuuKDF0cIHj/+5Bk/YAEn1zQezMc2lsmGg9oQ4hTFXs/7M0RqVUkZ72Wjf0QIP1NiIkYPXjXG0RQHmbrCAAUCoe26AXNAOEF7EPGoQud6w0YbKqn1Cnhe41WXzZ9Q+zoCJP+mgVoGBw4LtxyocM4YYWMz2JNDIlOlNM0OHdTz1ZoUQ4/LHePStiGyFc0GjkiQXoqMpsVe4M4bfwgcC963TYMgB7UTYDSghYWAZQYQ5EHlhvXfcmVKgjvCy7dVA99lN9ZMMhgCj4tBSf9XT9XdD/qQxOrqFahdXR9IdoY36RuC19PL4ajUyQQkwZl1Oa7fdv6/hICELtbfFEamBDDL7VlbSEJF4yTBMOLLMgEBOfpBACBUNmsPFxjx3kOBc7dYSMHNJ4hW1HQxaJAJ9+Pg/rfWGcFrvqErFcKsxLXlElgawjLB9xKo7IKBCkxxTA8bGpuqkd0FZMTspJC6Fr9nJr9Jm/XboCCJj+rOrD1IwphUYpQzKV9oK7P81CuNu5apQCAACruIGdBrAw9FFmSg1HSnGsguIhHVH/MYIy3xgoX8qF+//q//M//+6BkzYAEemfPezMb8lMlyd9lom1RqaNB7MxxoUkjJz2DlPTygOLDyC44omHwGHhYxylKhfNYpjKX/RyjjOz2odjFNKKpNLOldFDs75fwIADNv3wVkguHCqFlkTR7G6P6ODERJawBCSwj8F/CTLT6xER3DqB5esJsJ3RGE3SDAg6hRF9QvENn1heBf78fIcYa1I/HY5urL/aCeEoZssqToVj3FLbleC3mMaU0uWZkYD/CdGEFNXuUhB+xdldTFScgAAHwq4ASOZT6MiLIDxDR/yhYHoBv7X+c9/m/6v9yBzCgrQhAwUDljUoWpV7c1a7dJLV/Z9t4KABiP2gAp4eGBCGI9S4OIMcYDCyge2QmUYEEmnquOHCETsxd4ZOGljKAz/WE8CrkyKMi9RRCzYl4bwrqH0VNT6wzoVPW/KAkjUn6zA1I8khY1MhUG0FIixy7btfdjdpyl4qZNmNRnG10rqSbeJ1S2t1Hr7n14AISTEQnAKAAjCp6nKykRGwhJfvUcgqjm0ghP//tyw3gGv/Ol/CAAI2+4ATcjGr4GFK1Ypyg4TNkJwL3B4sB4le/kgIBl1NoJiusNHDTzcK03hg4H+R5Em50LmRC4cavyOITOeEACB9b6xdDBVc/zpYLpEBdMxzDg0kQoXphGcKyM/fUNKlWd9pJ6qtI8RJWZjZumSYowoAEAP/wktP/+5Bk34ADj0fQexIz+DZFub8cAtEPFRk97EkxqIcH5bwzsHy/25PgQAAJtsARTP88YXGG0HXmiYwMBGLzFid9aSEswEPwUuDjkfWGcgwJgDpt2IsFbkVS9QoYdY2fnyEznh5BF9b6xFBRtN+spEn1+ZNwiGHEMuleQ0Ey4WYa0vFVk9jDW2s7PZtf7EJzf/Fg6Cr//sXwQADT23AGVKYLlEDiPLWXGQ/g5KweLYDDhQA43V1DqySduc1jVDey2Dz9QjMF+KJOL6IX7Dyh4EvG6NnV4uhV6+xDgu4trT01Il8hZppJsvUfFbWnMdxxurnE+jN+Cit3JOOu7UairuewODGAZpCvGdXd/W3gwALZPsAKJZDBg5oTS7bamETBhmAOPk0qQAY35IYAQLvRPDkQBT5BQpb0AhGDnE2IYmzsVwLBBPYatMesGpRDVVeKGDT3rfj7E5H/TUgdKwNYXr1aQTBW8wt0qSe4+PhjsZd0XlFJWXXiGTMLpM7rwtAKcH3V/e244EAA277gB2AVRAYy4tGxd0wwDelS51hH0iEfw1n/+2Bk/IDzq0VP+xI0agaAGMUAAAENzRk/7MzP6AAANIAAAAS8EThq1Wi3pB5ARqJMGR6zAIYgoJATR+gBEQEClxDrDul/+NwPFr6hLxnu0mkjIj0ISsi9m0GIN4udlJ5jTWYi9TZVZy7w+Mcrau+o4nKRh5FMqXw4M7s3E4GAA5PtgHMaLDZIwrDtkEpgREVGCysOgkAw/ukpUNIFf7esGkCHogzfUEtFaEsJi7VHQamCAw0NJtYf0b+tuRwaW7L6g6oWwK9TUblEkP/+WSIBBAqJZpTMSRm1tamtEtBHSHW+TlHbrU+0YVJyEUdtFSkV7t6I4FADY9/gAwz2wKlsLLmYmCn/+2Bk94Dzp0hQexI0aAAADSAAAAEPCRc/7EzRqAAANIAAAARQetownh5oK5JZ/V2JExalv6gaUHbJsKk3UDSwZRkIabM7JA3MCUhm0fHyMPX5SEyWy/PBwDsl9Ra39nZjEVXhaDOFpM8tRZkzVk7WWuCIJ7Tq3OiS9ubKRpyymQxb+zajxQAFT/uABAX5mVbxo27qSEcEYT6CFskd9NTdQKgHldwz/7hLZPJ9CLf//6SdJsRJmuW9bmC4QxEK6vMCS1+gIuzL6xKg7JepP5GHiabAjD6Mik0kD9RMjMeqO9xl7OvfjPR0EdWUeRcyMS5Iq2Mshxz+7sfggAFL//AA25bGlkj/+2Bk8QDzrkdPexM0agAADSAAAAEO0R0/7EjRqAAANIAAAATSmJs3L2tqDEibJNcawRD/ZCExKT5Yk/HCGhcJQKWfuOkF2EYOakjlMCqwvSFx384f/pCLvX1iID2S938jCXJ0xzjIORChbsyaOJpWWElls0TFHIeCxmPk/UjEUNeDyhZEtAlRq6Ssj//7xwsACrYatIGoIMp9O8soWnpoxCWcXKzADV/qsAKDGojb4SgI8LAMG/cUICmTAial1rAWES4bUvywf/UMaCxnnfHUIcZrU3TMiujvtM48a6OXtmtRVObFwynrmEXXbk2zW9VON18b+UvkDSCCUlNEau3v+PFgA5z/+2Bk6wDzjkbQexI0agAADSAAAAEOhR0/7EDYqAAANIAAAATf8AOLAdHBL+sdUvS8XcZ+hNouoImOaRZzAjEVttcr6gngMQVwHN6wkgLqRIPGaOzl0A4wSQHEl5Yf9Q6xM9flMTIklue6BwlyKXbDrIX7c54qsMLRzJSXq3U6aJpcyYqqfexeVxGGIcyxak55bbudj6EAAkf9sBWuPO07rZuoMFkUhQZcHklr3PuuT7oqUEoUth6GdgawDtFeCrdSwgoNBJ4QOefOhYEGtA7jPx8H/5GiZa+oP+IBEKmUR45eSHq0yhExcJBuSpiZ5jQcww6GxS40d/uaFDvHRS2OTLJhxbT/+3Bk6IHztUhP+xM0aAAADSAAAAEONRVB7E0xqAAANIAAAASNEALd3N2XsAAAu9pQEBsM22IMAlSQ5EeGiBQEbKlttcHT6rpMt7l+v7gnMNcbgTi3/6uljil8hFSZ9QdwJUGzGJszwaof/ihw0/X1B5QuoJNcn6mQMUPn8IGzz2myAddaKToKWnuzavfKc7vw95JEyw2paAaZMts4jnDLQ3QZVZi2BCAXssYA0e31FP27Cc6VAWDAQZFNI3YWHC42cwKqJJ36msM6i+ReBbRQ9//+JCwRXuy0LHv/VSHESAYuIt4QInO+oMdBXPMT3LodIf20FuSBVlpkRSTVFIlOTkcyUNVEcu0+BZSxK76DbWm/08tEJKC6azaV/+3I0GABXd7QDfOWCQDJhLPdpoa4UgREyaA1mNSY//tgZP6A86dIUHsSNGgAAA0gAAABDtkTPexJEagAADSAAAAEWh+qX3MEJ3YfiP/6yyMVVAoO5//ik8TPxNf1nLepstaWIgBsR8Zj36gYwXtbaxoDUR2S1omhmOhqUJ4DFASbTJVo8yNMQoppuv+ianCyLGyS2DPdF9pOTe/Qv4fxW7u4+CgAI59KAkyzVbsSKF0qvCIw8IRcAUZZOrQAV8My1otW1jr9YjLyMqhxWnn6BFgZ0okWXrLASIEEAck1fj8SGrxExD9baw6g6SJIpFqYkabDGkR2yi+DLOt0N/sAPFPvdje/fTvR+T0Yb1tKq532op7Sg26Oqt3f+PBQE1ze4Bk8//tgZPkA89NGTnsSTboAAA0gAAABDwUNN+zE2KgAADSAAAAEAQ+wFLODFRjJSIBuoEZcKSMXWDAvoCUQv3FrOXCC4I4iWAtL0Av2BfQzIsCfLINxggQC4PmRLavEtFG1txnhNSTW5rmJNut1k5wkaQTwmhGSGe5jb378390n3mWWjXNIy2O2JG5OMmYs9xWdnU+gYAO7daBt8ofSVavTK3EwbIwMuZduqiQ1/iX6m0ty//2O7HmOgnn//+BVCUGmSIlPhnUgMWwimD9R8mx41dQbsQPrbpiTFZfrTWbwcYL0C5BNKzcPOZC8+UpfR52S+R61j2rf9jzr45v8+8eu7d7IwDAD//tgZPAA89tHT3stNioAAA0gAAABDvkZO+xM1SgAADSAAAAEHftQH/ZgtQhC0y+zhAGusccA2yBd7JCsuq6GKcOtc/V0qdLstUKBf/7uFWKNVGJo/LAf4EyD6h1jdJHV1Buxi6241xPxXTW0uEwXhzR3mB7xqikmPOvaKE6pkzUsYx06JkZNT25q8ZsRVrYe15/y2a1pA3939PhACbr/8ATXMtbAkalw+qpVHBCIYqASPL5C24CY+4h4YIbBoxc1hLodMLMBxvUE1h0hFA7JszzMB5QazBFlTawmEq/xEyF1tqF6Ogr7S8UCyYkKCG0BnGLrcM24s6yhipwilE84t/KCkNnl//twZOaA869Gz3szNGoAAA0gAAABDf0NPexI2KgAADSAAAAEvMsvfOaTys7Udr4kTv7dueBAIa7/cAAgToWGZCVkyfdqC7SA4yqWrkbvS/xg6l1LW5rCeQGNk0DhN4a0LyKgc02Z2JsLRACfgiSj1iXjv024XiPXboiBSXnFzE4eOkOFJ4a4FOJmTzUV0g2Idep7+/1Mr2lsGtdOZJGwYSUBGf466Kwhov+7tjxIBV2/uALul6XaiQ92dZ8yuoXkEyzq50HEV9V0EIqLK6wSmCKTh4/cLahWJNERS1mAjoIKgNTLy9YhCHn1+GHKybW1koHAm04V1IIEwXDEJhYWYWCaZtEcRBroOhU4mbdEpCE06Yc1+VQyHKdn8piUHox9Nd3uuNBgAW76UADKeKFjAB8K1niAQmbiFP/7YGT+APPJR097ETW6AAANIAAAAQ9VHT/szNGoAAA0gAAABB1C/SxWPLM+4MAQ7tOp9bhBEEYxywyvyoDJEOKKl6wKrBBkC2jZrOXQ4Np3mYJFLhZPW1h/BkRtJEwXp8usRQlgwOKgeIRhaUOpTREyYqUr5uficZxS4g6JUuwx5LnQk40dJIAlzd2Z0UABVe2s5PkqB4rGowgY2YqBN9HfUebqIybsItBAqWrvcEAQLyWGl+mH4AqEmBb0OmGAAlEHDR8fA2s7zoaKOw0PW1B/hAMnzpdJZiZGNI0oEUCIPKLFMRHXLeLZ974U7L/ndyIif+jrp46F7JxEWjUQzFzBVavLtv/7YGT0gPPCR0/7EzRqAAANIAAAAQ7lHT/sTQ/oAAA0gAAABMBBAcy6QDGAfRsaXJXaU7vKhKMYoq9yEpcJsUPJjJDLv/mSqo+XIiY/v6YQYCmpAv5aNzQvkgBjQHAg70vGoW9b5iFqRgIMptRFw7ZWMS6a65kXUY4oNIBQ6ck2kqRIaPVBWW7G9mzrcy+CVGvK04Zs7mnI3HSGr/kq9WoP283ZXQUgPVusArwBdGRER3iUVRKeZJZQf2IyRS/8i8gQF+rOVThMAL3JsNKbrCUg90hQYstH2dgl0LQAWUf8biXfUGiiitU3JsVM3Wts4WETfRkgTwEnkpNjKTMQglDKSjdo/f/7cGTtAfPoRk77E0RqAAANIAAAAQ8ZGTnsTNGoAAA0gAAABKnoWhX3cZGsecYufTkTjax6Rc/r3tnhMQWv/2AEJojqSFZYIf9JBuw7M5kibNF5qQzqKDKix13UF6Ad4mA7frCGAYXYN6NXzgYMBpAC4kX4iQ8anzgaKIa1TcVkhhXs2ovlErLodUipFVucLcq6Tam+mOw90lJqP/EDLt8VlXza3Els+2zqUZLNPF5m5saEAKv91oEAupBUoIo3Telo6i4AVFxJMuJyi8+rpUDNABarKquoIoBTQf4HGfrBq4H2FwijIuzsMMEFgYs2e6AZ8FxE1nH4Z2FxNTclRgH6j26BZPjLBWjhF3JtQP2ivFemnGG2ypNy217y1M2rOzi06WMTD/UtE+kJ6hfLyrjAYBE+ssAdhqf/+2Bk/ID0BEhNezJNSAAADSAAAAEO0SE57EzRoAAANIAAAAQogseNF67fr6EcBCuLS9szROZImGobjQDlnAaaBE8S4KLfsH+Ba5GjuR6wtyBGAdAO9WiLeDim6ziuGohlGqbWZCY6jes2Lhdc+JtRyM+yGr22IzZdZE2/MVPLNXTTNleDZnpQBz6MOSQxgP3V5lvYEBDe6yAPR9hsbLmGTjBKiL4ZFL3Mq0G5hDJV29d/9ELSlyHhMt3//krKI5fDVXL9wYIGAbQUCRm1jlVJQUYZPtXiHCFar6YCASf+pKEZcqK2SHnLxRyu9NC/w2dW3KaOFudScL2NzWUhcU2Wrr1OE8X/+2Bk8YDzvUZPexNMagAADSAAAAEPzRU57M0xqAAANIAAAAR/auoY3GXN3MjgkAVv+sAZ9ZlqyXYaS6TDVLQoMPBIWMw8lj+0pwshgsPWeEKCfEsEX9ANHAmYnRsP0AurCSgRYSfihSCam4roaStlc6Fx+qbX2Mk52taZhbgT1Yi1rGa/Vy9nLd17Vavbn8bq7HSMdC6l4T4kpN1gV3s7L42AV799wLLpqct3kNdn6MbnErARd/G/jiS/M0NA4MuxptQQEHuChA8fqCYhpxEQ8B9k0DMAxQE0FYR8a5i1TcjxAh5ldZsMV0TJz6jxgWET1mnk+EBcj1ajdJBMTzTpCNnU9Ob/+3Bk5wDzwUVN+xM0agAADSAAAAEPTRs37LU6KAAANIAAAARtadywtyGAAG+EDHFWtC7ZB0ewFcy8yNAwA6fW0Cq+8AtJe2mssQZyw8PtC20d5LT6iewmT16gTQZESwPF6giosRmHmfkoEEBwgRqefj5M221mobyXnV2JkTI+TxssyLKZPEYbHVZtFGlnQbmdM+pjq8GYvaxa6ss6x8PcrvXtGXNLzDzSDE4kt3dS2AwAKvq4ANLiDvyl1Xsswc/COpdCxKXvL8/dGQpSOLLsf7iSkRoTISi/9QSxGheENNkaoCcaoUEvOvrbUXQ00xqdCyYAYmCoqcExuSJckggvNWYYTtBjVPySLUsjCE63zUqo466y2J4xkpzV3bd/RXoU8kuBqrq7l8NQAd+SQAIFSOP2An1XYtfN//tgZPgA8546TvsTZFoAAA0gAAABD1EZPexI0agAADSAAAAEDwAB49zLACHlOTNDE02Fz9cYUnilMoX///p+lYKRC2ms9sS8FMC9QWUfOmWvqcQLqfjgyFSHMOoiCjoFM1FJImJ1YYWlUtSUcNkohpKk9xk2ZUObEjCDGJvG1sSpJC2fY65maawMQCnTSAXOj7FKzs1YfghpC1ifc81Bx0XPmBlRQO1Uyuw7wLUBooKO+G5B4CYKvoBeoL8giKXF8fI2mrZbpDWDjVF9JNOcPDYOF41UtM3UYvilLKXwWDreGrSLyf0Tk0DX8NEQldtc3OzZWXiv57WoMawq68zawpAC57pg//tgZPEA86NFTnsSM/oAAA0gAAABDvkdNexBNOgAADSAAAAEA4CwurbzRV9GuLLIemZzXZXDJfX6ojCBRKMP8/vGqHZESFu+agvS8v1ihxejRNm6y++/7eUPHEUIQ9HB23eaKUUMU0CFNC2fcmtjUHNSISOoSX+LQjepT2C0ZwjhiBwnxrG4Kz/RQ6Jg5JRRQOzd3q9HADH/9wG73GhOnB8YiTzt+FAAcr6P0zozr+nQVGkz97Dibi1D8OvxYAumRv6gqgV4y/z//5yzTqtIUH4HI1GKddoyUVsa42uUbmdmluVakFouXQNsKo1P+fauspKJAJnLI5kUdTYP1E7AhdFdzDUa//tgZOsA86pITXsQRhgAAA0gAAABDsETL+xM0agAADSAAAAEKrq5trBwBIeRQBrTlzT0z8BdvLqC4B58vjbCy5m8ElgUt2o3GNYjEbIdYVP1hBgqSKFvzATsKaSSvU/BdEexIjOClmG4uRCf3B+3BJhh8GMR0gTMnGmeq34bVVNSFz/8qhGMbljU7UxpWCX9IUE0C6MxUFs1e8ysjBUAbHtjAqt8/LxJeM9wsIDRFMqip4ZkjD/xUzTCvT+PGqVRLhbvOhKAXtOku3WHVE3jb+cfgIbCPrm7Du5RLLYfUXNMdMMLkNKrK7CwlW2vBSvndvyGmXcm+Q9SF2zDOw5OP3+m7k3z//twZOWA87RHTnsRTEoAAA0gAAABDnkdPew1MSgAADSAAAAE+pbH7RqylavMyrJANY/a0C5jI/dWdkcBwCygDkxSFbt0w+ESVTo8sm4NIN7brC8Bk3GE2s4FzgucevnPTWywPhJGQqIEmVGRMQaNwymESQDsoXEjFU+2m7Uipp+boQkXmxRtbxjDyglDPK5unGnzzfe2KmIThr3Vu7fTwWRzLf7ALBy1/8lCHcwtwwVBER8lhWsN7+nwLvtOqxnj64H4U38BVAKSJC9AJ0QB1V5zzfeIY+2TMk8VFCmIGISzKcELwwdCK4uKFnwPLlxcPmNKKOZ2Ndnl9jjoNKhKGwPVCU8fKmCg48Y25Sq6mbqxUxRHttATCbjA8FPJOT0jcklmcaO20pezDv4oGj9La/KKZGpg1g8T+P/7YGT6gPOkSEz7EUxIAAANIAAAAQ49FTXsTZEoAAA0gAAABJED8mX+K6UB6+cQ2PrLkRE2RlIyNg6gaFB1M8jGhTjoYzd3HSPcwtXmF4GGzukcScsNE3KpSY17QionznU/ZE3d3lYCMbU1sgC7dxJkDmwTJKF4G9I1X8h3cA/twWo/vPPKUOQbBAwcE3k0D2LKvULQRhCo+cJbGXqgFsWOgsOXFhwUQcNceeOdXubUbEbTZ0ExjTBzEiY2h6EmrZVWtHXbjELWK3Np4lTHTkKytXmYdoCDEpVkECv2BWROS7cfe6LKLApc49s9Td0QCFUsGd2B6vZ56i4E5Bd/oCewU8WTT//7YGT3gPOHSE57MEtoAAANIAAAAQ4JIT3sNREgAAA0gAAABEA1WI4HcbeZjtac0ioHFmZwkiIFQsRIEWZ0BZ6OlYElGbj7XSLX3hPug9+H+78Yk2/tUTBSNtPIYfrE9dIWd4LGdiZqnsUQAlZEgINV8vh5FjGSUBygoQBq5rLsAeY0ScY0Xc+axR2CIA/Cl8P4Z0T3rC8iyI6/IpK6tR8O5QKRsSa0nWWFZvkSUYpNErDDOsW03lCFiEnvkw5HkPP5G5pRxXU5WzLKpK27S2G45O4eSkOwoqrLucF2Cy65sDcTqVH6jj9xSIw6PgkEhji8/zaSr3ly5hvTIiREqIXrQCMgif/7YGT3APNdRkx7EERSAAANIAAAAQ25ETfsyRLoAAA0gAAABIulr1B/hdHm6xqmr+svDVHYmXSdfqPDlESNsbJ/MojSBM0sq5jbKQbcXnytjEN3cbY7btu+owov6n1iQ/VXe3OBSA3fq2B1lRzEuZTqAS1UA9AH9BPhIt/BgCbjPQ9L13Q3xsCIIXqAWxMDAs9Yk4zFxLxnP/Ol0VRIGTWOBCGB54jaIxw+RcXGCsDmmxobVDDWzkKSfNW2q/qpa2ZNE4f7mBsPb3RDn2Tqmqu4o1AHb5U2PmoVhTSJyWmP8wEMVD9mRwJlti69pRQb4hxQCCHX4CpBUoDb6YZQVoPJj40kff/7YGT6gPOmRkr7EzTKAAANIAAAAQ49Gy/ntTMoAAA0gAAABHtDqHgxNFLOGyTNB1OvM2ANM4bIQkVuLXZ9rPZD6/89njc/p5+zr4nqW1HYo3/X+7ddAgNzMvaw5AH597gI49chpWhu9EH9YgmSJUxh2tLt3VkpcPtK6TizIIhC34hQ8GxB6zADKFkHA3oluvxrESTzVSCmdbJCkMYpESQseXQRUjDU2hApJFboLw7WMb1nO84S9wq6SnFG3HjqjfXkeQxaWHWmO3131dy93OSwB2f+3AzKOSmplyR5Pg1gJmpXqcZusCyKk6yVuuNJ4Zj/yaKykfWLpwbfqP/yaLQ0eYGwwf/7YGT3gPNPPs37EjTKAAANIAAAAQ2NGzXntRMoAAA0gAAABKgQi5OdVYfQJxKgvCIeLiw4kqklRdklriZ2hnq9GjJuiXjaI4e5QZkJ4/CRFV/VEzFRaKATzyNgTVuYtyV+8qkBuOLOnpPD6t1u4kEwaQ02v/1G5ap1J/3uzQ2B6sUvjf1CAWD/GrX/9cNP+b41o7w8v1mWq9A3udBDGEJYgCcaNdkFaqwoUYNR0kxyWqIixenGj7R7ijYIYXXcZzFt57o7I56duqrawZAN7rZQLkZvXuX+bbqqiHMst48Ei/b0o0MQgeJ//tlkb4Wv+5npohQmLX+f/1HWZiHI38FFxDEHvv/7YGT8gPNaR0z7DTRaAAANIAAAAQ5dITnsNTFgAAA0gAAABEpDlXR90nnQKDkSqTqRGDxL68fKKIvy9JY1xf2dc07YzUr7SXOk0TlHLtLUp0ROgqkc+HvM1eXguAT6zRsfN3bkxOPyvdM9CQZD00jUPWn+bguK0yX/2RtLFVH/z+NAJ1VLev8XF1BcmJrvPhTY3HrSeAwvkBreK7qahMjTn81ZQshEbix2TZtki1JZzkiiLWbncITm9Dcd2Kcf3bJecqTXvbSklij16PkVm/+lqZmlo2ALu5EwIRyn5JPHa5EqWMtdH+iieXgDiEsiZI2sSEbYvj+dI5YTw4CCEv6g9gNHDP/7UGT9gPM/R0957URYAAANIAAAAQ6dHTHsPRaoAAA0gAAABLpVU6EY4bBFyIY+oIYCLQjbDw8FgaBLRopIuYKhQatDS84cPyFkWujx6a81EQ10ttDdHoY7WcKTV3TlxRro1kOQU8TE3JSAXetkoat0c44Mkj2MFrFNTFpw3T3+V03QwipGtf/+6KhbZL//ZiEpITQM/si/+fxnaHq54tY7Sbg1pFqHZSZRYdBAfHLjCxC5vl15x+tWXzxl/rsNn1Fyhus45lGcrfrt7inKCnX/+3Bk5QDziUhN+ws2GAAADSAAAAEPFRUz7D0t4AAANIAAAASnbHjm2vqDN2IoKgdG/6VqiZmasnQJbJEyPppVUheqOruXAoreLnbMxbL2sK5caI59wyeNcTZL//fvSlR5oey6vjG0C4yXPnDy0thJkW+UB8j3WimPOVnumTTistNoklBTk9E7tLQdHdvNuMRY/GxCpdyrQr9oRxwTF4daX0q4Ni7vENMiaBWo0SBqU36r8wl3I/lPEz2tafRiF3TKnumbmuvRfghRFu1v+1IdexDoVziZfoSA4JIdVD6prR0BceLAKpdkh/Q4JiChouZIticMkXeLnM55d0ONTaORgtMUfoo2UnkUgrST+ytnOdYPc6S4raSrZ3eHgYAHUygQO0sUhmINs6cZiKVbRqOeayo7hVVTTQQx//tgZPqA861IS/nxREgAAA0gAAABDzkdLewweqAAADSAAAAEa+4msMGYFAmyQrK1MU81HhZ0C9734jH3nYCMp39Z2JC95YcIfQLYLUPrwurefeept4PLrc3hMjS1AmIv6ZNBnBkeaq2u+U/RfNm2IK1BRomCSjytIJFFLE/QXDM7PBuBOqJAAQx+Zh5dKFcyVFpfJdvREZiIQD8LwoTk9KFEDqDufbjbWl5pESg54GAeBoCUAvWQYTvMkqiUU1AKa7LKrrKPZmrXQqQRj75ostrVU9VrJpvxGI6LVHhPV0CIvaQaOQxq2FNkW5kY7pp4iJmUcCttkSAzmFc9av40Y9DHUjEg//tgZPMA84dFy/sLNboAAA0gAAABDmUhKewpFmAAADSAAAAE2qWEMImzMpIH+kkWp3R8+zno3xjP8zgOw2RHAaSi3B7K0u0qhgmWMO3ZdGrs0SOayWFmGxPHvNMKPcVDO0mtF3roW0zuYafNwK1iW6yDPunbj3GZM06cCR9/++HJYkiB/M9idwfl5Uqm71l1E2VJpl90dOpaJgvRMGaHWWCEQhosunrBRsQlDiKiElHkKGTRBk5QIWOKpHzQRnh6hXNJEm2G1rPeKfcw2F6vHg7JZBE+kpLgw+kCL9IhNShtRz8QnlSGgVW7X//huVlFAenKE6y1I0wZcJ1jK0bovHAxDne+//tgZPGA891GSXsMNioAAA0gAAABDf0dJ+ekdyAAADSAAAAE+m5BN0aHvxIB0FoRSzBYCORGAZoClJEgY7JFuUcbKB7VdFZDujJ8FaYw+hRVUun9ezVYUdObWy0zn9tW4cv1gLBLkVfkgpFAZSbB4ESASG3G4kiAJC/Ci6rhEGUmpbEhOA0RAkjM9ZE0VaXY4DEwgIVhRmgpj/q//GoCQYm/UgwEgFVICFGEw1AowJHgVLPeJTvxDywikUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tgZOwA83BHS3npNboAAA0gAAABDYUZJ6ek1KgAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tQZO8A80NFSWkvMzoAAA0gAAABCVSzFaCkbQAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAH+AAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZN2P8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=]],
              ["uwu"] = [[T2dnUwACAAAAAAAAAAAigjslAAAAAIvsnZIBHgF2b3JiaXMAAAAAAkSsAAAAAAAAgLUBAAAAAAC4AU9nZ1MAAAAAAAAAAAAAIoI7JQEAAABclCBuEUH///////////////////8HA3ZvcmJpcw0AAABMYXZmNTguNzYuMTAwAQAAACAAAABlbmNvZGVyPUxhdmM1OC4xMzQuMTAwIGxpYnZvcmJpcwEFdm9yYmlzJUJDVgEAQAAAJHMYKkalcxaEEBpCUBnjHELOa+wZQkwRghwyTFvLJXOQIaSgQohbKIHQkFUAAEAAAIdBeBSEikEIIYQlPViSgyc9CCGEiDl4FIRpQQghhBBCCCGEEEIIIYRFOWiSgydBCB2E4zA4DIPlOPgchEU5WBCDJ0HoIIQPQriag6w5CCGEJDVIUIMGOegchMIsKIqCxDC4FoQENSiMguQwyNSDC0KImoNJNfgahGdBeBaEaUEIIYQkQUiQgwZByBiERkFYkoMGObgUhMtBqBqEKjkIH4QgNGQVAJAAAKCiKIqiKAoQGrIKAMgAABBAURTHcRzJkRzJsRwLCA1ZBQAAAQAIAACgSIqkSI7kSJIkWZIlWZIlWZLmiaosy7Isy7IsyzIQGrIKAEgAAFBRDEVxFAcIDVkFAGQAAAigOIqlWIqlaIrniI4IhIasAgCAAAAEAAAQNENTPEeURM9UVde2bdu2bdu2bdu2bdu2bVuWZRkIDVkFAEAAABDSaWapBogwAxkGQkNWAQAIAACAEYowxIDQkFUAAEAAAIAYSg6iCa0535zjoFkOmkqxOR2cSLV5kpuKuTnnnHPOyeacMc4555yinFkMmgmtOeecxKBZCpoJrTnnnCexedCaKq0555xxzulgnBHGOeecJq15kJqNtTnnnAWtaY6aS7E555xIuXlSm0u1Oeecc84555xzzjnnnOrF6RycE84555yovbmWm9DFOeecT8bp3pwQzjnnnHPOOeecc84555wgNGQVAAAEAEAQho1h3CkI0udoIEYRYhoy6UH36DAJGoOcQurR6GiklDoIJZVxUkonCA1ZBQAAAgBACCGFFFJIIYUUUkghhRRiiCGGGHLKKaeggkoqqaiijDLLLLPMMssss8w67KyzDjsMMcQQQyutxFJTbTXWWGvuOeeag7RWWmuttVJKKaWUUgpCQ1YBACAAAARCBhlkkFFIIYUUYogpp5xyCiqogNCQVQAAIACAAAAAAE/yHNERHdERHdERHdERHdHxHM8RJVESJVESLdMyNdNTRVV1ZdeWdVm3fVvYhV33fd33fd34dWFYlmVZlmVZlmVZlmVZlmVZliA0ZBUAAAIAACCEEEJIIYUUUkgpxhhzzDnoJJQQCA1ZBQAAAgAIAAAAcBRHcRzJkRxJsiRL0iTN0ixP8zRPEz1RFEXTNFXRFV1RN21RNmXTNV1TNl1VVm1Xlm1btnXbl2Xb933f933f933f933f931dB0JDVgEAEgAAOpIjKZIiKZLjOI4kSUBoyCoAQAYAQAAAiuIojuM4kiRJkiVpkmd5lqiZmumZniqqQGjIKgAAEABAAAAAAAAAiqZ4iql4iqh4juiIkmiZlqipmivKpuy6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6ruu6rguEhqwCACQAAHQkR3IkR1IkRVIkR3KA0JBVAIAMAIAAABzDMSRFcizL0jRP8zRPEz3REz3TU0VXdIHQkFUAACAAgAAAAAAAAAzJsBTL0RxNEiXVUi1VUy3VUkXVU1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU3TNE0TCA1ZCQCQAQCQEFMtLcaaCYskYtJqq6BjDFLspbFIKme1t8oxhRi1XhqHlFEQe6kkY4pBzC2k0CkmrdZUQoUUpJhjKhVSDlIgNGSFABCaAeBwHECyLECyLAAAAAAAAACQNA3QPA+wNA8AAAAAAAAAJE0DLE8DNM8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAADQPA/wPBHwRBEAAAAAAAAALM8DNNEDPFEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEDSNEDzPEDzPAAAAAAAAACwPA/wRBHQPBEAAAAAAAAALM8DPFEEPNEDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQ4AAAEGAhFBqyIgCIEwBwSBIkCZIEzQNIlgVNg6bBNAGSZUHToGkwTQAAAAAAAAAAAAAkTYOmQdMgigBJ06Bp0DSIIgAAAAAAAAAAAACSpkHToGkQRYCkadA0aBpEEQAAAAAAAAAAAADPNCGKEEWYJsAzTYgiRBGmCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQasiIAiBMAcDiKZQEAgOM4lgUAAI7jWBYAAFiWJYoAAGBZmigCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAABhwAAAIMKEMFBqyEgCIAgBwKIplAcexLOA4lgUkybIAlgXQPICmAUQRAAgAAChwAAAIsEFTYnGAQkNWAgBRAAAGxbEsTRNFkqRpmieKJEnTPE8UaZrneZ5pwvM8zzQhiqJomhBFUTRNmKZpqiowTVUVAABQ4AAAEGCDpsTiAIWGrAQAQgIAHIpiWZrmeZ4niqapmiRJ0zxPFEXRNE1TVUmSpnmeKIqiaZqmqrIsTfM8URRF01RVVYWmeZ4oiqJpqqrqwvM8TxRF0TRV1XXheZ4niqJomqrquhBFUTRN01RNVXVdIIqmaZqqqqquC0RPFE1TVV3XdYHniaJpqqqrui4QTdNUVVV1XVkGmKZpqqrryjJAVVXVdV1XlgGqqqqu67qyDFBV13VdWZZlAK7rurIsywIAAA4cAAACjKCTjCqLsNGECw9AoSErAoAoAADAGKYUU8owJiGkEBrGJIQUQiYlpdJSqiCkUlIpFYRUSiolo5RSailVEFIpqZQKQiollVIAANiBAwDYgYVQaMhKACAPAIAwRinGGHNOIqQUY845JxFSijHnnJNKMeacc85JKRlzzDnnpJTOOeecc1JK5pxzzjkppXPOOeeclFJK55xzTkopJYTOQSellNI555wTAABU4AAAEGCjyOYEI0GFhqwEAFIBAAyOY1ma5nmiaJqWJGma53meKJqmJkma5nmeJ4qqyfM8TxRF0TRVled5niiKommqKtcVRdM0TVVVXbIsiqZpmqrqujBN01RV13VdmKZpqqrrui5sW1VV1XVlGbatqqrqurIMXNd1ZdmWgSy7ruzasgAA8AQHAKACG1ZHOCkaCyw0ZCUAkAEAQBiDkEIIIWUQQgohhJRSCAkAABhwAAAIMKEMFBqyEgBIBQAAjLHWWmuttdZAZ6211lprrYDMWmuttdZaa6211lprrbXWUmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaay2llFJKKaWUUkoppZRSSimllFJKBQD6VTgA+D/YsDrCSdFYYKEhKwGAcAAAwBilGHMMQimlVAgx5px0VFqLsUKIMeckpNRabMVzzkEoIZXWYiyecw5CKSnFVmNRKYRSUkottliLSqGjklJKrdVYjDGppNZai63GYoxJKbTUWosxFiNsTam12GqrsRhjayottBhjjMUIX2RsLabaag3GCCNbLC3VWmswxhjdW4ultpqLMT742lIsMdZcAAB3gwMARIKNM6wknRWOBhcashIACAkAIBBSijHGGHPOOeekUow55pxzDkIIoVSKMcaccw5CCCGUjDHmnHMQQgghhFJKxpxzEEIIIYSQUuqccxBCCCGEEEopnXMOQgghhBBCKaWDEEIIIYQQSiilpBRCCCGEEEIIqaSUQgghhFJCKCGVlFIIIYQQQiklpJRSCiGEUkIIoYSUUkophRBCCKWUklJKKaUSSgklhBJSKSmlFEoIIZRSSkoppVRKCaGEEkopJaWUUkohhBBKKQUAABw4AAAEGEEnGVUWYaMJFx6AQkNWAgBkAACQopRSKS1FgiKlGKQYS0YVc1BaiqhyDFLNqVLOIOYklogxhJSTVDLmFEIMQuocdUwpBi2VGELGGKTYckuhcw4AAABBAICAkAAAAwQFMwDA4ADhcxB0AgRHGwCAIERmiETDQnB4UAkQEVMBQGKCQi4AVFhcpF1cQJcBLujirgMhBCEIQSwOoIAEHJxwwxNveMINTtApKnUgAAAAAAANAPAAAJBcABER0cxhZGhscHR4fICEiIyQCAAAAAAAGQB8AAAkJUBERDRzGBkaGxwdHh8gISIjJAEAgAACAAAAACCAAAQEBAAAAAAAAgAAAAQET2dnUwAE3GYAAAAAAAAigjslAgAAAAgbPC8hPDQnLzIyNtzAwc3WzbS1vLi+vL2twszQzrnNysbNxdvPnMbSnt0rjam9cPa2XjIYohSAz+2vHsOcd+5XRVurPpbrlZdmt1a1aWplEIOHauqqWa2SU1SllN24k7cBlMiyfahElu0LWw8Ty1AKgNoNm92CpIdoWtq20barTcOiQzIFUMkamg46aEF9+XE1vFJQAYTIlvcRhMiW9xGsqyMjI8lCATDWqsGIEh0XyeT6qgEpxTk3xLeFAJzI3HnZE5k7L3uzQhKUKgVAjSJGtKpbOk0ulU99/eLFpXChvOzebXfjfItW6esDlMQWa6AviS3WQL+uplKQaSiFEABrVTGYlRdf0wmiqu1WW2nx61Myu/IFrXJbC+oXRQXcRLztMm8i3naZq/oTMlPOADhiszs6CO+zMtV2W02jnL6V9xIbg/fu7d58cfgodPhUACTTxvE6MZk2jteJu82wMBoBMC1qc7RhRbJFXFwIxIRKN03T6XoVhuraVHSaQkfSkzQlXbHVAjpozfBUIFmg/+HqPOIr1EuAq/xOedCa4alAskD/w9V5xFeolwBX+Z3yD1KURVlQ1pRFCQDwOqMCAFhSbgAjEisWK0YAAIAYYw2IVYMKNRIACEaNihoFAbU0CK0ipJCgWijmZmk76baVNgW4PhUA5jVh2q/sSYV0u92kjYLPcfGzSIeR9/ROKf44OBaN6ey3acFJt6qqEiUkRTXUvNvCevEDinbRUh2tUtH26w0CaBHdEiadhjwd5SyAyQDyniKt+OYQUyQPz0QHjjOtsL4Vw19HNTtM2j8xar4GCgCeh82FUr8M2D+PLln6j6Ffi4E69x152Fwo9cuA/fPokqX/GPq1GKhz37ECAOCWAVjSYYAjVawqAAAAFQBAHewOdgMAAEAIE8EicCJgJgQASIkEpPhIIAAA6JcJAK+cAAMAqtOzR9oqkH8UJgGApludJgDwA7vfmelX19qGqE4rAIjHALMOU8sKfFfRKflO2dd6bWRvkWkdvRb2UiDEkzCdXo7+Fd0dvcGnrQ7cE5qe/qwPBUdjq9LyNMz+1J1PxwAemLVDL9Vc+/OoQx9eqX84PdRoDoHZIPBS09WfV2268Er9UwSo8ZxWAAB8UNYAAAE3BFoYt5iVc6hCrFxFCACgEgBAlPpNAAAAoKEyAAAAABYBAADAEXBgk0C0xPEVAiQCKQAAACdWAABwDQCWAbDi6QkARNOzAACIxIUAAEAAARQAgJcGIC61doFHLUjsl/AEOB+Bt+QCJduAQkcAEAACAKDQuOm3Cg2F7FMAaO77Xq60gSAsANTubx91nDHXItAHPqgdIEcpIvvns3ZKXtrG95BKPewWGQ1qB7guNex/fGRGXdrGPwwf6nGPiisAAH4BABAwOidh1QyxVgirnBUAANRIAIBGAAAQiQoAAIAkIRklougMFgKkAAAE0upr6QIAACSdHgcA0FwrAKjL9boGAADAhGEEAHw27NWA6NETABiA5V8GswGqRyAMXh0AAADKEdCFRj/sNrJ+BWcFtmAAND0AQADhqLpXVg2hrmxE5fsMWfuS/a7NuhVu6HIL7lHoIx8LdPRjA1yRc9MCAF6YHa52GSr/+eybU16DewBTTR8ozG6gjNJV/PO5NM/wchdgVJf6yAoAgI8sawMALOiDpYRVhlibnMsVIwQAUAkAoEY2FgAAAMwgCgAAIAiRKFDJ6imrNkhACiEB6NkzAABQwAoAgNKzRwUA6AoA8AEAeQSAgkSCMAMAAFSBkQUAgLTIYWAGsNxKO4yCEACAAU/oyIIf1IbpEndmqHVMBwOwZRsA3QZIEfZdvSHB+yzIAednoLkaSGz4qoTulUoj0XUy6HTFwrgo8AnuK6nSJ6ADvQ3TGQd+uM2po9SU/fNQ3fGV+kHL9cQ3DrdDyizVmj8P0dcjpa/VeqLTIei61QoA+AkAEBvsFCoUiGxW5YqZhAAAFrEICIKgQhEAAKRVqOoGimrqJAEAAOBdexgwAAAAi0IAAAA8uDsAAIDqUaMGAPRWAIDbAMBLAAAAiImLFdjTAA4DAwCQVC3SowUARGCBXctjeKbm/8Tda3BHHJJE4loBFfCnNyEt0tRVFKi2QsrbooYMNHD0OnogfhnVh/SCTE8DCwrOK8AM9ApKTQNzIDgAPqjN2VWqHf756IK3Rf9ASw3GoDYbFKl2+OdVk6dF/4CmRiPoemoTAFymB9wkCLBTYxhzJrEsAE2kIgDAaMQWAACI2OyGAQAAgMZXAQAAKA2idBo6bRcAIKcFKwsAAHgPAFTvIgB0qwIArQEAABCTICpgGyAAY04AjAEpiAtlAAQAFoBiAAIgHOFh6s4NgCMQoALxCgEAFQCs0gCPAZAClE6pAMxFggtAX4DPgqjCmN9SAjQBXni1Ai2D4b/5DB+2K1H/IKlVxGZj4dUKtAyG/+YzfNiuRP2DpFYRm40UTt2aAABv9ZQJAJMjsPkkNqig2AogLBIhAIA11gAAKGowKioCAAAI03JCmBgJAABACRMHAADgJQBANwBADxUA+BQAoLoAAABBglgBAOgCAHEARAEAAAji4psG+ATaAQAEYENGBwAgnQJwAQBcQAgq3Z4qhKpglxhgDiG0AF8TDB6QALcA4iAptAMOAD6YJYaodHn111cYPFPfSl1oRnUkFr/BLDFEpcurv77C4Jn6VupCM6ojsfgFXacWAPioJACwwGDanPLJCkMUVKAiRXIFAIhYBQAAjBhFEQAAMERQAAAAaRQpnR6k6QIAOt0AgFYBACA+MAAApdoeAAANAABEnAFAhwBwATQPAABQJC4EAFAAgPRQQHQA+ABUtwHgMgChdBVVlCSqU6koAs9BdhkQCFYI9ZPcV1HbagqUGeIAgMvOwIYMGGADXqgFWSozu/zXjwhGWc+Djppq8jR5hVqQpTKzy3/9iGCU9TzoqKkmT5M3sW4BAOKtDgCwA83BTitGTGpOiORILgAAqCAAAIA1CAAAAAAIy0bERx0mngAAAAApEQMAAFT1BABoAAA9AgBUFwC4BwBUzwBA6PQAAKgAwAUAAOAwUQkgAKBUtwIcY3Cph/RApANxAEA6AMD7ZTTZjYjDBkAC2PAPNIBpFTo3Y06+1cAHEBOgzbmBuOAwAH64zVlVatr8efSffixXHl37ul5+cD3c5qwqNW3+PPpPP5Yrj659XS8/uE6sJwGAt0oBAJqBwMBDrJUrV0UAAAAAABBjDQYAAFAAsC2ARHDCGAkAAKB6tAGA92kAOAGAtqsA4NMBgJ4AAD1TAEjToykABIALAFTb9gAAtN0A7l5owFiOLoIXdDQ7kOFiBYAp1WkQAJNefouKd/byDTZQQGEXYVcNpt9OM49X8x3/hmkGcgA+K4BNG61K3wBNFAze6N144iJV8nNdT39xvQTwFq7qHryN3o0nLlIlP9f19BfXSwBv4aruwXsFTG0CAE8fsIA92OPg6sBILhdBAAAAUAFArIZYBQAAVA3TpgAAgCooAAAAJLAAAAA61TYFgHQSAEh1CwA+FQD6AgBQEGcAAAAUFwkBAIgBG4DqqQBA220KAP0YIAYrpdB/Lf3J3/2hBdAAvrYbkRSI6hYBYAigUQANQAEDzQ0QOdZgDOM2AB8ChJK0DQxhrnYVDN7o3ZBYpebp54rDsbatKwTVsl+jd0NilZqnnysOx9q2rhBUy34TawMAwk8AgDHJtrjJyhHnypUNCgAAxCgAAIrVAgAAAAAAYUJFWCIAAIAgYTwGAAA0PQQAlZ4BAHACWQAAECoAfAEA/ABAqwMAgDgZAIAfAC4AILoFAF8BABoAyAeAAbIFQlwB5uvs9iYvaBEcNfgxFMGQb4ljJQKjdsK2cXi0lvdIYxPHQng9OhjtAByADIAGAPILAEqnAb7I3QgxSpf5f/Sv5Nm6q4HiTOp5F7kbIUbpMv+P/pU8W3c1UJxJPe/EegoA4GkHIIFmoMniyuUIYwiI5AgBALAqAgCAGpvF0QIAAIDaVRUAAAAAMECQuLQ9qwBgTgB4DgCQbtMEAJWuAECcAMCrBSB0DQAVID4DQHVUFTBgAegE0KpK98+HvRuA7wH26TjsAJQKAEcfiBOApkAqQIkRogYW4VsFELovQkdrCQAEnrjdkKvSRvvfWRR7xCijpfndidsNuSpttP+dRbFHjDJamt8d3w/gLaK2TAA4KyvLZRFnVSERAACIg2kRAADAirFWrSqAAAAS1ZGDMB5JAABc7zVQjgP1KK/XwCgOwnrVH3tyMDPIZ7U+13bHSoyR0bfLlTPfvu7r6fszzfnJ0kZkOOWY1Xdm90Ov+kWn1UppS4dtW/EDFEMFuHa94EuXeyTMb+9c/R6LAxQ0Tnr08/OUv5gbGQqOBPy+P5p0oxRqXRXeZ92EsMkY03+THe8pfT991k0Im4wx/TfZ8Z7S9wNbD9iynGUDirksK+YqAABYHE3DwaYmFpuDzRCwu4/BoPhEFGtJtqR0dZtWqoVy1emXi7+OOirUK0r/Y4QovxJLzO3ZA2JXtHKd8c1EWNhRAyT0phWux6/uESs6VCmq3J3Hq6YUn7/ifem7AoQ7edG4Fi7R2elGtmlC62MzAFT1PE279dL7eMQgYn1BJJwoBKUwH0zzKQeuV4st9qRWj9SFauMvWWGgo7sy6tefAhu+V90kYpWG/G8/4RXaq9pkZa+6ScQqDfnffsIrtFe1ycocaO9mWZuYK8ZirKoIAGA3LHYE1LA62ExTAFCMHCoIgjBBGImLiwnk0ETD0EGpBm3TdtpqqkprJIF/jqlRb3HT7aqX6jztk0Gakf4UqlSTUFXVfeVT9LBzb6sYGvQkHr1/pa7RsNZe5fUdfOMdD42WJbqiRBQhrdn2AIJSfLFGB/M+RuuExrJ1OG4Xm+txJ0QUcHTy6NWfpkU1TzVFf6Nt4Rt7GKqT0gA7QiUF0BQA3rgNjuYPaPb3sd6/0Xt1pW66M8fGbXA0f0Czv4/1/o3eqyt10505tq+DLOotSaDJA1jOVa7KVQEA1ooY1KoRsQJA2mrQrYQJYgObUI5EidiIVDdtUlIglbZHut0CwFwrj5mR+vezc6gTpoq20XabSAGh+03Wxusz4sDc1ZfgHSnNoRhShEVtb4+9+CqYpnorRL09nGJ1wGuQs/RvhLIPAzA//q8PoZ2+DPwDqPBcm9bu1nWLU/zs/gqbsEK3CPvy7WqIFk2YoWUcsJVvTAXe6NU78wd68+f8lux9za+knnUtBKLRq3fmD/Tmz/kt2fuaX0k961oIxFkZRNYUABWOca2qXAiSI4UAAIiiVkUNAAAAgIXiFUsgRBiExMVGQifjdyoAUU3TBXa0x7YBxRKHADCuV0ICM8cnTC+QkRBh/qbtEQFUqj4QHKimmm5VobNOl7y8PfsHvh5jXVz47BDDRMND0arQXHWLrKIRKFsA6ShsADYNvlEK21pCAwI5/OGAGAA/XQ8wIP53BQv2D9aOfG5jvqYo0IANf1ewYP9g7cjnNuZrigIN2NCuBBngJMacs1jEsWJVjABARNSGzepoNVUB6ESaNKmeIWHoIJLQxMaGYeCmv3MydiXg0aMMk1+aNGmlZ4+WIsFCzZaR7n/Ce3WwC2zqjK+VZdktWmeoy7H7dO/46H1tuqP+DtyErGqESIj89Pp02/9vF7k6gCJfiShR679J0Zo4sBwILQPAjnFAEp3QLbv2eTm8/N+zOlrPt09ZKw4flycbbhbD69EMmPd+dgCeZtyopu6AM1iTp4fDmj/NuFFN3QFnsCZPD4c1/42lZQdYzuWKZVXFKgIAAOwOdhMHdRR7vINAkDA2qogdOmrFEZuYBIkniGIBKR2KKiq1NJUFNJ0mSqmgl+TOVkniQNQihpYWsqphVdNs3ibu8X7Z26ITxqbNW7qaRTj/emQmh9Vf4x0Ti+2FLVq6SFYVtmpsA7PrVW5ay+bCXRNyrtdHJenSmsAORUAaQzeYfv15agrdblODY3CQ1BCbTTBAZbzBAx8TMRg/ugUAPmbcZMj2oRVWx8vHSpfxjxk3GbJ9aIXV8fKx0mX8c0BuFrMsF7OqIlUFABh2tYNasIuaVkMBHCaIxsXGEBeJBFGUaCKKEnUsQkh1VBFJqYXjRLxRN8E5fKv91l4kjj9qYr1OAO7jzjbi1oLx+8Vb/yR6uis/fvTsrKEQzW7FgnB81ANXNiEGxYSbRea/NaaNH8FVb+ZQ8boXacl/emeMhcQjF4EBoL75JmNusprYv7lC06qy7u6ivEnVCuZBzfJuQoYttPM7HnbcdChDL6ye5WHhDztuOpShF1bP8rDwn0sSwFlMcsyyrKqqCgAwbHbTbtotYhE1xBQA4qNBrCNhNAGODWMjjhIQG2dFE0Fp25aOaFC0rlyHO722Z5WSFpbnOwst8aPQrZIZEnYsJShRKd2vUixSAxH7p507RkSEQLmkXcWuvN+rdsF1GvZ9NyjIRvySDNWLSlA/FaCviZWv/Mj6/upera2pSoeJndPaENywe5UbkkascDxuzxwGEJDqfOJheJzz9l1e4UffJwLtyc2eAX5m3EQmgyg8PNsLOaM/M24ik0EUHp7thZzRn81izCtmOctVVcUAABCKJowPRKKRaBgXSxBR1IQRJwwcJMQKo3ac5SBUEFS1TaQTbaqN4MuHUh3J5sEqjxxQ7xGe9UUDMpQqf5YxFC5cTek26UalKgRb2bfkSlokDrvhkL4KUJPBIO/2WicG/yuJwdF/9EAFXAAbaMOFtsppu579tb7M611SPt1tOmCIJuTDiXeuWWRBKHWzKdmy1SV0Q8bp0PdAeSkF6KcFPmbcGI1bqovOT3xwGTNujMYt1UXnJz64zMGkyTEwy2LeDHA5VjnmJADAooaoqCkOdkexYUJIXEIFCRNRPHIYiTiUFBuNk6LA45c61ahIS9sjpSmkWxFNoeh2pKBIBSlpm2pI05NgL53lIh5VlE53APStKntcNX0IPf8rAbhPQq+wEPGUOqkbUp4okJ6JAAAu9YUKfAeg7WgTAt+rUABKzLa10tHzP+jPLySqhZSbV5zu/4ifZRGgqUyldQbULXcKHABxwGnQe3rRA+CTI2M+qIkiVRlOOgFUpw0B/mXMLfPPrH+m6l9ZtFuTcsExfxlzy/wz65+p+lcW7dakXHDMZ7OsnMtZuVxVFQEAYGEpDIgmSBgXJRIfwQSxEcUnEq9IbExshNgEsUSiAZaSbqcbUimE/1dUVb+SKvNPlHuo8v9KnpfXAgOVVO6pKv8Hpi32q1dSUJWdYpGX5cGr3BL+j9DN7e14afqVUjoA9IDd4E7NuvvVEbqBu9keJgHglyggxayy65Unz9kWYL5fZnunlpW7XnGw4Z62t2jTFGCe3uLhpdE2LA/CDQgA]],
        }
      
      for name, data in hitsounds do
          table.insert(cheat.Globals.HitSoundNames, name)
          local filePath = Library.Directory .. '/sounds/' .. name
  
          local dir = filePath:match("(.+)/[^/]+$")
          if dir and not isfolder(dir) then
              makefolder(dir)
          end
  
          local bytes
          if syn and syn.crypt and syn.crypt.base64 then
              bytes = syn.crypt.base64.decode(data)
          else
              bytes = crypt.base64decode(data)
          end
  
          writefile(filePath, bytes)
  
          cheat.Globals.HitSoundIds[name] = getcustomasset(filePath)
      end
  end
  
  do
      do
          local CombatMainTab = CombatPage:SubPage({Name = "Main"})
          local AimbotSection = CombatMainTab:Section({Name = "Aimbot", Side = 1})
          local ResolversSection = CombatMainTab:Section({Name = "Resolvers", Side = 1})
          local AntiAimTab = CombatPage:SubPage({Name = "Anti Aim"})
          GunModsTab = CombatPage:SubPage({Name = "Gun mods"})
          local AntiAimSection = AntiAimTab:Section({Name = "Anti Aim", Side = 1})
          local aa_t = AntiAimSection:Toggle({
              Name = "Anti Aim",
              Flag = "AntiAim",
              Default = false,
          })
          aa_t:Keybind({
              Name = "Anti Aim Bind",
              Flag = "AntiAimBind",
              Mode = "Toggle",
              Default = "None",
          })
          local aa_s = aa_t:Settings()
          local yawSection = aa_s:Section({Name = "Yaw"})
          yawSection:Dropdown({
              Name = "Yaw Base",
              Flag = "AntiAimYawBase",
              Items = { "Camera", "Random", "Spin", "Targets" },
              Default = "Camera",
          })
          yawSection:Slider({
              Name = "Yaw Modifier",
              Flag = "AntiAimYawModifier",
              Min = -180,
              Max = 180,
              Default = 0,
              Decimals = 1,
              Suffix = "deg",
          })
          local pitchSection = aa_s:Section({Name = "Pitch"})
          pitchSection:Dropdown({
              Name = "Pitch Base",
              Flag = "AntiAimPitchBase",
              Items = { "Nod", "Up", "Down", "Random" },
              Default = "Nod",
          })
          pitchSection:Slider({
              Name = "Pitch Modifier",
              Flag = "AntiAimPitchModifier",
              Min = -90,
              Max = 90,
              Default = 0,
              Decimals = 1,
              Suffix = "deg",
          })
          local DrawSection = CombatMainTab:Section({Name = "Drawings", Side = 2})
          local GunModsSection = GunModsTab:Section({Name = "Gun", Side = 1})
          local SoundsSection = GunModsTab:Section({Name = "Sounds", Side = 1})

          local sil_t = AimbotSection:Toggle({
              Name = "Silent Aim",
              Flag = "AimbotEnabled",
              Default = false,
          })
          sil_t:Keybind({
              Name = "Silent Aim Bind",
              Flag = "AimbotBind",
              Mode = "Toggle",
              Default = "None",
          })
          local sil_s = sil_t:Settings()
          local silentAimSection = sil_s:Section({Name = "Accuracy"})
          silentAimSection:Slider({
              Name = "Hit Chance",
              Flag = "HitChance",
              Min = 0,
              Max = 100,
              Default = 100,
              Suffix = "%",
          })
          AimbotSection:Toggle({
              Name = "Flags",
              Flag = "StatusFlags",
              Default = false,
          })
          local mtog = AimbotSection:Toggle({
              Name = "Manipulation",
              Flag = "Manipulation",
          })
          mtog:Keybind({
              Name = "Manipulation Bind",
              Flag = "ManipulationBind",
              Mode = "Toggle",
              Default = "None",
          })
          mtog:Colorpicker({
              Name = "Manipulation Color",
              Flag = "ManipulationIndicatorColor",
              Default = Color3.fromRGB(255, 70, 70),
          })
          local htog = AimbotSection:Toggle({
              Name = "Hitscan",
              Flag = "Hitscan",
          })
          htog:Keybind({
              Name = "Hitscan Bind",
              Flag = "HitscanBind",
              Mode = "Toggle",
              Default = "None",
          })
          AimbotSection:Toggle({
              Name = "Target Teammates",
              Flag = "TargetTeammates",
              Default = true,
          })
          AimbotSection:Toggle({
              Name = "Down Check",
              Flag = "DownCheck",
              Default = true,
          })
          AimbotSection:Dropdown({
              Name = "Target Parts",
              Flag = "TargetParts",
              Items = {
                  "Head",
                  "UpperTorso",
                  "LowerTorso",
                  "LeftUpperArm",
                  "LeftLowerArm",
                  "LeftHand",
                  "RightUpperArm",
                  "RightLowerArm",
                  "RightHand",
                  "LeftUpperLeg",
                  "LeftLowerLeg",
                  "LeftFoot",
                  "RightUpperLeg",
                  "RightLowerLeg",
                  "RightFoot",
              },
              Default = {"Head"},
              Multi = true,
          })

          ResolversSection:Toggle({
              Name = "Pitch Resolver",
              Flag = "PitchResolver",
              Default = false,
          })
          ResolversSection:Toggle({
              Name = "Desync Resolver",
              Flag = "DesyncResolver",
              Default = false,
          })
          ResolversSection:Toggle({
              Name = "Underground Resolver",
              Flag = "UndergroundResolver",
              Default = false,
          })
          ResolversSection:Toggle({
              Name = "Spin Resolver",
              Flag = "SpinResolver",
              Default = true,
          })
          ResolversSection:Toggle({
              Name = "Velocity Resolver",
              Flag = "VelocityResolver",
              Default = true,
          })
          local DebugSection = CombatMainTab:Section({Name = "Debug", Side = 1})
          DebugSection:Button({
              Name = "Debug Manipulation",
              Callback = function()
                  if cheat.debugStart then
                      cheat.debugStart()
                  end
              end,
          })
          DebugSection:Button({
              Name = "End Debug",
              Callback = function()
                  if cheat.debugStop then
                      cheat.debugStop()
                  end
              end,
          })

          local fov_t = DrawSection:Toggle({
              Name = "Draw Fov",
              Flag = "FovEnabled",
          })
          fov_t:Colorpicker({
              Name = "Fov Color",
              Flag = "FovColor",
              Default = Color3.fromRGB(255, 20, 147),
          })
          local fov_s = fov_t:Settings()
          local fovSection = fov_s:Section({Name = "Circle"})
          fovSection:Slider({
              Name = "Fov Size",
              Flag = "FovSize",
              Min = 0,
              Max = 500,
              Default = 200,
              Decimals = 1,
          })
          fovSection:Slider({
              Name = "Thickness",
              Flag = "FovThickness",
              Min = 1,
              Max = 5,
              Default = 2,
              Decimals = 0.1,
          })
          local snap_t = DrawSection:Toggle({
              Name = "Draw Snapline",
              Flag = "SnaplineEnabled",
          })
          snap_t:Colorpicker({
              Name = "Snapline Color",
              Flag = "SnaplineColor",
              Default = Color3.fromRGB(255, 255, 255),
          })
          local snap_s = snap_t:Settings()
          local snaplineSection = snap_s:Section({Name = "Line"})
          snaplineSection:Slider({
              Name = "Snapline Thickness",
              Flag = "SnaplineThickness",
              Min = 1,
              Max = 6,
              Default = 1,
              Decimals = 1,
          })
          snaplineSection:Toggle({
              Name = "Snapline Outline",
              Flag = "SnaplineOutline",
              Default = true,
          })

          GunModsSection:Toggle({
              Name = "Instant Bullet",
              Flag = "InstantBullet",
          }):Keybind({
              Name = "Instant Bullet Bind",
              Flag = "InstantBulletBind",
              Mode = "Toggle",
              Default = "None",
          })
          GunModsSection:Toggle({
              Name = "Instant Equip",
              Flag = "InstantEquip",
              Callback = function()
                  if apply_equip_aim then apply_equip_aim() end
              end,
          })
          GunModsSection:Toggle({
              Name = "Instant ADS",
              Flag = "InstantADS",
              Callback = function()
                  if apply_equip_aim then apply_equip_aim() end
              end,
          })
          GunModsSection:Toggle({
              Name = "RPM",
              Flag = "RPM",
          })
          GunModsSection:Slider({
              Name = "Multiplier",
              Flag = "RapidFireRate",
              Min = 1,
              Max = 1.5,
              Default = 1,
              Decimals = 0.1,
          })
          GunModsSection:Toggle({
              Name = "Always Grounded",
              Flag = "AlwaysGrounded",
          })
          local rem_t = GunModsSection:Toggle({
              Name = "Removals",
              Flag = "Removals",
              Default = false,
              Callback = function()
                  syncRemovals()
              end,
          })
          local rem_s = rem_t:Settings()
          local weaponSection = rem_s:Section({Name = "Weapon"})
          weaponSection:Toggle({
              Name = "No Recoil",
              Flag = "NoRecoil",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          weaponSection:Toggle({
              Name = "No Spread",
              Flag = "NoSpread",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          weaponSection:Toggle({
              Name = "No Sway",
              Flag = "NoSway",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          weaponSection:Toggle({
              Name = "Remove Arms",
              Flag = "RemoveArms",
          })
          weaponSection:Toggle({
              Name = "No Bob",
              Flag = "NoBob",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          weaponSection:Toggle({
              Name = "No VM Recoil",
              Flag = "NoVMRecoil",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          weaponSection:Toggle({
              Name = "No Muzzle Flash",
              Flag = "NoMuzzleFlash",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          local movementSection = rem_s:Section({Name = "Movement"})
          movementSection:Toggle({
              Name = "No Fall Damage",
              Flag = "NoFall",
              Default = true,
              Callback = function()
                  syncRemovals()
              end,
          })
          local snd_t = SoundsSection:Toggle({
              Name = "Hit Sounds",
              Flag = "Hitsounds",
          })
          local snd_s = snd_t:Settings()
          local hitSoundSection = snd_s:Section({Name = "Sound"})
          hitSoundSection:Dropdown({
              Name = "Hit Sound",
              Flag = "HitsoundSelect",
              Items = cheat.Globals.HitSoundNames,
          })
          hitSoundSection:Slider({
              Name = "Volume",
              Flag = "HitsoundVolume",
              Min = 0,
              Max = 1,
              Default = 0.5,
              Decimals = 0.1,
          })
          local shootSoundToggle = SoundsSection:Toggle({
              Name = "Shoot Sound",
              Flag = "ShootSound",
          })
          local shootSoundSection = shootSoundToggle:Settings():Section({Name = "Sound"})
          shootSoundSection:Dropdown({
              Name = "Shoot Sound",
              Flag = "ShootSoundSelect",
              Items = cheat.Globals.HitSoundNames,
          })
          shootSoundSection:Slider({
              Name = "Volume",
              Flag = "ShootSoundVolume",
              Min = 0,
              Max = 1,
              Default = 0.5,
              Decimals = 0.1,
          })
      end

      do
          local MainTab = VisualsPage:SubPage({Name = "Main"})
          local WorldTab = VisualsPage:SubPage({Name = "World"})
          local SelfTab = VisualsPage:SubPage({Name = "Self"})
          local EspSetTab = VisualsPage:SubPage({Name = "Settings"})

           local function espUi(sec, className, with_chams)
               sec:Toggle({
                   Name = "ESP",
                   Flag = className .. "ESPEnabled",
               })
              local boxes = sec:Toggle({
                  Name = "Boxes",
                  Flag = className .. "Boxes",
              })
              boxes:Colorpicker({
                  Name = "Color 1",
                  Flag = className .. "BoxColor1",
                  Default = Color3.fromRGB(90, 120, 255),
              })
              boxes:Colorpicker({
                  Name = "Color 2",
                  Flag = className .. "BoxColor2",
                  Default = Color3.fromRGB(180, 90, 255),
              })
              if with_chams then
                  local chams = sec:Toggle({
                      Name = "Chams",
                      Flag = className .. "Chams",
                  })
                  chams:Colorpicker({
                      Name = "Color",
                      Flag = className .. "ChamsColor1",
                      Default = Color3.fromRGB(90, 120, 255),
                  })
                  chams:Colorpicker({
                      Name = "Outline",
                      Flag = className .. "ChamsColor2",
                      Default = Color3.fromRGB(180, 90, 255),
                  })
              end
              sec:Toggle({
                  Name = "Names",
                  Flag = className .. "Names",
              }):Colorpicker({
                  Name = "Name Color",
                  Flag = className .. "NameColor",
                  Default = Color3.fromRGB(255, 255, 255),
              })
              local hp = sec:Toggle({
                  Name = "Health Bar",
                  Flag = className .. "Health",
              })
              hp:Colorpicker({
                  Name = "Health Color 1",
                  Flag = className .. "HealthColor1",
                  Default = Color3.fromRGB(255, 70, 70),
              })
              hp:Colorpicker({
                  Name = "Health Color 2",
                  Flag = className .. "HealthColor2",
                  Default = Color3.fromRGB(255, 220, 70),
              })
              hp:Colorpicker({
                  Name = "Health Color 3",
                  Flag = className .. "HealthColor3",
                  Default = Color3.fromRGB(80, 255, 120),
              })
              sec:Toggle({
                  Name = "Distance",
                  Flag = className .. "Distance",
              }):Colorpicker({
                  Name = "Distance Color",
                  Flag = className .. "DistanceColor",
                  Default = Color3.fromRGB(255, 255, 255),
              })
              sec:Toggle({
                  Name = "Weapon",
                  Flag = className .. "Weapon",
              }):Colorpicker({
                  Name = "Weapon Color",
                  Flag = className .. "WeaponColor",
                  Default = Color3.fromRGB(255, 255, 255),
              })
               if className == "Players" then
                  sec:Toggle({
                      Name = "Flags",
                      Flag = "PlayersFlags",
                  }):Colorpicker({
                      Name = "Flags Color",
                      Flag = "PlayersFlagsColor",
                      Default = Color3.fromRGB(255, 200, 80),
                  })
                  sec:Dropdown({
                      Name = "Selected Flags",
                      Flag = "PlayersFlagsList",
                      Multi = true,
                      Items = {
                          "Aiming",
                          "Reloading",
                          "Healing",
                      },
                  })
              end
                          end

          local players_sec = MainTab:Section({Name = "Players", Side = 1})
          local boss_sec = MainTab:Section({Name = "Boss", Side = 1})
          local ai_sec = MainTab:Section({Name = "AI", Side = 1})
          espUi(players_sec, "Players", true)
          espUi(boss_sec, "Boss", false)
          espUi(ai_sec, "AI", false)

          local esp_set_left = EspSetTab:Section({Name = "Render", Side = 1})
          esp_set_left:Toggle({
              Name = "Infinite Range",
              Flag = "EspInfiniteRange",
          })
          esp_set_left:Slider({
              Name = "Player ESP Max Distance",
              Flag = "PlayersMaxDistance",
              Min = 20,
              Max = 10000,
              Default = 10000,
              Decimals = 1,
          })
          esp_set_left:Slider({
              Name = "Boss ESP Max Distance",
              Flag = "BossMaxDistance",
              Min = 20,
              Max = 10000,
              Default = 10000,
              Decimals = 1,
          })
          esp_set_left:Slider({
              Name = "AI ESP Max Distance",
              Flag = "AIMaxDistance",
              Min = 20,
              Max = 10000,
              Default = 10000,
              Decimals = 1,
          })
          esp_set_left:Toggle({
              Name = "Hide Behind Walls",
              Flag = "EspHideBehind",
              Default = false,
          })
          local esp_set_right = EspSetTab:Section({Name = "Flag Colors", Side = 2})
          local flag_colors = {
              { "Aiming", Color3.fromRGB(255, 80, 80) },
              { "Reloading", Color3.fromRGB(255, 200, 80) },
              { "Healing", Color3.fromRGB(120, 255, 120) },
          }
          for _, fc in ipairs(flag_colors) do
              esp_set_right:Label({
                  Name = fc[1],
              }):Colorpicker({
                  Flag = "PlayersFlagCol" .. fc[1],
                  Default = fc[2],
              })
          end

          local world_esp = WorldTab:Section({Name = "Settings", Side = 1})
          world_esp:Toggle({
              Name = "Master Switch",
              Flag = "MiscEnabledESP",
          })
          world_esp:Toggle({
              Name = "Box",
              Flag = "WorldBox",
              Default = false,
          })
          world_esp:Toggle({
              Name = "Name",
              Flag = "WorldName",
              Default = true,
          })
          world_esp:Toggle({
              Name = "Distance",
              Flag = "WorldDistance",
              Default = true,
          })
          local wchams = world_esp:Toggle({
              Name = "Chams",
              Flag = "WorldChams",
              Default = false,
          })
          wchams:Colorpicker({
              Name = "Chams Color",
              Flag = "WorldChamsColor1",
              Default = Color3.fromRGB(90, 120, 255),
          })
          wchams:Colorpicker({
              Name = "Chams Glow",
              Flag = "WorldChamsColor2",
              Default = Color3.fromRGB(180, 90, 255),
          })


          local main_sec = WorldTab:Section({Name = "Main", Side = 1})
          local others_sec = WorldTab:Section({Name = "Others", Side = 1})
          local main_items_left = {
              "Stone",
              "Metal",
              "Phosphate",
              "Wool",
          }
          for i = 1, #main_items_left do
              local v = main_items_left[i]
              main_sec:Toggle({
                  Name = v,
                  Flag = v .. "Enabled",
              }):Colorpicker({
                  Name = v .. " Color",
                  Flag = v .. "Color",
              })
              main_sec:Slider({
                  Name = "Max Distance",
                  Flag = v .. "MaxDistance",
                  Min = 10,
                  Max = 400,
                  Default = 50,
              })
          end
          local others_items_left = {
              "Animals",
              "Salvaged Flycopter",
              "Auto Turret",
              "Shotgun Turret",
          }
          for i = 1, #others_items_left do
              local v = others_items_left[i]
              local max_d = 400
              local def_d = 50
              if v == "Salvaged Flycopter" then
                  max_d = 3000
                  def_d = 3000
              end
              others_sec:Toggle({
                  Name = v,
                  Flag = v .. "Enabled",
              }):Colorpicker({
                  Name = v .. " Color",
                  Flag = v .. "Color",
              })
              others_sec:Slider({
                  Name = "Max Distance",
                  Flag = v .. "MaxDistance",
                  Min = 10,
                  Max = max_d,
                  Default = def_d,
              })
          end

          local world_sec_r = WorldTab:Section({Name = "World", Side = 2})
          local raids_sec = WorldTab:Section({Name = "Raids", Side = 2})
          local world_items_right = {
              "Body Bag",
              "Drops",
              "Care Package",
          }
          for i = 1, #world_items_right do
              local v = world_items_right[i]
              local max_d = 1000
              local def_d = 50
              if v == "Care Package" then
                  max_d = 3000
                  def_d = 3000
              end
              world_sec_r:Toggle({
                  Name = v,
                  Flag = v .. "Enabled",
              }):Colorpicker({
                  Name = v .. " Color",
                  Flag = v .. "Color",
              })
              world_sec_r:Slider({
                  Name = "Max Distance",
                  Flag = v .. "MaxDistance",
                  Min = 10,
                  Max = max_d,
                  Default = def_d,
              })
          end
          raids_sec:Toggle({
              Name = "Raids",
              Flag = "RaidESP",
          }):Colorpicker({
              Name = "Raid Color",
              Flag = "RaidColor",
              Default = Color3.fromRGB(255, 80, 80),
          })
          raids_sec:Slider({
              Name = "Max Distance",
              Flag = "RaidMaxDistance",
              Min = 50,
              Max = 5000,
              Default = 2000,
          })
          raids_sec:Toggle({
              Name = "Raid Notifications",
              Flag = "RaidNotifications",
              Default = true,
          })

          world_sec_r:Toggle({
              Name = "Grenade",
              Flag = "GrenadeESP",
              Default = false,
          })
          world_sec_r:Slider({
              Name = "Grenade ESP Max Distance",
              Flag = "GrenadeESPDistance",
              Min = 10,
              Max = 3000,
              Default = 1000,
          })

          local light_sec = MainTab:Section({Name = "Ambience", Side = 2})
          local tracer_sec = MainTab:Section({Name = "Tracers", Side = 2})
          local effects_sec = MainTab:Section({Name = "Effects", Side = 2})
          light_sec:Toggle({
              Name = "Ambience",
              Flag = "AmbienceEnabled",
          }):Colorpicker({
              Name = "Color",
              Flag = "AmbienceColor",
              Default = Color3.fromRGB(255, 255, 255),
          })
          light_sec:Slider({
              Name = "Brightness",
              Flag = "AmbienceBrightness",
              Min = 0,
              Max = 1,
              Default = 0.12,
              Decimals = 0.001,
          })
          light_sec:Slider({
              Name = "Indoor Brightness",
              Flag = "AmbienceIndoorBrightness",
              Min = 0,
              Max = 1,
              Default = 0.035,
              Decimals = 0.001,
          })
          local tr_t = tracer_sec:Toggle({
              Name = "Bullet Tracers",
              Flag = "BulletTracers",
          })
          tr_t:Colorpicker({
              Name = "Color",
              Flag = "BulletTracersColor",
              Default = Color3.fromRGB(255, 255, 255),
          })
          tracer_sec:Dropdown({
              Name = "Style",
              Flag = "BulletTracersStyle",
              Items = {
                  "Default",
                  "Electric",
                  "Liquid",
                  "Wave",
                  "Curved",
                  "Dark",
              },
              Default = "Default",
          })
          tracer_sec:Slider({
              Name = "Lifetime",
              Flag = "BulletTracersDuration",
              Min = 0.1,
              Max = 3,
              Default = 1,
              Decimals = 0.1,
              Suffix = "s",
          })
          tracer_sec:Slider({
              Name = "Fade Speed",
              Flag = "TracerFadeSpeed",
              Min = 0,
              Max = 10,
              Default = 1,
              Decimals = 0.1,
              Suffix = "x",
          })

          effects_sec:Toggle({
              Name = "Hit Effects",
              Flag = "HitEffect",
              Default = false,
          }):Colorpicker({
              Name = "Hit Effects",
              Flag = "HitEffectColor",
          })
          effects_sec:Dropdown({
              Name = "Effect",
              Flag = "HitEffectStyle",
              Items = {
                  "Sparks",
                  "Dots",
                  "Catalyst",
                  "Mist",
                  "Chiral",
              },
              Default = "Sparks",
          })
          effects_sec:Slider({
              Name = "Lifetime",
              Flag = "HitEffectLifetime",
              Min = 0.1,
              Max = 5,
              Default = 1,
              Decimals = 0.1,
              Suffix = "s",
          })

          local vm_item = SelfTab:Section({Name = "Item", Side = 1})
          local vm_shirt = SelfTab:Section({Name = "Shirt", Side = 1})
          local vm_gloves = SelfTab:Section({Name = "Gloves", Side = 1})
          local vm_arms = SelfTab:Section({Name = "Arms", Side = 1})
          local vm_pos = SelfTab:Section({Name = "Position", Side = 2})

          local function vm_option(sec, name)
              local tgl = sec:Toggle({
                  Name = name,
                  Flag = "VM" .. name .. "Enabled",
              })
              tgl:Colorpicker({
                  Name = "Color",
                  Flag = "VM" .. name .. "Color",
              })
              sec:Dropdown({
                  Name = "Material",
                  Flag = "VM" .. name .. "Material",
                  Default = "None",
                  Items = {
                      "None",
                      "Forcefield",
                      "Neon",
                      "Glass",
                      "Plastic",
                  },
              })
              sec:Toggle({
                  Name = "Shading",
                  Flag = "VM" .. name .. "Shading",
              })
              sec:Slider({
                  Name = "Shading",
                  Flag = "VM" .. name .. "ShadingAmount",
                  Min = 1,
                  Max = 10,
                  Default = 4.8,
                  Decimals = 0.1,
              })
              sec:Toggle({
                  Name = "Texture",
                  Flag = "VM" .. name .. "Texture",
              })
              sec:Dropdown({
                  Name = "Texture",
                  Flag = "VM" .. name .. "TextureOption",
                  Items = {
                      "Galaxy",
                      "Universe",
                      "Damascus",
                      "Israel",
                  },
              })
              sec:Slider({
                  Name = "Speed",
                  Flag = "VM" .. name .. "TextureSpeed",
                  Min = 0,
                  Max = 1,
                  Default = 1,
                  Decimals = 0.01,
              })
          end

          vm_option(vm_item, "Item")
          vm_option(vm_shirt, "Shirt")
          vm_option(vm_gloves, "Gloves")
          vm_option(vm_arms, "Arms")

          vm_pos:Toggle({
              Name = "Position",
              Flag = "VMPosition",
          })
          vm_pos:Slider({
              Name = "X",
              Flag = "PosX",
              Min = -5,
              Max = 5,
              Default = 0,
              Decimals = 0.1,
          })
          vm_pos:Slider({
              Name = "Y",
              Flag = "PosY",
              Min = -5,
              Max = 5,
              Default = 0,
              Decimals = 0.1,
          })
          vm_pos:Slider({
              Name = "Z",
              Flag = "PosZ",
              Min = -5,
              Max = 5,
              Default = 0,
              Decimals = 0.1,
          })

          local vm_shaders = {
              Galaxy = "rbxassetid://13726625670",
              Universe = "rbxassetid://16666870788",
              Damascus = "rbxassetid://17672592862",
              Israel = "rbxassetid://964998527",
          }
          local vm_ff = "rbxassetid://5843010904"
          local vm_white = Color3.new(1, 1, 1)
          local vm_faces = {
              Enum.NormalId.Front,
              Enum.NormalId.Back,
              Enum.NormalId.Left,
              Enum.NormalId.Right,
              Enum.NormalId.Top,
              Enum.NormalId.Bottom,
          }
          local vm_scroll = {}
          setmetatable(vm_scroll, { __mode = "k" })

          local function vm_col(cat)
              return flagColor(flags["VM" .. cat .. "Color"], vm_white)
          end

          local function vm_scroll_apply(part, cat, image, color)
              for i = 1, #vm_faces do
                  local face = vm_faces[i]
                  local n = "VMTex" .. face.Name
                  local tex = part:FindFirstChild(n)
                  if not tex then
                      tex = Instance.new("Texture")
                      tex.Name = n
                      tex.Face = face
                      tex.StudsPerTileU = 2
                      tex.StudsPerTileV = 2
                      tex.Parent = part
                  end
                  if tex.Texture ~= image then
                      tex.Texture = image
                  end
                  tex.Color3 = color
                  vm_scroll[tex] = cat
              end
          end

          local function vm_scroll_clear(part)
              for i = 1, #vm_faces do
                  local face = vm_faces[i]
                  local tex = part:FindFirstChild("VMTex" .. face.Name)
                  if tex then
                      vm_scroll[tex] = nil
                      tex:Destroy()
                  end
              end
          end

          local function vm_part(part, cat)
              if not (part:IsA("BasePart")) then return end
              if part.Size.Magnitude < 0.05 then return end
              if part.Transparency >= 0.95 then return end
              local c, a = vm_col(cat)
              local mat = flags["VM" .. cat .. "Material"]
              if mat == "Forcefield" then
                  mat = "ForceField"
              end
              if type(mat) == "string" and mat ~= "None" then
                  pcall(function()
                      part.Material = Enum.Material[mat]
                  end)
              end
              part.Color = c
              part.Transparency = a
              if part:IsA("MeshPart") then
                  local tex_on = flags["VM" .. cat .. "Texture"]
                  local tex_name = flags["VM" .. cat .. "TextureOption"]
                  local img = tex_name and vm_shaders[tex_name]
                  if tex_on and img then
                      part.TextureID = ""
                      vm_scroll_apply(part, cat, img, c)
                  else
                      vm_scroll_clear(part)
                      if mat == "ForceField" then
                          part.TextureID = vm_ff
                      elseif part.Material == Enum.Material.SmoothPlastic or part.Material == Enum.Material.Glass or part.Material == Enum.Material.Neon then
                          part.TextureID = ""
                      end
                  end
              end
              local shade = part:FindFirstChild("VMShade")
              if flags["VM" .. cat .. "Shading"] then
                  if not shade then
                      shade = Instance.new("Highlight")
                      shade.Name = "VMShade"
                      shade.Adornee = part
                      shade.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
                      shade.OutlineTransparency = 1
                      shade.Parent = part
                  end
                  shade.FillColor = c
                  shade.FillTransparency = -(tonumber(flags["VM" .. cat .. "ShadingAmount"]) or 4.8)
              elseif shade then
                  shade:Destroy()
              end
          end

          local function vm_apply(model)
              if not (model and model:IsA("Model")) then
                  return
              end
              local arms = model:FindFirstChild("Arms")
              if arms then
                  local desc = arms:GetDescendants()
                  for i = 1, #desc do
                      local part = desc[i]
                      if (part:IsA("MeshPart") or part:IsA("Part")) and part:IsA("BasePart") then
                          local n = part.Name
                          local cat
                          if flags.VMShirtEnabled and (n == "Sleeve" or n == "Armor") then
                              cat = "Shirt"
                          elseif flags.VMGlovesEnabled and (n == "Glove" or n == "Wrap") then
                              cat = "Gloves"
                          elseif flags.VMArmsEnabled then
                              cat = "Arms"
                          end
                          if cat and part.Transparency < 1 then
                              vm_part(part, cat)
                          end
                      end
                  end
              end
              if flags.VMItemEnabled then
                  local wep = model:FindFirstChild("Weapon")
                  if wep then
                      local desc = wep:GetDescendants()
                      for i = 1, #desc do
                          local part = desc[i]
                          if part:IsA("MeshPart") and part.Transparency < 1 then
                              vm_part(part, "Item")
                          end
                      end
                  end
              end
          end

          local vm_last = 0
          Run.Heartbeat:Connect(LPH_NO_VIRTUALIZE(function()
              if not (flags.VMItemEnabled or flags.VMShirtEnabled or flags.VMGlovesEnabled or flags.VMArmsEnabled) then
                  return
              end
              local now = tick()
              if now - vm_last < 0.2 then
                  return
              end
              vm_last = now
              local vfx = workspace:FindFirstChild("VFX")
              local folder = vfx and vfx:FindFirstChild("VMs")
              if not folder then
                  return
              end
              local kids = folder:GetChildren()
              for i = 1, #kids do
                  local vm = kids[i]
                  if vm:IsA("Model") then
                      vm_apply(vm)
                  end
              end
          end))

          local tex_acc = 0
          Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function(dt)
              if next(vm_scroll) == nil then
                  return
              end
              tex_acc = tex_acc + dt
              if tex_acc < 0.05 then
                  return
              end
              local step = tex_acc
              tex_acc = 0
              for tex, cat in pairs(vm_scroll) do
                  if tex.Parent then
                      local spd = tonumber(flags["VM" .. cat .. "TextureSpeed"]) or 1
                      tex.OffsetStudsV = (tex.OffsetStudsV + step * spd) % 2
                  else
                      vm_scroll[tex] = nil
                  end
              end
          end))

          do
              local orig_local = {}
              local orig_use = {}
              setmetatable(orig_local, { __mode = "k" })
              setmetatable(orig_use, { __mode = "k" })
              local vm_tables = {}

              local function grab_vm_tables()
                  table.clear(vm_tables)
                  if type(getgc) ~= "function" then
                      return
                  end
                  local ok, list = pcall(getgc, true)
                  if not ok or type(list) ~= "table" then
                      return
                  end
                  for _, tbl in next, list do
                      if type(tbl) == "table" and rawget(tbl, "Global") ~= nil and typeof(rawget(tbl, "Local")) == "CFrame" then
                          vm_tables[#vm_tables + 1] = tbl
                      end
                  end
              end

              local function current_vm()
                  local vfx = workspace:FindFirstChild("VFX")
                  local folder = vfx and vfx:FindFirstChild("VMs")
                  if not folder then
                      return nil
                  end
                  return folder:GetChildren()[1]
              end

              local function apply_vm_off()
                  if flags.VMPosition then
                      local off = CFrame.new(tonumber(flags.PosX) or 0, tonumber(flags.PosY) or 0, tonumber(flags.PosZ) or 0)
                      for i = 1, #vm_tables do
                          local tbl = vm_tables[i]
                          local loc = rawget(tbl, "Local")
                          if typeof(loc) == "CFrame" then
                              if not orig_local[tbl] then
                                  orig_local[tbl] = loc
                              end
                              tbl.Local = orig_local[tbl] * off
                              local lu = rawget(tbl, "LocalUse")
                              if typeof(lu) == "CFrame" then
                                  if not orig_use[tbl] then
                                      orig_use[tbl] = lu
                                  end
                                  tbl.LocalUse = orig_use[tbl] * off
                              end
                          end
                      end
                  else
                      for tbl, v in pairs(orig_local) do
                          if rawget(tbl, "Local") ~= nil then
                              tbl.Local = v
                          end
                      end
                      for tbl, v in pairs(orig_use) do
                          if rawget(tbl, "LocalUse") ~= nil then
                              tbl.LocalUse = v
                          end
                      end
                  end
              end

              if type(getgc) == "function" then
                  local last_on, last_x, last_y, last_z, last_sig
                  Run.Heartbeat:Connect(LPH_NO_VIRTUALIZE(function()
                      local on = flags.VMPosition == true
                      local x = tonumber(flags.PosX) or 0
                      local y = tonumber(flags.PosY) or 0
                      local z = tonumber(flags.PosZ) or 0
                      local vm = current_vm()
                      local sig = vm
                      if vm then
                          sig = vm:FindFirstChild("Weapon") or vm
                      end
                      local sig_changed = sig ~= last_sig
                      local changed = on ~= last_on or x ~= last_x or y ~= last_y or z ~= last_z or sig_changed
                      if not changed then
                          return
                      end
                      if on and (sig_changed or #vm_tables == 0) then
                          grab_vm_tables()
                      end
                      last_on, last_x, last_y, last_z, last_sig = on, x, y, z, sig
                      apply_vm_off()
                  end))
              end
          end
      end

      do
          local MovementSection = MiscMain:Section({Name = "Movement", Side = 1})
          local CameraSection = MiscMain:Section({Name = "Camera", Side = 1})
          local ExploitsSection = GunModsTab:Section({Name = "Utility", Side = 2})
          local MeleeSection = GunModsTab:Section({Name = "Melee", Side = 2})
          local xrtog = ExploitsSection:Toggle({
              Name = "XRay",
              Flag = "WorldXRay",
              Default = false,
          })
          xrtog:Keybind({
              Name = "XRay Key",
              Flag = "WorldXRayKey",
              Mode = "Toggle",
              Default = "None",
          })
          local xr_s = xrtog:Settings()
          local xraySection = xr_s:Section({Name = "Visibility"})
          xraySection:Slider({
              Name = "XRay Transparency",
              Flag = "WorldXRayTransparency",
              Min = 0,
              Max = 1,
              Default = 0.5,
              Decimals = 0.01,
          })
          MeleeSection:Toggle({
              Name = "Perfect Farm",
              Flag = "PerfectFarm",
          })
          MeleeSection:Toggle({
              Name = "Fast Hit",
              Flag = "FastHit",
              Callback = function(v)
                  if getgenv().fastHit then
                      getgenv().fastHit(v == true)
                  end
              end,
          })
          MeleeSection:Toggle({
              Name = "Reach",
              Flag = "Reach",
          })

          local spd_t = MovementSection:Toggle({
              Name = "Speed",
              Flag = "SpeedEnabled",
          })
          spd_t:Keybind({
              Name = "Speed Bind",
              Flag = "SpeedBind",
              Mode = "Toggle",
              Default = "None",
          })
          local spd_s = spd_t:Settings()
          local speedSection = spd_s:Section({Name = "Movement"})
          speedSection:Slider({
              Name = "Speed",
              Flag = "SpeedSpeed",
              Min = 16,
              Max = 30,
              Default = 16,
          })
          local flt_t = MovementSection:Toggle({
              Name = "Flight",
              Flag = "FlightEnabled",
          })
          flt_t:Keybind({
              Name = "Flight Bind",
              Flag = "FlightBind",
              Mode = "Toggle",
              Default = "None",
          })
          local flt_s = flt_t:Settings()
          local flightSection = flt_s:Section({Name = "Movement"})
          flightSection:Slider({
              Name = "Speed",
              Flag = "FlightSpeed",
              Min = 1,
              Max = 20,
              Default = 10,
          })
          MovementSection:Toggle({
              Name = "Bunnyhop",
              Flag = "Bunnyhop",
          })

          local omni_t = MovementSection:Toggle({
              Name = "Omni Sprint",
              Flag = "OmniSprint",
          })
          omni_t:Keybind({
              Name = "Omni Sprint Bind",
              Flag = "OmniSprintBind",
              Mode = "Toggle",
              Default = "None",
          })
          local omni_s = omni_t:Settings()
          local omniSprintSection = omni_s:Section({Name = "Movement"})
          omniSprintSection:Slider({
              Name = "Omni Speed",
              Flag = "OmniSprintSpeed",
              Min = 18,
              Max = 30,
              Default = 24,
              Decimals = 1,
          })

          local zoom_t = CameraSection:Toggle({
              Name = "Zoom",
              Flag = "ZoomEnabled",
          })
          zoom_t:Keybind({
              Name = "Keybind",
              Flag = "ZoomKeybind",
              Mode = "Hold",
              Default = "None",
          })
          local zoom_s = zoom_t:Settings()
          local zoomSection = zoom_s:Section({Name = "Camera"})
          zoomSection:Slider({
              Name = "Fov",
              Flag = "ZoomAmount",
              Min = 1,
              Max = 120,
              Default = 30,
          })
          local free_t = CameraSection:Toggle({
              Name = "Freecam",
              Flag = "Freecam",
          })
          free_t:Keybind({
              Name = "Freecam Bind",
              Flag = "FreecamKeybind",
              Mode = "Toggle",
              Default = "None",
          })
          local free_s = free_t:Settings()
          local freecamSection = free_s:Section({Name = "Camera"})
          freecamSection:Slider({
              Name = "Speed",
              Flag = "FreecamSpeed",
              Min = 1,
              Max = 100,
              Default = 10,
          })

          local NotifSection = MiscMain:Section({Name = "Notifications", Side = 2})
          local HitSection = MiscMain:Section({Name = "Hitmarker", Side = 2})
          local CrossSection = MiscMain:Section({Name = "Crosshair", Side = 2})
          local hm_t = HitSection:Toggle({
              Name = "Hitmarkers",
              Flag = "Hitmarkers",
          })
          hm_t:Colorpicker({
              Name = "Color",
              Flag = "HitmarkerColor",
              Default = Color3.fromRGB(255, 255, 255),
          })
          local hm_s = hm_t:Settings()
          local hitmarkerSection = hm_s:Section({Name = "Hitmarker"})
          hitmarkerSection:Toggle({
              Name = "Random Rotation",
              Flag = "HitmarkerRandomRotation",
          })
          hitmarkerSection:Slider({
              Name = "Size",
              Flag = "HitmarkerSize",
              Min = 10,
              Max = 120,
              Default = 40,
              Suffix = "px",
          })
          hitmarkerSection:Slider({
              Name = "Lifetime",
              Flag = "HitmarkerTime",
              Min = 0.1,
              Max = 3,
              Default = 1,
              Decimals = 0.1,
              Suffix = "s",
          })
          local ch_t = CrossSection:Toggle({
              Name = "Crosshair",
              Flag = "Crosshair",
              Default = false,
          })
          ch_t:Colorpicker({
              Name = "Color",
              Flag = "CrosshairColor",
              Default = Color3.fromRGB(255, 255, 255),
          })
          local ch_s = ch_t:Settings()
          local crosshairBehaviorSection = ch_s:Section({Name = "Behavior"})
          crosshairBehaviorSection:Toggle({
              Name = "Follow Mouse",
              Flag = "CrosshairFollowMouse",
              Default = true,
          })
          crosshairBehaviorSection:Toggle({
              Name = "Rotate",
              Flag = "CrosshairRotate",
          })
          crosshairBehaviorSection:Toggle({
              Name = "Stick To Target",
              Flag = "CrosshairStick",
          })
          crosshairBehaviorSection:Toggle({
              Name = "Sync To Lock Color",
              Flag = "CrosshairSyncColor",
          })
          CrossSection:Slider({
              Name = "Length",
              Flag = "CrosshairLength",
              Min = 0,
              Max = 40,
              Default = 20,
          })
          CrossSection:Slider({
              Name = "Width",
              Flag = "CrosshairWidth",
              Min = 1,
              Max = 6,
              Default = 2,
          })
          CrossSection:Slider({
              Name = "Gap",
              Flag = "CrosshairGap",
              Min = 0,
              Max = 60,
              Default = 20,
          })

          NotifSection:Toggle({
              Name = "Hit Notifier",
              Flag = "HitNotifier",
              Default = false,
          })

          NotifSection:Toggle({
              Name = "Miss Notifier",
              Flag = "MissNotifier",
              Default = false,
          })

      end

      do
          local headButtons = {}
          local MenuPage = Window:Page({Name = "Menu"})
          local MenuMain = MenuPage:SubPage({Name = "Main"})
          local menuSec = MenuMain:Section({Name = "Menu", Side = 1})

          local menuKeyLabel = menuSec:Label({
              Name = "Menu Bind",
          })
          menuKeyLabel:Keybind({
              Flag = "MenuBind",
              Default = Enum.KeyCode.RightShift,
              Mode = "Toggle",
              Callback = function()
                  local picked = flags.MenuBind
                  if type(picked) == "table" and type(picked.Key) == "string" and picked.Key ~= "" and picked.Key ~= "None" then
                      Library.MenuKeybind = picked.Key
                  end
              end,
          })
          menuSec:Dropdown({
              Name = "Style",
              Flag = "MenuEasing",
              Items = {
                  "Linear",
                  "Sine",
                  "Quad",
                  "Cubic",
                  "Quart",
                  "Quint",
                  "Exponential",
                  "Back",
                  "Bounce",
                  "Elastic",
              },
              Default = "Quint",
              Callback = function(name)
                  if type(name) == "string" then
                      Library.Animation.Style = name
                  end
              end,
          })
          menuSec:Dropdown({
              Name = "Direction",
              Flag = "MenuEasingDirection",
              Items = {
                  "In",
                  "Out",
                  "InOut",
              },
              Default = "Out",
              Callback = function(name)
                  if type(name) == "string" then
                      Library.Animation.Direction = name
                  end
              end,
          })

          Library:RegisterSettingsWidget({
              Name = "Watermark",
              Flag = "WatermarkEnabled",
              Default = true,
              Callback = function(v)
                  Watermark:SetVisibility(v == true)
                  local hb = headButtons.Watermark
                  if hb then hb:SetActive(v == true) end
              end,
          })
          Library:RegisterSettingsWidget({
              Name = "Keybind List",
              Flag = "KeybindListEnabled",
              Default = false,
              Callback = function(v)
                  KeybindList:SetVisibility(v == true)
                  local hb = headButtons.Keybinds
                  if hb then hb:SetActive(v == true) end
              end,
          })
          Library:RegisterSettingsWidget({
              Name = "Target HUD",
              Flag = "TargetHUDEnabled",
              Default = true,
              Callback = function(v)
                  if v ~= true then
                      TargetHUD:SetVisibility(false)
                  end
                  local hb = headButtons.Target
                  if hb then hb:SetActive(v == true) end
              end,
          })
          Library:RegisterSettingsWidget({
              Name = "Inventory",
              Flag = "ArmorBarEnabled",
              Default = false,
              Callback = function(v)
                  local hb = headButtons.Inventory
                  if hb then hb:SetActive(v == true) end
              end,
          })
          Library:RegisterSettingsWidget({
              Name = "Player List",
              Flag = "PlayerListEnabled",
              Default = false,
              Callback = function(v)
                  PlayerList:SetVisibility(v == true)
                  if v == true then
                      pcall(syncRoster)
                  end
              end,
          })
          Window:CreateSettingsPage()
          local function headButton(key, label, flag)
              local btn = Window:AddHeaderButton({Text = label})
              btn:SetActive(flags[flag] == true)
              btn:SetCallback(function()
                  local setter = Library.SetFlags[flag]
                  if type(setter) == "function" then
                      setter(not (flags[flag] == true))
                  end
                  btn:SetActive(flags[flag] == true)
              end)
              headButtons[key] = btn
          end
          headButton("Watermark", "Watermark", "WatermarkEnabled")
          headButton("Keybinds", "Keybind List", "KeybindListEnabled")
          headButton("Target", "Target HUD", "TargetHUDEnabled")
          headButton("Inventory", "Inv Viewer", "ArmorBarEnabled")
      end
  end

  local Camera = workspace.CurrentCamera
  local Client = Players.LocalPlayer
  
  local wsVFXFolder = workspace:WaitForChild("VFX")
  local VMs = wsVFXFolder and wsVFXFolder:FindFirstChild('VMs')
  local Drops = workspace:FindFirstChild('Drops')
  local Plants = workspace:FindFirstChild('Plants')
  local Animals = workspace:FindFirstChild('Animals')
  
  local function hookModule(target_table, fn_name, new_fn)
      local orig = target_table and target_table[fn_name]
      if hookfunction and type(orig) == "function" then
          return hookfunction(orig, new_fn)
      end
      if setreadonly and type(target_table) == "table" then
          setreadonly(target_table, false)
      end
      target_table[fn_name] = new_fn
      if setreadonly and type(target_table) == "table" then
          setreadonly(target_table, true)
      end
      return orig
  end

  local Modules = RS:FindFirstChild("Modules") or RS:WaitForChild("Modules", 5)
  if not Modules then
      local lp_guard = Players.LocalPlayer
      if lp_guard then
          lp_guard:Kick("Launch only after loading into the game server")
      end
      return
  end
  local rsVFXFolder = RS:WaitForChild("VFX")
  local Values = RS:WaitForChild("Values")
  
  local ItemClass, VFXModule
  do
      local ok_ic, ic_r = pcall(function()
          return Modules and require(Modules:WaitForChild("ItemClass", 15))
      end)
      if not ok_ic or type(ic_r) ~= "table" then
          cheat.fatal("ItemClass load failed")
          return
      end
      ItemClass = ic_r
      local ok_vfx, vfx_r = pcall(function()
          return Modules and require(Modules.VFXModule)
      end)
      if not ok_vfx or type(vfx_r) ~= "table" then
          cheat.fatal("VFXModule load failed")
          return
      end
      VFXModule = vfx_r
  end
  local ItemsModule = Modules and require(Modules.Items)
  local RaycastUtil = Modules and (Modules:FindFirstChild("roosterchickens") and require(Modules.roosterchickens) or Modules:FindFirstChild("RaycastUtil") and require(Modules.RaycastUtil))
  local SettingsModule = Modules and Modules:FindFirstChild("SettingsModule") and require(Modules.SettingsModule) or nil
  local SoundModule = Modules and require(Modules.SoundModule)
  local ToolInfo = Modules and (Modules:FindFirstChild("chickenfried") and require(Modules.chickenfried) or Modules:FindFirstChild("ToolInfo") and require(Modules.ToolInfo))
  local VectorUtilModule = Modules and Modules:WaitForChild("VectorUtil", 10)
  local VectorUtil = VectorUtilModule and require(VectorUtilModule)

  if not (ToolInfo and RaycastUtil) then
      local lp_guard = Players.LocalPlayer
      if lp_guard then
          lp_guard:Kick("Launch only after loading into the game server")
      end
      return
  end

  local function ownFlash()
      if getcallingscript then
          local s = getcallingscript()
          return s and s.Name == "ViewmodelController"
      end
      local tb = debug.traceback()
      return tb and tb:find("ViewmodelController", 1, true) ~= nil
  end

  local bobOff = false

  local busyAnims = {
      Equip = true, Shoot = true, Reload = true, Reload1 = true, Reload2 = true, Reload3 = true,
      Aim = true, AimStart = true, AimHold = true, Bolt = true, Inspect = true, Use = true,
      Swing = true, Hit = true, Miss = true, Light = true, Dig = true, Loaded = true,
      Unloaded = true, SightFix = true, ThrowHold = true, Windup = true, WindupLoop = true,
      Throw = true, AimStop = true, ThrowWindup = true,
  }

  local function gunBusy(inst)
      if not inst then
          return false
      end
      for _, d in ipairs(inst:GetDescendants()) do
          if d:IsA("Animator") or d:IsA("AnimationController") then
              local ok, tracks = pcall(function()
                  return d:GetPlayingAnimationTracks()
              end)
              if ok and type(tracks) == "table" then
                  for _, t in ipairs(tracks) do
                      if busyAnims[t.Name] then
                          return true
                      end
                  end
              end
          end
      end
      return false
  end

  local function isFiring(inst)
      if not inst then
          return false
      end
      for _, d in ipairs(inst:GetDescendants()) do
          if d:IsA("Animator") or d:IsA("AnimationController") then
              local ok, tracks = pcall(function()
                  return d:GetPlayingAnimationTracks()
              end)
              if ok and type(tracks) == "table" then
                  for _, t in ipairs(tracks) do
                      if t.Name == "Shoot" then
                          return true
                      end
                  end
              end
          end
      end
      return false
  end

  local function forGuns(fn)
      local vmsFolder = VMs
      if vmsFolder == nil and wsVFXFolder then
          vmsFolder = wsVFXFolder:FindFirstChild("VMs")
      end
      if vmsFolder then
          for _, m in ipairs(vmsFolder:GetChildren()) do
              if m:IsA("Model") then
                  fn(m)
              end
          end
      end
      local cam = workspace.CurrentCamera
      if cam then
          for _, m in ipairs(cam:GetChildren()) do
              if m:IsA("Model") then
                  fn(m)
              end
          end
      end
  end

  do
      local hiddenArms = setmetatable({}, {__mode = "k"})
      local function setArmsHidden(model, hidden)
          local arms = model:FindFirstChild("Arms")
          if not arms then
              return
          end
          for _, item in ipairs(arms:GetDescendants()) do
              if item:IsA("BasePart") or item:IsA("Decal") or item:IsA("Texture") then
                  if hidden then
                      if item.Transparency < 1 then
                          hiddenArms[item] = item.Transparency
                          item.Transparency = 1
                      end
                  elseif hiddenArms[item] then
                      item.Transparency = hiddenArms[item]
                      hiddenArms[item] = nil
                  end
              end
          end
      end
      local armsWereHidden = false
      Run.RenderStepped:Connect(function()
          local hide = flags.RemoveArms == true
          if hide or armsWereHidden then
              forGuns(function(model)
                  setArmsHidden(model, hide)
              end)
              armsWereHidden = hide
          end
      end)
  end

  local function holdStill(inst)
      local id = CFrame.new()
      for _, d in ipairs(inst:GetDescendants()) do
          if d:IsA("Motor6D") or d:IsA("Bone") then
              pcall(function()
                  d.Transform = id
              end)
          end
      end
  end

  local function grabSprings()
      local hum = cheat.Globals.ClientCharacter and cheat.Globals.ClientCharacter:FindFirstChildOfClass("Humanoid")
      if not hum then
          return 0
      end
      local conns = {}
      if getconnections then
          for _, c in ipairs(getconnections(hum.StateChanged)) do
              conns[#conns + 1] = c
          end
      end
      if #conns == 0 then
          return 0
      end
      local found = 0
      local seen = {}
      local springs = cheat.Globals.Springs
      if type(springs) ~= "table" then
          springs = {}
          cheat.Globals.Springs = springs
      end
      local cam_offset
      for _, c in ipairs(conns) do
          local fn = c.Function
          if type(fn) ~= "function" then
              continue
          end
          local src = debug.info(fn, "s")
          if src == "[C]" then
              continue
          end
          for i = 1, 30 do
              local ok, name, val = pcall(debug.getupvalue, fn, i)
              if not ok or not name then break end
              if type(val) == "table" and not seen[val] then
                  local has_spring = val._position0 ~= nil
                      or val._velocity0 ~= nil
                      or val._target ~= nil
                      or val.Position ~= nil
                  if has_spring and (val._position0 or val._velocity0) then
                      seen[val] = true
                      springs[#springs + 1] = val
                      found = found + 1
                  end
              end
          end
      end
      pcall(function()
          Run:UnbindFromRenderStep("HumCamOffset")
      end)
      local bob = cheat.Globals.BobSpring
      if type(bob) ~= "table" then
          for _, s in ipairs(springs) do
              if typeof(s.Position) == "Vector3" then
                  cheat.Globals.BobSpring = s
                  break
              end
          end
      end
      return found
  end

  local bobSaved = {}


  local function zeroLike(val)
      local tv = typeof(val)
      if tv == "number" then
          return 0
      elseif tv == "Vector3" then
          return Vector3.zero
      elseif tv == "CFrame" then
          return CFrame.new()
      end
      return nil
  end

  local function cleanCopy(t)
      if type(t) ~= "table" then
          return zeroLike(t) or t
      end
      local out = {}
      for k, v in pairs(t) do
          if type(v) == "table" then
              out[k] = cleanCopy(v)
          else
              local nz = zeroLike(v)
              out[k] = nz ~= nil and nz or v
          end
      end
      return out
  end

  local function zeroStats(t, on, path, store)
      if type(t) ~= "table" then
          return
      end
      local shooting = path[#path] == "Shooting"
      for k, v in pairs(t) do
          local kt = type(k) == "string" and k or tostring(k)
          if type(v) == "table" then
              path[#path + 1] = kt
              zeroStats(v, on, path, store[k] or (function()
                  store[k] = {}
                  return store[k]
              end)())
              path[#path] = nil
          elseif not shooting then
              local nz = zeroLike(v)
              if nz ~= nil then
                  local key = tostring(k)
                  if store[key] == nil then
                      store[key] = v
                  end
                  pcall(function()
                      t[k] = on and nz or store[key]
                  end)
              end
          end
      end
  end

  local function thawAll(t, depth)
      if type(t) ~= "table" then
          return
      end
      if depth > 6 then
          return
      end
      if setreadonly then
          pcall(setreadonly, t, false)
      end
      for _, v in pairs(t) do
          if type(v) == "table" then
              thawAll(v, depth + 1)
          end
      end
  end

  local function patchData(parent, key, store, on)
      if type(parent) ~= "table" then
          return
      end
      if on then
          local cur = parent[key]
          if type(cur) ~= "table" then
              return
          end
          if store.orig == nil then
              store.orig = cur
          end
          thawAll(parent, 0)
          thawAll(cur, 0)
          if not store.swapped then
              local blob = store.blob
              if blob == nil then
                  blob = {}
                  store.blob = blob
              end
              zeroStats(cur, true, { tostring(key) }, blob)
          end
          local clean = true
          local function scan(t)
              for _, v in pairs(t) do
                  if type(v) == "number" then
                      if v ~= 0 then
                          clean = false
                          return
                      end
                  elseif type(v) == "table" then
                      scan(v)
                      if not clean then
                          return
                      end
                  end
              end
          end
          scan(parent[key])
          if not clean then
              local clone = cleanCopy(store.orig)
              pcall(function() parent[key] = clone end)
              if parent[key] == clone then
                  store.swapped = true
              end
          end
      else
          if store.swapped then
              pcall(function() parent[key] = store.orig end)
              if parent[key] == store.orig then
                  store.swapped = false
              end
          else
              local cur = parent[key]
              if type(cur) == "table" then
                  zeroStats(cur, false, { tostring(key) }, store.blob or {})
              end
          end
      end
  end

  local function calmSpring(sp)
      if type(sp) ~= "table" then
          return
      end
      local seed = sp._target
      if seed == nil then
          seed = sp._position0
      end
      if seed == nil then
          local ok, cur = pcall(function() return sp.Target end)
          if ok then
              seed = cur
          end
      end
      local nz = seed ~= nil and zeroLike(seed) or nil
      if nz == nil then
          return
      end
      pcall(function() sp._position0 = nz end)
      pcall(function() sp._velocity0 = nz end)
      pcall(function() sp._target = nz end)
      pcall(function() sp.Position = nz end)
      pcall(function() sp.Velocity = nz end)
      pcall(function() sp.Target = nz end)
  end

  local function runBob()
      if type(ToolInfo) ~= "table" then
          return
      end
      for name, entry in pairs(ToolInfo) do
          pcall(function()
              local w = entry and entry.Weapon
              if type(w) ~= "table" then
                  return
              end
              local st = bobSaved[name]
              if not st then
                  st = { bob = w.Bobbing, mults = {} }
                  bobSaved[name] = st
              end
              thawAll(w, 0)
              if w.Bobbing ~= nil then
                  local nz = zeroLike(w.Bobbing)
                  if nz ~= nil then
                      pcall(function()
                          w.Bobbing = bobOff and nz or st.bob
                      end)
                  end
              end
              if type(w.VMMovementMults) == "table" then
                  patchData(w, "VMMovementMults", st.mults, bobOff)
              end
          end)
      end
  end

  getgenv().bobSwitch = function(v)
      bobOff = v == true
      pcall(runBob)
  end

  local kickOff = false
  local kickSaved = {}
  local function runKick()
      if type(ToolInfo) ~= "table" then
          return
      end
      for name, entry in pairs(ToolInfo) do
          pcall(function()
              local recoil = entry and entry.Recoil
              if type(recoil) == "table" and type(recoil.VM) == "table" then
                  local st = kickSaved[name]
                  if not st then
                      st = {}
                      kickSaved[name] = st
                  end
                  patchData(recoil, "VM", st, kickOff)
              end
          end)
      end
  end
  getgenv().kickSwitch = function(v)
      kickOff = v == true
      pcall(runKick)
  end

  local oldFlash = nil
  local flashGone = false
  getgenv().flashSwitch = function(v)
      if v == true then
          if flashGone then
              return
          end
          if type(VFXModule) ~= "table" or type(VFXModule.FlashPart) ~= "function" then
              return
          end
          local ok, orig = pcall(hookModule, VFXModule, "FlashPart", LPH_NO_UPVALUES(function(self, part)
              if ownFlash() then
                  return
              end
              return oldFlash(self, part)
          end))
          if ok and type(orig) == "function" then
              oldFlash = orig
              flashGone = true
          end
      else
          if not flashGone then
              return
          end
          if hookfunction and type(oldFlash) == "function" then
              pcall(hookfunction, VFXModule.FlashPart, oldFlash)
          else
              pcall(function()
                  if setreadonly then
                      setreadonly(VFXModule, false)
                  end
                  VFXModule.FlashPart = oldFlash
                  if setreadonly then
                      setreadonly(VFXModule, true)
                  end
              end)
          end
          oldFlash = nil
          flashGone = false
      end
  end

  task.spawn(function()
      task.wait(2)
      if bobOff then
          pcall(runBob)
      end
  end)

  pcall(function()
      Run:UnbindFromRenderStep("GunStill")
  end)
  local scanClock = 0
  local lastFix = 0
  local lastCam = 0
  local camBase = Vector3.new(0, -0.25, 0)
  Run:BindToRenderStep("GunStill", Enum.RenderPriority.Camera.Value + 3, function()
      if not bobOff and not kickOff then
          return
      end
      local stamp = os.clock()
      if bobOff then
      if not cheat.Globals.BobSpring and stamp - scanClock > 1.5 then
          scanClock = stamp
          pcall(grabSprings)
      end
      local ch = cheat.Globals.ClientCharacter or Client.Character
      local hum = ch and ch:FindFirstChildOfClass("Humanoid")
      if hum and hum.Health <= 0 then
          return
      end
      local bob = cheat.Globals.BobSpring
      if bob and typeof(bob) == "table" then
          pcall(function()
              if bob._target and bob._target ~= Vector3.zero then bob._target = Vector3.zero end
              if bob._position0 and bob._position0 ~= Vector3.zero then bob._position0 = Vector3.zero end
              if bob._velocity0 and bob._velocity0 ~= Vector3.zero then bob._velocity0 = Vector3.zero end
          end)
      end
      local springs = cheat.Globals.Springs
      if type(springs) == "table" then
          pcall(function()
              for i = 1, #springs do
                  local s = springs[i]
                  if type(s) == "table" then
                      if s._position0 and s._position0 ~= Vector3.zero then s._position0 = Vector3.zero end
                      if s._velocity0 and s._velocity0 ~= Vector3.zero then s._velocity0 = Vector3.zero end
                      if s._target and s._target ~= Vector3.zero then s._target = Vector3.zero end
                  end
              end
          end)
      end
      if stamp - lastCam > 1 then
          lastCam = stamp
          pcall(function()
              Run:UnbindFromRenderStep("HumCamOffset")
          end)
      end
      pcall(function()
          local h = Client.Character and Client.Character:FindFirstChildOfClass("Humanoid")
          if h and h.CameraOffset ~= camBase then
              h.CameraOffset = camBase
          end
      end)
          local bobFresh = cheat.Globals.BobSpring
          if bobFresh ~= nil then
              pcall(calmSpring, bobFresh)
          end
          local springList = cheat.Globals.Springs
          if type(springList) == "table" then
              for i = 1, #springList do
                  local sp = springList[i]
                  if type(sp) == "table" then
                      pcall(calmSpring, sp)
                  end
              end
          end
      end
      forGuns(function(m)
          if isFiring(m) then
              if kickOff then
                  holdStill(m)
              end
          elseif not gunBusy(m) then
              if bobOff then
                  holdStill(m)
              end
          end
      end)

      if stamp - lastFix > 2 then
          lastFix = stamp
          if bobOff then pcall(runBob) end
          if kickOff then pcall(runKick) end
      end
  end)


  if not (ItemClass and VFXModule and ItemsModule and RaycastUtil and SoundModule) then
      return
  end
  
  local clanController, clanControllerShared
  if Client:FindFirstChild("PlayerScripts") and Client.PlayerScripts:FindFirstChild("ClanController") then
      clanController = getsenv(Client.PlayerScripts:WaitForChild("ClanController"))
      clanControllerShared = clanController and clanController.shared
  else
      clanControllerShared = {cachedTeamModels = {}}
  end
  
   local isTeam = LPH_NO_VIRTUALIZE(function(player)
       if typeof(player) ~= 'Instance' or not player:IsA('Player') then return false end
       local teamCache = clanControllerShared and clanControllerShared.cachedTeamModels
       return teamCache and teamCache[player.UserId] or false
   end)
  
  local getgun = function(character)
      if not character then return "None" end
      for _, model in character:GetChildren() do
          if not model:IsA('Model') then
              continue
          end
  
          if model.Name == 'Hair' or model.Name == 'HolsterModel' then
              continue
          end
  
          if not model.PrimaryPart then
              continue
          end
  
          if model:FindFirstChild("Detail") or model:FindFirstChild("Main") or model:FindFirstChild("Handle") or model:FindFirstChild("Attachments") or model:FindFirstChild("ArrowAttach") or model:FindFirstChild("Attach") then
              return model.Name
          end;
      end;
  
      return "None"
  end
  
  local Targeting = {
      TargetPart = nil,
      TargetCharacter = nil,
      ManipulatedPosition = nil,
      ManipPos = nil,
      ScannedPosition = nil,
      HitscanPoint = nil,
      Visible = false,
      Targets = {},
  }

  cheat.targetStatus = function(part)
      if not (part and typeof(part) == "Instance" and part:IsA("BasePart") and part.Parent) then
          return nil
      end
      local rootPart = Client.Character and Client.Character.PrimaryPart
      local eyes = rootPart and (rootPart.CFrame * CFrame.new(0, 1.5, 0)).Position
      local silentActive = flags.AimbotEnabled == true and bindOn(true, "AimbotBind")
      local isVisible = false
      if typeof(eyes) == "Vector3" and type(cheat.isPartVisible) == "function" then
          local okVisible, result = pcall(cheat.isPartVisible, part, eyes)
          isVisible = okVisible and result == true
      end
      if isVisible then
          return "Visible", Color3.fromRGB(80, 255, 120), true
      end
      if silentActive and bindOn(flags.Manipulation == true, "ManipulationBind") and typeof(Targeting.ScannedPosition) == "Vector3" then
          return "Manipulated", Color3.fromRGB(170, 110, 255), true
      end
      if silentActive and bindOn(flags.Hitscan == true, "HitscanBind") and typeof(Targeting.HitscanPoint) == "Vector3" then
          return "Hitscanned", Color3.fromRGB(255, 170, 60), true
      end
      return "Unvisible", Color3.fromRGB(255, 80, 80), false
  end

  do
      local flagText = Drawing.new("Text")
      flagText.Center = true
      flagText.Outline = true
      flagText.Size = 16
      flagText.Visible = false
      Run.RenderStepped:Connect(function()
          local part = Targeting.TargetPart
          local show = flags.StatusFlags == true and flags.AimbotEnabled == true and bindOn(true, "AimbotBind")
              and part ~= nil and typeof(part) == "Instance" and part.Parent ~= nil
          if not show then
              flagText.Visible = false
              return
          end
          local okStatus, name, color, withPart = pcall(cheat.targetStatus, part)
          if not okStatus or not name then
              flagText.Visible = false
              return
          end
          local viewport = Camera.ViewportSize
          flagText.Text = withPart and ("[" .. name .. " - " .. part.Name .. "]") or ("[" .. name .. "]")
          flagText.Color = color
          flagText.Position = Vector2.new(viewport.X * 0.5, viewport.Y * 0.5 + 70)
          flagText.Visible = true
      end)
  end

  local spinStates = setmetatable({}, { __mode = "k" })
  Run.Heartbeat:Connect(function()
      if flags.SpinResolver == false then
          return
      end
      local now = os.clock()
      for _, player in ipairs(Players:GetPlayers()) do
          local character = player ~= Players.LocalPlayer and player.Character
          local root = character and character:FindFirstChild("HumanoidRootPart")
          if root then
              local _, yaw = root.CFrame:ToOrientation()
              local state = spinStates[root]
              if not state then
                  spinStates[root] = { yaw = yaw, t = now, rate = 0, jumps = 0, lastJump = 0 }
              else
                  local elapsed = now - state.t
                  if elapsed > 0 then
                      local delta = (yaw - state.yaw + math.pi) % (2 * math.pi) - math.pi
                      local rate = math.abs(delta) / elapsed
                      state.rate = state.rate * 0.85 + rate * 0.15
                      if math.abs(delta) > math.rad(45) then
                          state.jumps = math.min(state.jumps + 1, 10)
                          state.lastJump = now
                      elseif now - state.lastJump > 0.6 then
                          state.jumps = 0
                      end
                  end
                  state.yaw, state.t = yaw, now
              end
          end
      end
  end)

  local function resolveAimPoint(part, humanoid)
      local pos = part.Position
      if flags.SpinResolver == false then
          return pos, false
      end
      local root = humanoid and humanoid.RootPart
      local state = root and spinStates[root]
      if not state then
          return pos, false
      end
      local angular = math.abs(root.AssemblyAngularVelocity.Y)
      local spinning = state.rate > 5 or angular > 5 or state.jumps >= 2
      if not spinning then
          return pos, false
      end
      local rootPos = root.Position
      return Vector3.new(rootPos.X, pos.Y, rootPos.Z), true
  end
  cheat.resolveAimPoint = resolveAimPoint

  local predictPos = LPH_NO_VIRTUALIZE(function(part, humanoid, gravity, speed, leadTime)
      local pos = resolveAimPoint(part, humanoid)
      if not (humanoid and humanoid.Parent) or speed <= 0 then
          return pos
      end
      local velocity = humanoid.RootPart and humanoid.RootPart.AssemblyLinearVelocity
      if typeof(velocity) ~= "Vector3" then
          velocity = part.AssemblyLinearVelocity
      end
      if typeof(velocity) ~= "Vector3" then
          return pos
      end
      local spoofed = velocity.Y ~= velocity.Y or velocity.X ~= velocity.X or velocity.Y < -100
          or math.abs(velocity.X) > 1000 or math.abs(velocity.Z) > 1000
      if spoofed and flags.VelocityResolver ~= false then
          velocity = humanoid:GetMoveVelocity() * 1.7
      elseif humanoid:GetState() == Enum.HumanoidStateType.Freefall
          or (humanoid.MoveDirection.Magnitude > 0.05
              and (humanoid.RootPart and (humanoid.RootPart.AssemblyLinearVelocity * Vector3.new(1, 0, 1)).Magnitude or 0) < 1) then
          velocity = humanoid.MoveDirection * humanoid.WalkSpeed * 1.7
      end
      local leadX = math.clamp(velocity.X, -26, 26)
      local leadZ = math.clamp(velocity.Z, -26, 26)
      local camPos = Camera.CFrame.Position
      local flyTime = (camPos - pos).Magnitude / speed
      local lead = Vector3.new(leadX, 0, leadZ) * (leadTime or flyTime)
      local drop = 0.5 * 196.2 * gravity * flyTime * flyTime
      if drop ~= drop then
          drop = 0
      end
      return pos + lead + Vector3.new(0, drop, 0)
  end)

  local resolver_state = {
      Desync = {
          State = {},
          Resolved = {},
      },
      DesyncedPositions = {},
      Pitch = {},
  }
  local function get_player_pitch_resolved(player, head)
      if flags.PitchResolver ~= true then
          return nil
      end
      if not (head and head:IsA("BasePart")) then
          return nil
      end
      local ly = head.CFrame.LookVector.Y
      if ly > 0.3 then
          return "up"
      elseif ly < -0.3 then
          return "down"
      end
      return "neutral"
  end
  local function update_desync_resolver()
      local State = resolver_state.Desync.State
      local Resolved = resolver_state.Desync.Resolved
      local DesyncedPositions = resolver_state.DesyncedPositions
      if flags.DesyncResolver ~= true then
          for k in pairs(DesyncedPositions) do
              DesyncedPositions[k] = nil
          end
          for k in pairs(State) do
              State[k] = nil
          end
          for k in pairs(Resolved) do
              Resolved[k] = nil
          end
          return
      end
      local now = os.clock()
      for _, player in ipairs(Players:GetPlayers()) do
          if player ~= Client then
              local character = player.Character
              local root = character and character:FindFirstChild("HumanoidRootPart")
              if not root then
                  State[player] = nil
                  Resolved[player] = nil
                  if character then DesyncedPositions[character] = nil end
              else
                  local player_state = State[player]
                  local raw = root.Position
                  if not player_state or player_state.Character ~= character then
                      State[player] = {
                          Character = character,
                          LastRaw = raw,
                          LastGood = raw,
                          LastDesync = nil,
                          SpikeCount = 0,
                          LastSpikeTime = 0,
                          HoldUntil = 0,
                          IgnoreUntil = now + 1.2,
                      }
                      Resolved[player] = raw
                      DesyncedPositions[character] = nil
                  else
                      local distance = (raw - player_state.LastRaw).Magnitude
                      if now < player_state.IgnoreUntil or distance > 60 then
                          player_state.LastRaw = raw
                          player_state.LastGood = raw
                          player_state.SpikeCount = 0
                          player_state.LastDesync = nil
                          player_state.HoldUntil = 0
                          Resolved[player] = raw
                          DesyncedPositions[character] = nil
                      else
                          if distance > 14 then
                              local chain_distance = player_state.LastDesync
                                  and (raw - player_state.LastDesync).Magnitude
                                  or distance
                              if chain_distance > 6 then
                                  if (now - player_state.LastSpikeTime) <= 0.45 then
                                      player_state.SpikeCount = player_state.SpikeCount + 1
                                  else
                                      player_state.SpikeCount = 1
                                  end
                                  player_state.LastSpikeTime = now
                                  player_state.LastDesync = raw
                                  if player_state.SpikeCount >= 3 then
                                      player_state.HoldUntil = now + 0.9
                                  end
                              end
                          else
                              player_state.SpikeCount = 0
                              player_state.LastDesync = nil
                              player_state.LastGood = raw
                          end
                          player_state.LastRaw = raw
                          local current = Resolved[player]
                          if now < player_state.HoldUntil and current then
                              Resolved[player] = current:Lerp(player_state.LastGood, 0.35)
                          else
                              Resolved[player] = current and current:Lerp(raw, 0.35) or raw
                          end
                          DesyncedPositions[character] = Resolved[player]
                      end
                  end
              end
          end
      end
  end
  local desync_beat = nil
  do
      local conn
      local undergroundCheck = 0
      conn = Run.Heartbeat:Connect(function()
          pcall(update_desync_resolver)
          if flags.UndergroundResolver == true and os.clock() - undergroundCheck > 0.15 then
              undergroundCheck = os.clock()
              for _, player in ipairs(Players:GetPlayers()) do
                  local character = player ~= Players.LocalPlayer and player.Character
                  local humanoid = character and character:FindFirstChildOfClass("Humanoid")
                  local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
                  if animator then
                      for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
                          if track.Animation and track.Animation.AnimationId == "rbxassetid://13435049596" then
                              track:Stop(0)
                          end
                      end
                  end
              end
          end
      end)
      desync_beat = conn
  end
  Players.PlayerRemoving:Connect(function(p)
      resolver_state.Desync.State[p] = nil
      resolver_state.Desync.Resolved[p] = nil
      resolver_state.Pitch[p] = nil
  end)
  
  do
      local wrapped = {}

      local function field(t, k)
          local ok, v = pcall(function()
              return t[k]
          end)
          if ok then
              return v
          end
          return nil
      end

      local shake_store = {}
      local vm_store = {}

      local function scale_ab(a, b, s)
          if type(a) == "number" then
              a = a * s
          elseif typeof(a) == "Vector2" then
              a = a * s
          end
          if type(b) == "number" then
              b = b * s
          elseif typeof(b) == "Vector2" then
              b = b * s
          end
          return a, b
      end

      local function apply_shake(cam, on)
          local sh = field(cam, "Shake")
          if type(sh) ~= "table" then
              return
          end
          if not shake_store[cam] then
              shake_store[cam] = { X = sh.X, Y = sh.Y }
          end
          local st = shake_store[cam]
          if on then
              sh.X = { 0, 0 }
              sh.Y = { 0, 0 }
          else
              sh.X = st.X
              sh.Y = st.Y
          end
      end

      local function apply_vm(vm, on)
          if type(vm) ~= "table" then
              return
          end
          if not vm_store[vm] then
              vm_store[vm] = { StartTime = field(vm, "StartTime"), EndTime = field(vm, "EndTime") }
          end
          local st = vm_store[vm]
          if setreadonly then
              pcall(setreadonly, vm, false)
          end
          if on then
              vm.StartTime = 0
              vm.EndTime = 0
          else
              if st.StartTime ~= nil then
                  vm.StartTime = st.StartTime
              end
              if st.EndTime ~= nil then
                  vm.EndTime = st.EndTime
              end
          end
      end

      local function wrap_recoil(cam)
          if type(cam) ~= "table" or wrapped[cam] then
              return
          end
          local rs = field(cam, "RecoilStart")
          local rf = field(cam, "RecoilFinish")
          if type(rs) ~= "function" or type(rf) ~= "function" then
              return
          end
          wrapped[cam] = true
          if setreadonly then
              pcall(setreadonly, cam, false)
          end
          cam.RecoilStart = function(...)
              local a, b = rs(...)
              local on = isRemoved("No Recoil") == true
              apply_shake(cam, on)
              if on then
                  return scale_ab(a, b, 0)
              end
              return a, b
          end
          cam.RecoilFinish = function(...)
              local a, b = rf(...)
              local on = isRemoved("No Recoil") == true
              if on then
                  return scale_ab(a, b, 0)
              end
              return a, b
          end
      end

      local function scan_recoil()
          if type(ToolInfo) ~= "table" then
              return 0
          end
          local n = 0
          local function walk(t, d)
              if type(t) ~= "table" or d > 4 then
                  return
              end
              local a = field(t, "RecoilStart")
              local b = field(t, "RecoilFinish")
              if type(a) == "function" and type(b) == "function" then
                  wrap_recoil(t)
                  n = n + 1
              end
              if type(field(t, "StartTime")) == "number" and type(field(t, "Pos")) == "table" and type(field(t, "Rot")) == "table" then
                  apply_vm(t, isRemoved("No Recoil") == true)
              end
              for _, v in pairs(t) do
                  if type(v) == "table" then
                      walk(v, d + 1)
                  end
              end
          end
          walk(ToolInfo, 0)
          return n
      end

      scan_recoil()
      task.spawn(function()
          task.wait(2)
          scan_recoil()
      end)

      local oldAttachmentStats
      oldAttachmentStats = hookModule(ItemClass, "AttachmentStats", LPH_NO_UPVALUES(function(v50, v51)
          local r = oldAttachmentStats(v50, v51)

          local vm = false
          if getcallingscript then
              local s = getcallingscript()
              vm = s and s.Name == "ViewmodelController"
          else
              local tb = debug.traceback()
              vm = tb and tb:find("ViewmodelController", 1, true) ~= nil
          end
          if vm and r then
              if table.isfrozen and table.isfrozen(r) then
                  r = table.clone(r)
              end

              if flags["RPM"] then
                  r.FireRateMult = flags["RapidFireRate"] - 1
              end

              if isRemoved("No Spread") then
                  r.AimSpreadMult = -1
                  r.HipSpreadMult = -1
              end

              if isRemoved("No Sway") or bobOff then
                  r.SwayMult = -1
              end
          end

          return r
      end))

      local ea_store = {}

      local function writable(t)
          if type(t) ~= "table" then
              return false
          end
          if setreadonly then
              pcall(setreadonly, t, false)
              return true
          end
          if table.isfrozen and table.isfrozen(t) then
              return false
          end
          return true
      end

      local function ensure_clone(entry)
          if type(entry) ~= "table" then
              return nil
          end
          local w = entry.Weapon
          if type(w) ~= "table" then
              return nil
          end
          if writable(w) then
              return w
          end
          if not table.clone then
              return nil
          end
          local nw = table.clone(w)
          if setreadonly then
              pcall(setreadonly, entry, false)
          end
          local ok = pcall(function()
              entry.Weapon = nw
          end)
          if not ok then
              return nil
          end
          return nw
      end

      apply_equip_aim = function()
          if type(ToolInfo) ~= "table" then
              return
          end
          local on_eq = flags.InstantEquip == true
          local on_aim = flags.InstantADS == true
          for name, entry in pairs(ToolInfo) do
              pcall(function()
                  local w = ensure_clone(entry)
                  if not w then
                      return
                  end
                  local ads = w.AimDownSpeed
                  if type(ads) == "table" and not writable(ads) and table.clone then
                      w.AimDownSpeed = table.clone(ads)
                      ads = w.AimDownSpeed
                  end
                  local st = ea_store[name]
                  if not st then
                      st = {}
                      ea_store[name] = st
                  end
                  local ea = w.EquipAnimSpeed
                  if ea ~= nil then
                      if type(ea) == "table" then
                          if st.equip_tbl == nil then
                              st.equip_tbl = {}
                              for sk, sv in pairs(ea) do
                                  st.equip_tbl[sk] = sv
                              end
                          end
                          if on_eq then
                              for sk in pairs(ea) do
                                  ea[sk] = 8
                              end
                              ea.Default = 8
                          else
                              for sk, sv in pairs(st.equip_tbl) do
                                  ea[sk] = sv
                              end
                          end
                      else
                          if st.equip == nil then
                              st.equip = ea
                          end
                      if on_eq then
                          w.EquipAnimSpeed = on_eq and 8
                      else
                          w.EquipAnimSpeed = st.equip
                      end
                      end
                  end
                  if type(ads) == "table" then
                      if st.aim_in == nil then
                          st.aim_in = ads.In
                      end
                      if st.aim_out == nil then
                          st.aim_out = ads.Out
                      end
                      if on_aim then
                          w.AimDownSpeed.In = 0
                          w.AimDownSpeed.Out = 0
                      else
                          if st.aim_in ~= nil then
                              w.AimDownSpeed.In = st.aim_in
                          end
                          if st.aim_out ~= nil then
                              w.AimDownSpeed.Out = st.aim_out
                          end
                      end
                  end
                  if w.IsBow ~= nil then
                      if st.bow == nil then
                          st.bow = w.IsBow
                      end
                  end
              end)
          end
      end

      apply_equip_aim()
      task.spawn(function()
          task.wait(2)
          apply_equip_aim()
      end)

  
  end

          local getArmor = LPH_NO_VIRTUALIZE(function(Character)
              local final = {}
              local names = {}
              if not Character then return {} end
              if type(Character) == 'string' then
                  return {}
              end
              for _, child in Character:GetChildren() do
                  local armorNumber, skinName = child.Name:match('Armor_(%d+)/(.*)')
  
                  if armorNumber then
                      local key = tonumber(armorNumber)
                      if key then
                          local item = ItemsModule[key]
                          if item and item.Type == 'Armor' and not table.find(names, item.Name) then
                              local image = ''
                              if type(item.Image) == 'table' then
                                  if skinName and item.Image[skinName] then
                                      image = item.Image[skinName]
                                  elseif item.Image.Default then
                                      image = item.Image.Default
                                  end
                              elseif type(item.Image) == 'string' then
                                  image = item.Image
                              end
  
                              local id = string.match(image or '', '%d+')
                              local imageData = ''
  
                              table.insert(names, item.Name)
                              table.insert(final, {
                                  ['Skin'] = skinName,
                                  ['Name'] = item.Name,
                                  ['Type'] = item.ArmorType,
                                  ['Image'] = id
                              })
                          end
                      end
                  end
              end
  
              return final
          end)



  local cham_skip = {
      ["humanoidrootpart"] = true,
      ["ignoreme"] = true,
      ["facehitbox"] = true,
      ["headtophitbox"] = true,
  }

  local function isBodyPart(inst)
      if not (inst and inst:IsA("BasePart")) then
          return false
      end
      if inst:GetAttribute("IgnoreChams") == true then
          return false
      end
      local nm = string.lower(inst.Name or "")
      if cham_skip[nm] then
          return false
      end
      if nm:find("lagcham", 1, true) or nm:find("fakecham", 1, true) then
          return false
      end
      return true
  end

  local function clearChams(entry)
      entry.chams_hlmode = false
      entry.chams_miss = nil
      entry.chams_rebuilds = nil
      local hl = entry.chams_hl
      if hl then
          hl:Destroy()
          entry.chams_hl = nil
      end
      if not entry.chams_conns and not entry.chams_model and (entry.adornments == nil or next(entry.adornments) == nil) then
          return
      end
      if entry.chams_conns then
          for _, c in ipairs(entry.chams_conns) do
              if c then c:Disconnect() end
          end
          entry.chams_conns = nil
      end
      entry.chams_model = nil
      if entry.adornments then
          for _, pair in pairs(entry.adornments) do
              for _, a in ipairs(pair) do
                  if a and a.Parent then a:Destroy() end
              end
          end
          entry.adornments = {}
      end
  end

  local function applyWorldChams(entry, obj, mainColor, mainTrans, glowColor)
      if not obj or not obj.Parent then
          clearChams(entry)
          return
      end
      local hl = entry.chams_hl
      if hl and hl.Parent ~= obj then
          hl:Destroy()
          hl = nil
      end
      if not hl then
          hl = Instance.new("Highlight")
          hl.Name = "chamhl"
          hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
          hl.Parent = obj
          entry.chams_hl = hl
      end
      hl.FillColor = mainColor
      hl.FillTransparency = mainTrans
      hl.OutlineColor = glowColor
      hl.OutlineTransparency = 0
  end

  local function ensureAdorns(entry, part, glowColor, mainColor, mainTrans)
      local pair = entry.adornments[part]
      local glow = pair and pair[1]
      local main = pair and pair[2]

      if typeof(glow) ~= "Instance" or glow.Parent ~= part then
          glow = Instance.new("BoxHandleAdornment")
          glow.Name = "chamglow"
          glow.AlwaysOnTop = true
          glow.ZIndex = (part.Name == "Head" or part.Name == "FakeHead") and 10 or 9
          glow.Adornee = part
          glow.Size = part.Size + Vector3.new(0.03, 0.03, 0.03)
          glow.Color3 = glowColor
          glow.Transparency = -1
          glow.Visible = true
          pcall(function() glow.Shading = Enum.AdornShading.XRayShaded end)
          glow.Parent = part
      end
      if typeof(main) ~= "Instance" or main.Parent ~= part then
          main = Instance.new("BoxHandleAdornment")
          main.Name = "chammain"
          main.AlwaysOnTop = true
          main.ZIndex = 10
          main.Adornee = part
          main.Size = part.Size + Vector3.new(0.02, 0.02, 0.02)
          main.Color3 = mainColor
          main.Transparency = mainTrans
          main.Visible = true
          main.Parent = part
      end
      glow.Color3 = glowColor
      glow.Transparency = -1
      glow.Size = part.Size + Vector3.new(0.03, 0.03, 0.03)
      glow.Visible = true
      main.Color3 = mainColor
      main.Transparency = mainTrans
      main.Size = part.Size + Vector3.new(0.02, 0.02, 0.02)
      main.Visible = true
      pcall(function() glow.Shading = Enum.AdornShading.XRayShaded end)

      entry.adornments[part] = { glow, main }
  end

  local function applyChams(entry, model, mainColor, mainTrans, glowColor)
      if not model or not model.Parent then
          clearChams(entry)
          return
      end
      if entry.chams_hlmode then
          local hl = entry.chams_hl
          if hl and hl.Parent ~= model then
              hl:Destroy()
              hl = nil
          end
          if not hl then
              clearChams(entry)
              hl = Instance.new("Highlight")
              hl.Name = "chamhl"
              hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
              hl.Parent = model
              entry.chams_hl = hl
          end
          hl.FillColor = mainColor
          hl.FillTransparency = mainTrans
          hl.OutlineColor = glowColor
          hl.OutlineTransparency = 0
          return
      end
      entry.adornments = entry.adornments or {}
      local glowHot = Color3.new(glowColor.R * 5, glowColor.G * 5, glowColor.B * 5)

      if entry.chams_model ~= model then
          clearChams(entry)
          entry.chams_model = model
          if model:IsA("Model") then
              entry.chams_conns = {
                  model.DescendantAdded:Connect(function(d)
                      if isBodyPart(d) then
                          pcall(ensureAdorns, entry, d, glowHot, mainColor, mainTrans)
                      end
                  end),
                  model.DescendantRemoving:Connect(function(d)
                      local pair = entry.adornments[d]
                      if pair then
                          for _, a in ipairs(pair) do
                              if a and a.Parent then a:Destroy() end
                          end
                          entry.adornments[d] = nil
                      end
                  end),
              }
          end
      end

      if model:IsA("BasePart") then
          pcall(ensureAdorns, entry, model, glowHot, mainColor, mainTrans)
      else
          for _, d in ipairs(model:GetDescendants()) do
              if isBodyPart(d) then
                  pcall(ensureAdorns, entry, d, glowHot, mainColor, mainTrans)
              end
          end
      end

      for part, pair in pairs(entry.adornments) do
          if not part.Parent or not part:IsDescendantOf(model) then
              for _, a in ipairs(pair) do
                  if a and a.Parent then a:Destroy() end
              end
              entry.adornments[part] = nil
          end
      end

      local eligible = 0
      for _, d in ipairs(model:GetDescendants()) do
          if isBodyPart(d) then
              eligible = eligible + 1
          end
      end
      if eligible == 0 then
          return
      end
      local have = 0
      for part, pair in pairs(entry.adornments) do
          if part.Parent and pair[1] and pair[1].Parent then
              have = have + 1
          end
      end
      if have >= eligible then
          entry.chams_miss = nil
          entry.chams_rebuilds = nil
          return
      end
      entry.chams_miss = (entry.chams_miss or 0) + 1
      if entry.chams_miss < 15 then
          return
      end
      entry.chams_miss = 0
      local rb = entry.chams_rebuilds or 0
      clearChams(entry)
      entry.chams_model = nil
      if rb >= 3 then
          entry.chams_hlmode = true
      else
          entry.chams_rebuilds = rb + 1
      end
  end

  do
      do
          local ESP = {}

          local function getTracks(char)
              local hum = char and char:FindFirstChildOfClass('Humanoid')
              if not hum then
                  return {}
              end
              local ok, tracks = pcall(function()
                  return hum:GetPlayingAnimationTracks()
              end)
              if ok and type(tracks) == "table" then
                  return tracks
              end
              return {}
          end
  
          local ScreenGui = Instance.new('ScreenGui')
          ScreenGui.IgnoreGuiInset = true
          ScreenGui.Parent = gethui()
  
          local OUTLINE = 1
          local BOX_THICKNESS = 2
          local NAME_PADDING_X = 6
          local NAME_PADDING_Y = 2
  
          local function BoxMath(item, fallbackPosition)
              local cf, pos
              local Torso = item and (
                  item:FindFirstChild('HumanoidRootPart')
                  or item:FindFirstChild('UpperTorso')
                  or item:FindFirstChild('Torso')
                  or item:FindFirstChild('Head')
                  or item:FindFirstChildWhichIsA('BasePart'))
              if Torso then
                  cf = Torso.CFrame
                  pos = Torso.Position
              elseif fallbackPosition then
                  cf = CFrame.new(fallbackPosition)
                  pos = fallbackPosition
              else
                  return nil, nil, false
              end
              local vTop = pos + (cf.UpVector * 2)
              local vBottom = pos - (cf.UpVector * 2.8)
              local top, topVisible = Camera:WorldToViewportPoint(vTop)
              local bottom, bottomVisible = Camera:WorldToViewportPoint(vBottom)
              if not topVisible and not bottomVisible then return nil, nil, false end
              local height = math.abs(bottom.Y - top.Y)
              if height <= 0 then return nil, nil, false end
              if height < 14 then
                  local dist = (Camera.CFrame.Position - pos).Magnitude
                  local zoom = math.clamp(dist / 250, 0, 1) * 2.2
                  height = height * (1 + zoom)
                  if height < 12 then
                      height = 12
                  end
              end
              local width = height / 1.2
              return Vector2.new(
                  math.floor((top.X + bottom.X) * 0.5 - width * 0.5),
                  math.min(top.Y, bottom.Y)
              ), Vector2.new(width, height), true
          end
  
          local function createBox(parent, color)
              local box = Instance.new('Frame')
              box.BackgroundTransparency = 1
              box.Parent = parent
              local sides = {}
              for i = 1, 4 do
                  local f = Instance.new('Frame')
                  f.BorderSizePixel = 0
                  f.BackgroundColor3 = color
                  f.Parent = box
                  sides[i] = f
              end
              return box, sides
          end
  
          local function newText()
              local t = Instance.new('TextLabel')
              t.BackgroundTransparency = 1
              t.TextColor3 = Color3.new(1,1,1)
              t.TextTransparency = 0
              t.TextStrokeColor3 = Color3.new(0,0,0)
              t.TextStrokeTransparency = 0
              t.FontFace = Library.Font
              t.TextSize = 11
              t.TextXAlignment = Enum.TextXAlignment.Center
              t.TextYAlignment = Enum.TextYAlignment.Center
              return t
          end
  
          local function createESP(subject, name, classname)
              local holder = Instance.new('Frame')
              holder.BackgroundTransparency = 1
              holder.Visible = false
              holder.Parent = ScreenGui
  
              local nameText = newText()
              nameText.Text = name
              nameText.Parent = holder
  
              local boxGroup = Instance.new('Frame')
              boxGroup.BackgroundTransparency = 1
              boxGroup.Parent = holder
  
              local outerBox, outerSides = createBox(boxGroup, Color3.new(0,0,0))
              local gradBox, gradSides = createBox(boxGroup, Color3.new(1,1,1))
              local innerBox, innerSides = createBox(boxGroup, Color3.new(0,0,0))
  
              local gradients = {}
              for i = 1, 4 do
                  local g = Instance.new('UIGradient')
                  g.Rotation = 90
                  g.Parent = gradSides[i]
                  gradients[i] = g
              end
  
              local healthBack = Instance.new('Frame')
              healthBack.BackgroundTransparency = 1
              healthBack.BorderSizePixel = 0
              healthBack.Parent = holder
  
              local healthOutline = Instance.new('Frame')
              healthOutline.BackgroundColor3 = Color3.new(0,0,0)
              healthOutline.BorderSizePixel = 0
              healthOutline.Parent = healthBack
  
              local healthInner = Instance.new('Frame')
              healthInner.BackgroundColor3 = Color3.fromRGB(35,35,35)
              healthInner.BorderSizePixel = 0
              healthInner.Parent = healthBack
  
              local healthFillHolder = Instance.new('Frame')
              healthFillHolder.BackgroundTransparency = 1
              healthFillHolder.BorderSizePixel = 0
              healthFillHolder.ClipsDescendants = true
              healthFillHolder.Parent = healthInner
  
              local healthFill = Instance.new('Frame')
              healthFill.BorderSizePixel = 0
              healthFill.AnchorPoint = Vector2.new(0,1)
              healthFill.Position = UDim2.fromScale(0,1)
              healthFill.Size = UDim2.fromScale(1,1)
              healthFill.BackgroundColor3 = Color3.new(1,1,1)
              healthFill.Parent = healthFillHolder
  
              local healthGradient = Instance.new('UIGradient')
              healthGradient.Rotation = 90
              healthGradient.Parent = healthFill
  
              local distText = newText()
              distText.Parent = holder
  
              local weaponText = newText()
              weaponText.Text = '[None]'
              weaponText.Parent = holder
  
              local flagText = newText()
              flagText.Parent = holder

              ESP[subject] = {
                  chams_model = nil,
                  chams_conns = nil,
                  adornments = {},
                  Holder = holder,
                  Name = nameText,
                  BoxGroup = boxGroup,
                  OuterBox = outerBox,
                  OuterSides = outerSides,
                  GradBox = gradBox,
                  GradSides = gradSides,
                  Gradients = gradients,
                  InnerBox = innerBox,
                  InnerSides = innerSides,
                  HealthBack = healthBack,
                  HealthOutline = healthOutline,
                  HealthInner = healthInner,
                  HealthFillHolder = healthFillHolder,
                  HealthFill = healthFill,
                  HealthGradient = healthGradient,
                  Distance = distText,
                  Weapon = weaponText,
                  Flags = flagText,
                  Class = classname,
              }
          end
  
          local function sizeSides(sides, w, h, t)
              sides[1].Position = UDim2.fromOffset(0,0)
              sides[1].Size = UDim2.fromOffset(w, t)
              sides[2].Position = UDim2.fromOffset(0, h - t)
              sides[2].Size = UDim2.fromOffset(w, t)
              sides[3].Position = UDim2.fromOffset(0,0)
              sides[3].Size = UDim2.fromOffset(t, h)
              sides[4].Position = UDim2.fromOffset(w - t,0)
              sides[4].Size = UDim2.fromOffset(t, h)
          end
  
          Run.RenderStepped:Connect(function()
              for subject, e in pairs(ESP) do
                  local class = e.Class
                  if not subject.Parent then
                      e.Holder:Destroy()
                      clearChams(e)
                      ESP[subject] = nil
                      continue
                  end
                  local char = subject
                  local infiniteRange = flags.EspInfiniteRange == true
                  if class == 'Players' then
                      char = subject.Character
                      if not char or not char.Parent then
                          local named = workspace:FindFirstChild(subject.Name)
                          if named and named:IsA('Model') and named:FindFirstChildOfClass('Humanoid') then
                              char = named
                          end
                      end
                      if not char or not char.Parent then
                          if not (infiniteRange and e.LastPosition and flags[class .. 'ESPEnabled']) then
                              e.Holder.Visible = false
                              clearChams(e)
                              continue
                          end
                          char = nil
                      end
                  end
                  if not flags[class .. 'ESPEnabled'] then
                      e.Holder.Visible = false
                      clearChams(e)
                      continue
                  end
  
                  local hum = char and char:FindFirstChildOfClass('Humanoid')
                  if (char and not hum and class ~= 'Players') or (hum and hum.Health <= 0) then
                      e.Holder.Visible = false
                      e.LastPosition = nil
                      clearChams(e)
                      continue
                  end
                  local rootPart = char and (char:FindFirstChild('HumanoidRootPart') or char:FindFirstChildWhichIsA('BasePart'))
                  if rootPart then
                      e.LastPosition = rootPart.Position
                  elseif not infiniteRange or not e.LastPosition then
                      e.Holder.Visible = false
                      clearChams(e)
                      continue
                  end

                  if char and class == 'Players' and flags[class .. 'Chams'] then
                      local c1 = flags[class .. 'ChamsColor1']
                      local c2 = flags[class .. 'ChamsColor2']
                      local a1 = c1 and c1.Alpha
                      applyChams(e, char, c1 and c1.Color or Color3.new(1, 1, 1), type(a1) == "number" and a1 or 0.5, c2 and c2.Color or Color3.new(1, 1, 1))
                  else
                      clearChams(e)
                  end
  
                  local pos, size, ok = BoxMath(char, e.LastPosition)
                  if not ok then
                      e.Holder.Visible = false
                      continue
                  end
                  local distance = (Camera.CFrame.Position - e.LastPosition).Magnitude
                  if not infiniteRange and distance > flags[class .. 'MaxDistance'] then
                      e.Holder.Visible = false
                      continue
                  end
                  if flags.EspHideBehind == true then
                      local myroot = cheat.Globals.ClientCharacter
                      myroot = myroot and (myroot.PrimaryPart or myroot:FindFirstChild('HumanoidRootPart'))
                      local eyes = myroot and (myroot.CFrame * CFrame.new(0, 1.5, 0)).Position
                      if eyes and not clearLos(eyes, e.LastPosition) then
                          e.Holder.Visible = false
                          continue
                      end
                  end
  
                  local barW = 4
                  local gap = 4
                  local reservedLeft = barW + gap + OUTLINE
  
                  e.Holder.Position = UDim2.fromOffset(pos.X - reservedLeft, pos.Y)
                  e.Holder.Visible = true
  
                  e.BoxGroup.Position = UDim2.fromOffset(reservedLeft, 0)
                  e.BoxGroup.Size = UDim2.fromOffset(size.X, size.Y)
  
                  e.Name.Position = UDim2.fromOffset(reservedLeft - NAME_PADDING_X, -15 - NAME_PADDING_Y)
                  e.Name.Size = UDim2.fromOffset(size.X + NAME_PADDING_X*2, 14 + NAME_PADDING_Y*2)
                  e.Name.Visible = flags[class .. 'Names']
                  e.Name.TextColor3 = flags[class .. 'NameColor'].Color
  
                  e.OuterBox.Position = UDim2.fromOffset(-OUTLINE, -OUTLINE)
                  e.OuterBox.Size = UDim2.fromOffset(size.X + OUTLINE*2, size.Y + OUTLINE*2)
                  sizeSides(e.OuterSides, size.X + OUTLINE*2, size.Y + OUTLINE*2, OUTLINE)
  
                  e.GradBox.Position = UDim2.fromOffset(0,0)
                  e.GradBox.Size = UDim2.fromOffset(size.X, size.Y)
                  sizeSides(e.GradSides, size.X, size.Y, BOX_THICKNESS)
  
                  e.InnerBox.Position = UDim2.fromOffset(OUTLINE, OUTLINE)
                  e.InnerBox.Size = UDim2.fromOffset(size.X - OUTLINE*2, size.Y - OUTLINE*2)
                  sizeSides(e.InnerSides, size.X - OUTLINE*2, size.Y - OUTLINE*2, OUTLINE)

                  local on = flags[class .. 'Boxes']
                  e.OuterBox.Visible = on
                  e.GradBox.Visible = on
                  e.InnerBox.Visible = on

                  for _, g in ipairs(e.Gradients) do
                      g.Color = ColorSequence.new({
                          ColorSequenceKeypoint.new(0, flags[class .. 'BoxColor1'].Color),
                          ColorSequenceKeypoint.new(1, flags[class .. 'BoxColor2'].Color),
                      })
                  end
  
                  e.HealthBack.Visible = flags[class .. 'Health']
                  e.HealthBack.Position = UDim2.fromOffset(reservedLeft - barW - gap, 0)
                  e.HealthBack.Size = UDim2.fromOffset(barW, size.Y)
  
                  e.HealthOutline.Position = UDim2.fromOffset(0,0)
                  e.HealthOutline.Size = UDim2.fromOffset(barW, size.Y)
  
                  e.HealthInner.Position = UDim2.fromOffset(1,1)
                  e.HealthInner.Size = UDim2.fromOffset(barW - 2, size.Y - 2)
  
                  e.HealthFillHolder.Position = UDim2.fromOffset(0,0)
                  e.HealthFillHolder.Size = UDim2.fromScale(1,1)
  
                  local hp = hum and math.clamp(hum.Health / math.max(hum.MaxHealth, 1), 0, 1) or 1
                  e.HealthFill.Size = UDim2.fromScale(1, hp)
  
                  e.HealthGradient.Color = ColorSequence.new({
                      ColorSequenceKeypoint.new(0, flags[class .. 'HealthColor1'].Color),
                      ColorSequenceKeypoint.new(0.5, flags[class .. 'HealthColor2'].Color),
                      ColorSequenceKeypoint.new(1, flags[class .. 'HealthColor3'].Color),
                  })
  
                  e.Distance.Position = UDim2.fromOffset(reservedLeft, size.Y + 6)
                  e.Distance.Size = UDim2.fromOffset(size.X, 14)
                  e.Distance.Visible = flags[class .. 'Distance']
                  e.Distance.Text = math.floor(distance) .. ' studs'
                  e.Distance.TextColor3 = flags[class .. 'DistanceColor'].Color
  
                  e.Weapon.Position = UDim2.fromOffset(reservedLeft, size.Y + 20)
                  e.Weapon.Size = UDim2.fromOffset(size.X, 14)
                  e.Weapon.Visible = flags[class .. 'Weapon']
                  e.Weapon.Text = char and `[{getgun(char)}]` or '[?]'
                  e.Weapon.TextColor3 = flags[class .. 'WeaponColor'].Color

                  if char and class == 'Players' and flags.PlayersFlags == true then
                      local picked = flags.PlayersFlagsList
                      local has = type(picked) == "table" and #picked > 0
                      if has then
                          local tags = {}
                          local tag_cols = {}
                          local tool = getgun(char)
                          local hum = char:FindFirstChildOfClass('Humanoid')
                          local root = hum and hum.RootPart or char:FindFirstChild('HumanoidRootPart')
                          for _, tag in ipairs(picked) do
                              local on = false
                              if tag == "Aiming" then
                                  if root then
                                      local wep = tool ~= "None" and root:FindFirstChild(tool) or nil
                                      if root:FindFirstChild('Wooden BowDraw') or root:FindFirstChild(tool .. 'Scope') or root:FindFirstChild('Scope') then
                                          on = true
                                      end
                                      if not on then
                                          for _, track in ipairs(getTracks(char)) do
                                              local n = track.Animation and track.Animation.AnimationId
                                              if n == "rbxassetid://10982316984" then
                                                  on = true
                                                  break
                                              end
                                          end
                                      end
                                  end
                              elseif tag == "Reloading" then
                                  if root and tool ~= "None" then
                                      local mi, mo
                                      if tool == "Crossbow" then
                                          mi = root:FindFirstChild('CrossbowPlaceArrow')
                                          mo = root:FindFirstChild('CrossbowPull')
                                      else
                                          mi = root:FindFirstChild(tool .. 'MagIn')
                                          mo = root:FindFirstChild(tool .. 'MagOut')
                                      end
                                      on = (mi and mi.IsPlaying) or (mo and mo.IsPlaying) == true
                                  end
                              elseif tag == "Healing" then
                                  for _, track in ipairs(getTracks(char)) do
                                      local n = track.Animation and track.Animation.AnimationId
                                      if n == "rbxassetid://14860445359" or n == "rbxassetid://2529243689" then
                                          on = true
                                          break
                                      end
                                  end
                              end
                              if on then
                                  tags[#tags + 1] = "[" .. string.upper(tag) .. "]"
                                  tag_cols[tag] = flags['PlayersFlagCol' .. tag]
                              end
                          end
                          if #tags > 0 then
                              e.Flags.Visible = true
                              e.Flags.Text = table.concat(tags, ' | ')
                              local fc = tag_cols[tags[1]]
                              e.Flags.TextColor3 = (fc and fc.Color) or flags.PlayersFlagsColor.Color
                              e.Flags.Position = UDim2.fromOffset(reservedLeft, size.Y + 34)
                              e.Flags.Size = UDim2.fromOffset(size.X, 14)
                          else
                              e.Flags.Visible = false
                          end
                      else
                          e.Flags.Visible = false
                      end
                  else
                      e.Flags.Visible = false
                  end
              end
          end)
  
          local function hookPlayer(p)
              if p == Client then return end
              if not ESP[p] then
                  createESP(p, p.Name, 'Players')
              end
          end
  
          for _, p in ipairs(Players:GetPlayers()) do hookPlayer(p) end
          Players.PlayerAdded:Connect(hookPlayer)
          Players.PlayerRemoving:Connect(function(p)
              local e = ESP[p]
              if e then
                  e.Holder:Destroy()
                  ESP[p] = nil
                  clearChams(e)
              end
          end)
  
          local SoldierClassType = {
              Brutus = "Boss",
              Bruno = "Boss",
              BTR = "Boss",
              Boris = "Boss",
              Soldier = "AI",
          }
  
          local Military = workspace:FindFirstChild('Military')
          local Events = workspace:FindFirstChild('Events')
  
          if Military and Events then
              local function CacheSoldier(model)
                  if (not model) or (not model.Parent) then return end
                  local classType = SoldierClassType[model.Name]
                  if not classType then return end
                  if ESP[model] then return end
                  createESP(model, model.Name, classType)
              end
  
              local function OnModelAdded(model)
                  task.defer(function()
                      if model and model.Parent then
                          CacheSoldier(model)
                      end
                  end)
              end
  
              local function OnModelRemoved(model)
                  if model and ESP[model] then ESP[model].Holder:Destroy() ESP[model]=nil end
              end
  
              for _, obj in ipairs(Events:GetChildren()) do
                  if obj.Name == 'BTR' then
                      CacheSoldier(obj)
                  end
              end
  
              Events.ChildAdded:Connect(function(obj)
                  if obj.Name == 'BTR' then
                      OnModelAdded(obj)
                  end
              end)
  
              Events.ChildRemoved:Connect(function(obj)
                  if obj.Name == 'BTR' then
                      OnModelRemoved(obj)
                  end
              end)
  
              for _, folder in ipairs(Military:GetChildren()) do
                  for _, soldier in ipairs(folder:GetChildren()) do
                      if soldier:IsA('Model') then
                          CacheSoldier(soldier)
                      end
                  end
  
                  folder.ChildAdded:Connect(function(soldier)
                      if soldier:IsA('Model') then
                          OnModelAdded(soldier)
                      end
                  end)
  
                  folder.ChildRemoved:Connect(function(soldier)
                      if soldier:IsA('Model') then
                          OnModelRemoved(soldier)
                      end
                  end)
              end
          end
      end
  
      do
          local FovCircleOutline, FovCircle
          pcall(function()
              FovCircleOutline = Drawing.new("Circle")
              FovCircleOutline.Visible = false
              FovCircleOutline.NumSides = 64
              FovCircleOutline.ZIndex = 9
              FovCircleOutline.Filled = false
              FovCircleOutline.Transparency = 1
              FovCircleOutline.Radius = 200
              FovCircleOutline.Thickness = 4
              FovCircleOutline.Color = Color3.fromRGB(0, 0, 0)
              FovCircle = Drawing.new("Circle")
              FovCircle.Visible = false
              FovCircle.NumSides = 64
              FovCircle.ZIndex = 10
              FovCircle.Filled = false
              FovCircle.Transparency = 1
              FovCircle.Radius = 200
              FovCircle.Thickness = 2
              FovCircle.Color = Color3.fromRGB(255, 20, 147)
          end)
          local snap_out, snap_main
          pcall(function()
              snap_out = Drawing.new("Line")
              snap_out.Visible = false
              snap_out.Thickness = 3
              snap_out.Color = Color3.new(0, 0, 0)
              snap_out.ZIndex = 1
              snap_out.Transparency = 1
              snap_main = Drawing.new("Line")
              snap_main.Visible = false
              snap_main.Thickness = 1
              snap_main.Color = Color3.new(1, 1, 1)
              snap_main.ZIndex = 2
              snap_main.Transparency = 1
          end)

          local function snap_from()
              return Vector2.new(UIS:GetMouseLocation().X, UIS:GetMouseLocation().Y)
          end

          Run.RenderStepped:Connect(function()
              previewTicks.targetHud = os.clock()
              local vp = Camera.ViewportSize
              local pos = snap_from()
              local radius = tonumber(flags.FovSize) or 200
              local thickness = tonumber(flags.FovThickness) or 2
              local col, _ = flagColor(flags.FovColor, Color3.fromRGB(255, 20, 147))

              if FovCircle then
                  if flags.FovEnabled then
                      FovCircle.Position = pos
                      FovCircle.Radius = radius
                      FovCircle.Thickness = thickness
                      FovCircle.Color = col
                      FovCircle.Transparency = 1
                      FovCircle.Visible = true
                      if FovCircleOutline then
                          FovCircleOutline.Position = pos
                          FovCircleOutline.Radius = radius
                          FovCircleOutline.Thickness = thickness + 2
                          FovCircleOutline.Color = Color3.new(0, 0, 0)
                          FovCircleOutline.Transparency = 1
                          FovCircleOutline.Visible = true
                      end
                  else
                      FovCircle.Visible = false
                      if FovCircleOutline then
                          FovCircleOutline.Visible = false
                      end
                  end
              end

              local snap_on = flags.SnaplineEnabled == true
              local tp = Targeting.TargetPart
              if snap_on and snap_main and tp and tp.Parent then
                  local head = tp.Parent:FindFirstChild("Head")
                  local world = head and head.Position or tp.Position
                  local sp, on = Camera:WorldToViewportPoint(world)
                  if on then
                      local a = snap_from()
                      local b = Vector2.new(sp.X, sp.Y)
                      local sc, _ = flagColor(flags.SnaplineColor, Color3.new(1, 1, 1))
                      local th = tonumber(flags.SnaplineThickness) or 1
                      if snap_out then
                          snap_out.From = a
                          snap_out.To = b
                          snap_out.Thickness = th + 2
                          snap_out.Transparency = 1
                          snap_out.Visible = flags.SnaplineOutline ~= false
                      end
                      snap_main.From = a
                      snap_main.To = b
                      snap_main.Thickness = th
                      snap_main.Color = sc
                      snap_main.Transparency = 1
                      snap_main.Visible = true
                  else
                      snap_main.Visible = false
                      if snap_out then
                          snap_out.Visible = false
                      end
                  end
              else
                  if snap_main then
                      snap_main.Visible = false
                  end
                  if snap_out then
                      snap_out.Visible = false
                  end
              end

              if flags.TargetHUDEnabled then
                  if tp and typeof(tp) == "Instance" and tp:IsA("BasePart") and tp.Parent and tp.Parent.Parent then
                      TargetHUD:SetVisibility(true)
                      local char = tp.Parent
                      local plr = Players:GetPlayerFromCharacter(char)
                      local hudTarget = plr or char
                      if indTarget ~= hudTarget then
                          indTarget = hudTarget
                          task.spawn(function()
                              pcall(function()
                                  TargetHUD:SetTarget(plr)
                              end)
                          end)
                      end
                      local gun = ""
                      local tool = char:FindFirstChildOfClass("Tool")
                      if tool then
                          gun = tool.Name
                      end
                      indSetLine("weapon", "WPN " .. gun)
                      pcall(function()
                          local dist = (Camera.CFrame.Position - tp.Position).Magnitude
                          indSetLine("dist", string.format("%.1f m", dist / 3))
                      end)
                      local okStatus, statusError = pcall(function()
                          local statusName, statusColor = cheat.targetStatus(tp)
                          indSetLine("status", tostring(statusName) .. " - " .. tostring(tp.Name), statusColor)
                      end)
                      if not okStatus then
                          indSetLine("status", "Unvisible - " .. tostring(tp.Name), Color3.fromRGB(255, 80, 80))
                          if cheat.debugSession and cheat.debugSession.active then
                              cheat.debugWrite("hud-error", tostring(statusError))
                          end
                      end
                  elseif Library.WindowOpenState ~= false then
                      TargetHUD:SetVisibility(true)
                      if indTarget ~= Client then
                          indTarget = Client
                          keepOnScreen(TargetHUD)
                          task.spawn(function()
                              pcall(function()
                                  TargetHUD:SetTarget(Client)
                              end)
                          end)
                          indSetLine("weapon", "WPN Preview")
                          indSetLine("dist", "0.0 m")
                          indSetLine("status", "Visible - Head", Color3.fromRGB(80, 255, 120))
                      end
                  else
                      TargetHUD:SetVisibility(false)
                      indTarget = nil
                      TargetHUD:SetTarget(nil)
                      indSetLine("weapon", "")
                      indSetLine("dist", "")
                      indSetLine("status", "")
                  end
              else
                  TargetHUD:SetVisibility(false)
              end
          end)
      end

  
      do
          local folder = Instance.new('Folder')
          folder.Parent = workspace
  
          local chunks = {}
          local lights = {}
          local bases = {}
  
          local rayParams = RaycastParams.new()
          rayParams.FilterType = Enum.RaycastFilterType.Exclude or Enum.RaycastFilterType.Blacklist
          rayParams.FilterDescendantsInstances = { folder }
  
          local function key(cx, cy, cz)
              return cx .. ':' .. cy .. ':' .. cz
          end
  
          local classify = LPH_NO_VIRTUALIZE(function(pos)
              return workspace:Raycast(pos, Vector3.new(0, 200, 0), rayParams) ~= nil
                  and 'Indoor'
                  or 'Outdoor'
          end)
  
          local createNode = LPH_NO_VIRTUALIZE(function(pos)
              local p = Instance.new('Part')
              p.Size = Vector3.new(0.1, 0.1, 0.1)
              p.Anchored = true
              p.CanCollide = false
              p.Transparency = 1
              p.CFrame = CFrame.new(pos)
              p.Parent = folder
  
              local l = Instance.new('PointLight')
              l.Range = 140
              l.Shadows = false
  
              local t = classify(pos)
              local base =
                  (t == 'Indoor' and flags.AmbienceIndoorBrightness)
                  or flags.AmbienceBrightness
  
              l.Brightness = base
              l.Parent = p
  
              lights[l] = true
              bases[l] = base
  
              if flags.AmbienceEnabled then
                  l.Color = flags.AmbienceColor.Color
              end
  
              return p
          end)
  
          local buildChunk = LPH_NO_VIRTUALIZE(function(cx, cy, cz)
              local k = key(cx, cy, cz)
              if chunks[k] then return end
  
              local group = {}
              local basePos = Vector3.new(cx * 150, cy * 150, cz * 150)
  
              for x = 0, 150, 100 do
                  for y = 0, 150, 100 do
                      for z = 0, 150, 100 do
                          group[#group + 1] =
                              createNode(basePos + Vector3.new(x, y, z))
                      end
                  end
              end
  
              chunks[k] = group
          end)
  
          local destroyChunk = LPH_NO_VIRTUALIZE(function(k)
              local group = chunks[k]
              if not group then return end
              for i = 1, #group do
                  group[i]:Destroy()
              end
              chunks[k] = nil
          end)
  
          folder.DescendantRemoving:Connect(function(d)
              if d:IsA('PointLight') then
                  lights[d] = nil
                  bases[d] = nil
              end
          end)
  
          local sceneLuminance = LPH_NO_VIRTUALIZE(function()
              local t = Lighting.ClockTime
              local sun = math.clamp(
                  math.cos((t - 14) / 24 * math.pi * 2) * -0.5 + 0.5,
                  0,
                  1
              )
  
              local amb =
                  (Lighting.Ambient.R + Lighting.Ambient.G + Lighting.Ambient.B) / 3
  
              return math.max(
                  0.05,
                  (sun * 0.7 + amb * 0.3) * (2 ^ Lighting.ExposureCompensation)
              )
          end)
  
          local recomputeBases = LPH_NO_VIRTUALIZE(function()
              for light in pairs(lights) do
                  if (light.Parent) then
                      local t = light:GetAttribute('AmbienceType')
                      bases[light] =
                          (t == 'Indoor' and flags.AmbienceIndoorBrightness)
                          or flags.AmbienceBrightness
                  end
              end
          end)
  
          local lastCenter
          local scale = 1
          local lastAppliedScale = 1
          local acc = 0
          local savedflags = {
              AmbienceBrightness = flags.AmbienceBrightness,
              AmbienceIndoorBrightness = flags.AmbienceIndoorBrightness,
              AmbienceEnabled = flags.AmbienceEnabled,
              AmbienceColor = {
                  Color = flags.AmbienceColor.Color
              }
          }
  
          Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function(dt)
              local cam = workspace.CurrentCamera
              if not cam then return end
  
              local pos = cam.CFrame.Position
              local center = Vector3.new(
                  math.floor(pos.X / 150),
                  math.floor(pos.Y / 150),
                  math.floor(pos.Z / 150)
              )
  
              if not lastCenter or center ~= lastCenter then
                  lastCenter = center
                  local needed = {}
  
                  for x = -2, 2 do
                      for y = -2, 2 do
                          for z = -2, 2 do
                              local k = key(center.X + x, center.Y + y, center.Z + z)
                              needed[k] = true
                              buildChunk(center.X + x, center.Y + y, center.Z + z)
                          end
                      end
                  end
  
                  for k in pairs(chunks) do
                      if not needed[k] then
                          destroyChunk(k)
                      end
                  end
  
                  acc = 0.11
              end
  
              acc = acc + dt
              if acc < 0.2 then return end
              acc = 0
  
              local desired = math.clamp(1.0 / sceneLuminance(), 0.25, 1.6)
              scale = scale + (desired - scale) * 0.6
  
              local flagschanged = false
  
              if (savedflags.AmbienceBrightness ~= flags.AmbienceBrightness) then
                  savedflags.AmbienceBrightness = flags.AmbienceBrightness
                  flagschanged = true
              end
  
              if (savedflags.AmbienceIndoorBrightness ~= flags.AmbienceIndoorBrightness) then
                  savedflags.AmbienceIndoorBrightness = flags.AmbienceIndoorBrightness
                  flagschanged = true
              end
  
              if (savedflags.AmbienceEnabled ~= flags.AmbienceEnabled) then
                  savedflags.AmbienceEnabled = flags.AmbienceEnabled
                  flagschanged = true
              end
  
              if (savedflags.AmbienceColor.Color ~= flags.AmbienceColor.Color) then
                  savedflags.AmbienceColor.Color = flags.AmbienceColor.Color
                  flagschanged = true
              end
  
              if (flagschanged) then
                  recomputeBases()
                  lastAppliedScale = -1
              end
  
              if math.abs(scale - lastAppliedScale) < 0.02 then
                  return
              end
  
              lastAppliedScale = scale
  
              for light in pairs(lights) do
                  if light.Parent then
                      if flags.AmbienceEnabled then
                          light.Brightness = bases[light] * scale
                          light.Color = flags.AmbienceColor.Color
                      else
                          light.Brightness = 0
                      end
                  end
              end
          end))
      end
  
      do
          local lastload = ''

          local function itemImage(item, skinName)
              local image = item and item.Image
              if type(image) == "table" then
                  image = (skinName and image[skinName]) or image.Default
              end
              if type(image) ~= "string" or image == "" then
                  return nil
              end
              if image:match("^%d+$") then
                  return "rbxassetid://" .. image
              end
              return image
          end

          local inventoryWasShown = false
          Run.RenderStepped:Connect(function()
              previewTicks.inventory = os.clock()
              local targetCharacter = Targeting.TargetCharacter
              local menuOpen = Library.WindowOpenState ~= false
              local character = targetCharacter
              local isPreview = false
              if character == nil and menuOpen then
                  character = Client.Character
                  isPreview = character ~= nil
              end
              local show = flags.ArmorBarEnabled == true and (targetCharacter ~= nil or menuOpen)
              InvViewer:SetVisibility(show)
              if show and not inventoryWasShown then
                  keepOnScreen(InvViewer)
              end
              inventoryWasShown = show
              if not show then
                  return
              end
              if character == nil then
                  if lastload ~= "" then
                      lastload = ""
                      InvViewer:SetTarget("")
                      InvViewer:SetSummary("")
                      InvViewer:SetSections({})
                  end
                  return
              end
              local humanoid = character:FindFirstChildOfClass("Humanoid")
              local hp = humanoid and math.floor(humanoid.Health) or 0
              local held = {}
              local armor = {}
              local seen = {}
              for _, child in ipairs(character:GetChildren()) do
                  if child:IsA("Model") then
                      local modelName = child.Name
                      if modelName ~= "Hair" and modelName ~= "HolsterModel" and not modelName:match("^Armor_") then
                          local base, skin = modelName:match("^(.-)/(.*)$")
                          base = base or modelName
                          local id = tonumber(base:match("_(%d+)$"))
                          local item = id and ItemsModule[id]
                          local label
                          if item then
                              label = item.Name
                              if skin and skin ~= "" and skin ~= "Default" then
                                  label = label .. " [" .. skin .. "]"
                              end
                          else
                              label = base
                          end
                          if label ~= "" and not seen[label] then
                              seen[label] = true
                              held[#held + 1] = { Name = label, Image = itemImage(item, skin) }
                          end
                      end
                  end
              end
              for _, armorPiece in ipairs(getArmor(character)) do
                  local label = armorPiece.Name or "?"
                  if armorPiece.Skin and armorPiece.Skin ~= "" and armorPiece.Skin ~= "Default" then
                      label = label .. " [" .. armorPiece.Skin .. "]"
                  end
                  if not seen[label] then
                      seen[label] = true
                      local imageId = armorPiece.Image
                      armor[#armor + 1] = {
                          Name = label,
                          Image = (imageId and imageId ~= "") and ("rbxassetid://" .. imageId) or nil,
                      }
                  end
              end
              local signature = (isPreview and "preview|" or "") .. character.Name .. "|" .. hp
              for _, entry in ipairs(held) do
                  signature = signature .. "|" .. entry.Name
              end
              for _, entry in ipairs(armor) do
                  signature = signature .. "|" .. entry.Name
              end
              if signature ~= lastload then
                  lastload = signature
                  InvViewer:SetTarget(isPreview and (character.Name .. " (preview)") or character.Name)
                  InvViewer:SetSummary("HP " .. hp)
                  InvViewer:SetSections({
                      { Name = "Holding Weapon", Entries = held },
                      { Name = "Armor", Entries = armor },
                  })
              end
          end)
      end

  
      do
          local miscCache = {}
          local worldToViewportPoint = Camera.WorldToViewportPoint
  
          local ScreenGui = Instance.new('ScreenGui')
          ScreenGui.IgnoreGuiInset = true
          ScreenGui.Parent = gethui()
  
          local function espify(obj, staticname, manualflag)
              if not obj or miscCache[obj] then return end
  
              local flag = manualflag or obj.Name:gsub('_Node$', '')
  
              local label = Instance.new('TextLabel')
              label.BackgroundTransparency = 1
              label.TextSize = 12
              label.FontFace = Library.Font
              label.TextColor3 = Color3.new(1, 1, 1)
              label.AnchorPoint = Vector2.new(0.5, 1)
              label.AutomaticSize = Enum.AutomaticSize.XY
              label.Size = UDim2.fromOffset(0, 0)
              label.Visible = false
              label.Parent = ScreenGui
  
              label.TextSize = 11
              label.TextStrokeColor3 = Color3.new(0, 0, 0)
              label.TextStrokeTransparency = 0

              local distLabel = Instance.new('TextLabel')
              distLabel.BackgroundTransparency = 1
              distLabel.TextSize = 11
              distLabel.FontFace = Library.Font
              distLabel.TextColor3 = Color3.new(1, 1, 1)
              distLabel.AnchorPoint = Vector2.new(0.5, 0)
              distLabel.AutomaticSize = Enum.AutomaticSize.XY
              distLabel.Size = UDim2.fromOffset(0, 0)
              distLabel.Visible = false
              distLabel.Parent = ScreenGui
              distLabel.TextStrokeColor3 = Color3.new(0, 0, 0)
              distLabel.TextStrokeTransparency = 0
  
              local box_outer = Instance.new('Frame')
              box_outer.BackgroundTransparency = 1
              box_outer.Visible = false
              box_outer.Parent = ScreenGui

              local box_grad = Instance.new('Frame')
              box_grad.BackgroundTransparency = 1
              box_grad.Visible = false
              box_grad.Parent = ScreenGui

              local box_inner = Instance.new('Frame')
              box_inner.BackgroundTransparency = 1
              box_inner.Visible = false
              box_inner.Parent = ScreenGui

              local function fill_sides(holder, color)
                  local sides = {}
                  for i = 1, 4 do
                      local f = Instance.new('Frame')
                      f.BorderSizePixel = 0
                      f.BackgroundColor3 = color
                      f.Parent = holder
                      sides[i] = f
                  end
                  return sides
              end

              local outer_sides = fill_sides(box_outer, Color3.new(0, 0, 0))
              local grad_sides = fill_sides(box_grad, Color3.new(1, 1, 1))
              local inner_sides = fill_sides(box_inner, Color3.new(0, 0, 0))
              local box_gradients = {}
              for i = 1, 4 do
                  local g = Instance.new('UIGradient')
                  g.Rotation = 90
                  g.Parent = grad_sides[i]
                  box_gradients[i] = g
              end

              miscCache[obj] = {
                  obj = obj,
                  label = label,
                  dist = distLabel,
                  chams_hl = nil,
                  box_outer = box_outer,
                  box_grad = box_grad,
                  box_inner = box_inner,
                  outer_sides = outer_sides,
                  grad_sides = grad_sides,
                  inner_sides = inner_sides,
                  box_gradients = box_gradients,
                  flag = flag,
                  staticname = staticname
              }
          end
  
  
          local function removeEsp(obj)
              local data = miscCache[obj]
              if data then
                  data.label:Destroy()
                  data.dist:Destroy()
                  clearChams(data)
                  if data.box_outer then
                      data.box_outer:Destroy()
                      data.box_grad:Destroy()
                      data.box_inner:Destroy()
                  end
                  miscCache[obj] = nil
              end
          end
  
          local nodes = workspace:FindFirstChild('Nodes')
          local bases = workspace:FindFirstChild('Bases')
  
          if nodes then
              local function addNode(v)
                  if v:IsA('BasePart') or v:IsA('Model') then
                      espify(v)
                  end
              end
  
              for _, v in nodes:GetChildren() do
                  addNode(v)
              end
  
              nodes.ChildAdded:Connect(addNode)
              nodes.ChildRemoved:Connect(removeEsp)
          end
  
          if bases then
              local function handleObject(obj)
                  if obj:IsA('Model') and (obj.Name == 'Care Package' or obj.Name == 'Salvaged Flycopter' or obj.Name == 'Body Bag' or obj.Name == 'Auto Turret' or obj.Name == 'Shotgun Turret') then
                      espify(obj)
                  end
              end
  
              local function handleFolder(folder)
                  for _, obj in folder:GetChildren() do
                      handleObject(obj)
                  end
                  folder.ChildAdded:Connect(handleObject)
              end
  
              for _, base in bases:GetChildren() do
                  for _, folder in base:GetChildren() do
                      handleFolder(folder)
                  end
                  base.ChildAdded:Connect(handleFolder)
              end
          end
          
          if Drops and Plants then
              Run.RenderStepped:Connect(function()
                  if not flags.MiscEnabledESP then return end
                  for _, item in pairs(Drops:GetChildren()) do
                      if item:IsA('Model') and not miscCache[item] then
                          local distance = (Camera.CFrame.Position - item:GetPivot().Position).Magnitude
                          if distance <= (flags.DropsMaxDistance or 10000) then
                              espify(item, item.Name, 'Drops')
                          end
                      end
                  end
                  for _, plant in pairs(Plants:GetChildren()) do
                      if plant:IsA('Model') and not miscCache[plant] then
                          local name = string.gsub(plant.Name, ' Plant', '')
                          local distance = (Camera.CFrame.Position - plant:GetPivot().Position).Magnitude
  
                          if name == 'Wool' and distance <= (flags.WoolMaxDistance or 10000) then
                              espify(plant, 'Wool', 'Wool')
                          end
                      end
                  end
              end)
          end
  
          if Animals then
              for _, animal in pairs(Animals:GetChildren()) do
                  if animal:IsA('Model') then
                      local name = animal.Name:lower():gsub('prefab_animal_', ''):gsub('_', ' ')
                      espify(animal, name, 'Animals')
                  end
              end
              Animals.ChildAdded:Connect(function(animal)
                  if animal:IsA('Model') then
                      local name = animal.Name:lower():gsub('prefab_animal_', ''):gsub('_', ' ')
                      espify(animal, name, 'Animals')
                  end
              end)
              Animals.ChildRemoved:Connect(removeEsp)
          end
  
          local function size_sides(sides, w, h, t)
              sides[1].Position = UDim2.fromOffset(0, 0)
              sides[1].Size = UDim2.fromOffset(w, t)
              sides[2].Position = UDim2.fromOffset(0, h - t)
              sides[2].Size = UDim2.fromOffset(w, t)
              sides[3].Position = UDim2.fromOffset(0, 0)
              sides[3].Size = UDim2.fromOffset(t, h)
              sides[4].Position = UDim2.fromOffset(w - t, 0)
              sides[4].Size = UDim2.fromOffset(t, h)
          end

          local function projectBox(cf, size)
              local hx = size.X * 0.5
              local hy = size.Y * 0.5
              local hz = size.Z * 0.5
              local minX, minY = math.huge, math.huge
              local maxX, maxY = -math.huge, -math.huge
              for i = 0, 7 do
                  local corner = cf * CFrame.new(
                      (i % 2 == 0) and -hx or hx,
                      (math.floor(i / 2) % 2 == 0) and -hy or hy,
                      (i < 4) and -hz or hz
                  )
                  local p = worldToViewportPoint(Camera, corner.Position)
                  if p.Z > 0 then
                      if p.X < minX then minX = p.X end
                      if p.X > maxX then maxX = p.X end
                      if p.Y < minY then minY = p.Y end
                      if p.Y > maxY then maxY = p.Y end
                  end
              end
              if minX == math.huge then
                  return nil
              end
              return minX, minY, maxX - minX, maxY - minY
          end

          Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function()
              local miscEnabled = flags.MiscEnabledESP
              local camPos = Camera.CFrame.Position
  
              for obj, data in pairs(miscCache) do
                  if not obj or not obj.Parent then
                      data.label:Destroy()
                      data.dist:Destroy()
                      clearChams(data)
                      if data.box_outer then
                          data.box_outer:Destroy()
                          data.box_grad:Destroy()
                          data.box_inner:Destroy()
                      end
                      miscCache[obj] = nil
                      continue
                  end
  
                  local show_box = miscEnabled and flags.WorldBox == true
                  local show_name = miscEnabled and flags.WorldName ~= false
                  local show_dist = miscEnabled and flags.WorldDistance ~= false
                  local chamsOn = miscEnabled and flags.WorldChams == true
                  if not miscEnabled or not flags[data.flag .. 'Enabled'] or not (show_name or show_dist or show_box or chamsOn) then
                      data.label.Visible = false
                      data.dist.Visible = false
                      clearChams(data)
                      if data.box_outer then
                          data.box_outer.Visible = false
                          data.box_grad.Visible = false
                          data.box_inner.Visible = false
                      end
                      continue
                  end
  
                  local worldPos
                  local boxCF
                  if obj:IsA('BasePart') then
                      worldPos = obj.Position
                      boxCF = obj.CFrame
                  else
                      boxCF = obj:GetPivot()
                      worldPos = boxCF.Position
                  end
  
                  local screenPos, onScreen = worldToViewportPoint(Camera, worldPos)
                  if not onScreen then
                      data.label.Visible = false
                      data.dist.Visible = false
                      clearChams(data)
                      if data.box_outer then
                          data.box_outer.Visible = false
                          data.box_grad.Visible = false
                          data.box_inner.Visible = false
                      end
                      continue
                  end
  
                  local dist = (camPos - worldPos).Magnitude
                  if dist > flags[data.flag .. 'MaxDistance'] then
                      data.label.Visible = false
                      data.dist.Visible = false
                      clearChams(data)
                      if data.box_outer then
                          data.box_outer.Visible = false
                          data.box_grad.Visible = false
                          data.box_inner.Visible = false
                      end
                      continue
                  end
                  local name = data.staticname or data.flag
                  local col = flags[data.flag .. 'Color']

                  local size
                  if obj:IsA('BasePart') then
                      size = obj.Size
                  else
                      size = obj:GetExtentsSize()
                  end
                  local bx0, by0, box_w, box_h = projectBox(boxCF, size)
                  local box_ok = bx0 ~= nil
                  if not box_ok then
                      box_w, box_h = 0, 0
                  end
                  local topY = box_ok and by0 or 0
                  local botY = box_ok and (by0 + box_h) or 0
                  local midX = box_ok and (bx0 + box_w * 0.5) or screenPos.X
                  local text_size = math.clamp(math.floor(box_h * 0.16), 11, 18)
                  local gap = math.clamp(math.floor(box_h * 0.06), 3, 8)

                  if show_name and box_ok then
                      data.label.Visible = true
                      data.label.Text = name
                      data.label.TextSize = text_size
                      data.label.Position = UDim2.fromOffset(midX, topY - gap)
                      if col then
                          data.label.TextColor3 = col.Color
                      end
                  else
                      data.label.Visible = false
                  end

                  if show_dist and box_ok then
                      data.dist.Visible = true
                      data.dist.Text = tostring(math.floor(dist + 0.5)) .. ' Studs'
                      data.dist.TextSize = text_size
                      data.dist.Position = UDim2.fromOffset(midX, botY + gap)
                      if col then
                          data.dist.TextColor3 = col.Color
                      end
                  else
                      data.dist.Visible = false
                  end

                  if data.box_outer then
                      if show_box and box_ok and box_w >= 1 and box_h >= 1 then
                          local bx = math.floor(bx0)
                          local by = math.floor(by0)
                          local bc = col and col.Color or Color3.new(1, 1, 1)

                          data.box_outer.Position = UDim2.fromOffset(bx - 1, by - 1)
                          data.box_outer.Size = UDim2.fromOffset(box_w + 2, box_h + 2)
                          size_sides(data.outer_sides, box_w + 2, box_h + 2, 1)

                          data.box_grad.Position = UDim2.fromOffset(bx, by)
                          data.box_grad.Size = UDim2.fromOffset(box_w, box_h)
                          size_sides(data.grad_sides, box_w, box_h, 2)

                          if box_w >= 4 and box_h >= 4 then
                              data.box_inner.Position = UDim2.fromOffset(bx + 1, by + 1)
                              data.box_inner.Size = UDim2.fromOffset(box_w - 2, box_h - 2)
                              size_sides(data.inner_sides, box_w - 2, box_h - 2, 1)
                              data.box_inner.Visible = true
                          else
                              data.box_inner.Visible = false
                          end

                          for _, g in ipairs(data.box_gradients) do
                              g.Color = ColorSequence.new(bc, Color3.new(bc.R * 0.4, bc.G * 0.4, bc.B * 0.4))
                          end

                          data.box_outer.Visible = true
                          data.box_grad.Visible = true
                      else
                          data.box_outer.Visible = false
                          data.box_grad.Visible = false
                          data.box_inner.Visible = false
                      end
                  end

                  if chamsOn then
                      local c1 = flags.WorldChamsColor1
                      local c2 = flags.WorldChamsColor2
                      local a1 = c1 and c1.Alpha
                      applyWorldChams(data, obj, c1 and c1.Color or Color3.new(1, 1, 1), type(a1) == "number" and a1 or 0.5, c2 and c2.Color or Color3.new(1, 1, 1))
                  else
                      clearChams(data)
                  end
              end
          end))
          local xray_parts = {}
          local xray_orig = {}
          local xray_bases = nil
          local xray_level = 0.5
          local xray_allowed = {
              Wall = true,
              ["Half Wall"] = true,
              ["Low Wall"] = true,
              Doorway = true,
              Window = true,
              Foundation = true,
              Floor = true,
              ["Triangle Floor"] = true,
              ["Wall Frame"] = true,
              ["Floor Frame"] = true,
              ["Triangle Floor Frame"] = true,
              ["L-Shaped Stairs"] = true,
              ["U-Shaped Stairs"] = true,
              ["Foundation Steps"] = true,
              ["Triangle Foundation"] = true,
          }
          Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function()
              local on = bindOn(flags.WorldXRay == true, "WorldXRayKey")
              local lvl = tonumber(flags.WorldXRayTransparency)
              if lvl then
                  xray_level = lvl
              end
              if not xray_bases then
                  local b = workspace:FindFirstChild('Bases')
                  if b then
                      xray_bases = b
                      for _, v in ipairs(b:GetDescendants()) do
                          if v:IsA('MeshPart') and v.Name == 'Detail' and v.Parent and xray_allowed[v.Parent.Name] then
                              xray_parts[#xray_parts + 1] = v
                          end
                      end
                      b.DescendantAdded:Connect(function(v)
                          task.delay(0.5, function()
                              if v and v.Parent and v:IsA('MeshPart') and v.Name == 'Detail' and xray_allowed[v.Parent.Name] then
                                  xray_parts[#xray_parts + 1] = v
                                  if on then
                                      xray_orig[v] = v.Transparency
                                      v.Transparency = xray_level
                                  end
                              end
                          end)
                      end)
                  end
              end
              local w = 0
              for i = 1, #xray_parts do
                  local p = xray_parts[i]
                  if p.Parent then
                      w = w + 1
                      xray_parts[w] = p
                      if on then
                          if xray_orig[p] == nil then
                              xray_orig[p] = p.Transparency
                          end
                          p.Transparency = xray_level
                      elseif xray_orig[p] ~= nil then
                          p.Transparency = xray_orig[p]
                          xray_orig[p] = nil
                      end
                  else
                      xray_orig[p] = nil
                  end
              end
              for i = #xray_parts, w + 1, -1 do
                  xray_parts[i] = nil
              end
          end))
      end
  end
  do
      local hm_gui = Instance.new('ScreenGui')
      hm_gui.IgnoreGuiInset = true
      hm_gui.Parent = gethui()

      local hitmarkers = {}
      cheat.Globals.spawnHitmarker = function(part, position)
          if typeof(position) ~= "Vector3" then
              return
          end
          local holder = Instance.new('Frame')
          holder.AnchorPoint = Vector2.new(0.5, 0.5)
          holder.BackgroundTransparency = 1
          holder.Size = UDim2.fromOffset(40, 40)
          holder.ZIndex = 60
          holder.Visible = false
          holder.Parent = hm_gui
          local scale = Instance.new('UIScale')
          scale.Parent = holder
          local frame = Instance.new('Frame')
          frame.AnchorPoint = Vector2.new(0.5, 0.5)
          frame.Position = UDim2.new(0.5, 0, 0.5, 0)
          frame.Size = UDim2.new(1, 0, 1, 0)
          frame.BackgroundTransparency = 1
          frame.ZIndex = 60
          frame.Parent = holder
          local specs = {
              {Vector2.new(0.5, 1), UDim2.new(0.5, 0, 0.5 - 3 / 40, 0), UDim2.fromOffset(3, 13)},
              {Vector2.new(0.5, 0), UDim2.new(0.5, 0, 0.5 + 3 / 40, 0), UDim2.fromOffset(3, 13)},
              {Vector2.new(1, 0.5), UDim2.new(0.5 - 3 / 40, 0, 0.5, 0), UDim2.fromOffset(13, 3)},
              {Vector2.new(0, 0.5), UDim2.new(0.5 + 3 / 40, 0, 0.5, 0), UDim2.fromOffset(13, 3)},
          }
          local outers = {}
          local inners = {}
          for i = 1, 4 do
              local o = Instance.new('Frame')
              o.AnchorPoint = specs[i][1]
              o.Position = specs[i][2]
              o.Size = specs[i][3]
              o.BackgroundColor3 = Color3.new(0, 0, 0)
              o.BorderSizePixel = 0
              o.ZIndex = 60
              o.Parent = frame
              local oc = Instance.new('UICorner')
              oc.CornerRadius = UDim.new(1, 0)
              oc.Parent = o
              local n = Instance.new('Frame')
              n.AnchorPoint = Vector2.new(0.5, 0.5)
              n.Position = UDim2.new(0.5, 0, 0.5, 0)
              n.Size = UDim2.new(1, -2, 1, -2)
              n.BackgroundColor3 = Color3.new(1, 1, 1)
              n.BorderSizePixel = 0
              n.ZIndex = 61
              n.Parent = o
              local nc = Instance.new('UICorner')
              nc.CornerRadius = UDim.new(1, 0)
              nc.Parent = n
              outers[i] = o
              inners[i] = n
          end
          hitmarkers[#hitmarkers + 1] = {
              pos = position,
              holder = holder,
              frame = frame,
              scale = scale,
              outers = outers,
              inners = inners,
              rot = flags.HitmarkerRandomRotation == true and math.random(0, 359) or 0,
              expanded = false,
              born = tick(),
          }
      end

      Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function(dt)
          local col = flags.HitmarkerColor
          local base = (col and col.Color) or Color3.new(1, 1, 1)
          local size = tonumber(flags.HitmarkerSize) or 40
          local life = tonumber(flags.HitmarkerTime) or 1
          if life <= 0.1 then
              life = 0.1
          end
          local w = 0
          for i = 1, #hitmarkers do
              local m = hitmarkers[i]
              local age = tick() - m.born
              if age > life then
                  m.holder:Destroy()
              else
                  local sp = Camera:WorldToViewportPoint(m.pos)
                  if sp.Z <= 0 then
                      m.holder.Visible = false
                      w = w + 1
                      hitmarkers[w] = m
                  else
                      if not m.expanded then
                          if age < 0.1 then
                              local sc = 1 + 3 * (age / 0.1)
                              m.frame.Size = UDim2.new(sc, 0, sc, 0)
                          else
                              m.expanded = true
                              m.frame.Size = UDim2.new(1, 0, 1, 0)
                          end
                      end
                      m.rot = (m.rot + dt * 120) % 360
                      m.frame.Rotation = m.rot
                      m.scale.Scale = size / 40
                      m.holder.Position = UDim2.fromOffset(sp.X, sp.Y)
                      local tr = 0
                      if age >= life - 0.3 then
                          local p = math.clamp((age - (life - 0.3)) / 0.3, 0, 1)
                          local sh = 1 - 0.7 * p
                          m.frame.Size = UDim2.new(sh, 0, sh, 0)
                          tr = p
                      end
                      m.holder.Visible = true
                      for k = 1, 4 do
                          m.inners[k].BackgroundColor3 = base
                          m.inners[k].BackgroundTransparency = tr
                          m.outers[k].BackgroundTransparency = tr
                      end
                      w = w + 1
                      hitmarkers[w] = m
                  end
              end
          end
          for i = #hitmarkers, w + 1, -1 do
              hitmarkers[i] = nil
          end
      end))

      local cross_holder = Instance.new('Frame')
      cross_holder.AnchorPoint = Vector2.new(0.5, 0.5)
      cross_holder.BackgroundTransparency = 1
      cross_holder.Size = UDim2.fromOffset(100, 100)
      cross_holder.Visible = false
      cross_holder.Parent = hm_gui

      local function cross_line(grad_rot)
          local f = Instance.new('Frame')
          f.AnchorPoint = Vector2.new(0.5, 0.5)
          f.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
          f.BorderColor3 = Color3.fromRGB(0, 0, 0)
          f.BorderMode = Enum.BorderMode.Middle
          f.Position = UDim2.new(0.5, 0, 0.5, 0)
          f.Size = UDim2.fromOffset(2, 20)
          f.Parent = cross_holder
          local g = Instance.new('UIGradient')
          g.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.new(0, 0, 0))
          g.Transparency = NumberSequence.new({
              NumberSequenceKeypoint.new(0, 0),
              NumberSequenceKeypoint.new(0.6945, 0.525),
              NumberSequenceKeypoint.new(0.8504, 0.78125),
              NumberSequenceKeypoint.new(1, 0.8625),
          })
          g.Rotation = grad_rot
          g.Parent = f
          return f
      end

      local ctop = cross_line(-90)
      local cbottom = cross_line(90)
      local cleft = cross_line(180)
      local cright = cross_line(0)
      local cross_lines = {ctop, cbottom, cleft, cright}
      local cur_x = Camera.ViewportSize.X / 2
      local cur_y = Camera.ViewportSize.Y / 2
      local cur_gap = 20
      local cur_len = 20
      local cur_wdt = 2
      local cur_col = Color3.new(1, 1, 1)

      Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function()
          local on = flags.Crosshair == true
          cross_holder.Visible = on
          if not on then
              return
          end
          local length = tonumber(flags.CrosshairLength) or 20
          local width = tonumber(flags.CrosshairWidth) or 2
          local gap = tonumber(flags.CrosshairGap) or 20
          local part = Targeting.TargetPart
          if part and not part.Parent then
              part = nil
          end
          local stick = flags.CrosshairStick == true and part ~= nil
          local vp = Camera.ViewportSize
          local gx, gy = vp.X / 2, vp.Y / 2
          if not stick and flags.CrosshairFollowMouse ~= false then
              local mp = UIS:GetMouseLocation()
              gx, gy = mp.X, mp.Y
          end
          local ggap = gap
          local glen = length
          local gwid = width
          if stick then
              local sp, vis = Camera:WorldToViewportPoint(part.Position)
              if vis then
                  gx, gy = sp.X, sp.Y
                  local ch = part.Parent
                  local hrp = ch and ch:FindFirstChild('HumanoidRootPart')
                  if hrp then
                      local p1 = Camera:WorldToViewportPoint(hrp.Position)
                      local p2 = Camera:WorldToViewportPoint(hrp.Position + Vector3.new(0, 5, 0))
                      if p1.Z > 0 and p2.Z > 0 then
                          local hpx = math.abs(p2.Y - p1.Y)
                          local fit = math.clamp(hpx * 0.5, gap * 2, 140)
                          ggap = math.clamp(fit * 0.5 - length * 0.5, gap, 120)
                          glen = math.clamp(fit * 0.3, length, math.max(length, 30))
                          gwid = math.clamp(math.floor(fit / 18) + 1, width, 4)
                      end
                  end
              end
          end
          cur_x = cur_x + (gx - cur_x) * 0.3
          cur_y = cur_y + (gy - cur_y) * 0.3
          cur_gap = cur_gap + (ggap - cur_gap) * 0.2
          cur_len = cur_len + (glen - cur_len) * 0.2
          cur_wdt = cur_wdt + (gwid - cur_wdt) * 0.2
          cross_holder.Position = UDim2.fromOffset(cur_x, cur_y)
          local c1 = flags.CrosshairColor
          local col_goal = (c1 and c1.Color) or Color3.new(1, 1, 1)
          if stick and flags.CrosshairSyncColor == true then
              local pc = flags.PlayersBoxColor1
              if pc and pc.Color then
                  col_goal = pc.Color
              end
          end
          cur_col = cur_col:Lerp(col_goal, 0.25)
          ctop.Size = UDim2.fromOffset(cur_wdt, cur_len)
          cbottom.Size = UDim2.fromOffset(cur_wdt, cur_len)
          cleft.Size = UDim2.fromOffset(cur_len, cur_wdt)
          cright.Size = UDim2.fromOffset(cur_len, cur_wdt)
          ctop.Position = UDim2.new(0.5, 0, 0.5, -cur_gap - cur_len / 2)
          cbottom.Position = UDim2.new(0.5, 0, 0.5, cur_gap + cur_len / 2)
          cleft.Position = UDim2.new(0.5, -cur_gap - cur_len / 2, 0.5, 0)
          cright.Position = UDim2.new(0.5, cur_gap + cur_len / 2, 0.5, 0)
          for _, f in ipairs(cross_lines) do
              f.BackgroundColor3 = cur_col
          end
          if flags.CrosshairRotate == true then
              cross_holder.Rotation = cross_holder.Rotation + 0.5
          else
              cross_holder.Rotation = 0
          end
      end))
  end
  local createExplosion
  do
      local raid_gui = Instance.new('ScreenGui')
      raid_gui.IgnoreGuiInset = true
      raid_gui.Parent = gethui()

      local raidCache = {}
      local notified = {}

      local function raidNotify(name, pos)
          local dist = math.floor((Camera.CFrame.Position - pos).Magnitude + 0.5)
          if dist > (tonumber(flags.RaidMaxDistance) or 2000) then
              return
          end
          local key = tostring(math.floor(pos.X / 40)) .. "_" .. tostring(math.floor(pos.Z / 40))
          if notified[key] and os.clock() - notified[key] < 30 then
              return
          end
          notified[key] = os.clock()
          pcall(function()
              Library:Notification("Raid in " .. dist .. "m away from you!", 8, flags.RaidColor and flags.RaidColor.Color or Color3.fromRGB(255, 80, 80))
          end)
      end

      local function raidEspify(part)
          if not part or raidCache[part] then return end
          local holder = Instance.new('TextLabel')
          holder.BackgroundTransparency = 1
          holder.TextSize = 11
          holder.FontFace = Library.Font
          holder.TextColor3 = Color3.new(1, 1, 1)
          holder.TextStrokeColor3 = Color3.new(0, 0, 0)
          holder.TextStrokeTransparency = 0
          holder.AnchorPoint = Vector2.new(0.5, 0.5)
          holder.Visible = false
          holder.Parent = raid_gui
          raidCache[part] = { label = holder, born = os.clock() }
      end

      createExplosion = hookModule(VFXModule, "CreateExplosion", LPH_NO_UPVALUES(function(self, ...)
          local args = {...}
          task.spawn(function()
              pcall(function()
                  local pos = args[2]
                  if typeof(pos) == "CFrame" then
                      pos = pos.Position
                  end
                  if typeof(pos) ~= "Vector3" then
                      return
                  end
                  local name = tostring(args[5] or "?")
                  if flags.RaidNotifications == true then
                      raidNotify(name, pos)
                  end
                  if flags.RaidESP == true then
                      local marker = Instance.new('Part')
                      marker.Anchored = true
                      marker.CanCollide = false
                      marker.CanQuery = false
                      marker.CanTouch = false
                      marker.Transparency = 1
                      marker.Size = Vector3.new(2, 2, 2)
                      marker.CFrame = CFrame.new(pos)
                      marker:SetAttribute('RaidAt', os.clock())
                      marker.Name = name
                      marker.Parent = workspace.Terrain
                      raidEspify(marker)
                      task.delay(600, function()
                          marker:Destroy()
                          raidCache[marker] = nil
                      end)
                  end
              end)
          end)
          return createExplosion(self, ...)
      end))

      Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function()
          local cam = Camera.CFrame.Position
          local any = false
          for part, data in pairs(raidCache) do
              if not part.Parent then
                  data.label:Destroy()
                  raidCache[part] = nil
              else
                  any = true
                  break
              end
          end
          if not any or flags.RaidESP ~= true or flags.MiscEnabledESP ~= true then
              return
          end
          for part, data in pairs(raidCache) do
              if part.Parent then
                  local pos = part.Position
                  local dist = (cam - pos).Magnitude
                  local ok_sp, sp = pcall(function()
                      return Camera:WorldToViewportPoint(pos)
                  end)
                  if not ok_sp or typeof(sp) ~= "Vector3" then
                      sp = Vector3.new(-9999, -9999, -1)
                  end
                  if flags.RaidESP == true and sp.Z > 0 and dist <= (tonumber(flags.RaidMaxDistance) or 2000) then
                      local age = math.floor(os.clock() - (part:GetAttribute('RaidAt') or data.born))
                      data.label.Visible = true
                      data.label.Text = "Raid - " .. part.Name .. "\n" .. tostring(math.floor(dist + 0.5)) .. "m, " .. age .. "s ago"
                      data.label.TextColor3 = flags.RaidColor.Color
                      data.label.Position = UDim2.fromOffset(sp.X, sp.Y)
                  else
                      data.label.Visible = false
                  end
              end
          end
      end))
  end
  do
      local aa_spin = 0
      Run.RenderStepped:Connect(LPH_NO_VIRTUALIZE(function(dt)
          local ch = Client.Character
          local hum = ch and ch:FindFirstChildOfClass('Humanoid')
          local root = ch and ch:FindFirstChild('HumanoidRootPart')
          if not hum or not root or hum.Health <= 0 then
              return
          end
          local on = flags.AntiAim == true and bindOn(flags.AntiAim == true, "AntiAimBind")
          if not on then
              if not hum.AutoRotate then
                  hum.AutoRotate = true
              end
              return
          end
          local ls = cheat.Globals.lastShot
          if ls and ls.t and os.clock() - ls.t < 1.5 then
              if not hum.AutoRotate then
                  hum.AutoRotate = true
              end
              return
          end
          local look = Camera.CFrame.LookVector
          local base = flags.AntiAimYawBase or "Camera"
          local yaw
          if base == "Random" then
              yaw = math.rad(math.random(-180, 180))
          elseif base == "Spin" then
              aa_spin = (aa_spin + dt * 90) % 360
              yaw = math.rad(aa_spin)
          elseif base == "Targets" then
              local tp = Targeting.TargetPart
              if tp and tp.Parent then
                  local d = tp.Position - root.Position
                  yaw = math.atan2(-d.X, -d.Z)
              else
                  yaw = math.atan2(-look.X, -look.Z)
              end
          else
              yaw = math.atan2(-look.X, -look.Z)
          end
          yaw = yaw + math.rad(tonumber(flags.AntiAimYawModifier) or 0)
          local cur = select(2, root.CFrame:ToOrientation())
          local diff = math.deg(yaw - cur) % 360
          if diff > 180 then
              diff = diff - 360
          end
          local step = math.clamp(diff, -dt * 120, dt * 120)
          root.CFrame = root.CFrame * CFrame.Angles(0, math.rad(step), 0)
          hum.AutoRotate = false

          local pitch_base = flags.AntiAimPitchBase or "Nod"
          local pitch
          if pitch_base == "Down" then
              pitch = -0.7
          elseif pitch_base == "Up" then
              pitch = 0.7
          elseif pitch_base == "Random" then
              pitch = (math.random() - 0.5) * 1.4
          else
              pitch = math.sin(os.clock() * 3) * 0.7
          end
          pitch = math.clamp(pitch + math.rad(tonumber(flags.AntiAimPitchModifier) or 0), -0.79, 0.79)
          local torso = ch:FindFirstChild('TorsoController')
          local look_r = torso and torso:FindFirstChild('Look')
          if look_r then
              pcall(function()
                  look_r:FireServer(pitch, 0)
              end)
          end
      end))
  end
  do
      cheat.Globals.RaycastParams = RaycastParams.new()
      do
          local ft = Enum.RaycastFilterType.Exclude
          if not ft then
              ft = Enum.RaycastFilterType.Blacklist
          end
          cheat.Globals.RaycastParams.FilterType = ft
      end
      cheat.Globals.RaycastParams.IgnoreWater = true

      local function visFilters()
          local f = { Camera, cheat.Globals.ClientCharacter }
          local vfx = workspace:FindFirstChild("VFX")
          if vfx then
              f[#f + 1] = vfx
          end
          local drops = workspace:FindFirstChild("Drops")
          if drops then
              f[#f + 1] = drops
          end
          local plants = workspace:FindFirstChild("Plants")
          if plants then
              f[#f + 1] = plants
          end
          if VMs then
              f[#f + 1] = VMs
          end
          return f
      end

      local function vis_hit(from, to)
          local dir = to - from
          if dir.Magnitude < 0.05 then
              return nil
          end
          local filters = visFilters()
          cheat.Globals.RaycastParams.FilterDescendantsInstances = filters
          if RaycastUtil and type(RaycastUtil.Raycast) == "function" then
              local ok, inst = pcall(function()
                  return RaycastUtil:Raycast(from, dir, "Blacklist", filters)
              end)
              if ok then
                  if typeof(inst) == "Instance" then
                      return inst
                  end
                  return nil
              end
          end
          local r = workspace:Raycast(from, dir, cheat.Globals.RaycastParams)
          if not r then
              return nil
          end
          return r.Instance
      end

      local IsPartVisible = LPH_NO_VIRTUALIZE(function(Part, Origin)
          if not Part then
              return false
          end
          if typeof(Origin) == "CFrame" then
              Origin = Origin.Position
          end
          if typeof(Origin) ~= "Vector3" then
              local cam = workspace.CurrentCamera or Camera
              if cam then
                  Origin = cam.CFrame.Position
              end
          end
          if typeof(Origin) ~= "Vector3" then
              return false
          end
          local parent = Part.Parent
          local pts = {
              Part.Position,
              Part.Position + Vector3.new(0, Part.Size.Y * 0.4, 0),
          }
          if type(cheat.fastRay) == "function" then
              for i = 1, #pts do
                  local offset = pts[i] - Origin
                  if offset.Magnitude < 0.05 then
                      return true
                  end
                  local okRay, result = pcall(cheat.fastRay, Origin, offset + offset.Unit * 0.5)
                  if okRay and (result == nil or (parent and result.Instance:IsDescendantOf(parent))) then
                      return true
                  end
              end
              return false
          end
          for i = 1, #pts do
              local inst = vis_hit(Origin, pts[i])
              if typeof(inst) ~= "Instance" then
                  return true
              end
              if parent and inst:IsDescendantOf(parent) then
                  return true
              end
          end
          return false
      end)
      cheat.isPartVisible = IsPartVisible
  
      clearLos = LPH_NO_VIRTUALIZE(function(Origin, Target)
          if typeof(Origin) ~= "Vector3" or typeof(Target) ~= "Vector3" then
              return false
          end
          local inst = vis_hit(Origin, Target)
          if typeof(inst) ~= "Instance" then
              return true
          end
          local ok_ip, ipos = pcall(function() return inst.Position end)
          if ok_ip and typeof(ipos) == "Vector3" and (ipos - Target).Magnitude < 4 then
              return true
          end
          return false
      end)

      local fastParams = RaycastParams.new()
      fastParams.FilterType = Enum.RaycastFilterType.Exclude
      fastParams.IgnoreWater = true
      cheat.refreshFastFilter = function()
          local filters = visFilters()
          local animals = workspace:FindFirstChild("Animals")
          if animals then
              filters[#filters + 1] = animals
          end
          fastParams.FilterDescendantsInstances = filters
      end
      cheat.refreshFastFilter()

      cheat.fastRay = LPH_NO_VIRTUALIZE(function(origin, direction)
          local start = origin
          local remaining = direction
          for _ = 1, 4 do
              local result = workspace:Raycast(start, remaining, fastParams)
              if not result then
                  return nil
              end
              local hit = result.Instance
              if hit.Transparency < 0.95 and hit.CanCollide then
                  return result
              end
              local travelled = (result.Position - start).Magnitude + 0.02
              local length = remaining.Magnitude - travelled
              if length <= 0.02 then
                  return nil
              end
              start = result.Position + remaining.Unit * 0.02
              remaining = remaining.Unit * length
          end
          return nil
      end)

      cheat.strictClear = LPH_NO_VIRTUALIZE(function(origin, target)
          if typeof(origin) ~= "Vector3" or typeof(target) ~= "Vector3" then
              return false
          end
          local offset = target - origin
          if offset.Magnitude < 0.05 then
              return true
          end
          return cheat.fastRay(origin, offset + offset.Unit * 0.4) == nil
      end)

      cheat.serverOrigins = function()
          local character = cheat.Globals.ClientCharacter
          local root = character and character.PrimaryPart
          if not root then
              return {}
          end
          local origin = (root.CFrame * CFrame.new(0, 1.5, 0)).Position
          local okPing, ping = pcall(function() return Client:GetNetworkPing() end)
          local lag = math.clamp((okPing and type(ping) == "number" and ping or 0.1) + 0.05, 0.05, 0.35)
          local velocity = root.AssemblyLinearVelocity
          local origins = { origin }
          if velocity.Magnitude > 1 then
              origins[2] = origin - velocity * lag
              origins[3] = origin - velocity * (lag * 0.5)
          end
          return origins
      end

      cheat.manipValid = LPH_NO_VIRTUALIZE(function(candidate, target)
          for _, origin in ipairs(cheat.serverOrigins()) do
              if not cheat.strictClear(origin, candidate) then
                  return false
              end
          end
          if typeof(target) == "Vector3" then
              local flash = cheat.manipFlash and cheat.manipFlash(candidate, target) or candidate
              if not cheat.strictClear(candidate, flash) then
                  return false
              end
          end
          return true
      end)

      cheat.bulletRay = LPH_NO_VIRTUALIZE(function(origin, direction)
          local filters = { cheat.Globals.ClientCharacter, Camera }
          for _, name in ipairs({ "VFX", "Drops", "Plants" }) do
              local folder = workspace:FindFirstChild(name)
              if folder then
                  filters[#filters + 1] = folder
              end
          end
          if RaycastUtil and type(RaycastUtil.Raycast) == "function" then
              if cheat.hitFilter == nil and type(RaycastUtil.FilterFunction) == "function" then
                  local okFilter, filter = pcall(function() return RaycastUtil:FilterFunction("Hit") end)
                  cheat.hitFilter = (okFilter and type(filter) == "function") and filter or false
              end
              local ok, hit, position = pcall(function()
                  return RaycastUtil:Raycast(origin, direction, "Blacklist", filters, nil, cheat.hitFilter or nil, true)
              end)
              if ok then
                  if typeof(hit) == "Instance" then
                      return hit, typeof(position) == "Vector3" and position or origin + direction
                  end
                  return nil
              end
          end
          cheat.Globals.RaycastParams.FilterDescendantsInstances = filters
          local result = workspace:Raycast(origin, direction, cheat.Globals.RaycastParams)
          if result then
              return result.Instance, result.Position
          end
          return nil
      end)

      cheat.simulatePath = LPH_NO_VIRTUALIZE(function(origin, direction, speed, gravity, maxRange, targetCharacter, targetPoint)
          if typeof(origin) ~= "Vector3" or typeof(direction) ~= "Vector3" or type(speed) ~= "number" or speed <= 1 then
              return false, math.huge
          end
          gravity = type(gravity) == "number" and gravity or 0
          maxRange = type(maxRange) == "number" and maxRange or 1000
          local step = 1 / 60
          local position = origin
          local velocity = direction.Unit * speed
          local travelled = 0
          local closest = math.huge
          for _ = 1, 400 do
              local length = math.min(speed * step, maxRange - travelled)
              if length <= 0.05 then
                  break
              end
              local segment = velocity.Unit * length
              if typeof(targetPoint) == "Vector3" then
                  local toTarget = targetPoint - position
                  local along = math.clamp(toTarget:Dot(segment.Unit), 0, length)
                  closest = math.min(closest, (position + segment.Unit * along - targetPoint).Magnitude)
              end
              local hitInstance, hitPosition = cheat.bulletRay(position, segment)
              if hitInstance then
                  local hitTarget = targetCharacter ~= nil and hitInstance:IsDescendantOf(targetCharacter)
                  return hitTarget, closest, hitPosition
              end
              position = position + segment
              travelled = travelled + length
              velocity = velocity - Vector3.new(0, 196.2 * gravity, 0) * step
          end
          return false, closest, position
      end)

      local GetDistanceFromCenter = LPH_NO_VIRTUALIZE(function(part)
          local position = part
          if typeof(part) == "Instance" then position = part.CFrame.Position end
          local sp, on = Camera:WorldToViewportPoint(position)
          if not on then return math.huge end
          local c = Vector2.new(Camera.ViewportSize.X * 0.5, Camera.ViewportSize.Y * 0.5)
          return (c - Vector2.new(sp.X, sp.Y)).Magnitude
      end)
  

      local hitscanPartNames = { "Head", "UpperTorso", "HumanoidRootPart", "LowerTorso", "Torso", "LeftUpperArm", "RightUpperArm", "LeftUpperLeg", "RightUpperLeg", "LeftLowerLeg", "RightLowerLeg", "LeftFoot", "RightFoot" }
      local findHitscanPoint = LPH_NO_VIRTUALIZE(function(character, root, hitPart)
          if not (character and character.Parent and hitPart and hitPart.Parent) then
              return nil
          end
          local stats = cheat.Globals.bulletStats
          local myCharacter = Client.Character
          local myRoot = myCharacter and myCharacter:FindFirstChild("HumanoidRootPart")
          if not (stats and myRoot and type(cheat.simulatePath) == "function" and type(cheat.solveAim) == "function") then
              return nil
          end
          local eye = (myRoot.CFrame * CFrame.new(0, 1.5, 0)).Position
          local toTarget = hitPart.Position - eye
          if toTarget.Magnitude > stats.range then
              return nil
          end
          local flat = Vector3.new(toTarget.X, 0, toTarget.Z)
          local origin = eye + (flat.Magnitude > 0.05 and flat.Unit * 2 or Vector3.zero) + Vector3.new(0, -0.3, 0)
          local function reaches(point)
              local okAim, aimPoint = pcall(cheat.solveAim, origin, point, stats.speed, stats.gravity)
              if not okAim or typeof(aimPoint) ~= "Vector3" then
                  aimPoint = point
              end
              local direction = aimPoint - origin
              if direction.Magnitude < 0.05 then
                  return false
              end
              local okSim, reached = pcall(cheat.simulatePath, origin, direction.Unit, stats.speed, stats.gravity, stats.range, character, point)
              return okSim and reached == true
          end
          if reaches(hitPart.Position) then
              return nil
          end
          for _, name in ipairs(hitscanPartNames) do
              local part = character:FindFirstChild(name)
              if part and part:IsA("BasePart") then
                  local halfHeight = part.Size.Y * 0.3
                  for _, offset in ipairs({ Vector3.zero, Vector3.new(0, halfHeight, 0), Vector3.new(0, -halfHeight, 0) }) do
                      local point = part.Position + offset
                      if reaches(point) then
                          return point
                      end
                  end
              end
          end
          return nil
      end)

      cheat.streamTarget = function(position)
          if typeof(position) ~= "Vector3" or not workspace.StreamingEnabled then
              return
          end
          local now = os.clock()
          if now - (cheat.Globals.lastStreamRequest or 0) < 1.5 then
              return
          end
          cheat.Globals.lastStreamRequest = now
          task.spawn(pcall, function()
              Client:RequestStreamAroundAsync(position, 2)
          end)
      end

      local manipOffsets = {}
      do
          for _, radius in ipairs({ 3, 5.5, 8, 10 }) do
              for _, height in ipairs({ 0, 3, 6 }) do
                  for index = 0, 15 do
                      local angle = index * math.pi / 8
                      local offset = Vector3.new(math.sin(angle) * radius, height, -math.cos(angle) * radius)
                      if offset.Magnitude <= 10.5 then
                          manipOffsets[#manipOffsets + 1] = offset
                      end
                  end
              end
          end
          for _, height in ipairs({ 3, 5, 7.5, 10 }) do
              manipOffsets[#manipOffsets + 1] = Vector3.new(0, height, 0)
          end
      end

      cheat.manipFlash = function(candidate, target)
          local flatTarget = Vector3.new(target.X, candidate.Y, target.Z)
          if (flatTarget - candidate).Magnitude < 0.05 then
              return candidate
          end
          return (CFrame.lookAt(candidate, flatTarget) * CFrame.new(0.5, -0.3, -2)).Position
      end

      cheat.ballisticReach = LPH_NO_VIRTUALIZE(function(origin, point, character)
          local stats = cheat.Globals.bulletStats
          if not stats then
              return nil
          end
          if (point - origin).Magnitude > stats.range then
              return false
          end
          local okAim, aimPoint = pcall(cheat.solveAim, origin, point, stats.speed, stats.gravity)
          if not okAim or typeof(aimPoint) ~= "Vector3" then
              aimPoint = point
          end
          local direction = aimPoint - origin
          if direction.Magnitude < 0.05 then
              return false
          end
          local okSim, reached = pcall(cheat.simulatePath, origin, direction.Unit, stats.speed, stats.gravity, stats.range, character, point)
          return okSim and reached == true
      end)

      local manipBodyParts = { "Head", "UpperTorso", "Torso", "HumanoidRootPart", "LowerTorso" }

      local findVisiblePosition
      findVisiblePosition = LPH_NO_VIRTUALIZE(function(part)
          if not (part and part.Parent) then
              return nil
          end
          local character = cheat.Globals.ClientCharacter
          local myRoot = character and character.PrimaryPart
          if not myRoot then
              return nil
          end
          cheat.refreshFastFilter()
          local origin = (myRoot.CFrame * CFrame.new(0, 1.5, 0)).Position
          local target = part.Position
          local targetModel = part.Parent
          local flat = Vector3.new(target.X - origin.X, 0, target.Z - origin.Z)
          local forward = flat.Magnitude > 0.05 and flat.Unit or Vector3.new(0, 0, -1)
          local right = forward:Cross(Vector3.new(0, 1, 0))
          local far = flat.Magnitude > 150 and cheat.Globals.bulletStats ~= nil
          local points = { part.Position }
          for _, name in ipairs(manipBodyParts) do
              local body = targetModel:FindFirstChild(name)
              if body and body:IsA("BasePart") and body ~= part then
                  points[#points + 1] = body.Position
              end
          end
          local candidates = {}
          for _, offset in ipairs(manipOffsets) do
              local world = right * offset.X + Vector3.new(0, offset.Y, 0) - forward * offset.Z
              local towardTarget = world.Magnitude > 0.01 and forward:Dot(world.Unit) or 0
              candidates[#candidates + 1] = { world = world, score = world.Magnitude - towardTarget * 1.5 }
          end
          table.sort(candidates, function(left, rightItem) return left.score < rightItem.score end)
          local simulations = 0
          for _, item in ipairs(candidates) do
              local candidate = origin + item.world
              if cheat.strictClear(origin, candidate) then
                  local flash = cheat.manipFlash(candidate, target)
                  if cheat.strictClear(candidate, flash) then
                      for _, point in ipairs(points) do
                          local toPoint = point - flash
                          local blocker = cheat.fastRay(flash, toPoint + toPoint.Unit * 0.5)
                          if not blocker or blocker.Instance:IsDescendantOf(targetModel) then
                              if not far then
                                  if cheat.manipValid(candidate, target) then
                                      return candidate, point
                                  end
                                  break
                              end
                              if simulations < 24 then
                                  simulations = simulations + 1
                                  if cheat.ballisticReach(flash, point, targetModel) and cheat.manipValid(candidate, target) then
                                      return candidate, point
                                  end
                              end
                          end
                      end
                  end
              end
          end
          return nil
      end)
      cheat.findVisiblePosition = findVisiblePosition

      Run.Heartbeat:Connect(LPH_NO_VIRTUALIZE(function()
          cheat.Globals.RaycastParams.FilterDescendantsInstances = visFilters()
  
          local Silent = bindOn(flags.AimbotEnabled == true, "AimbotBind")
          local TargetParts = flags.TargetParts
          local part_list = {}
          if type(TargetParts) == "table" then
              for k, v in pairs(TargetParts) do
                  if type(k) == "number" and type(v) == "string" then
                      part_list[#part_list + 1] = v
                  elseif type(k) == "string" and v then
                      part_list[#part_list + 1] = k
                  end
              end
          end
          local DesiredPartName = "Head"
          if #part_list > 0 then
              DesiredPartName = part_list[math.random(#part_list)]
          end
          local ManipulationActive = Silent and bindOn(flags.Manipulation == true, "ManipulationBind") or false
          local DownCheck = flags.DownCheck == true
          local ClosestDistance = flags.FovSize
          if type(ClosestDistance) ~= "number" or ClosestDistance <= 0 then
              ClosestDistance = 200
          end
  
          local ClosestTarget = nil
          local EntityCharacter = nil
          local EntityData = nil
          local EntityInstance = nil
          local Manipulated = false
          local Visible = false
          local ManipulatedPart, ManipulatedPosition, ManipulatedPlayer = nil, nil, nil
          local ScannedPosition = nil
          
          local now = tick()
  
          for Entity, Object in pairs(Targeting.Targets) do
              if not Object then continue end
              if not Object.Character or not Object.Character.Parent then
                  Object.Character = (Object.Class == "Player" and Object.Player.Character) or nil
              end
              if Object.Class ~= "Player" and not Object.Character then
                  Targeting.Targets[Entity] = nil
                  continue
              end
  
              local character = Object.Character
              if not character or not character.Parent then
                  Object.CoreInformation = { Visible = false, OnScreen = false, Root = nil }
                  continue
              end
  
              if now - (Object.LastUpdate or 0) > 1/30 then
                  Object.LastUpdate = now
                  local Humanoid = character:FindFirstChildOfClass("Humanoid")
                  if Humanoid then Object.Humanoid = Humanoid end
                  if Object.Class == "Player" or Object.Class == "AI" then
                      Object.Root = (Humanoid and Humanoid.RootPart) or character:FindFirstChild("HumanoidRootPart")
                  end
                  if not Object.Root then
                      Object.Root = character:FindFirstChild("RootPart") or character:FindFirstChild("HumanoidRootPart")
                  end
  
                  local root = Object.Root
                  if not root then
                      Object.CoreInformation = { Visible = false, OnScreen = false, Root = nil }
                  elseif (Camera.CFrame.Position - root.Position).Magnitude > 2000 then
                      Object.CoreInformation = { Visible = false, OnScreen = false, Root = root }
                  else
                      local parts = character:GetChildren()
                      local inf = math.huge
                      local minx, miny, minz = inf, inf, inf
                      local maxx, maxy, maxz = -inf, -inf, -inf
                      local rc = root.CFrame
                      for _, Part in ipairs(parts) do
                          if Part:IsA("BasePart") then
                              local Cf = rc:ToObjectSpace(Part.CFrame)
                              local sx, sy, sz = Part.Size.X, Part.Size.Y, Part.Size.Z
                              local X, Y, Z, R00, R01, R02, R10, R11, R12, R20, R21, R22 = Cf:components()
                              local wsx = 0.5 * (math.abs(R00) * sx + math.abs(R01) * sy + math.abs(R02) * sz)
                              local wsy = 0.5 * (math.abs(R10) * sx + math.abs(R11) * sy + math.abs(R12) * sz)
                              local wsz = 0.5 * (math.abs(R20) * sx + math.abs(R21) * sy + math.abs(R22) * sz)
                              minx = math.min(minx, X - wsx) ; miny = math.min(miny, Y - wsy) ; minz = math.min(minz, Z - wsz)
                              maxx = math.max(maxx, X + wsx) ; maxy = math.max(maxy, Y + wsy) ; maxz = math.max(maxz, Z + wsz)
                          end
                      end
                      local minv = Vector3.new(minx, miny, minz)
                      local maxv = Vector3.new(maxx, maxy, maxz)
                      local middle = (maxv + minv) * 0.5
                      local cf = rc - rc.Position + rc * middle
                      local half = (maxv - minv) * 0.5
                      local hx, hy, hz = math.min(half.X, 5), math.min(half.Y, 10), math.min(half.Z, 5)
                      local offsets = {
                          Vector3.new( hx,  hy,  hz), Vector3.new( hx,  hy, -hz),
                          Vector3.new( hx, -hy,  hz), Vector3.new( hx, -hy, -hz),
                          Vector3.new(-hx,  hy,  hz), Vector3.new(-hx,  hy, -hz),
                          Vector3.new(-hx, -hy,  hz), Vector3.new(-hx, -hy, -hz),
                      }
                      local on = false
                      for i = 1, 8 do
                          local _, s = Camera:WorldToViewportPoint(cf * offsets[i])
                          if s then on = true break end
                      end
  
                      if not on then
                          local head = character:FindFirstChild("Head")
                          local vis = head and IsPartVisible(head) or false
                          Object.CoreInformation = { Root = root, RootPosition = root.Position, OnScreen = false, Visible = vis, VisiblePart = vis and head or nil }
                      else
                          if character:FindFirstChild(DesiredPartName) and IsPartVisible(character[DesiredPartName]) then
                              Object.CoreInformation = { Visible = true, VisiblePart = character[DesiredPartName], Root = root, RootPosition = root.Position, OnScreen = on }
                          else
                              local visPart = nil
                              local names = { "HumanoidRootPart", "RightLowerLeg", "LeftLowerLeg", "RightUpperArm", "LeftUpperArm" }
                              for _, n in ipairs(names) do
                                  local p = character:FindFirstChild(n)
                                  if p and p:IsA("BasePart") and IsPartVisible(p) then visPart = p break end
                              end
                              Object.CoreInformation = { Visible = visPart ~= nil, VisiblePart = visPart, Root = root, RootPosition = root.Position, OnScreen = on }
                          end
                      end
                  end
              end
  
              local Core = Object.CoreInformation
               if not flags.TargetTeammates and isTeam(Entity) then continue end
                if not (Core and Core.Root and Entity ~= Client) then continue end
                if not (Core.OnScreen and not Object.Teammate and flags.AimbotEnabled) then continue end

               local humanoid = character:FindFirstChildOfClass("Humanoid")
               if not humanoid or humanoid.Health <= 0 then continue end
                if DownCheck and humanoid:GetAttribute('Downed') then continue end

                local tpart = character:FindFirstChild(DesiredPartName)
              if not tpart then
                  tpart = Core.VisiblePart or character:FindFirstChild("HumanoidRootPart") or character:FindFirstChild("Head")
              end
  
              if cheat.Globals.DesyncedPositions[character] and cheat.Globals.DesyncParts[character] then
                  tpart = cheat.Globals.DesyncParts[character]
              end
  
              if character.Name == "BTR" then
                  tpart = character:FindFirstChild("HumanoidRootPart")
              end
  
              if tpart then
                  local vp = Camera:WorldToViewportPoint(tpart.Position)
                  if vp.Z > 0 then
                      local mouse = UIS:GetMouseLocation()
                      local dist = math.sqrt((vp.X - mouse.X) ^ 2 + (vp.Y - mouse.Y) ^ 2)
                      if dist <= ClosestDistance then
                          ClosestDistance = dist
                          ClosestTarget  = tpart
                          EntityCharacter = character
                          EntityData      = Object
                          EntityInstance  = Entity
                          Visible         = Core.Visible
                      end
                  end
              end
          end
  
          if ManipulationActive and ClosestTarget and EntityData and cheat.Globals.ClientCharacter then
              if now - (EntityData.LastManip or 0) > 0.08 then
                  EntityData.LastManip = now
                  local ch = cheat.Globals.ClientCharacter
                  local hrp = ch.PrimaryPart or ch:FindFirstChild("HumanoidRootPart")
                  if hrp then
                      local eye = (hrp.CFrame * CFrame.new(0, 1.5, 0)).Position
                      local needsManip = not IsPartVisible(ClosestTarget, eye)
                      if not needsManip and cheat.Globals.bulletStats and (ClosestTarget.Position - eye).Magnitude > 150 then
                          local flatToTarget = Vector3.new(ClosestTarget.Position.X - eye.X, 0, ClosestTarget.Position.Z - eye.Z)
                          local flash = eye + (flatToTarget.Magnitude > 0.05 and flatToTarget.Unit * 2 or Vector3.zero) + Vector3.new(0, -0.3, 0)
                          needsManip = cheat.ballisticReach(flash, ClosestTarget.Position, EntityCharacter) == false
                      end
                      EntityData.ManipHitPoint = nil
                      if needsManip then
                          local ok_sp, sp, reachedPoint = false, nil, nil
                          local kept = EntityData.StableManip
                          if kept and kept.part == ClosestTarget and now - kept.t < 1.5 then
                              local candidate = eye + kept.offset
                              local point = ClosestTarget.Position + kept.hit
                              local flash = cheat.manipFlash(candidate, point)
                              local toPoint = point - flash
                              local okRay, blocker = pcall(cheat.fastRay, flash, toPoint + toPoint.Unit * 0.5)
                              if okRay and (not blocker or blocker.Instance:IsDescendantOf(EntityCharacter)) and cheat.manipValid(candidate, point) then
                                  ok_sp, sp, reachedPoint = true, candidate, point
                              end
                          end
                          if not sp then
                              ok_sp, sp, reachedPoint = pcall(findVisiblePosition, ClosestTarget)
                              if ok_sp and typeof(sp) == "Vector3" then
                                  EntityData.StableManip = { part = ClosestTarget, offset = sp - eye, hit = typeof(reachedPoint) == "Vector3" and (reachedPoint - ClosestTarget.Position) or Vector3.zero, t = now }
                              else
                                  EntityData.StableManip = nil
                              end
                          end
                          if not ok_sp then
                              sp = nil
                              if os.clock() - (cheat.Globals.lastB2 or 0) > 5 then
                                  cheat.Globals.lastB2 = os.clock()
                                  cheat.log("manip", "scan skipped, retrying")
                              end
                          end
                          if typeof(sp) == "Vector3" then
                              EntityData.ManipHitPoint = typeof(reachedPoint) == "Vector3" and (reachedPoint - ClosestTarget.Position) or nil
                              Manipulated = true
                              ManipulatedPart = ClosestTarget
                              ScannedPosition = sp
                              ManipulatedPlayer = EntityData.Pointer
                          end
                      end
                  end

                  EntityData.LastManipCFG = {
                      Manipulated = Manipulated,
                      ManipulatedPosition = ManipulatedPosition,
                      ScannedPosition = ScannedPosition,
                      ManipulatedPart = ManipulatedPart,
                      ManipulatedPlayer = ManipulatedPlayer,
                  }
              elseif EntityData.LastManipCFG then
                  Manipulated = EntityData.LastManipCFG.Manipulated
                  ManipulatedPosition = EntityData.LastManipCFG.ManipulatedPosition
                  ScannedPosition = EntityData.LastManipCFG.ScannedPosition
                  ManipulatedPart = EntityData.LastManipCFG.ManipulatedPart
                  ManipulatedPlayer = EntityData.LastManipCFG.ManipulatedPlayer
              end
          end

          local scanPoint = nil
          if Silent and ClosestTarget and EntityCharacter and EntityData and bindOn(flags.Hitscan == true, "HitscanBind") then
              local lastScan = EntityData.lastHitscanAt or 0
              if os.clock() - lastScan > 0.25 then
                  EntityData.lastHitscanAt = os.clock()
                  local targetRoot = EntityCharacter:FindFirstChild("HumanoidRootPart")
                  local okScan, point = pcall(findHitscanPoint, EntityCharacter, targetRoot, ClosestTarget)
                  EntityData.lastHitscanPoint = (okScan and point) or nil
              end
              scanPoint = EntityData.lastHitscanPoint
          end
          Targeting.HitscanPoint = scanPoint
          if ClosestTarget and (Camera.CFrame.Position - ClosestTarget.Position).Magnitude > 300 then
              cheat.streamTarget(ClosestTarget.Position)
          end
          Targeting.TargetPart = ClosestTarget
          Targeting.TargetCharacter = EntityCharacter
          Targeting.TargetObject = EntityData
          Targeting.Visible = Visible
          Targeting.ManipulatedPosition = Manipulated and ManipulatedPosition or nil
          Targeting.ManipPos = Targeting.ManipulatedPosition
          Targeting.ManipulatedOrigin = Targeting.ManipulatedPosition
          Targeting.ScannedPosition = Manipulated and ScannedPosition or nil
          Targeting.ManipHitOffset = (Manipulated and EntityData and EntityData.ManipHitPoint) or nil
          Targeting.ManipulatedPosition = ManipulatedPosition
          if Targeting.ManipulatedPosition == nil and Targeting.ScannedPosition ~= nil then
              Targeting.ManipulatedPosition = Targeting.ScannedPosition
          end
          Targeting.PitchOffset = nil
          if EntityData and EntityData.Class == "Player" and EntityData.Player then
              local head = EntityCharacter and EntityCharacter:FindFirstChild("Head")
              if flags.PitchResolver == true and head and ClosestTarget == head then
                  local pitch = get_player_pitch_resolved(EntityData.Player, head)
                  if pitch == "up" then
                      Targeting.PitchOffset = Vector3.new(0, 0.5, 0)
                  elseif pitch == "down" then
                      Targeting.PitchOffset = Vector3.new(0, -0.5, 0)
                  end
              end
          end
      end))
  
      for _, Player in ipairs(Players:GetPlayers()) do
          if Player ~= Client then
              Targeting.Targets[Player] = {
                  Class = "Player",
                  Player = Player,
                  Character = Player.Character,
                  LastUpdate = 0,
                  Root = nil,
                  CoreInformation = { Visible = false, OnScreen = false, Root = nil },
              }
          end
      end
  
      Players.PlayerAdded:Connect(function(Player)
          if Player ~= Client then
              Targeting.Targets[Player] = {
                  Class = "Player",
                  Player = Player,
                  Character = Player.Character,
                  LastUpdate = 0,
                  Root = nil,
                  CoreInformation = { Visible = false, OnScreen = false, Root = nil },
              }
          end
      end)
  
      Players.PlayerRemoving:Connect(function(Player)
          Targeting.Targets[Player] = nil
      end)
      
      local SoldierClassType = {
              Brutus = "Boss",
              Bruno = "Boss",
              BTR = "Boss",
              Boris = "Boss",
              Soldier = "AI",
        }
  
        local Military = workspace:FindFirstChild("Military")
        if Military then
              local Events = workspace:FindFirstChild("Events")
              local CacheSoldier = function(Soldier)
                    local ClassType = SoldierClassType[Soldier.Name]
                    if not ClassType then return end
              
              if Targeting.Targets[Soldier] then return end
              Soldier.AncestryChanged:Connect(function()
                  if not Soldier:IsDescendantOf(workspace) then
                      Targeting.Targets[Soldier] = nil
                  end
              end)
              Targeting.Targets[Soldier] = {
                  Class = ClassType,
                  Player = Soldier,
                  Character = Soldier,
                  LastUpdate = 0,
                  Root = nil,
                  CoreInformation = { Visible = false, OnScreen = false, Root = nil },
              }
              end;
  
              if Events then
              for Index, BTR in Events:GetChildren() do
                    if BTR.Name == "BTR" then
                          CacheSoldier(BTR)
                    end;
              end;
  
              Events.ChildAdded:Connect(function(BTR)
                    task.wait(1)
                    if BTR.Name == "BTR" then
                          CacheSoldier(BTR)
                    end;
              end)
              end
  
              for _, Folder in Military:GetChildren() do
                    for Index, Soldier in Folder:GetChildren() do
                          if Soldier:IsA("Model") then
                                CacheSoldier(Soldier)
                          end;
                    end;
  
                    Folder.ChildAdded:Connect(function(Soldier)
                          task.wait(1)
                          if Soldier:IsA("Model") then
                                CacheSoldier(Soldier)
                          end;
                    end)
              end;
        end;
  end
  
  do 
      do
          local Keys = Enum.KeyCode
          local fc_cf, fc_type, fc_subj, fc_root
          local fall_busy = false

          Run:BindToRenderStep("fc_zoom", Enum.RenderPriority.Camera.Value + 1, LPH_NO_VIRTUALIZE(function()
              local cam = workspace.CurrentCamera
              if not cam then
                  return
              end
              if bindOn(flags.ZoomEnabled, "ZoomKeybind") then
                  local v = tonumber(flags.ZoomAmount) or 30
                  if v < 1 then
                      v = 1
                  end
                  if v > 120 then
                      v = 120
                  end
                  cam.FieldOfView = v
              end
          end))

          Run.Heartbeat:Connect(LPH_NO_VIRTUALIZE(function(dt)
              local Character = cheat.Globals.ClientCharacter
              local Humanoid = Character and Character:FindFirstChildOfClass("Humanoid")
              local Root = Character and (Character:FindFirstChild("HumanoidRootPart") or (Humanoid and Humanoid.RootPart))
              if not (Character and Humanoid and Root) or Humanoid.Health <= 0 then
                  return
              end
              local cam = workspace.CurrentCamera or Camera
              local cf = cam.CFrame
              local flying = bindOn(flags.FlightEnabled, "FlightBind")
              local speed_on = bindOn(flags.SpeedEnabled, "SpeedBind")
              local freecam_on = bindOn(flags.Freecam, "FreecamKeybind")

              if speed_on and not flying then
                  local x, z = 0, 0
                  if UIS:IsKeyDown(Keys.D) then
                      x = x + 1
                  end
                  if UIS:IsKeyDown(Keys.A) then
                      x = x - 1
                  end
                  if UIS:IsKeyDown(Keys.W) then
                      z = z + 1
                  end
                  if UIS:IsKeyDown(Keys.S) then
                      z = z - 1
                  end
                  if x ~= 0 or z ~= 0 then
                      local forward = Vector3.new(cf.LookVector.X, 0, cf.LookVector.Z)
                      local right = Vector3.new(cf.RightVector.X, 0, cf.RightVector.Z)
                      if forward.Magnitude > 0 then
                          forward = forward.Unit
                      end
                      if right.Magnitude > 0 then
                          right = right.Unit
                      end
                      local move = (right * x + forward * z)
                      if move.Magnitude > 0 then
                          move = move.Unit * (tonumber(flags.SpeedSpeed) or 16)
                          Root.Velocity = Vector3.new(move.X, Root.Velocity.Y, move.Z)
                      end
                  end
              end

              local omni_on = bindOn(flags.OmniSprint, "OmniSprintBind")
              if omni_on and not flying then
                  local md = Humanoid.MoveDirection
                  if md.Magnitude > 0.01 then
                      local dir = md.Unit
                      local spd = tonumber(flags.OmniSprintSpeed) or 24
                      local airState = Humanoid:GetState()
                      if airState == Enum.HumanoidStateType.Jumping or airState == Enum.HumanoidStateType.Freefall then
                          spd = spd * 0.75
                      end
                      Root.Velocity = Vector3.new(dir.X * spd, Root.Velocity.Y, dir.Z * spd)
                  end
              end

              if flags.Bunnyhop and Humanoid.FloorMaterial ~= Enum.Material.Air and UIS:IsKeyDown(Keys.Space) then
                  Humanoid.Jump = true
              end

              if flying then
                  local look = cf.LookVector
                  local right = cf.RightVector
                  local move = Vector3.zero
                  if UIS:IsKeyDown(Keys.W) then
                      move = move + Vector3.new(look.X, 0, look.Z)
                  end
                  if UIS:IsKeyDown(Keys.S) then
                      move = move - Vector3.new(look.X, 0, look.Z)
                  end
                  if UIS:IsKeyDown(Keys.A) then
                      move = move - Vector3.new(right.X, 0, right.Z)
                  end
                  if UIS:IsKeyDown(Keys.D) then
                      move = move + Vector3.new(right.X, 0, right.Z)
                  end
                  if UIS:IsKeyDown(Keys.Space) then
                      move = move + Vector3.new(0, 1, 0)
                  end
                  if UIS:IsKeyDown(Keys.LeftControl) then
                      move = move + Vector3.new(0, -1, 0)
                  end
                  if move.Magnitude > 0 then
                      move = move.Unit
                  end
                  local pos = Root.CFrame.Position + move * (dt * (tonumber(flags.FlightSpeed) or 7) * 3)
                  Humanoid.PlatformStand = false
                  Root.Velocity = Vector3.zero
                  Root.CFrame = CFrame.new(pos, pos + Vector3.new(look.X, 0, look.Z))
              end

              if freecam_on and not flying then
                  if not fc_cf then
                      fc_cf = cam.CFrame
                      fc_type = cam.CameraType
                      fc_subj = cam.CameraSubject
                      fc_root = Root
                      Root.Anchored = true
                      cam.CameraType = Enum.CameraType.Scriptable
                      cam.CFrame = CFrame.new(cam.CFrame.Position, cam.CFrame.Position + cam.CFrame.LookVector)
                  end
                  local md = UIS:GetMouseDelta()
                  local ncf = cam.CFrame
                  ncf = ncf * CFrame.Angles(-math.rad(md.Y), 0, 0)
                  ncf = CFrame.Angles(0, -math.rad(md.X), 0) * (ncf - ncf.Position) + ncf.Position
                  cam.CFrame = CFrame.new(ncf.Position, ncf.Position + ncf.LookVector)
                  local spd = (tonumber(flags.FreecamSpeed) or 10) * 0.5
                  if UIS:IsKeyDown(Keys.LeftShift) then
                      spd = spd * 0.25
                  end
                  local mv = Vector3.new(
                      (UIS:IsKeyDown(Keys.D) and 1 or 0) + (UIS:IsKeyDown(Keys.A) and -1 or 0),
                      0,
                      (UIS:IsKeyDown(Keys.S) and 1 or 0) + (UIS:IsKeyDown(Keys.W) and -1 or 0)
                  )
                  if mv.Magnitude > 0 then
                      cam.CFrame = cam.CFrame * CFrame.new(mv.Unit * spd)
                  end
                  local vert = (UIS:IsKeyDown(Keys.Space) and 1 or 0) + (UIS:IsKeyDown(Keys.LeftControl) and -1 or 0)
                  if vert ~= 0 then
                      cam.CFrame = cam.CFrame + Vector3.new(0, vert * spd, 0)
                  end
              elseif fc_cf then
                  if fc_root and fc_root.Parent then
                      fc_root.Anchored = false
                  end
                  cam.CameraType = fc_type or Enum.CameraType.Custom
                  cam.CameraSubject = fc_subj
                  cam.CFrame = fc_cf
                  fc_cf, fc_type, fc_subj, fc_root = nil, nil, nil, nil
              end

              if isRemoved("No Fall Damage") and not flying and not fall_busy then
                  local humanoid = Character:FindFirstChildOfClass("Humanoid")
                  if humanoid and humanoid:GetState() == Enum.HumanoidStateType.Freefall then
                      fall_busy = true
                      task.spawn(function()
                          local current = Root.AssemblyLinearVelocity
                          Root.AssemblyLinearVelocity = Vector3.new(0, -9e9, 0)
                          Run.RenderStepped:Wait()
                          Root.AssemblyLinearVelocity = Vector3.new(current.X, math.clamp(current.Y, -7.5, 0), current.Z)
                          fall_busy = false
                      end)
                  end
              end
          end))
      end
  end
  
  do
      local penSkip = {
          Military = true,
          Events = true,
          Animals = true,
          VFX = true,
          Camera = true,
          Terrain = true,
      }

      local function hasHumanoid(x)
          return x and x:FindFirstChildOfClass("Humanoid") ~= nil
      end

      local oldRaycast
      oldRaycast = hookModule(RaycastUtil, "Raycast", LPH_NO_VIRTUALIZE(function(self, ...)
          local Arguments = {...}

          if not checkcaller() then
              if flags.AimbotEnabled == true and bindOn(true, "AimbotBind") then
                  local tp = Targeting.TargetPart
                  if tp and tp.Parent then
                      local okTrace, trace = pcall(debug.traceback)
                      if okTrace and tostring(trace):find("MouseRaycast", 1, true) then
                          local okPos, partPos = pcall(function() return tp.Position end)
                          if okPos and typeof(partPos) == "Vector3" then
                              local chance = tonumber(flags.HitChance) or 100
                              if (math.floor(Random.new():NextNumber(0, 1) * 100) / 100) <= (chance / 100) then
                                  cheat.Globals.lastMouseHit = { pos = partPos, t = os.clock() }
                                  return tp, partPos, Vector3.new(0, 1, 0), Enum.Material.Plastic
                              end
                          end
                      end
                  end
              end
              if ownFlash() and flags.Reach then
                  if typeof(Arguments[2]) == "Vector3" then
                      Arguments[2] = Arguments[2] * 10
                  end
              end


              local sync = cheat.Globals.ownProjectile
              local tp = Targeting.TargetPart
              if sync and sync.hit == true and not sync.consumed and tp and tp.Parent then
                  local ibOn = bindOn(flags.InstantBullet == true, "InstantBulletBind")
                  local rewrite = ibOn or sync.mode == "manip" or sync.mode == "scan"
                  if rewrite then
                      local okTrace, trace = pcall(debug.traceback)
                      if okTrace and tostring(trace):find("VFXModule", 1, true) then
                          local result = {oldRaycast(self, unpack(Arguments))}
                          local hitPart = result[1]
                          local targetModel = tp.Parent
                          local onTarget = hitPart and typeof(hitPart) == "Instance" and targetModel and hitPart:IsDescendantOf(targetModel)
                          cheat.debugWrite("ray", "origin", Arguments[1], "dir", Arguments[2], "hit", result[1], result[2])
                          if onTarget then
                              sync.consumed = true
                              return unpack(result)
                          end
                          local okPos, partPos = pcall(function() return tp.Position end)
                          if okPos and typeof(partPos) == "Vector3" then
                              local from = sync.origin or partPos
                              local normal = from - partPos
                              normal = normal.Magnitude > 0.01 and normal.Unit or Vector3.yAxis
                              sync.consumed = true
                              cheat.log("shot", "hit " .. tp.Name .. " (" .. tostring(sync.mode) .. (ibOn and ", instant" or "") .. ")")
                              cheat.debugWrite("ray-rewrite", tp, partPos + normal * 0.05)
                              return tp, partPos + normal * 0.05, normal, tp.Material
                          end
                          return unpack(result)
                      end
                  end
              end
              if flags.PerfectFarm then
                  local Output = {oldRaycast(self, unpack(Arguments))}
                  local HitInstance = Output[1]
                  local HitPosition = Output[2]

                  if HitInstance and typeof(HitInstance) == "Instance" and HitPosition and typeof(HitPosition) == "Vector3" then
                      local Model = HitInstance.Parent
                      if Model and Model:IsA("Model") then
                          local Folder = Model.Parent
                          if Folder and Folder:IsA("Folder") and (Folder.Name == "Trees" or Folder.Name == "Nodes") then
                              local CriticalPart = Model:FindFirstChild("NodeSpark") or Model:FindFirstChild("TreeX")
                              if CriticalPart and CriticalPart:IsA("Model") and CriticalPart.PrimaryPart then
                                  Output[1] = CriticalPart.PrimaryPart
                                  return unpack(Output)
                              end
                          end
                      end
                  end

                  return unpack(Output)
              end
          end

          return oldRaycast(self, unpack(Arguments))
      end))
  
      if SoundModule and type(SoundModule.PlayDuplicateSound) == "function" then
          local playDuplicate
          playDuplicate = hookModule(SoundModule, "PlayDuplicateSound", function(self, sound, ...)
              if flags.ShootSound == true and typeof(sound) == "Instance" and sound:IsA("Sound")
                  and sound.Name:sub(-5) == "Shoot" and Client.Character and sound:IsDescendantOf(Client.Character) then
                  local soundId = cheat.Globals.HitSoundIds[flags.ShootSoundSelect]
                  if soundId then
                      local custom = Instance.new("Sound")
                      custom.SoundId = soundId
                      custom.Volume = tonumber(flags.ShootSoundVolume) or 0.5
                      custom.PlayOnRemove = true
                      custom.Parent = workspace
                      custom:Destroy()
                      return
                  end
              end
              return playDuplicate(self, sound, ...)
          end)
      end

      local hitsoundsbind = Instance.new('BindableEvent', game:GetService('ReplicatedStorage'))
      local bullettracersbind = Instance.new('BindableEvent', game:GetService('ReplicatedStorage'))
      hitsoundsbind.Event:Connect(function()
          if flags.Hitsounds and flags.HitsoundSelect and cheat.Globals.HitSoundIds[flags.HitsoundSelect] then
              local sound = Instance.new("Sound")
              sound.SoundId = cheat.Globals.HitSoundIds[flags.HitsoundSelect]
              sound.Volume = flags.HitsoundVolume
              sound.PlayOnRemove = true
              sound.Parent = workspace
              sound:Destroy()
          end
      end)
  
      bullettracersbind.Event:Connect(function(position)
          if (not flags.BulletTracers) then
              return;
          end;
  
          local character = Client.Character;
          if (not character) then
              return;
          end;
  
          local head = character:FindFirstChild('Head');
          if (not head) then
              return;
          end;
  
          local att0 = Instance.new('Attachment');
          att0.Name = 'IgnoreMe';
          att0.WorldPosition = head.Position;
          att0.Parent = VMs;
  
          local att1 = Instance.new('Attachment');
          att1.Name = 'IgnoreMe';
          att1.WorldPosition = position;
          att1.Parent = VMs;
  
          local beam = Instance.new('Beam');
          beam.Name = 'IgnoreMe';
          beam.Attachment0 = att0;
          beam.Attachment1 = att1;
          beam.Transparency = NumberSequence.new({
              NumberSequenceKeypoint.new(0, 0),
              NumberSequenceKeypoint.new(1, 0)
          })
  
          beam.Color = ColorSequence.new({
              ColorSequenceKeypoint.new(0, flags.BulletTracersColor.Color),
              ColorSequenceKeypoint.new(1, flags.BulletTracersColor.Color),
          });
  
          beam.Texture = 'rbxassetid://115789305736770'
          beam.TextureSpeed = 1;
          beam.TextureLength = 4;
          beam.Width0 = 0.2;
          beam.Width1 = 0.2;
          beam.FaceCamera = true;
          beam.LightEmission = 1;
          beam.Parent = VMs;
          beam.Brightness = 1
          beam.TextureMode = Enum.TextureMode.Stretch
  
          local expiry = flags.BulletTracersDuration or 1;
          Debris:AddItem(att0, expiry);
          Debris:AddItem(att1, expiry);
          Debris:AddItem(beam, expiry);
      end)

      local function draw_hit_effect(position, color, lifetime, style)
          local lines = {}
          if style == "Sparks" then
              for i = 1, 6 do
                  local a = (i - 1) * (math.pi * 2 / 6)
                  local dx = math.cos(a) * 0.6
                  local dz = math.sin(a) * 0.6
                  local p1 = position + Vector3.new(dx, 0, dz)
                  local p2 = position
                  local l = Drawing.new("Line")
                  l.From = Camera:WorldToViewportPoint(p1)
                  l.To = Camera:WorldToViewportPoint(p2)
                  l.Color = color
                  l.Thickness = 1.5
                  l.Transparency = 1
                  l.Visible = true
                  lines[#lines + 1] = l
              end
          elseif style == "Dots" then
              for i = 1, 8 do
                  local a = (i - 1) * (math.pi * 2 / 8)
                  local dx = math.cos(a) * 0.4
                  local dz = math.sin(a) * 0.4
                  local p = position + Vector3.new(dx, 0, dz)
                  local sp = Camera:WorldToViewportPoint(p)
                  local cir = Drawing.new("Circle")
                  cir.Position = Vector2.new(sp.X, sp.Y)
                  cir.Radius = 3
                  cir.Color = color
                  cir.Filled = true
                  cir.Transparency = 1
                  cir.Visible = true
                  lines[#lines + 1] = cir
              end
          elseif style == "Catalyst" then
              for ix = -1, 1 do
                  for iz = -1, 1 do
                      local p = position + Vector3.new(ix * 0.4, 0, iz * 0.4)
                      local sp = Camera:WorldToViewportPoint(p)
                      local sq = Drawing.new("Square")
                      sq.Position = Vector2.new(sp.X - 4, sp.Y - 4)
                      sq.Size = Vector2.new(8, 8)
                      sq.Color = color
                      sq.Filled = true
                      sq.Transparency = 1
                      sq.Visible = true
                      lines[#lines + 1] = sq
                  end
              end
          elseif style == "Mist" then
              for i = 1, 5 do
                  local dy = (i - 3) * 0.2
                  local p1 = position + Vector3.new(-0.5, dy, 0)
                  local p2 = position + Vector3.new(0.5, dy, 0)
                  local l = Drawing.new("Line")
                  l.From = Camera:WorldToViewportPoint(p1)
                  l.To = Camera:WorldToViewportPoint(p2)
                  l.Color = color
                  l.Thickness = 2
                  l.Transparency = 1
                  l.Visible = true
                  lines[#lines + 1] = l
              end
          else
              local pairs4 = {
                  {Vector3.new(-0.5, -0.5, 0), Vector3.new(0.5, 0.5, 0)},
                  {Vector3.new(-0.5, 0.5, 0), Vector3.new(0.5, -0.5, 0)},
              }
              for i = 1, #pairs4 do
                  local p1 = position + pairs4[i][1]
                  local p2 = position + pairs4[i][2]
                  local l = Drawing.new("Line")
                  l.From = Camera:WorldToViewportPoint(p1)
                  l.To = Camera:WorldToViewportPoint(p2)
                  l.Color = color
                  l.Thickness = 2
                  l.Transparency = 1
                l.Visible = true
                  lines[#lines + 1] = l
              end
          end
          task.delay(lifetime, function()
              for i = 1, #lines do
                  pcall(function() lines[i]:Remove() end)
              end
          end)
      end
  
      local createBlood
      createBlood = hookModule(VFXModule, "CreateBlood", LPH_NO_UPVALUES(function(self, hit, position)
          local ok_tb, tb = pcall(debug.traceback)
          if not ok_tb or type(tb) ~= "string" then
              tb = ""
          end

          if flags.HitEffect == true and typeof(position) == "Vector3" then
              local picker = flags.HitEffectColor
              local c = (picker and picker.Color) or Color3.fromRGB(255, 255, 255)
              local life = tonumber(flags.HitEffectLifetime) or 1
              local style = flags.HitEffectStyle or "Sparks"
              task.spawn(function()
                  pcall(draw_hit_effect, position, c, life, style)
              end)
          end

          if not tb:find("function HitVFX", 1, true) then
              pcall(function()
                  hitsoundsbind:Fire()
              end)
          end

          if typeof(hit) == "Instance" and hit:IsA("BasePart") then
              local model = hit:FindFirstAncestorOfClass("Model")
              if model then
                  local plr = Players:GetPlayerFromCharacter(model)
                  if plr and flags.Hitmarkers == true and cheat.Globals.spawnHitmarker then
                      cheat.Globals.spawnHitmarker(hit, position)
                  end
                  local nm = plr and plr.DisplayName or model.Name
                  local partName = hit.Name
                  local dmg = 0
                  local hum = model:FindFirstChildOfClass("Humanoid")
                  local isHead = partName == "Head"
                  if hum then
                      local mx = hum.MaxHealth
                      if isHead then
                          dmg = math.floor(mx * 0.7)
                      else
                          dmg = math.floor(mx * 0.3)
                      end
                  end
                  local hp = hum and hum.Health or 0
                  cheat.Globals.NotifHit = {
                      name = nm,
                      part = partName,
                      damage = dmg,
                      hp_remaining = hp,
                      t = tick(),
                  }
              end
          end

          return createBlood(self, hit, position)
      end))


      local function wrap_delay(fn, wait_t)
          if type(fn) ~= "function" then
              return fn
          end
          return function(...)
              local n = select("#", ...)
              local a = {...}
              task.delay(wait_t, function()
                  fn(unpack(a, 1, n))
              end)
          end
      end


      local tracer_styles = {
          Default = { tex = "", segs = 1, width = 0.3, tex_len = 5, tex_speed = 0, mode = Enum.TextureMode.Stretch },
          Electric = { tex = "rbxassetid://7151778302", segs = 10, width = 1.2, tex_len = 1, tex_speed = 1, mode = Enum.TextureMode.Stretch },
          Liquid = { tex = "rbxassetid://2382169232", segs = 1, width = 0.35, tex_len = 5, tex_speed = 1, mode = Enum.TextureMode.Stretch },
          Wave = { tex = "rbxassetid://7071778278", segs = 1, width = 0.6, tex_len = 12, tex_speed = 1, mode = Enum.TextureMode.Wrap },
      }

      local function tracer_parent()
          return workspace:FindFirstChild("VFX") or workspace
      end

      local function beamTracer(origin, destination, style, color, alpha, life)
          local cfg = tracer_styles[style] or tracer_styles.Default
          local parent = tracer_parent()
          local a0, a1, beam
          local ok = pcall(function()
              a0 = Instance.new("Attachment")
              a1 = Instance.new("Attachment")
              beam = Instance.new("Beam")
          end)
          if not ok or not beam then
              return
          end
          a0.WorldCFrame = CFrame.new(origin)
          a1.WorldCFrame = CFrame.new(destination)
          a0.Parent = workspace.Terrain
          a1.Parent = workspace.Terrain
          beam.Color = ColorSequence.new(color)
          beam.Texture = cfg.tex
          beam.TextureMode = cfg.mode
          beam.TextureLength = cfg.tex_len
          beam.TextureSpeed = cfg.tex_speed
          beam.Segments = cfg.segs
          beam.Width0 = cfg.width
          beam.Width1 = cfg.width
          beam.Brightness = 1.5
          beam.LightEmission = 1
          beam.LightInfluence = 0
          beam.FaceCamera = true
          beam.Transparency = NumberSequence.new(alpha)
          beam.Attachment0 = a0
          beam.Attachment1 = a1
          beam.Parent = parent
          task.spawn(function()
              local dur = life > 0 and life or 0.5
              local fade = tonumber(flags.TracerFadeSpeed) or 1
              local ext = fade > 0 and (1 / fade) or 0
              local t0 = tick()
              while true do
                  local now = tick() - t0
                  if ext > 0 then
                      if now >= ext then
                          a1.WorldCFrame = CFrame.new(destination)
                      else
                          a1.WorldCFrame = CFrame.new(origin:Lerp(destination, now / ext))
                      end
                  end
                  local e = now / dur
                  if e >= 1 or not beam.Parent then
                      break
                  end
                  beam.Transparency = NumberSequence.new(alpha + (1 - alpha) * e)
                  Run.Heartbeat:Wait()
              end
              beam:Destroy()
              a0:Destroy()
              a1:Destroy()
          end)
      end

      local function darkTracer(origin, destination, color, alpha, life)
          local parent = tracer_parent()
          local startAttachment = Instance.new("Attachment")
          local endAttachment = Instance.new("Attachment")
          startAttachment.WorldCFrame = CFrame.new(origin)
          endAttachment.WorldCFrame = CFrame.new(origin)
          startAttachment.Parent = workspace.Terrain
          endAttachment.Parent = workspace.Terrain
          local beams = {}
          for _ = 1, 3 do
              local beam = Instance.new("Beam")
              beam.Attachment0 = startAttachment
              beam.Attachment1 = endAttachment
              beam.FaceCamera = true
              beam.Color = ColorSequence.new({
                  ColorSequenceKeypoint.new(0, color),
                  ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)),
                  ColorSequenceKeypoint.new(1, color),
              })
              beam.Texture = "rbxassetid://12781848822"
              beam.TextureLength = 20
              beam.TextureSpeed = 0.9
              beam.TextureMode = Enum.TextureMode.Static
              beam.LightInfluence = 1
              beam.LightEmission = 0.25
              beam.Brightness = 2
              beam.Width0 = 0.5
              beam.Width1 = 0.5
              beam.Transparency = NumberSequence.new(alpha)
              beam.Parent = parent
              beams[#beams + 1] = beam
          end
          task.spawn(function()
              local distance = (destination - origin).Magnitude
              local travelTime = math.clamp(distance / 900, 0.03, 0.35)
              local fadeTime = 0.5
              local started = tick()
              while true do
                  local elapsed = tick() - started
                  if elapsed < travelTime then
                      endAttachment.WorldCFrame = CFrame.new(origin:Lerp(destination, elapsed / travelTime))
                  else
                      endAttachment.WorldCFrame = CFrame.new(destination)
                  end
                  local fadeProgress = (elapsed - life) / fadeTime
                  if fadeProgress >= 1 or not beams[1].Parent then
                      break
                  end
                  if fadeProgress > 0 then
                      local width = 0.5 * (1 - fadeProgress)
                      for _, beam in ipairs(beams) do
                          beam.Width0 = width
                          beam.Width1 = width
                          beam.Transparency = NumberSequence.new(alpha + (1 - alpha) * fadeProgress)
                      end
                  end
                  Run.Heartbeat:Wait()
              end
              for _, beam in ipairs(beams) do
                  beam:Destroy()
              end
              startAttachment:Destroy()
              endAttachment:Destroy()
          end)
      end

      local function trajectory_points(origin, dest, speed, gravity)
          local pts = { origin }
          local dir = dest - origin
          if dir.Magnitude <= 0 then
              return pts
          end
          local vel = dir.Unit * speed
          local step = 1 / 30
          local pos = origin
          local max_range = dir.Magnitude
          local travelled = 0
          for _ = 1, 150 do
              vel = vel - Vector3.new(0, gravity * step, 0)
              local nxt = pos + vel * step
              travelled = travelled + (nxt - pos).Magnitude
              pos = nxt
              pts[#pts + 1] = pos
              if travelled >= max_range then
                  break
              end
          end
          return pts
      end

      local function curvedTracer(origin, destination, color, alpha, life, speed, gravity)
          local pts = trajectory_points(origin, destination, speed, gravity)
          local params = RaycastParams.new()
          local ft = Enum.RaycastFilterType.Exclude
          if not ft then
              ft = Enum.RaycastFilterType.Blacklist
          end
          params.FilterType = ft
          params.FilterDescendantsInstances = Client.Character and { Client.Character } or {}
          params.IgnoreWater = true
          local clipped = { pts[1] }
          for i = 1, #pts - 1 do
              local a, b = pts[i], pts[i + 1]
              local res = workspace:Raycast(a, b - a, params)
              if res then
                  clipped[#clipped + 1] = res.Position
                  break
              end
              clipped[#clipped + 1] = b
          end
          pts = clipped
          local parent = tracer_parent()
          task.spawn(function()
              local segs = {}
              for i = 1, #pts - 1 do
                  local a, b = pts[i], pts[i + 1]
                  local cf = CFrame.new(a, b)
                  local len = (b - a).Magnitude
                  local outline, fill
                  local ok = pcall(function()
                      outline = Instance.new("LineHandleAdornment")
                      fill = Instance.new("LineHandleAdornment")
                  end)
                  if not ok or not fill then
                      break
                  end
                  outline.Adornee = workspace.Terrain
                  outline.CFrame = cf
                  outline.Length = 0
                  outline.AlwaysOnTop = true
                  outline.Thickness = 3.5
                  outline.Color3 = Color3.new(0, 0, 0)
                  outline.Transparency = alpha
                  outline.ZIndex = 0
                  outline.Visible = false
                  outline.Parent = parent
                  fill.Adornee = workspace.Terrain
                  fill.CFrame = cf
                  fill.Length = 0
                  fill.AlwaysOnTop = true
                  fill.Thickness = 2
                  fill.Color3 = color
                  fill.Transparency = alpha
                  fill.ZIndex = 1
                  fill.Visible = false
                  fill.Parent = parent
                  segs[i] = { outline = outline, fill = fill, len = len }
              end
              local fade = tonumber(flags.TracerFadeSpeed) or 1
              local total = fade > 0 and math.max(1 / fade, 0.03) or 0.001
              local path_len = 0
              for i = 1, #segs do
                  path_len = path_len + segs[i].len
              end
              local t0 = tick()
              while true do
                  local e = tick() - t0
                  local reached = math.min(e / total, 1) * path_len
                  local acc = 0
                  for i = 1, #segs do
                      local seg = segs[i]
                      local frac = (reached - acc) / seg.len
                      acc = acc + seg.len
                      if frac > 1 then
                          frac = 1
                      end
                      if frac < 0 then
                          frac = 0
                      end
                      if frac > 0 then
                          seg.outline.Length = seg.len * frac
                          seg.fill.Length = seg.len * frac
                          seg.outline.Visible = true
                          seg.fill.Visible = true
                      end
                  end
                  if e >= total then
                      break
                  end
                  Run.Heartbeat:Wait()
              end
              for i = 1, #segs do
                  segs[i].outline.Length = segs[i].len
                  segs[i].fill.Length = segs[i].len
              end
              local dur = life > 0 and life or 0.5
              local f0 = tick()
              while true do
                  local e = (tick() - f0) / dur
                  if e >= 1 then
                      break
                  end
                  local tr = alpha + (1 - alpha) * e
                  for i = 1, #segs do
                      local seg = segs[i]
                      if seg.outline.Parent then
                          seg.outline.Transparency = tr
                      end
                      if seg.fill.Parent then
                          seg.fill.Transparency = tr
                      end
                  end
                  Run.Heartbeat:Wait()
              end
              for i = 1, #segs do
                  segs[i].outline:Destroy()
                  segs[i].fill:Destroy()
              end
          end)
      end

      local function tracer(origin, destination, speed, gravity)
          if typeof(origin) ~= "Vector3" or typeof(destination) ~= "Vector3" then
              return
          end
          local style = flags.BulletTracersStyle or "Default"
          if type(style) == "table" then
              style = style[1] or style.Value or "Default"
          end
          local color, alpha = flagColor(flags.BulletTracersColor, Color3.new(1, 1, 1))
          local life = tonumber(flags.BulletTracersDuration) or 1
          if life < 0.1 then
              life = 0.1
          end
          if style == "Dark" then
              pcall(darkTracer, origin, destination, color, alpha, life)
              return
          end
          if style == "Curved" then
              local sp = tonumber(speed) or 0
              if sp <= 0 then
                  beamTracer(origin, destination, "Default", color, alpha, life)
                  return
              end
              curvedTracer(origin, destination, color, alpha, life, sp, tonumber(gravity) or workspace.Gravity)
              return
          end
          beamTracer(origin, destination, style, color, alpha, life)
      end

      cheat.solveAim = function(from, target, speed, gravity)
          if type(speed) ~= "number" or speed <= 1 or type(gravity) ~= "number" or gravity <= 0 then
              return target
          end
          local step = 1 / 60
          local aim = target
          for _ = 1, 5 do
              local direction = aim - from
              if direction.Magnitude < 0.05 then
                  return target
              end
              local position = from
              local velocity = direction.Unit * speed
              local closestPoint, closestDistance = position, math.huge
              local previousDistance = math.huge
              for _ = 1, 600 do
                  local segment = velocity.Unit * speed * step
                  local toTarget = target - position
                  local along = math.clamp(toTarget:Dot(segment.Unit), 0, segment.Magnitude)
                  local point = position + segment.Unit * along
                  local distance = (point - target).Magnitude
                  if distance < closestDistance then
                      closestPoint, closestDistance = point, distance
                  end
                  if distance > previousDistance and along <= 0 then
                      break
                  end
                  previousDistance = distance
                  position = position + segment
                  velocity = velocity - Vector3.new(0, 196.2 * gravity, 0) * step
              end
              local miss = target - closestPoint
              if miss.Magnitude < 0.05 then
                  break
              end
              aim = aim + miss
          end
          return aim
      end

      cheat.clampFlash = function(offset)
          if offset.Magnitude > 5.6 then
              return offset.Unit * 5.6
          end
          return offset
      end

      cheat.bulletIds = function(firedTick, totalSpread, count)
          local generator = Random.new(math.floor(firedTick * 10000))
          local rounded = math.floor(totalSpread * 100) / 100
          local ids = {}
          for index = 1, count do
              generator:NextNumber(0, rounded)
              generator:NextNumber(0, 2 * math.pi)
              ids[index] = generator:NextInteger(1, math.ceil(math.max(1, rounded) * 1e9))
          end
          return ids
      end

      local function flat_root(pos, aim)
          local hawk = CFrame.lookAt(pos, aim)
          local _, yaw = hawk:ToEulerAnglesYXZ()
          return CFrame.new(hawk.Position) * CFrame.fromEulerAnglesYXZ(0, yaw, 0)
      end

      local createProjectile
      local cp_hook
      cp_hook = LPH_NO_UPVALUES(function(self, ...)
          local Args = {...}

          local vm = false
          if getcallingscript then
              local s = getcallingscript()
              vm = s and s.Name == "ViewmodelController"
          else
              local tb = debug.traceback()
              vm = tb and tb:find("ViewmodelController", 1, true) ~= nil
          end
          if vm and type(Args[1]) == "table" then
              local cfg = Args[1]
              if cheat.debugSession.active then
                  cheat.debugWrite("proj-orig", "pos", cfg.Position, "dir", cfg.Direction, "posFirst", cfg.PositionFirst, "dirFirst", cfg.DirectionFirst, "speed", cfg.Speed, "grav", cfg.Gravity, "range", cfg.MaxRange)
              end
              local legitSpeed = cfg.Speed
              if type(cfg.Speed) == "number" and cfg.Speed > 1 then
                  cheat.Globals.bulletStats = { speed = cfg.Speed, gravity = tonumber(cfg.Gravity) or 0, range = tonumber(cfg.MaxRange) or 1000 }
              end
              local ballistic = type(legitSpeed) == "number" and legitSpeed > 1
                  and type(cfg.Gravity) == "number" and cfg.Gravity > 0.01
              local ibOn = bindOn(flags.InstantBullet == true, "InstantBulletBind")
              local silOn = bindOn(flags.AimbotEnabled == true, "AimbotBind")
              local bulletSpeed = cfg.Speed
              if type(bulletSpeed) ~= "number" or bulletSpeed <= 1 then
                  bulletSpeed = 800
              end
              local aimSpeed = legitSpeed
              if ibOn or type(aimSpeed) ~= "number" or aimSpeed <= 1 then
                  aimSpeed = bulletSpeed
              end
              local grav = cfg.Gravity
              if type(grav) ~= "number" then
                  grav = 1
              end



              local spreadLocal, spreadLocalFirst = nil, nil
              do
                  local character = Client.Character
                  local rootPart = character and character.PrimaryPart
                  if rootPart and typeof(cfg.Position) == "Vector3" then
                      local eye = (rootPart.CFrame * CFrame.new(0, 1.5, 0)).Position
                      if (cfg.Position - eye).Magnitude > 8 then
                          local look = Camera.CFrame.LookVector
                          cfg.Position = eye + look * 3
                          if typeof(cfg.Direction) == "Vector3" then
                              cfg.Direction = look
                          end
                      end
                  end
              end
              local originalFlash = cfg.Position
              local mouseHit = cheat.Globals.lastMouseHit
              if mouseHit and os.clock() - mouseHit.t < 0.25 and typeof(originalFlash) == "Vector3" and typeof(cfg.Direction) == "Vector3"
                  and (mouseHit.pos - originalFlash).Magnitude > 0.05 then
                  spreadLocal = CFrame.new(originalFlash, mouseHit.pos):VectorToObjectSpace(cfg.Direction)
              end
              if typeof(cfg.DirectionFirst) == "Vector3" then
                  spreadLocalFirst = Camera.CFrame:VectorToObjectSpace(cfg.DirectionFirst)
              end
              local rootSend, flashOffset, cameraSend = nil, nil, nil
              local originalCfg = { Position = cfg.Position, Direction = cfg.Direction, PositionFirst = cfg.PositionFirst, DirectionFirst = cfg.DirectionFirst }
              if silOn then
                  spreadLocal, spreadLocalFirst = nil, nil
              end

              local chanceOk = ((math.floor(Random.new():NextNumber(0, 1) * 100) / 100) <= (flags.HitChance / 100))

              local dest
              local part = Targeting.TargetPart
              local shotFrom
              local moved = nil
              local mode = "direct"
              local safe = false
              local drop_v = Vector3.zero
              local partAlive = part and typeof(part) == "Instance"
                  and part:IsA("BasePart")
                  and part.Parent ~= nil
                  and part.Parent.Parent ~= nil
              if partAlive and Client.Character and chanceOk and silOn then
                  local camPos = Camera.CFrame.Position
                  local hrp = Client.Character.PrimaryPart
                  local rootPos
                  if hrp and hrp.Parent then
                      rootPos = (hrp.CFrame * CFrame.new(0, 1.5, 0)).Position
                  end

                  local origin = cfg.Position
                  if typeof(origin) ~= "Vector3" then
                      origin = camPos
                  end
                  local ok_pos, pos = pcall(function() return part.Position end)
                  if not ok_pos or typeof(pos) ~= "Vector3" then
                      partAlive = false
                  else
                      dest = pos
                      local humanoid = Targeting.TargetCharacter
                          and Targeting.TargetCharacter:FindFirstChildOfClass("Humanoid")
                      if humanoid then
                          local leadTime = nil
                          if ibOn then
                              local okPing, ping = pcall(function() return Client:GetNetworkPing() end)
                              leadTime = math.clamp((okPing and type(ping) == "number" and ping or 0.1) + 0.05, 0.05, 0.4)
                          end
                          local okLead, leadPos = pcall(predictPos, part, humanoid, 0, aimSpeed, leadTime)
                          if okLead and typeof(leadPos) == "Vector3" then
                              dest = leadPos
                          end
                      end
                  end
                  if partAlive and typeof(Targeting.PitchOffset) == "Vector3" then
                      dest = dest + Targeting.PitchOffset
                  end
                  local manipPos = nil
                  local scan = Targeting.ScannedPosition
                  if typeof(scan) == "Vector3" and partAlive and type(cfg.MaxRange) == "number" and (dest - scan).Magnitude > cfg.MaxRange then
                      scan = nil
                  end
                  if typeof(scan) == "Vector3" then
                      manipPos = scan
                      if partAlive and typeof(Targeting.ManipHitOffset) == "Vector3" then
                          dest = dest + Targeting.ManipHitOffset
                      end
                      if partAlive and rootPos and not cheat.manipValid(manipPos, dest) then
                          manipPos = nil
                          if type(cheat.findVisiblePosition) == "function" then
                              local okFresh, fresh, freshPoint = pcall(cheat.findVisiblePosition, part)
                              if okFresh and typeof(fresh) == "Vector3" then
                                  manipPos = fresh
                                  if typeof(freshPoint) == "Vector3" then
                                      dest = dest - (typeof(Targeting.ManipHitOffset) == "Vector3" and Targeting.ManipHitOffset or Vector3.zero) + (freshPoint - part.Position)
                                  end
                              end
                          end
                      end
                  end
                  local scanPos = nil
                  local hitPoint = Targeting.HitscanPoint
                  if typeof(hitPoint) == "Vector3" then
                      scanPos = hitPoint
                  end

                  safe = true
                  if partAlive and rootPos and typeof(manipPos) ~= "Vector3" and not scanPos and not clearLos(rootPos, dest) then
                      safe = false
                  end

                  mode = "direct"
                  if typeof(manipPos) == "Vector3" then
                      mode = "manip"
                  elseif scanPos then
                      mode = "scan"
                  end

                  drop_v = Vector3.zero
                  local solveFrom = (mode == "manip" and manipPos) or origin
                  if ballistic and typeof(solveFrom) == "Vector3" then
                      local okSolve, aimPoint = pcall(cheat.solveAim, solveFrom, dest, legitSpeed, cfg.Gravity)
                      if okSolve and typeof(aimPoint) == "Vector3" then
                          drop_v = aimPoint - dest
                      end
                  end
                  local aim_dest = dest + drop_v
                  if mode == "scan" then
                      dest = scanPos
                      if ballistic then
                          local okSolve, aimPoint = pcall(cheat.solveAim, origin, scanPos, legitSpeed, cfg.Gravity)
                          drop_v = (okSolve and typeof(aimPoint) == "Vector3") and (aimPoint - scanPos) or Vector3.zero
                      else
                          drop_v = Vector3.zero
                      end
                      aim_dest = dest + drop_v
                  end

                  local from = origin
                  if safe then
                      shotFrom = from
                      local fromPoint = (mode == "manip" and manipPos) or from
                      local dir_v = aim_dest - fromPoint
                      local d0 = dir_v.Magnitude
                      local dir
                      if d0 > 0.05 then
                          dir = dir_v.Unit
                      end
                      local packetDest = dest

                      if dir then
                          moved = nil
                          if mode == "manip" then
                              moved = manipPos
                          end
                          local shotDirection = dir
                          if spreadLocal then
                              shotDirection = CFrame.new(fromPoint, aim_dest):VectorToWorldSpace(spreadLocal)
                          end
                          cfg.Direction = shotDirection
                          if spreadLocalFirst and (aim_dest - camPos).Magnitude > 0.05 then
                              cfg.DirectionFirst = CFrame.new(camPos, aim_dest):VectorToWorldSpace(spreadLocalFirst)
                          else
                              cfg.DirectionFirst = dir
                          end
                          if moved and rootPos and hrp then
                              local rootFrame = hrp.CFrame * CFrame.new(0, 1.5, 0)
                              flashOffset = Vector3.new(0.5, -0.3, -2)
                              rootSend = flat_root(moved, aim_dest)
                              local flashWorld = rootSend:PointToWorldSpace(flashOffset)
                              local cameraOffset = camPos - rootFrame.Position
                              if cameraOffset.Magnitude > 1.9 then
                                  cameraOffset = cameraOffset.Unit * 1.9
                              end
                              cameraSend = CFrame.new(moved + Vector3.new(0, math.clamp(cameraOffset.Y, -0.5, 0.5), 0), aim_dest)
                              if spreadLocalFirst then
                                  cfg.DirectionFirst = cameraSend:VectorToWorldSpace(spreadLocalFirst)
                              else
                                  cfg.DirectionFirst = cameraSend.LookVector
                              end
                              cfg.Position = flashWorld
                              cfg.Direction = (aim_dest - flashWorld).Magnitude > 0.05 and (aim_dest - flashWorld).Unit or cfg.Direction
                              cfg.PositionFirst = rootSend.Position
                              if not (cheat.manipValid(moved, aim_dest) and cheat.strictClear(moved, flashWorld)) then
                                  safe = false
                                  dest = nil
                                  moved = nil
                                  rootSend, flashOffset, cameraSend = nil, nil, nil
                                  cfg.Position = originalCfg.Position
                                  cfg.Direction = originalCfg.Direction
                                  cfg.PositionFirst = originalCfg.PositionFirst
                                  cfg.DirectionFirst = originalCfg.DirectionFirst
                                  if cheat.debugSession.active then
                                      cheat.debugWrite("manip", "rejected: root to send position obstructed")
                                  end
                              end
                          elseif rootPos and hrp and typeof(originalFlash) == "Vector3" then
                              local rootFrame = hrp.CFrame * CFrame.new(0, 1.5, 0)
                              flashOffset = cheat.clampFlash(rootFrame:PointToObjectSpace(originalFlash))
                              rootSend = flat_root(rootFrame.Position, aim_dest)
                              local turnedFlash = rootSend:PointToWorldSpace(flashOffset)
                              if (aim_dest - turnedFlash).Magnitude > 0.05 then
                                  if spreadLocal then
                                      cfg.Direction = CFrame.new(turnedFlash, aim_dest):VectorToWorldSpace(spreadLocal)
                                  else
                                      cfg.Direction = (aim_dest - turnedFlash).Unit
                                  end
                                  cfg.Position = turnedFlash
                                  cfg.PositionFirst = rootSend.Position
                                  if (aim_dest - camPos).Magnitude > 0.05 then
                                      cameraSend = CFrame.new(camPos, aim_dest)
                                  end
                              else
                                  rootSend, flashOffset = nil, nil
                              end
                          end
                      end
                  else
                      dest = nil
                  end
              end

              if dest and chanceOk and safe and ballistic and typeof(cfg.Position) == "Vector3" and typeof(cfg.Direction) == "Vector3" then
                  local targetCharacter = Targeting.TargetCharacter
                  local okSim, reached, closest = pcall(cheat.simulatePath, cfg.Position, cfg.Direction, legitSpeed, cfg.Gravity, cfg.MaxRange, targetCharacter, dest)
                  if okSim then
                      local passes = reached or (mode ~= "scan" and closest < 2.5)
                      if cheat.debugSession.active then
                          cheat.debugWrite("trajectory", mode, "reached", reached, "closest", closest)
                      end
                      if not passes then
                          safe = false
                          dest = nil
                          moved = nil
                          rootSend, flashOffset, cameraSend = nil, nil, nil
                          cfg.Position = originalCfg.Position
                          cfg.Direction = originalCfg.Direction
                          cfg.PositionFirst = originalCfg.PositionFirst
                          cfg.DirectionFirst = originalCfg.DirectionFirst
                      end
                  end
              end

              if dest and chanceOk and safe then
                  cheat.Globals.shotSync = {
                      dest = dest,
                      hit = true,
                      t = os.clock(),
                      manip = moved,
                      mode = mode,
                      drop = drop_v,
                      origin = moved or shotFrom,
                      rootSend = rootSend,
                      flashOffset = flashOffset,
                      cameraSend = cameraSend,
                      clear = (moved ~= nil) or (shotFrom ~= nil and clearLos(shotFrom, dest)),
                  }
                  if ibOn or mode ~= "direct" then
                      cfg.Instant = 1 / 60
                      local travelFrom = moved or shotFrom or cfg.Position
                      local travelSpeed = (type(legitSpeed) == "number" and legitSpeed > 1) and legitSpeed or 800
                      local travelTime = 0.05
                      if typeof(travelFrom) == "Vector3" then
                          travelTime = math.clamp((dest - travelFrom).Magnitude / travelSpeed, 0, 3) + 0.05
                      end
                      local reported = false
                      local function deferred(callback)
                          if type(callback) ~= "function" then
                              return callback
                          end
                          return function(...)
                              if reported then
                                  return
                              end
                              reported = true
                              local packed = table.pack(...)
                              local function fire()
                                  cheat.debugWrite("hit-fire", packed[1], packed[2])
                                  callback(table.unpack(packed, 1, packed.n))
                              end
                              if ibOn then
                                  cheat.debugWrite("hit-queued", "next-frame", packed[1], packed[2])
                                  task.defer(fire)
                              else
                                  cheat.debugWrite("hit-queued", "delay", travelTime, packed[1], packed[2])
                                  task.delay(travelTime, fire)
                              end
                          end
                      end
                      cfg.HitFunction = deferred(cfg.HitFunction)
                      cfg.MissFunction = deferred(cfg.MissFunction)
                  end
                  local shotName
                  local tchar = Targeting.TargetCharacter
                  if tchar then
                      local tplr = Players:GetPlayerFromCharacter(tchar)
                      shotName = tplr and tplr.DisplayName or tchar.Name
                  end
                  cheat.Globals.NotifShot = {
                      name = shotName or "?",
                      part = part and part.Name or "?",
                      has_los = safe == true,
                      t = os.clock(),
                  }
              else
                  cheat.Globals.shotSync = nil
                  if ibOn then
                      cfg.Instant = 1 / 60
                      local reported = false
                      for _, key in ipairs({ "HitFunction", "MissFunction" }) do
                          local callback = cfg[key]
                          if type(callback) == "function" then
                              cfg[key] = function(...)
                                  if reported then
                                      return
                                  end
                                  reported = true
                                  local packed = table.pack(...)
                                  task.defer(function()
                                      callback(table.unpack(packed, 1, packed.n))
                                  end)
                              end
                          end
                      end
                  end
              end


              if flags.BulletTracers then
                  local tracerFrom = shotFrom or cfg.Position or Camera.CFrame.Position
                  local tracerTo = dest
                  if typeof(tracerTo) ~= "Vector3" and typeof(cfg.Position) == "Vector3" and typeof(cfg.Direction) == "Vector3" then
                      tracerFrom = cfg.Position
                      local okPath, _, _, endPoint = pcall(cheat.simulatePath, cfg.Position, cfg.Direction, tonumber(cfg.Speed) or 1000, tonumber(cfg.Gravity) or 0, tonumber(cfg.MaxRange) or 1000, nil, nil)
                      if okPath and typeof(endPoint) == "Vector3" then
                          tracerTo = endPoint
                      else
                          tracerTo = cfg.Position + cfg.Direction.Unit * math.min(tonumber(cfg.MaxRange) or 1000, 1000)
                      end
                  end
                  if typeof(tracerTo) == "Vector3" then
                      tracer(tracerFrom, tracerTo, cfg.Speed, cfg.Gravity)
                  end
              end

              if type(bulletSpeed) == "number" and bulletSpeed > 1 then
                  cheat.Globals.lastShot = {
                      t = os.clock(),
                      speed = bulletSpeed,
                      range = (type(cfg.MaxRange) == "number" and cfg.MaxRange) or 400,
                      grav = (type(cfg.Gravity) == "number" and cfg.Gravity) or 0,
                      origin = (typeof(cfg.Position) == "Vector3" and cfg.Position) or Camera.CFrame.Position,
                      part = partAlive and part or nil,
                  }
              end
          end

          if vm and cheat.debugSession.active and type(Args[1]) == "table" then
              local cfg = Args[1]
              local sync = cheat.Globals.shotSync
              cheat.debugWrite("proj-final", "pos", cfg.Position, "dir", cfg.Direction, "posFirst", cfg.PositionFirst, "dirFirst", cfg.DirectionFirst, "instant", cfg.Instant)
              cheat.debugWrite("shot-sync", sync and { mode = sync.mode, dest = sync.dest, manip = sync.manip, drop = sync.drop, clear = sync.clear, origin = sync.origin } or "none", "target", Targeting.TargetPart)
          end
          cheat.Globals.ownProjectile = vm and cheat.Globals.shotSync or nil
          local results = table.pack(pcall(createProjectile, self, unpack(Args)))
          cheat.Globals.ownProjectile = nil
          if not results[1] then
              error(results[2], 0)
          end
          return unpack(results, 2, results.n)
      end)
      createProjectile = hookModule(VFXModule, "CreateProjectile", cheat.watch(cp_hook, "projectile hook"))

      do
          local meleeStore = {}
          local meleeCaps = {
              ["Stone Hatchet"] = 1.65, ["Iron Shard Hatchet"] = 1.3, ["Steel Axe"] = 1.3, ["Chainsaw"] = 1.6,
              ["Stone Pickaxe"] = 1.65, ["Iron Shard Pickaxe"] = 1.3, ["Bone Tool"] = 1.3, ["Candy Cane"] = 1.3,
              ["Carrot Blade"] = 1.3, ["Steel Pickaxe"] = 1.3, ["Mining Drill"] = 1.6, ["Wooden Spear"] = 1.3,
              ["Stone Spear"] = 1.3, ["Halloween Scythe"] = 1.3, ["Boulder"] = 1.34, ["Steel Shovel"] = 1.3,
              ["Salvaged Shovel"] = 1.3, ["Saw Bat"] = 1.3, ["Machete"] = 1.3, ["Hammer"] = 1.3,
          }
          getgenv().fastHit = function(on)
              if type(ToolInfo) ~= "table" then
                  return
              end
              for name, cfg in pairs(ToolInfo) do
                  pcall(function()
                      if type(cfg) == "table" and type(cfg.Melee) == "table" and type(cfg.Weapon) == "table" then
                          local store = meleeStore[name]
                          if on then
                              if store == nil then
                                  store = { cd = cfg.Weapon.Cooldown, anim = cfg.Weapon.SwingAnimSpeed }
                                  meleeStore[name] = store
                              end
                              local cap = meleeCaps[name] or 1.3
                              if type(store.cd) == "number" then
                                  cfg.Weapon.Cooldown = store.cd / cap
                              end
                              if type(store.anim) == "number" then
                                  cfg.Weapon.SwingAnimSpeed = store.anim * cap
                              end
                          elseif store then
                              if type(store.cd) == "number" then
                                  cfg.Weapon.Cooldown = store.cd
                              end
                              if type(store.anim) == "number" then
                                  cfg.Weapon.SwingAnimSpeed = store.anim
                              end
                              meleeStore[name] = nil
                          end
                      end
                  end)
              end
          end

      end

      cheat.debugStart = function()
          local session = cheat.debugSession
          if session.active then
              return
          end
          session.lines = {}
          session.startedAt = os.clock()
          session.active = true
          local remotes = game:GetService("ReplicatedStorage"):FindFirstChild("Remotes")
          if remotes then
              for _, remote in ipairs(remotes:GetDescendants()) do
                  if remote:IsA("RemoteEvent") then
                      session.connections[#session.connections + 1] = remote.OnClientEvent:Connect(function(...)
                          cheat.debugWrite("server", remote, ...)
                      end)
                  elseif remote:IsA("UnreliableRemoteEvent") then
                      session.connections[#session.connections + 1] = remote.OnClientEvent:Connect(function(...)
                          cheat.debugWrite("server-u", remote, ...)
                      end)
                  end
              end
          end
          local watchedHumanoid = nil
          session.connections[#session.connections + 1] = Run.Heartbeat:Connect(function()
              local character = Targeting.TargetCharacter
              local humanoid = character and character:FindFirstChildOfClass("Humanoid")
              if humanoid ~= watchedHumanoid then
                  watchedHumanoid = humanoid
                  if humanoid then
                      cheat.debugWrite("target", character, "health", humanoid.Health)
                      session.connections[#session.connections + 1] = humanoid.HealthChanged:Connect(function(health)
                          cheat.debugWrite("target-hp", character, health)
                      end)
                  end
              end
          end)
          local character = Client.Character
          local tool = character and character:FindFirstChildOfClass("Tool")
          cheat.debugWrite("session", "weapon", tool and tool.Name or "none", "silent", tostring(flags.AimbotEnabled), "manip", tostring(flags.Manipulation), "hitscan", tostring(flags.Hitscan), "instant", tostring(flags.InstantBullet), "noSpread", tostring(flags.NoSpread))
          Library:Notification("Debug started", 3, Color3.fromRGB(80, 200, 255))
      end
      cheat.debugStop = function()
          local session = cheat.debugSession
          if not session.active then
              return
          end
          cheat.debugWrite("session", "end")
          session.active = false
          for _, connection in ipairs(session.connections) do
              pcall(function() connection:Disconnect() end)
          end
          session.connections = {}
          local ok = pcall(writefile, "debug.txt", table.concat(session.lines, "\n"))
          Library:Notification(ok and ("debug.txt saved (" .. #session.lines .. " lines)") or "debug.txt write failed", 4, ok and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 80, 80))
          session.lines = {}
      end

      do
          local loadingScreen = game:GetService("ReplicatedStorage"):FindFirstChild("LoadingScreen")
          if loadingScreen and loadingScreen:IsA("RemoteEvent") then
              loadingScreen.OnClientEvent:Connect(function(kind, message)
                  if kind ~= "Invalid" then
                      return
                  end
                  local text = tostring(message)
                  if cheat.debugSession.active then
                      cheat.debugWrite("server-invalid", text)
                  end
                  if flags.ShowRejects ~= false then
                      Library:Notification("Server: " .. text, 6, Color3.fromRGB(255, 120, 80))
                  end
              end)
          end
      end

      if type(VectorUtil) == "table" and type(VectorUtil.FireRemote) == "function" then
          local fireRemote
          local fire_hook
          fire_hook = LPH_NO_UPVALUES(function(self, ...)
              local args = { ... }
              local now0 = os.clock()
              local bulletIdMap = cheat.Globals.bulletIdMap
              if bulletIdMap and next(bulletIdMap) then
                  for index, value in pairs(args) do
                      if type(value) == "number" and bulletIdMap[value] then
                          args[index] = bulletIdMap[value].id
                      elseif type(value) == "table" then
                          for key, inner in pairs(value) do
                              if type(inner) == "number" and bulletIdMap[inner] then
                                  value[key] = bulletIdMap[inner].id
                              end
                          end
                      end
                  end
                  for clientId, entry in pairs(bulletIdMap) do
                      if now0 - entry.t > 8 then
                          bulletIdMap[clientId] = nil
                      end
                  end
              end
              if cheat.debugSession.active then
                  cheat.debugWrite("remote-in", args[1], args[2], args[3])
              end
              local shotSync = cheat.Globals.shotSync
              local payload = nil
              for i = #args, 1, -1 do
                  local p = args[i]
                  if type(p) == "table" and #p == 8
                      and typeof(p[1]) == "Vector3"
                      and typeof(p[2]) == "number"
                      and typeof(p[3]) == "number"
                      and typeof(p[4]) == "CFrame"
                      and typeof(p[5]) == "Vector3"
                      and typeof(p[6]) == "CFrame"
                      and typeof(p[7]) == "string"
                      and typeof(p[8]) == "number" then
                      payload = p
                      break
                  end
              end
              if payload then
                  local now = os.clock()
                  local originalTick = payload[8]
                  local originalSpread = payload[3] + payload[2]
                  if payload[5].Magnitude > 8 then
                      payload[5] = payload[4]:VectorToObjectSpace(payload[6].LookVector * 3)
                  end
                  payload[5] = cheat.clampFlash(payload[5])
                  local synced = shotSync and shotSync.hit and typeof(shotSync.dest) == "Vector3" and now0 - shotSync.t < 0.2
                  if synced then
                      local aim8 = shotSync.dest + (shotSync.drop or Vector3.zero)
                      local moved = shotSync.manip
                      payload[6] = CFrame.new(payload[6].Position, aim8)
                      if typeof(shotSync.rootSend) == "CFrame" and typeof(shotSync.flashOffset) == "Vector3" then
                          payload[4] = shotSync.rootSend
                          payload[5] = shotSync.flashOffset
                          if typeof(shotSync.cameraSend) == "CFrame" then
                              payload[6] = CFrame.new(shotSync.cameraSend.Position, aim8)
                          end
                      end
                      if typeof(moved) == "Vector3" then
                          cheat.Globals.lastMoveShot = now
                          cheat.Globals.lastMovePos = moved
                      end
                      payload[1] = aim8
                      local wideSpread = 40
                      local chosenTick = nil
                      local lastTick = cheat.Globals.lastSentTick or 0
                      for step = 0, 800 do
                          local candidate = originalTick + step * 0.0001
                          if candidate % 1 ~= 0 and candidate > lastTick then
                              local generator = Random.new(math.floor(candidate * 10000))
                              if generator:NextNumber(0, wideSpread) < 0.5 then
                                  chosenTick = candidate
                                  break
                              end
                          end
                      end
                      local serverTick, serverSpread = originalTick, 0
                      if chosenTick then
                          serverTick, serverSpread = chosenTick, wideSpread
                      end
                      if serverTick ~= originalTick or serverSpread ~= originalSpread then
                          local clientIds = cheat.bulletIds(originalTick, originalSpread, 16)
                          local serverIds = cheat.bulletIds(serverTick, serverSpread, 16)
                          local map = cheat.Globals.bulletIdMap or {}
                          cheat.Globals.bulletIdMap = map
                          for index = 1, 16 do
                              if clientIds[index] ~= serverIds[index] then
                                  map[clientIds[index]] = { id = serverIds[index], t = now }
                              end
                          end
                      end
                      payload[8] = serverTick
                      payload[3] = serverSpread
                      payload[2] = 0
                      if shotSync.mode ~= "direct" then
                          cheat.log("shot", string.format("mode=%s tick=%s", tostring(shotSync.mode), tostring(chosenTick ~= nil)))
                      end
                  else
                      local previousTick = cheat.Globals.lastSentTick or 0
                      if payload[8] <= previousTick then
                          local bumpedTick = nil
                          for step = 1, 400 do
                              local candidate = previousTick + step * 0.0001
                              if candidate % 1 ~= 0 and math.floor(candidate * 10000) ~= math.floor(previousTick * 10000) then
                                  bumpedTick = candidate
                                  break
                              end
                          end
                          if bumpedTick then
                              local clientIds = cheat.bulletIds(originalTick, originalSpread, 16)
                              local serverIds = cheat.bulletIds(bumpedTick, originalSpread, 16)
                              local map = cheat.Globals.bulletIdMap or {}
                              cheat.Globals.bulletIdMap = map
                              for index = 1, 16 do
                                  if clientIds[index] ~= serverIds[index] then
                                      map[clientIds[index]] = { id = serverIds[index], t = now }
                                  end
                              end
                              payload[8] = bumpedTick
                          end
                      end
                      local camera = payload[6]
                      local toMouse = payload[1] - camera.Position
                      if toMouse.Magnitude > 0.05 and camera.LookVector:Dot(toMouse.Unit) < 0.995 then
                          payload[1] = camera.Position + camera.LookVector * toMouse.Magnitude
                      end
                  end
                  cheat.Globals.lastSentTick = payload[8]
              end
              if cheat.debugSession.active then
                  cheat.debugWrite("remote-out", args[1], args[2], args[3])
              end
              return fireRemote(self, unpack(args))
          end)
          fireRemote = hookModule(VectorUtil, "FireRemote", cheat.watch(fire_hook, "packet hook"))
      end

      do
          local function restrictOff(hum)
              for _, conn in getconnections(hum.StateChanged) do
                  local fn = conn.Function
                  if type(fn) == "function" then
                      local okSrc, source = pcall(debug.info, fn, "s")
                      if okSrc and tostring(source):find("ViewmodelController", 1, true) then
                          local old
                          old = hookfunction(fn, function(...)
                              if flags.AlwaysGrounded == true then
                                  return
                              end
                              return old(...)
                          end)
                      end
                  end
              end
          end
          local function wireGrounded(ch)
              task.spawn(function()
                  local hum = ch:WaitForChild("Humanoid", 10)
                  local vmc = ch:WaitForChild("ViewmodelController", 10)
                  if hum and vmc then
                      restrictOff(hum)
                  end
              end)
          end
          local lp = Players.LocalPlayer
          if lp then
              if lp.Character then
                  wireGrounded(lp.Character)
              end
              lp.CharacterAdded:Connect(wireGrounded)
          end
      end

      if SoundModule and SoundModule.ToggleFootstep and SoundModule.StopSound then
          local oldToggle = SoundModule.ToggleFootstep
          local oldPlay = SoundModule.PlaySound
          SoundModule.ToggleFootstep = oldToggle
          SoundModule.PlaySound = oldPlay
      end


      cheat.Globals.shotSync = nil
      cheat.Globals.NotifHit = nil
      cheat.Globals.NotifShot = nil
      cheat.Globals.NotifLast = { hit = 0, miss = 0 }


      local notif_cooldown = 0.1
      Run.Heartbeat:Connect(function()
          if not flags.HitNotifier and not flags.MissNotifier then
              return
          end
          local now = tick()
          local hit = cheat.Globals.NotifHit
          local shot = cheat.Globals.NotifShot
          if hit and (now - hit.t) < 0.5 and (now - cheat.Globals.NotifLast.hit) > notif_cooldown then
              if flags.HitNotifier then
                  local hp = math.floor(hit.hp_remaining + 0.5)
                  local hp_text = hp <= 0 and " (0 hp remaining)" or string.format(" (%d hp remaining)", hp)
                  local msg = string.format("hit %s in %s for %d damage%s", hit.name, hit.part, hit.damage, hp_text)
                  pcall(function()
                      Library:Notification(msg, 3, Color3.fromRGB(120, 255, 120))
                  end)
                  cheat.Globals.NotifLast.hit = now
              end
              cheat.Globals.NotifHit = nil
              cheat.Globals.NotifShot = nil
              return
          end
          if shot and (now - shot.t) > 0.4 and (now - shot.t) < 0.6 and (now - cheat.Globals.NotifLast.miss) > notif_cooldown then
              if flags.MissNotifier then
                  local reason = shot.has_los and "due to resolver" or "due to occlusion/wall"
                  local msg = string.format("missed at %s %s", shot.name, reason)
                  pcall(function()
                      Library:Notification(msg, 3, Color3.fromRGB(255, 90, 90))
                  end)
                  cheat.Globals.NotifLast.miss = now
              end
              cheat.Globals.NotifShot = nil
          end
      end)


      local UpdateChar = LPH_NO_VIRTUALIZE(function()
          local character = Client.Character or Client.CharacterAdded:Wait()
          cheat.Globals.ClientCharacter = character
          if character:FindFirstChildOfClass('Humanoid') or character:WaitForChild('Humanoid', 10) then
              task.defer(function()
                  task.wait(1)
                  grabSprings()
                  pcall(syncRemovals)
              end)
          end
      end)

      UpdateChar()
      Client.CharacterAdded:Connect(UpdateChar)

  end
