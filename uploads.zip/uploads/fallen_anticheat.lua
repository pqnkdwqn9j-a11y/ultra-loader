--[[
	  _                  _                 _
	 | |                | |               | |
	 | | __ _ _ __ _ __ | |__   ___   ___ | | __
	 | |/ _` | '__| '_ \| '_ \ / _ \ / _ \| |/ /
	 | | (_| | |  | |_) | | | | (_) | (_) |   <
	 |_|\__,_|_|  | .__/|_| |_|\___/ \___/|_|\_\
	              | |
	              |_|

	deobfuscator version: 1.0.0
	deobfuscated by aquabeary's deobfuscator
]]

local function Fn(Arg1)
	local V = ("ChickenBagelz is %* you {lol}"):format(((function()
		return "Watching"
	end)()))
	local V2 = "e"
	local V3 = V2:rep(11)
	local function Fn(Arg1, Arg2, Arg3, Arg4, ...)
		local V = 0
		for _ in Arg2 do
			V = V + 1
			if not (if V > 0 then Arg3 else Arg4) then
				V = 0
			end
		end
		return V .. ("%*"):format(Arg1.Name), 1234 // V
	end
	local V4, V5 = (function(Arg1)
		return if V2 == "e" then "ChickenBagelz" else nil, Arg1
	end)(Fn)
	local function Fn2(Arg1)
		return Arg1, #{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{nil}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} + #{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{nil}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} + #{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{nil}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} + #{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{nil}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} + #table.clone({{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{nil}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}) + #("%*"):format(Arg1)
	end
	local V6, V7 = Fn2(V5)
	local V8, V9 = V6(game.Lighting, {
		a = {"ChickenBagelz"},
		b = function()
			return {}
		end,
	}, true, nil, 0, true)
	local V10, V11 = Fn2(0)
	local V12, V13 = Fn2(function()
	end)
	for _ in {0} do
		return {V, "\t\tlocal test;\n\t\t;\";,.?lp+-)4927(@#$&^\"[]'``workspace:Destroy()\n\t\t%u%c%d\\u{001}\\000\n\t\t\\n\\r\n\t", V2, V3, Fn, V4, V5, V8, V7, V13, V11, V12, V9, Arg1}
	end
end
local V = Fn(8)
local V2 = 295950284
local V3 = 687093657
local Workspace = workspace
local V4 = 857521036
local V5 = 895631756
local function Fn2()
	local V = nil
	local function Fn()
		local Part = Instance.new("Part")
		Part.Archivable = false
		Part.Changed:Connect(V)
		Part.Parent = workspace
	end
	V = Fn
	V()
end
local Game = game
local V6 = false
local V7 = nil
local V8 = nil
local function Fn3(Arg1)
	local Pcall = pcall
	local FindService = Game.FindService
	local V = ("%*\0"):format(Arg1)
	local V6, V7 = Pcall(FindService, Game, V)
	if V6 ~= true or typeof(V7) ~= "Instance" or (V7.ClassName ~= Arg1 or not V7:IsA(Arg1) or V7.Parent ~= Game) then
		Fn2()
	end
	return V7
end
local ReplicatedFirst = Fn3("ReplicatedFirst")
local ReplicatedStorage = Fn3("ReplicatedStorage")
local Players = Fn3("Players")
local HttpService = Fn3("HttpService")
local LogService = Fn3("LogService")
local ScriptContext = Fn3("ScriptContext")
local RunService = Fn3("RunService")
local PointsService = Fn3("PointsService")
local GuiService = Fn3("GuiService")
local MarketplaceService = Fn3("MarketplaceService")
local ContentProvider = Fn3("ContentProvider")
local Lighting = Fn3("Lighting")
local SoundService = Fn3("SoundService")
local TestService = Fn3("TestService")
local CollectionService = Fn3("CollectionService")
local Stats = Fn3("Stats")
local NetworkClient = Fn3("NetworkClient")
Game:GetService("CoreGui\0")
local LocalPlayer = Players.LocalPlayer
local V9 = nil
local function Fn4(Arg1, ...)
	if (game:GetService("Players"):GetAttribute("Debug") or ""):sub(Arg1, Arg1) ~= "1" then
		return ""
	end
	local V = ("[DEBUG%*]"):format(Arg1)
	if ... == true then
		warn(V, select(2, ...))
	else
		print(V, ...)
	end
	return ""
end
local V10 = nil
local function Fn5(CurrentCamera)
	if CurrentCamera == nil then
		return "nil"
	end
	local Pcall = pcall
	local function Fn()
		if not V10 then
			V10 = Instance.new("ViewportFrame\0sigma")
		end
		V10.CurrentCamera = CurrentCamera
		return CurrentCamera == V9
	end
	local V, V2 = Pcall(Fn)
	if V or ("%*"):format(V2) ~= V2 then
		if V ~= true or V2 ~= true then
			V6 = {tostring(20), 0, V, V2}
			return
		end
		return "Instance", "Camera"
	else
		local V3 = string.match(V2, "^Unable to assign property CurrentCamera%. Camera expected, got (.+)$")
		if V3 then
			return V3
		end
		local V4 = string.match(V2, "^Expected Camera got (.+) for ViewportFrame.CurrentCamera%.$")
		if not V4 then
			V6 = {tostring(20), 0, V, V2}
			return
		end
		return "Instance", V4
	end
	V6 = {tostring(20), 0, V, V2}
end
local function Fn6(Arg1)
	local V = ("%*"):format(Arg1)
	if V == Arg1 then
		return 0
	end
	local V2, V3 = V:gsub(", ", "")
	if V3 == 1 then
		return 2
	end
	if V3 == 11 then
		return 5
	end
	local V4, V5 = pcall(function()
		return Arg1.FuzzyEq
	end)
	if V4 and V3 == 2 then
		return 3
	end
	if V5 == "FuzzyEq is not a valid member of Color3" then
		return 6
	end
	if V5 and V5:find("attempt to index number with 'FuzzyEq'", 1, true) then
		return 1
	end
	if V5 and (V5:find("FuzzyEq is not a valid member of ", 1, true) and V5:find(V, 1, true)) then
		return 4
	end
	return nil
end
local function Fn7(Arg1)
	local V, V2 = pcall(function()
		return Arg1["\1"]
	end)
	if not V and ("%*"):format(V2) == V2 then
		local V3, V4 = string.match(V2, "\1 is not a valid member of (%u%w+) \"(.+)\"$")
		if V4 and V3 then
			return V4, V3
		end
	end
	V8 = {13, 1, V, V2}
end
local function Fn8(Instance2, Arg2)
	local Pcall = pcall
	local function Fn()
		return Instance2[Arg2]
	end
	local V, V2 = Pcall(Fn)
	if not V then
		if V2 ~= ("%* is not a valid member of %* \"%*\""):format(Arg2, Instance2.ClassName, Instance2:GetFullName()) then
			V6 = {20, 2, V, V2, Arg2}
			return
		end
		return nil
	else
		if type(V2) ~= "userdata" or (V2.Parent ~= Instance2 or V2.Name ~= Arg2) then
			V6 = {20, 2, V, V2, Arg2}
			return
		end
		return V2
	end
	V6 = {20, 2, V, V2, Arg2}
end
local function Fn9(Arg1, Arg2, Arg3)
	local V = Arg3 or math.huge
	local V7 = 0
	local V8
	while true do
		V8 = Fn8(Arg1, Arg2)
		if V8 then
			break
		end
		if V <= V7 then
			local V9 = Fn7(Arg1)
			warn(("Infinite yield possible for (%*) in"):format(Arg2), V9)
			return nil
		end
		V7 = V7 + task.wait(0.1)
	end
	return V8
end
local function Fn10(Str, Arg2, Arg3)
	local V = Str:sub(Arg2 or 1, Arg3)
	local V2 = #V
	local V3 = buffer.fromstring(string.rep(".", V2))
	buffer.writestring(V3, 0, V)
	if V2 == 1 then
		local V4 = buffer.readu8(V3, 0)
		buffer.writeu8(V3, 0, 0)
		return V4
	end
	local T = {}
	for Index = 0, V2 - 1 do
		table.insert(T, buffer.readu8(V3, Index))
	end
	buffer.fill(V3, 0, 0, V2)
	return unpack(T)
end
local function Fn11(...)
	local V, V2 = VM_pack(...)
	local T = {}
	local V3 = V + -1
	local V4, V5
	if V3 < 0 then
		V4 = #T
		V5 = buffer.fromstring(string.rep(" ", V4))
	else
		local Count = 0
		for Index = 3, 3 + V3 do
			REG[i_85] = V2[1 + Count]
			Count = Count + 1
		end
		table.move(REG, 3, 3 + V3, 1, T)
		V4 = #T
		V5 = buffer.fromstring(string.rep(" ", V4))
	end
	for Key, Value in T do
		buffer.writeu8(V5, Key - 1, Value)
	end
	local V6 = buffer.readstring(V5, 0, V4)
	buffer.fill(V5, 0, 0, V4)
	return V6
end
local V11 = nil
local function Fn12(Arg1)
	local V = Arg1 .. "\1"
	local V6 = string.match(("%*"):format(tick()), "%d$")
	if V6 == "0" or V6 == "1" then
		PathWaypoint.new(Vector3.new())[V] = 0
	elseif V6 == "2" or V6 == "3" then
		SharedTable.increment(SharedTable.new(), V, 0)
	else
		if V6 == "4" or V6 == "5" then
			ReplicatedFirst[V] = 0
		elseif V6 == "6" or V6 == "7" then
			Instance.new(V)
		else
			assert(V11, V)
			V11(V)
		end
	end
end
local function VectorsEqual(Arg1, Arg2)
	return (Arg1.X - Arg2.X) ^ 2 + (Arg1.Y - Arg2.Y) ^ 2 + (Arg1.Z - Arg2.Z) ^ 2
end
local V12 = nil
local function DeepCopy(Tbl)
	local T = {}
	for Key, Value in Tbl do
		local V
		if type(Value) ~= "table" then
			V = Value
		else
			V = V12(Value)
		end
		T[Key] = V
	end
	return T
end
V12 = DeepCopy
local V13 = nil
local function Fn13(Arg1, Arg2, Arg3, Arg4)
	for Key, Value in Arg1 do
		local V = Arg2[Key]
		local V2 = if type(Value) == "table" then if type(V) == "table" then true else false else false
		if Value ~= V and (Arg4 or not V2) then
			return Key
		end
		if Arg3 and V2 then
			local V3 = V13(Value, V, Arg3, Arg4)
			if V3 ~= nil then
				return V3
			end
		end
	end
	for Key2 in Arg2 do
		if Arg1[Key2] == nil then
			return Key2
		end
	end
end
V13 = Fn13
local function Fn14(Arg1)
	local V = 0
	for _, Value in Arg1 do
		V = V + Value
	end
	return V
end
local V14 = Fn9(ReplicatedFirst, "Preload")
local V15 = Fn9(ReplicatedStorage, "Remotes")
local V16 = Fn9(ReplicatedStorage, "Modules")
V9 = Fn9(Workspace, "Camera")
local V17 = Fn9(LocalPlayer, "PlayerGui")
Fn9(Workspace, "Bases")
local T = {Fn9(Workspace, "Nodes"), Fn9(Workspace, "Trees")}
local V18 = Fn9(V16, "ToolInfo")
local V19 = Fn9(Lighting, "Atmosphere")
local V20 = Fn9(Lighting, "ColorCorrection")
local V21 = Fn9(Lighting, "Sky")
local V22 = Fn9(NetworkClient, "ClientReplicator", 3)
local V23 = nil
local V24 = require(V18)
require(Fn9(V16, "VFXModule"))
local V25 = ("%*"):format(getfenv())
local Script = script
local Pcall = pcall
local Name = LocalPlayer.Name
local UserId = LocalPlayer.UserId
local V26 = nil
local T2 = {}
local T3 = {
	"^CoreGui%.RobloxGui%.Modules%.",
	"CoreGui%.RobloxGui%.CoreScripts/",
	"^CorePackages%.Packages%.",
	"^CorePackages%.Workspace%.",
	"^Script Context%.CoreScripts",
}
local V27 = V12(V24)
local V28 = Enum["MessageType\0ts"]["MessageError\0pmo"]
local T4 = {
	AvatarEditorPrompts = 70,
	JestGlobals = 15,
	EventConnection = 75,
	PlayerListManager = 10,
	UnibarMenu = 625,
	LeaveGame = 30,
	StyledTextLabel = 100,
	GetHasGuiHidingPermission = 40,
	["en-us"] = 99,
	Url = 99,
	RaycastUtil = 270,
	ViewmodelController = 2610,
	EquipController = 240,
	VRNavigation = 460,
}
local T5 = {"^%U", "^%u+$", "^%l+$", "%A[^2]", "%W", "", "%.%W", "[^ _%w%.]", " .* ", "[^%l2I]$"}
local T6 = {"^%A", "^%u+$", "[_%.%-/].*[_%.%-/]", "", "%.[^%w_]", "[^ _/%w%.%-]", "[^%a1-3]$"}
local T7 = {"%.Items", true, 0}
local T8 = {"LootTable", true, 0}
local T9 = {
	{"Script ''", true, 0},
	{"RobloxReplicatedStorage%..+%.Scripts?%.", true, 0},
	{"CoreGui%.Oxy%.", true, 0},
	{"%[string \".*\"%]", true, 0},
	{"Luraph[ \"][S%]]", true, 0},
	{"[^ts], line %d+", true, 0},
	{"Maximum event re%-entrancy depth (%d+) exceeded for Object%.%w+Changed", true, 0},
	{"Cannot require a[ no%-]*RobloxScript module from a[ no%-]*RobloxScript", true, 0},
	{"%D[^:] User is not authorized to access Asset", true, 0},
	{"An unknown error occured by the server%.", true, 0},
	{"Orion Library ", true, 0},
	{"^corescript ", true, 0},
	{"%[mod", false, 0},
	{"%[zephyr%]", false, 0},
	{"%[fallen%]", false, 0},
	{"[^%]]%[.*hub%]", false, 0},
	{"%[exec", false, 0},
	{"discord%.gg", false, 0},
	{"<eof>", false, 0},
	{"the current thread cannot ", false, 0},
	{"amongus%.hook", false, 0},
	{"have a head", false, 0},
	{"buffer:", false, 0},
	{"[^\"_%w]loadstring[^\"_%w]", false, 0},
	{"queue_on_teleport", false, 0},
	{"'setfenv'", false, 0},
	{"'getfenv'", false, 0},
	{"get_tool_name", false, 0},
	{"infinite yield is already running", false, 0},
	{"attempt to index nil with 'body'", false, 0},
	{" function synapse", false, 0},
	{"passed value is not a function", false, 0},
	{" when parsing ", false, 0},
	{" malformed ", false, 0},
	{"'waiting'", false, 0},
	{"v.?g hub", false, 0},
	{" script env ", false, 0},
	{"^.+ notification: ", false, 0},
	{"^.+ initialization.", false, 0},
	{"^error loading script:", false, 0},
	{"^Server Kick Message:", true, 2},
	{"RelicsXYZ", true, 2},
	{"Remote event invocation queue exhausted for", true, 2},
	{"^not enough memory$", true, 2},
	{"ReactReconciler", true, 2},
	{"API: %a+, Data Store: [%w_]+$", true, 2},
	{"cloud_%d+", true, 2},
	{"TextChatService%.OnIncomingMessage", true, 2},
	{"contentprovider:", false, 2},
	{"roblox%.com", false, 2},
	{"_workspace", false, 2},
	{"purchaseprompt", false, 2},
	{"Unhandled Promise rejection:", true, 1},
	{"Multiple StyleLinks", true, 1},
	{"Mic Update ", true, 1},
	{"Report Abuse V%d failed: ", true, 1},
	{"LUMBERYAK INTERNAL", true, 1},
	{"CrossExperienceVoice", true, 1},
	{"Native code generation is not supported on this platform%.", true, 1},
	{"This may be caused by an accidental early return statement%.", true, 1},
	{
		"RunService:UnbindFromRenderStep removed different functions with same reference name utility%-",
		true,
		1,
	},
	{"^%[LOG%] %[", true, 1},
	{"^INVALID: ", true, 1},
	{"^KILLED BY: ", true, 1},
	{"%[UIBlox", true, 1},
	{".Archivable = true.", true, 1},
	{"PING BREAK DOWN", true, 1},
	{"CoreScriptMemory", true, 1},
	{" DataPing", true, 1},
	{"http error", false, 1},
	{"httpresponse", false, 1},
	{"locale not found: ", false, 1},
	{"friendstatus", false, 1},
	{"chatinputbarconfiguration", false, 1},
	{"^>>> true table: 0x", false, 1},
	{"maintainvisiblecontentposition", false, 1},
	{"^========================================================$", false, 1},
	{"Script 'Connection'", true, 0},
	{"rendered fewer hooks than expected", false, 0},
	{"invalid animation id", false, 0},
	{" and may timeout", false, 0},
	{"checkheaderforxml", false, 0},
	{"promise created at:", false, 0},
	{"expchat", false, 0},
	{"%[Instance%(", true, 1},
	{"^Argument ", true, 1},
	{"passed:", false, 1},
	{"[^e] called", false, 1},
	{"'',", true, 0},
	{"Preload", true, 0},
	{"SharedTable", true, 0},
	T7,
	T8,
	{"Expected ':' not '%.' calling ", true, 0},
	{"AttachmentStats", true, 0},
	{"VMMovementMults", true, 0},
	{" Crossbow", true, 0},
	{"Rayfield", true, 0},
	{"^localhitfunction", false, 0},
	{"assetcontainer", false, 0},
	{"recoilstart", false, 0},
	{"%[error%]:", false, 0},
	{"incomplete statement: ", false, 0},
	{"unaccounted for ", false, 0},
	{"remotefunction", false, 0},
	{"remoteevent", false, 0},
	{"enum%.", false, 0},
	{"lph_", false, 0},
	{"discord", false, 0},
	{"github", false, 0},
	{"gui [^\"]", false, 0},
	{"metatable", false, 0},
	{"cclosure", false, 0},
	{"lclosure", false, 0},
	{"remotespy", false, 0},
	{"bypass", false, 0},
	{"cheat", false, 0},
	{"lua vm", false, 0},
	{"upvalue", false, 0},
	{"stack level", false, 0},
	{"out of range", false, 0},
	{" closure[^\n\r]", false, 0},
	{"rconsoleprint", false, 0},
	{"getnilinstances", false, 0},
	{"writefile", false, 0},
	{"unable to assign property [^t]", false, 0},
	{"userdata", false, 0},
	{"thread:", false, 0},
	{"function:", false, 0},
	{"hooked", false, 0},
	{"hooking", false, 0},
	{"toolinfo", false, 0},
	{"maxstack", false, 0},
	{"fallenguard", false, 0},
	{"newindex", false, 0},
	{"namecall", false, 0},
	{"metamethod", false, 0},
	{"mousemoveabs", false, 0},
	{"proto", false, 0},
	{"noclip", false, 0},
	{"gravity", false, 0},
	{"decompile", false, 0},
	{"hookfunction", false, 0},
	{"thread ?identity", false, 0},
	{"getclosestplayer", false, 0},
	{"pointsservice", false, 0},
	{"loadstring", false, 0},
	{"destroy_chams", false, 0},
	{"updateesp", false, 0},
	{"createesp", false, 0},
	{"exception caught", false, 0},
	{"getteleportposition", false, 0},
	{"luau.execute", false, 0},
	{"typeface to ", false, 0},
	{"xray ", false, 0},
	{"parse json", false, 0},
	{"queue.?on.?teleport", false, 0},
	{"auto.?execute", false, 0},
	{"\1", false, 0},
	{"^init ez ez$", false, 0},
	{"ban attempt", false, 0},
	{"value of type nil", false, 0},
	{"nil with 'format'", false, 0},
	{"function getsetting", false, 0},
	{"viewmodelcontroller:%d:", false, 0},
	{"[`|%^%$]", false, 0},
	{"[:,#!<>=~%?%+%*%+%%][:,#!<>=~%?%+%*%+%%]", false, 0},
	{"[/_;%[%]%(%)][/_;\"%[%]%(%)][/_;\"%[%]%(%)]", false, 0},
}
local T10 = {
	["Steel Pickaxe"] = {nil, true, 1.5, nil, nil, nil, 5.5, 0, 0, 25, 25},
	["Admin Tool"] = {nil, true, 0.12, nil, nil, nil, 100, 5, 5},
	["Military MP7"] = {
		575,
		true,
		nil,
		1900,
		0.6,
		800,
		nil,
		15,
		24,
		1,
		2,
		0.08,
		0.08,
		220,
		1.15,
		-0.8635788820547359,
		false,
		false,
		nil,
		220,
		13,
	},
	["Bone Tool"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	["Small Medkit"] = {nil, nil, 2.75, nil, nil, nil, nil, 0, 0},
	["Military Grenade Launcher"] = {70, false, nil, 85, 0.15, 2000, nil, 10, 10, 10, 15, 0.2, 0.08, 60, 6, 0},
	["Salvaged Pump Action"] = {150, false, nil, 650, 0.6, 200, nil, 40, 50, 40, 40, 0.15, 0.1, 50, 6.5, 0},
	["Pink Keycard"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Red Keycard"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Salvaged AK47"] = {
		450,
		true,
		nil,
		2100,
		0.55,
		1100,
		nil,
		18,
		30,
		0.3,
		0.6,
		0.08,
		0.08,
		300,
		1.75,
		0.24197462311618628,
		false,
		false,
		nil,
		290,
		7,
	},
	["Salvaged AK74u"] = {
		540,
		true,
		nil,
		1800,
		0.6,
		800,
		nil,
		15,
		24,
		1,
		2,
		0.08,
		0.08,
		300,
		0,
		-2.7438062851016993,
		false,
		false,
		nil,
		300,
		13,
	},
	["Military Barrett"] = {160, true, nil, 2500, 0.55, 1100, nil, 18, 30, 0.3, 0.6, 0.15, 0.1, 50, 8, 0},
	["Iron Shard Hatchet"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	["Wooden Spear"] = {nil, true, 1.3, nil, nil, nil, 7.5, 0, 0, 25, 25},
	["Salvaged P250"] = {
		375,
		false,
		nil,
		1400,
		0.6,
		600,
		nil,
		16,
		28,
		1.75,
		3.5,
		0.07,
		0.07,
		80,
		2.2,
		0,
		false,
		true,
		nil,
		nil,
		2.5,
	},
	Blueprint = {},
	["Salvaged M14"] = {
		370,
		false,
		nil,
		2100,
		0.55,
		1100,
		nil,
		21,
		36,
		0.5,
		1,
		0.08,
		0.08,
		150,
		3.05,
		0,
		false,
		true,
		nil,
		nil,
		6,
	},
	["Saw Bat"] = {nil, true, 1.6, nil, nil, nil, 6.5, 0, 0, 25, 25},
	["Black Keycard"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Candy Cane"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	Hammer = {nil, true, 0.72, nil, nil, nil, 10, 0, 0},
	["Salvaged Python"] = {
		300,
		false,
		nil,
		1800,
		0.6,
		700,
		nil,
		14,
		27,
		1,
		2,
		0.07,
		0.07,
		60,
		5.4,
		0,
		false,
		true,
		60,
		nil,
		1,
	},
	["Pumpkin Launcher"] = {70, false, nil, 80, 0.16, 2000, nil, 10, 10, 10, 10, 0.2, 0.08, 60, 6, 0},
	["Bruno's M4A1"] = {
		530,
		true,
		nil,
		2100,
		0.55,
		1050,
		nil,
		20,
		32,
		0.3,
		0.6,
		0.08,
		0.08,
		300,
		1.54,
		-0.7949723686588435,
		false,
		false,
		nil,
		300,
		5,
	},
	["Salvaged Shovel"] = {nil, true, 1.3, nil, nil, nil, 6, 0, 0, 25, 25},
	["Salvaged Pipe Rifle"] = {135, false, nil, 1700, 0.6, 850, nil, 24, 40, 0, 0, 0.15, 0.1, 10, 6.5, 0},
	["Dynamite Bundle"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Salvaged RPG"] = {60, false, nil, 100, 0.12, 1000, nil, 10, 10, 10, 10, 0.3, 0.12, 10, 10, 0},
	["Yellow Keycard"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Salvaged Shotgun"] = {100, false, nil, 400, 0.6, 100, nil, 55, 60, 55, 60, 0.15, 0.1, 10, 8, 0},
	["Salvaged SMG"] = {
		462,
		true,
		nil,
		1800,
		0.6,
		750,
		nil,
		17,
		28,
		1,
		2,
		0.09,
		0.09,
		200,
		2.6,
		-2.1646522708002403,
		false,
		false,
		nil,
		200,
		5,
	},
	Boulder = {nil, true, 1.5, nil, nil, nil, 4.5, 0, 0, 25, 25},
	["ez shovel"] = {nil, true, 0.85, nil, nil, nil, 6, 0, 0},
	["Salvaged Break Action"] = {130, false, nil, 550, 0.6, 200, nil, 45, 55, 45, 45, 0.15, 0.1, 10, 6.5, 0},
	["Nail Gun"] = {
		400,
		false,
		nil,
		165,
		0.25,
		125,
		nil,
		15,
		24,
		2,
		2,
		0.08,
		0.08,
		140,
		2,
		0,
		false,
		true,
		nil,
		nil,
		3,
	},
	Crossbow = {180, false, nil, 420, 0.2, 500, nil, 24, 40, 0.05, 0.05, 0.15, 0.1, 10, 5, 0},
	["Steel Shovel"] = {nil, true, 1.35, nil, nil, nil, 6, 0, 0, 25, 25},
	["Steel Axe"] = {nil, true, 1.5, nil, nil, nil, 5.5, 0, 0, 25, 25},
	["Military M4A1"] = {
		500,
		true,
		nil,
		2100,
		0.55,
		1050,
		nil,
		20,
		32,
		0.3,
		0.6,
		0.08,
		0.08,
		300,
		2.03,
		-1.0499635057758308,
		false,
		false,
		nil,
		300,
		5,
	},
	["Care Package Signal"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Carrot Blade"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	["Iron Shard Pickaxe"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	["Military PKM"] = {425, true, nil, 2400, 0.55, 1250, nil, 24, 40, 0.3, 0.6, 0.08, 0.08, 750, 3.5, 0.3},
	Lighter = {nil, nil, 1.4, nil, nil, nil, nil, 0, 0},
	["Wire Cutters"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Salvaged Double Barrel"] = {120, false, nil, 550, 0.6, 200, nil, 45, 55, 45, 45, 0.15, 0.1, 20, 6, 0},
	Chainsaw = {nil, true, 0.15, nil, nil, nil, 6.5, 0, 0},
	["Military Grenade"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Military USP"] = {
		430,
		false,
		nil,
		1500,
		0.6,
		650,
		nil,
		15,
		26,
		1.75,
		3.5,
		0.07,
		0.07,
		120,
		2.2,
		0,
		false,
		true,
		nil,
		nil,
		2.5,
	},
	Machete = {nil, true, 1.25, nil, nil, nil, 5.5, 0, 0, 25, 25},
	["Stone Hatchet"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	Bandage = {nil, nil, 4, nil, nil, nil, nil, 0, 0},
	["Halloween Scythe"] = {nil, true, 1.5, nil, nil, nil, 5.5, 0, 0, 25, 25},
	["Wooden Bow"] = {150, false, nil, 280, 0.2, 400, nil, 5, 5, 0.1, 0.1, 0.15, 0.1, 10, 0, 0},
	["Dynamite Stick"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Mining Drill"] = {nil, true, 0.15, nil, nil, nil, 6.5, 0, 0},
	["Stone Spear"] = {nil, true, 1.3, nil, nil, nil, 7.5, 0, 0, 25, 25},
	["Salvaged Sniper"] = {160, true, nil, 2400, 0.55, 1100, nil, 18, 30, 0.3, 0.6, 0.15, 0.1, 50, 7, 0},
	["Military AA12"] = {220, true, nil, 600, 0.6, 200, nil, 45, 55, 45, 45, 0.15, 0.1, 100, 5.5, 0},
	["Stone Pickaxe"] = {nil, true, 0.9, nil, nil, nil, 5, 0, 0, 25, 25},
	["Purple Keycard"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
	["Military M39"] = {
		420,
		false,
		nil,
		2400,
		0.52,
		1300,
		nil,
		21,
		36,
		0.5,
		1,
		0.08,
		0.08,
		200,
		3.05,
		0,
		false,
		true,
		nil,
		nil,
		6,
	},
	["Salvaged Grenade Launcher"] = {80, false, nil, 85, 0.15, 2000, nil, 10, 10, 10, 15, 0.2, 0.08, 10, 6, 0},
	["Salvaged Skorpion"] = {
		600,
		true,
		nil,
		1600,
		0.6,
		550,
		nil,
		20,
		32,
		3,
		5,
		0.09,
		0.09,
		150,
		2.75,
		0.13064320449606434,
		false,
		false,
		nil,
		150,
		5,
	},
	["Timed Charge"] = {nil, nil, 1, nil, nil, nil, nil, 0, 0},
}
local V29 = "C\233\147\186\243\221\172\1J\189N\129\236\240-(\186a\197\171"
local V30 = "\179\"\213\187\234\245\184\190\253l\206\180\220~\1M\t\133.\23"
local V31 = nil
local V32 = nil
local V33 = false
local T11 = {}
local Script2 = script
local T12 = {}
local V34 = nil
local T13 = {}
local T14 = {}
local T15 = {}
local V35 = -1
local V36 = false
local V37 = Game.Name == "Ugc"
local V38 = false
local V39 = false
local V40 = false
local Roll = math.random(0, 10000000)
local V41 = newproxy(true)
local V42 = HttpService:GenerateGUID(false)
local T16 = {}
local V43 = 29
local V44 = 0
local JobId = Game.JobId
local function Fn15(Arg1)
	if Arg1 ~= "-" then
		V44 = V44 + tonumber(Arg1, 16)
		return
	end
end
JobId:gsub(".", Fn15)
local V45 = nil
local V46 = nil
local V47 = table.create(6, os.clock())
local T17 = {}
local Pcall2 = pcall
local function Fn16()
	local V = V15
	local V6
	while true do
		local RemoteFunction = V:FindFirstChildWhichIsA("RemoteFunction", true)
		if RemoteFunction then
			V6 = RemoteFunction:GetTags()[1]
			if type(V6) == "string" then
				break
			end
		end
		task.wait()
		V = V15
	end
	local V7
	while true do
		V7 = CollectionService:GetTagged(V6)
		if 36 <= #V7 then
			break
		end
		task.wait()
	end
	for _, Value in V7 do
		local Name = Value.Name
		local Name2 = Value.Parent.Name
		local V8 = Roll + Fn14({Fn10(Name2)})
		local V9 = T17[V8]
		if not V9 then
			V9 = {}
			T17[V8] = V9
		end
		local V10, V11 = Fn7(Value)
		local V12 = Roll + Fn14({Fn10(Name)})
		local V13
		if V11 ~= "RemoteFunction" then
			V13 = 1
		else
			V13 = -1
		end
		local V14 = V12 * V13
		if V9[V14] then
			local Error = error
			local V16 = ("zZ %* %* %*"):format(Name2, Name, V14)
			Error(V16)
		end
		V9[V14] = Value
		Value:RemoveTag(V6)
	end
end
local V48, V49 = Pcall2(Fn16)
if V48 ~= true or V49 ~= nil then
	if V37 then
		Fn2()
	end
	local function Fn17()
		if not (512588834 < V5) then
			V5 = 567327955
			V3 = V3 - 1838
			V4 = V4 - 113
			V2 = 869671673
		end
	end
	return Fn17
else
	local function Fn18(Instance2)
		local V = 0
		local V7 = nil
		repeat
			if Instance2.Parent or 3 <= V then
				pcall(Instance2.Destroy, Instance2)
				if V5 == 895632957 then
					V3 = 477461382
					V2 = 111149141
					V5 = V5 + 879
					V4 = 174389244
				else
					pcall(Instance2.Remove, Instance2)
				end
				local Pcall = pcall
				local function Fn()
					V7 = 550426015
					if V7 == 550427195 then
						V7 = 165694794
						V5 = V5 + 394
						local V = V2 + 1267
						local V6 = V2[3]
						V2 = V
						V4 = 669988723
						local V8 = V3
						V3 = 483188040
						local V9 = V8[V6]
						return
					end
					Instance2.Parent = nil
				end
				Pcall(Fn)
			end
			V = V + task.wait()
		until 5 <= V
	end
	local function Fn19(Arg1)
		local V = Arg1 == nil
		local V7
		if not V then
			V7 = Arg1
		else
			V7 = newproxy(true)
		end
		local V8
		if not V then
			V8 = {}
		else
			V8 = getmetatable(V7)
		end
		local T = {25}
		local V9 = getmetatable(V7)
		local V10
		if not V then
			V10 = nil
		else
			V10 = V8
		end
		if V9 ~= V10 or rawget(V8, "__iter") then
			V45 = {T, 0, V}
			return
		end
		for Key, Value in V8 do
			local V11 = ("%*/%*"):format(Key, Value)
			V45 = {T, 1, V, V11}
			return
		end
		local Count = 0
		local V12 = false
		for _, Value2 in string.split("index/newindex/call/concat/unm/add/sub/mul/div/idiv/mod/pow/tostring/eq/lt/le/gc/len/iter/mode/namecall/next/pairs/ipairs/name/close/band/bor/bxor/bnot/and/or/xor/not/shl/shr/xyz/type/typeof/ev/group/super/extend/inherit/get/set/n", "/") do
			Count = Count + 1
			if 47 < Count then
				break
			end
			local V13 = ("__%*"):format(Value2)
			local function Fn(Arg1, Arg2, Arg3)
				local V7 = rawequal(Arg2, nil)
				local V8 = rawequal(Arg3, nil)
				local V9 = Value2 == "unm"
				V6 = {26, V, Value2}
				if not V8 then
					rawset(Arg1, Arg2, Arg3)
				end
				local V10
				if V7 or V9 then
					V10 = tostring(T2)
				else
					V10 = nil
				end
				return V10
			end
			V8[V13] = Fn
		end
		rawset(V8, "__metatable", "The metatable is locked")
		if not V then
			setmetatable(V7, V8)
		end
		local V14 = getmetatable(V7)
		local V15 = -V7
		if Count ~= 47 or V14 ~= "The metatable is locked" or V15 ~= ("%*"):format(T2) or V12 ~= true then
			local V16 = ("%*/%*/%*/%*/%*"):format(Count, tostring(V14), V15, tostring(T2), V12)
			V45 = {T, 2, V, V16}
			return
		end
		return V7
	end
	local V50, V51
	local function Fn20(Arg1)
		local V = math.abs(Arg1)
		return math.abs(math.round(Arg1) - Arg1) <= 1e-05, if V <= V50 then true else false, if V <= V51 then true else false
	end
	local V52
	local function Fn21(Arg1)
		local V = 9
		for Index = 1, math.max(table.maxn(Arg1), 1) do
			V = V + 1
			local V2 = Arg1[Index]
			if V2 ~= nil and (V2 ~= false and V2 ~= true) then
				local V3 = Fn6(V2)
				if V3 == 0 then
					V = V + (math.min(#V2, V52) + 2)
					continue
				end
				if V3 == 1 then
					local V4, V5, V6 = Fn20(V2)
					V = if V4 and V6 then if V5 then V + 2 else V + 4 else V + 8
					continue
				end
				if V3 == 2 or V3 == 3 then
					V = V + 4 * V3
					continue
				end
				if V3 == 4 then
					local V7 = nil
					for _, Tag in CollectionService:GetTags(V2) do
						if #Tag == 36 then
							V7 = Tag:gsub("-", "")
						end
					end
					if V7 and #V7 == 32 then
						V = V + 32
					end
					continue
				end
				if V3 == 5 then
					V = V + 18
					continue
				end
				if V3 == 6 then
					V = V + 3
				end
			end
		end
		return V
	end
	local function Fn22(Vector, Arg2, Arg3, Arg4)
		if Vector ~= true then
			if Vector ~= false then
				if Vector ~= nil then
					local V = Fn5(Vector)
					if V ~= "string" then
						if V ~= "number" then
							if V ~= "Instance" then
								if V == "Vector2" or V == "Vector3" then
									local V2
									if V ~= "Vector3" then
										V2 = 9
									else
										V2 = 8
									end
									buffer.writeu8(Arg2, Arg3, V2)
									buffer.writef32(Arg2, Arg3 + 1, Vector.X)
									buffer.writef32(Arg2, Arg3 + 5, Vector.Y)
									if V2 ~= 8 then
										Arg3 = Arg3 + 8
									else
										buffer.writef32(Arg2, Arg3 + 9, Vector.Z)
										Arg3 = Arg3 + 12
									end
								elseif V ~= "CFrame" then
									if V ~= "Color3" then
										return
									end
									buffer.writeu8(Arg2, Arg3, 11)
									for Key, Value in {"R", "G", "B"} do
										buffer.writeu8(Arg2, Arg3 + Key, math.round(Vector[Value] * 255))
									end
									Arg3 = Arg3 + 3
								else
									buffer.writeu8(Arg2, Arg3, 10)
									buffer.writef32(Arg2, Arg3 + 1, Vector.X)
									buffer.writef32(Arg2, Arg3 + 5, Vector.Y)
									buffer.writef32(Arg2, Arg3 + 9, Vector.Z)
									for Key2, Value2 in {Vector:ToEulerAnglesXYZ()} do
										buffer.writei16(Arg2, Arg3 + 13 + 2 * (Key2 - 1), math.round(Value2 * 10000))
									end
									Arg3 = Arg3 + 18
								end
							else
								local V3 = nil
								for _, Tag in CollectionService:GetTags(Vector) do
									if #Tag == 36 then
										V3 = Tag:gsub("-", "")
									end
								end
								if not V3 or #V3 ~= 32 then
									buffer.writeu8(Arg2, Arg3, 6)
								else
									buffer.writeu8(Arg2, Arg3, 7)
									buffer.writestring(Arg2, Arg3 + 1, V3)
									Arg3 = Arg3 + 32
								end
							end
						else
							local V4, V5, V6 = Fn20(Vector)
							local V7
							if not Arg4 then
								if not V4 or not V6 then
									V7 = 3
								elseif not V5 then
									V7 = 2
								else
									V7 = 1
								end
							else
								V7 = 12
							end
							buffer.writeu8(Arg2, Arg3, V7)
							if V7 ~= 1 then
								if V7 ~= 2 then
									buffer.writef64(Arg2, Arg3 + 1, Vector)
								else
									buffer.writei32(Arg2, Arg3 + 1, Vector)
								end
							else
								buffer.writei16(Arg2, Arg3 + 1, Vector)
							end
							local V8
							if not Arg4 then
								V8 = 2 ^ V7
							else
								V8 = 8
							end
							Arg3 = Arg3 + V8
						end
					else
						buffer.writeu8(Arg2, Arg3, 0)
						local V9 = Vector:sub(1, 1000)
						local V10 = #V9
						buffer.writeu16(Arg2, Arg3 + 1, V10)
						if 0 < V10 then
							buffer.writestring(Arg2, Arg3 + 3, V9)
						end
						Arg3 = Arg3 + (2 + V10)
					end
				else
					buffer.writeu8(Arg2, Arg3, 6)
				end
			else
				buffer.writeu8(Arg2, Arg3, 5)
			end
		else
			buffer.writeu8(Arg2, Arg3, 4)
		end
		return Arg3 + 1
	end
	local function Fn23(...)
		local V, V2 = VM_pack(...)
		local V3 = V2[1]
		local V4 = workspace.GetServerTimeNow(workspace) // 1
		local T = {}
		local V5 = V + -2
		local V8, V9
		if V5 < 0 then
			V8 = if T[7] == nil then false else true
			if not V45 then
				if V6 and V3 then
					V9 = V6[1]
					V6[1] = {V9}
					T = table.move(V6, 1, #V6, #T + 1, T)
					table.clear(V6)
					V7 = true
					V6 = nil
				end
			elseif not V3 then
				if V6 and V3 then
					V9 = V6[1]
					V6[1] = {V9}
					T = table.move(V6, 1, #V6, #T + 1, T)
					table.clear(V6)
					V7 = true
					V6 = nil
				end
			else
				T = table.move(V45, 1, #V45, #T + 1, T)
				table.clear(V45)
				V45 = false
			end
		else
			local Count = 0
			for Index = 5, 5 + V5 do
				REG[m_506] = V2[2 + Count]
				Count = Count + 1
			end
			table.move(REG, 5, 5 + V5, 1, T)
			V8 = if T[7] == nil then false else true
			if not V45 then
				if V6 and V3 then
					V9 = V6[1]
					V6[1] = {V9}
					T = table.move(V6, 1, #V6, #T + 1, T)
					table.clear(V6)
					V7 = true
					V6 = nil
				end
			elseif not V3 then
				if V6 and V3 then
					V9 = V6[1]
					V6[1] = {V9}
					T = table.move(V6, 1, #V6, #T + 1, T)
					table.clear(V6)
					V7 = true
					V6 = nil
				end
			else
				T = table.move(V45, 1, #V45, #T + 1, T)
				table.clear(V45)
				V45 = false
			end
		end
		local Roll = math.random(1, 64)
		local V10 = Fn21(T)
		local V11 = Roll + math.round(V10 + 0.01)
		local V12 = buffer.fromstring(string.rep("\1", V11))
		buffer.writeu8(V12, 0, Roll)
		if 1 < Roll then
			buffer.fill(V12, 1, math.random(0, 255), Roll - 1)
		end
		local V13 = Roll
		local V14 = math.clamp(table.maxn(T), 1, 15)
		local Roll2 = math.random(1, V14)
		local V15 = math.round(os.clock() * 100) % 65536
		local V16 = Random.new(math.round((UserId + V44 + V11 + V15) * 2))
		local V17 = V16:NextInteger(0, V11 - 1)
		for Index2 = 1, V14 do
			local V18
			if Roll2 ~= Index2 then
				V18 = 1
			else
				V18 = 2
			end
			for Index3 = 1, V18 do
				local V19 = Index3 == 2
				local V20
				if not V19 then
					V20 = T[Index2]
				else
					V20 = V4
				end
				local V21
				if Index2 ~= 1 or Index3 ~= 1 then
					V21 = V13
				else
					V21 = 0
				end
				local V22 = Fn22(V20, V12, V13, V19)
				if not V22 then
					local Pcall = pcall
					local function Fn()
						return V20[1]
					end
					local V23, V24 = Pcall(Fn)
					local Writeu8 = buffer.writeu8
					local V25 = V13
					local V26
					if not V23 or not V24 then
						V26 = 13
					else
						V26 = 12 + V24
					end
					Writeu8(V12, V25, V26)
					V13 = V13 + 1
				else
					V13 = V22
				end
				for Index4 = V21, V13 - 1 do
					local V27 = buffer.readu8(V12, Index4)
					local V28 = V16:NextInteger(0, 255)
					buffer.writeu8(V12, Index4, (V27 + V28) % 256)
				end
			end
		end
		local V29 = buffer.fromstring(string.rep("\1", V11 + 2))
		local V30 = V11 - 1
		local V31 = 1
		local V32 = 0 - V31
		while true do
			V32 = V32 + V31
			if V31 > 0 and V32 <= V30 or V31 <= 0 and V32 >= V30 then
				local V33 = V32
				buffer.writeu8(V29, (V17 + V33) % V11, buffer.readu8(V12, V33))
			else
				break
			end
		end
		buffer.fill(V12, 0, 0, V11)
		buffer.writeu16(V29, V11, V15)
		table.clear(T)
		return V29, V8
	end
	local function FireServer(Arg1, Arg2, Arg3, ...)
		local V = ...
		if not (Arg3 == V42 or not (Arg3 ~= nil or (Arg1 ~= V29 or (type(V) ~= "number" or V <= 0)))) then
			V6 = {"27", Arg3, V42}
		end
		local V2 = T17[Roll + Fn14({Fn10(Arg1)})]
		if not V2 then
			return
		end
		local V3 = Fn14({Fn10(Arg2)})
		local V4 = Roll + V3
		local V5 = V2[V4]
		local V7
		if V3 == 2876 or V3 == 1941 then
			V7 = {...}
			local V8 = V7[7]
		else
			local V9, V10 = Fn23(V5, ...)
			V7 = V9
		end
		local V11 = string.match(("%*"):format(os.clock()), "%d$")
		local V12
		if V11 == "0" or V11 == "2" then
			V12 = {[V41] = V7}
		else
			V12 = V7
		end
		local V13 = nil
		local V14 = nil
		if V11 % 2 ~= 0 then
			V14 = V12
		else
			V13 = V12
		end
		if not V5 then
			return V2[-V4]:InvokeServer(V13, V14)
		end
		local V15 = V43
		V43 = V43 + 1
		if V43 <= V15 then
			debug.info()
		end
		local V16
		if V43 ~= 30 then
			if V43 ~= 60 then
				if 90 <= V43 then
					V43 = 0
					local V17 = newproxy(true)
					V16 = 0
					local V18 = getmetatable(V17)
					local function __tostring()
						V16 = V16 + 1
						local V = ("%*"):format(V17)
						return V
					end
					V18.__tostring = __tostring
					local V19, V20 = pcall(V5.FireServer, V5, {[V17] = 2})
					if V19 ~= false or V20 ~= "C stack overflow" or V16 ~= 196 then
						V6 = {"28", 2, V19, V20, V16}
					end
				end
			else
				local T = {}
				T[1] = T
				local V21, V22 = pcall(V5.FireServer, V5, T)
				if V21 ~= false or not string.match(V22, "^tables cannot be cyclic$") then
					V6 = {"28", 1, V21, V22}
				end
			end
		else
			local V23 = newproxy(true)
			V16 = 0
			local V24 = getmetatable(V23)
			local function __tostring2()
				local Count = 0
				local V = false
				for Index = 1, 15 do
					local V2, V3 = pcall(getfenv, Index)
					if V2 then
						if V then
							V16 = 3
							return 0
						end
						if type(V3) ~= "table" or V3.clonefunction ~= nil then
							V16 = 4
							return false
						end
						Count = Count + 1
					else
						if V then
							break
						end
						V = true
					end
				end
				if Count <= 6 then
					V16 = 5
				end
				task.wait()
				return " "
			end
			V24.__tostring = __tostring2
			local V25, V26 = pcall(V5.FireServer, V5, {[V23] = 1})
			if V25 ~= false or (not string.match(V26, "^thread is not yieldable$") or V16 ~= 0) then
				V6 = {"28", V16, V25, V26}
			end
		end
		V16 = V5
		V5.FireServer(V16, V13, V14)
	end
	local V53, V54
	local function Fn24(Arg1, Arg2)
		local Number = tonumber(Arg1)
		return Number and (if V54 <= Number then Number <= (if Arg2 then Arg2 else V53) else false)
	end
	local function Fn25(Arg1, Arg2)
		if Arg1 == "" or not Arg1:find(".%..") then
			return nil, 0, false
		end
		local V = Arg1:gsub("%[.-%] ?", "")
		local V2, V3
		if Arg2 then
			V2 = Arg2
			V3 = V
		else
			V2 = V:reverse():match("^([^%.]+)%.*"):reverse()
			V3 = V
		end
		local V4, V5 = false, V2
		for _, Value in T3 do
			if V3:find(Value) then
				V4 = true
				break
			end
		end
		local V6 = false
		for Key, Value2 in if V4 then T6 else T5 do
			if Value2 == "" and V6 == false then
				V6 = true
				continue
			end
			if (if V6 then V3 else V5):match(Value2) then
				return nil, Key, V4
			end
		end
		if not V6 then
			return nil, 0, V4
		end
		return V3:find(V5, 1, true) ~= nil, T4[V5], V4
	end
	local function Fn26(Arg1)
		if game:GetService("Players"):FindFirstChild(Arg1) then
			return ""
		end
		return nil
	end
	local T18 = {3}
	local T19 = {"103"}
	local function Fn27(Str, Arg2, Arg3, Arg4)
		if not (Arg4 == true or type(Arg3) == "table") then
			return T19, 1
		end
		if string.match(Str, ".animation: .") or string.match(Str, "^%[ExpChat/mountClientApp ") then
			return
		end
		local V = Str:gsub("[WP][ol][ra][ky][se][pr][as]c?e? ?%.([%w_ ]+)%W", Fn26)
		local V2 = V:lower()
		local T = {}
		local V3 = false
		local Count = 0
		for Key, Value in T9 do
			if Key % 50 == 0 then
				task.wait()
			end
			if not ((Key ~= 1 or not (Value[1] ~= "Script ''" or Value[2] ~= true or Value[3] ~= 0)) and (Key ~= 4 or not (Value[1] ~= "%[string \".*\"%]" or (Value[2] ~= true or Value[3] ~= 0)))) then
				return T19, 2
			end
			Count = Count + 1
			local V4 = Value[3]
			if not ((V4 ~= 1 or Arg2 ~= V28) and (V4 ~= 2 or Arg2 == V28)) then
				continue
			end
			local V5
			if not Value[2] then
				V5 = V2
			else
				V5 = V
			end
			if not string.match(V5, Value[1]) then
				continue
			end
			if not (40 < Key) or not (Key <= 84) then
				table.insert(T, Key)
			else
				V3 = true
				break
			end
		end
		if (Count ~= #T9 or Count < 168) and not V3 then
			return T19, 3
		end
		local V6 = false
		local V7, V8 = string.match(Str:gsub("^.+ [Uu]nexpected error while invoking callback: ", ""), "^(.-):(%d+): ")
		if V7 or V8 then
			local V9, V10, V11 = Fn25(V7)
			if not V3 then
				if V9 ~= true then
					return T18, Str, Arg2.Name, ("%*/NAME1"):format(V10), 0
				end
				if not Fn24(V8) then
					return T18, Str, Arg2.Name, ("%*/LINE1"):format(V8), 0
				end
			end
			V6 = V11
		end
		local V12 = nil
		local V13 = nil
		local function Fn(Arg1, Arg2)
			if Arg1 == "Connection" or Arg1 == "LoadingScript" then
				return
			end
			local V, V2, V3 = Fn25(Arg1)
			if not V then
				V12 = V2
				V13 = true
			else
				if Fn24(Arg2, V2) then
					return
				end
				V12 = Arg2
				V13 = false
			end
			if not V6 then
				V6 = V3
				return
			end
		end
		Str:gsub("Script '(.-)', Line (%d+)", Fn)
		if V12 == nil or V3 then
			if 0 < #T then
				return {2}, Str, Arg2.Name, table.concat(T, "/"), 0
			end
			if not Arg4 then
				return
			end
			return V6
		else
			local V14 = Str
			local Name = Arg2.Name
			local V15 = "%*/%*2"
			local Format = V15.format
			local V16 = V12
			local V17
			if not V13 then
				V17 = "LINE"
			else
				V17 = "NAME"
			end
			return T18, V14, Name, Format(V15, V16, V17), 0
		end
	end
	local V55 = Fn27
	local function Fn28()
		local V = false
		local V2 = false
		for Index = 0, 14 do
			local Pcall = pcall
			local function Fn()
				return getfenv(Index)
			end
			local V3, V4 = Pcall(Fn)
			if not ((V3 == false or V3 == true) and (V3 ~= true or not (V or ("%*"):format(V4) ~= V25 or (not rawequal(V4.script, Script2) or V4.setreadonly ~= nil))) and (V3 ~= false or string.match(V4, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 to 'getfenv' %(invalid level%)$")) or V2) then
				V45 = table.pack(table.pack(29), Index, V3, tostring(V4))
				V2 = true
			end
			V = if V3 then V else true
		end
		return V
	end
	local function Fn29(Arg1, Arg2, ...)
		V31 = Arg1
		local T = {...}
		local V = Arg1 + math.random(1, 1000000)
		local V6 = V + 1
		local V7 = nil
		local Pcall = pcall
		local function Fn()
			V7 = Fn28()
			V6 = V
			return Arg1, Arg2(unpack(T))
		end
		local V8, V9, V10, V11 = Pcall(Fn)
		if not V31 or (V6 ~= V or Arg1 ~= Arg1 or V7 ~= true or not (V8 == false or V8 == true) or not (V8 ~= true or V9 == Arg1) or V8 == false and (("%*"):format(V9) ~= V9 or V9 == Arg1)) then
			local V12 = ("3%*"):format(0)
			local T2 = {V12}
			local V13 = ("%*/%*/%*"):format(V, V6, V7)
			V45 = {T2, Arg1, V8, V9, V13}
		end
		local V14
		if not V8 then
			V14 = V9
		else
			V14 = V10
		end
		return V8, V14, V11
	end
	local function Fn30(Arg1, Arg2, Arg3, ...)
		local T = {...}
		local V = nil
		local function Fn(Arg1)
			local V6 = nil
			for Index = 1, 2 do
				if Index == 2 then
					V6 = coroutine.yield(Arg1 + 1)
				end
				local V7 = coroutine.isyieldable()
				local V8 = coroutine.running()
				local V9 = V8 == V
				if V7 ~= true or not V9 or ("%*"):format(V8) ~= ("%*"):format(V) then
					local V10 = ("SSPWN%*.%*.%*"):format(Index, V7, V9)
					Fn12(V10)
				end
				if Index ~= 2 then
					continue
				end
				if Arg1 + 2 ~= V6 then
					local V11 = ("SSPWN3.%*.%*"):format(Arg1, V6)
					Fn12(V11)
				end
				if Arg2 then
					task.wait(Arg2)
				end
				assert(Fn28(), "SSPWN4")
				Arg3(unpack(T))
			end
			return V6
		end
		V = coroutine.create(Fn)
		local V7 = Fn5(V)
		if V7 ~= "thread" then
			V6 = {31, Arg1, V7}
			return
		end
		local V8 = coroutine.status(V)
		if V8 ~= "suspended" then
			V6 = {31, Arg1, V7, V8}
			return
		end
		local V9, V10 = coroutine.resume(V, math.random(1, 10000000))
		local V11 = coroutine.status(V)
		if V9 ~= true or (Fn6(V10) ~= 1 or V11 ~= "suspended") then
			local V12 = ("%*/%*"):format(Arg1, V11)
			V6 = {32, V9, V10, V12}
			return
		end
		local V13, V14 = coroutine.resume(V, V10 + 1)
		local V15 = coroutine.status(V)
		if V13 ~= true or (V15 ~= "suspended" or V14 ~= nil) and (V15 ~= "dead" or V10 ~= V14 - 1) then
			V6 = {32, V13, V14, ("%*/%*"):format(Arg1, V15), V10}
			return
		end
		return V
	end
	local function Fn31(Arg1, Arg2)
		local V = Arg1:Connect(function()
		end)
		if typeof(V) ~= "RBXScriptConnection" or not V.Connected then
			Fn12((("SCONN3.%*.%*"):format(typeof(V), V.Connected)))
		end
		V:Disconnect()
		return Arg2(T12, function()
		end)
	end
	local function Fn32(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7)
		local V, V7 = Fn5(Arg1)
		if V ~= "Instance" or not V7 or (Fn5(Arg2) ~= "string" or Fn5(Arg7) ~= "function") then
			V6 = string.split(("33*1*%*/%*/%*/%*"):format(V, V7, typeof(Arg2), typeof(Arg7)), "*")
			return
		end
		local V8 = nil
		local function Fn()
			V8 = Fn7(Arg1)
			return Arg1[Arg2]
		end
		local V9, V10 = Fn29("001", Fn)
		local V11 = Fn5(Arg3)
		if ("%*"):format(V8) ~= V8 or not (V11 ~= "nil" or V9 == true and Fn5(V10) == "RBXScriptSignal") or not (V11 == "nil" or not (V11 ~= "RBXScriptSignal" or V9 == true or (not string.match(Arg2, "Changed$") or V10 ~= ("%* is not a valid member of %* \"%*\""):format(Arg2, V7, V8)))) then
			V6 = string.split(("33*2*%*/%*/%*/%*/%*"):format(V8, V11, V9, V10, Arg2), "*")
			return
		end
		if V9 then
			Arg3 = V10
		end
		local T = {}
		local function Fn2(Arg1, ...)
			if tostring(Arg1) == "1" then
				table.insert(T, 0)
			end
			local T2 = {Arg7(...)}
			if table.maxn(T2) ~= 0 or #T2 ~= 0 or T2[1] then
				V45 = T2
				return
			end
		end
		local V12 = nil
		if Arg5 ~= false then
			local function Fn3()
				local Pcall = pcall
				local function Fn()
					while not Arg6 or Arg1:IsDescendantOf(Game) do
						local T = {Arg3:Wait()}
						if V40 or not (not Arg6 or Arg1:IsDescendantOf(Game)) then
							return -1
						end
						Fn2(2, unpack(T))
					end
					return -1
				end
				local V, V2 = Pcall(Fn)
				if V ~= true or V2 ~= -1 then
					V6 = string.split(("34*%**%**%**%*"):format(V8, Arg2, V, V2), "*")
					return
				end
			end
			V12 = Fn30(0, nil, Fn3)
		end
		local T2 = {}
		local V13 = Arg1
		local V14 = Arg2
		local V15 = Arg3
		local V16 = V8
		local V17 = "%*%*%*"
		local Format = V17.format
		local V18
		if not Arg4 then
			V18 = 0
		else
			V18 = 1
		end
		local V19
		if not Arg5 then
			V19 = 0
		else
			V19 = 1
		end
		local V20
		if not Arg6 then
			V20 = 0
		else
			V20 = 1
		end
		local V21 = Format(V17, V18, V19, V20)
		T2[1] = V13
		T2[2] = V14
		T2[3] = V15
		T2[4] = Fn2
		T2[5] = V16
		T2[6] = V7
		T2[7] = true
		T2[8] = V21
		T2[9] = T
		T2[10] = 0
		T2[11] = nil
		T2[12] = nil
		T2[13] = nil
		T2[14] = V12
		table.insert(T11, T2)
	end
	local function Fn33(Arg1, Arg2, Arg3)
		return not Arg1 and (if Arg2 > 0 then true else false), if Arg2 == 1 then Arg3 else false, if Arg1 then if Arg2 == 0 then if Arg3 then Arg3:find("line ", 1, true) else Arg3 else false else Arg1
	end
	local function Fn34(Arg1, Arg2)
		local V = T13[Arg1]
		local V2 = V == nil
		if V2 then
			V = {}
			T13[Arg1] = V
		end
		local Count = 0
		for Index = 1, 20 do
			local V3, V4, V5, V6, V7, V8 = debug.info(Index, "slfna\0lol")
			local V9 = if V3 == nil then false else true
			local V10 = V3 == "[C]"
			if V9 then
				if not (V3 == "ReplicatedStorage.Modules.AssetContainer" or V10) then
					return 1, Index, V3
				end
				if not ((not V10 or not (V4 ~= -1 or V7 ~= 0 or V8 ~= true)) and (V10 or not (V4 < 3 or 2 < V7))) then
					local V11 = ("%*/%*/%*/%*"):format(V3, V4, V7, V8)
					return 2, Index, V11
				end
			end
			local Pcall = pcall
			local function Fn()
				return getfenv(Index + 2)
			end
			local V12, V13 = Pcall(Fn)
			if V12 ~= V9 then
				local V14 = ("%*/%*"):format(V12, V3)
				return 3, Index, V14
			end
			if not ((not V12 or not (("%*"):format(V13) ~= V25 or V13.writefile)) and (V12 or string.match(V13, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 to 'getfenv' %(invalid level%)$"))) then
				local V15 = ("%*/%*"):format(V12, tostring(V13))
				return 4, Index, V15
			end
			if not V12 then
				break
			end
			Count = Count + 1
			local V16 = ("%*"):format(V5)
			local V17 = string.match(V16, "^function: 0x(%w+)$")
			if not V17 then
				local V18 = ("%*/%*"):format(V16, V17)
				return 5, Index, V18
			end
			if not V2 then
				local V19 = V[Index]
				local V20
				if V19[1] ~= V10 or V19[2] ~= V4 then
					V20 = ("%*/%*/%*/%*/%*/%*"):format(V3, V4, V7, V8, V16, V6)
					return 6, Index, V20
				end
				local V21
				if type(Arg2) ~= "table" then
					V21 = Index ~= Arg2
				else
					V21 = not table.find(Arg2, Index)
				end
				if (not V21 or V19[3] == V17) and V19[4] == V6 and V19[5] == V7 and V19[6] == V8 then
					continue
				end
				V20 = ("%*/%*/%*/%*/%*/%*"):format(V3, V4, V7, V8, V16, V6)
				return 6, Index, V20
			else
				table.insert(V, {V10, V4, V17, V6, V7, V8})
			end
		end
		if Count == #V then
			return
		end
		local V22 = ("%*/%*"):format(Count, #V)
		return 7, 0, V22
	end
	local V56 = nil
	local function Fn35()
		local T = {}
		return function(Arg1, Arg2)
			local V = T[Arg1]
			if not V then
				T[Arg1] = Arg2
			end
			if V and V ~= Arg2 then
				return false
			end
			if type(Arg2) ~= "function" then
				return false
			end
			local V2, V3, V4, V5, V6 = debug.info(Arg2, "lans")
			return if V6 == nil or (#V6 ~= 3 or (V2 ~= -1 or (V5 ~= "" or V3 ~= 0))) then false else V4 == true
		end
	end
	local V57 = Fn35()
	local function Fn36(Arg1)
		local V = T15[Arg1 or Name]
		if not V then
			return
		end
		return V[1], V[2]
	end
	local function Fn37()
		local StartMemory = gcinfo()
		local T = {}
		for Index = 1, 100 do
			table.insert(T, table.create(10, Index))
		end
		table.clear(T)
		return gcinfo() - StartMemory
	end
	local function Fn38(Arg1, Arg2)
		local ClassName = Arg1.ClassName
		local V = if ClassName == "SurfaceGui" then true else false
		local V2 = if ClassName == "BillboardGui" then true else false
		local V3 = if ClassName == "Highlight" then true else false
		if Arg2 then
			local Name = Arg1.Name
			if (not V or (Name == "ReticleFront" or (Name == "ReticleBack" or (Name == "Label" or Name:find(" Sign", 1, true))))) and ((not V2 or (Name == "NameTag" or (Name == "Glare" or (Name == "TeamDot" or Name == "Info")))) and (not V3 or (Name == "CombatHighlight" or (Name == "TeamHighlight" or Name == "SelectedHighlight")))) then
				return
			end
		elseif not (V or (V2 or V3)) then
			return
		end
		V8 = {2, Arg1:GetFullName(), ClassName, Arg2}
	end
	local T20 = {15}
	local function Fn39(Instance2, Arg2)
		local V, V2 = Fn7(Instance2)
		local Name = Instance2.Name
		local Parent = Instance2.Parent
		if not ((V2 ~= "Humanoid" or Arg2) and not (V2 == "ForceField" or Instance2:IsA("HandleAdornment") or Instance2:IsA("PVAdornment") or Instance2:IsA("PartAdornment") or not (not Instance2:IsA("BodyMover") or (Name == "JumpForce" or Name == "WaterForce"))) and (not Instance2:IsA("Constraint") or V2 == "RodConstraint" or Name:sub(1, 17) == "RagdollConstraint") and (not Instance2:IsA("Light") or not (Parent == V32 or Parent and Parent.Parent == V32)) and (V2 ~= "LocalScript" or not Parent or (Parent == V32 or Name == "Client"))) then
			V45 = {T20, V, V2, Arg2}
			task.spawn(Fn18, Instance2)
		end
	end
	local V58 = Fn39
	local function Fn40(Instance2)
		local Name = Instance2.Name
		if Name == "PhoneUpsellToasts" or Name == "NotificationModals" then
			return
		end
		V45 = {
			{9},
			Name,
			Instance2.ClassName,
		}
		task.spawn(Fn18, Instance2)
	end
	local T21 = {
		"Main",
		"Freecam",
		"Chat",
		"BubbleChat",
		"LoadingScreen",
		"Loading",
		"CustomChat",
		"ConnectionsBillboardGui",
		"FilmGrain",
		"ChatInstallVerifier",
		"MainMenu",
		"UI",
		"InGameExplorerClient",
		"TouchGui",
		"Boombox",
		"ItemSearchMain",
		"TextBox",
		"PilotClient",
	}
	local function Fn41(Arg1)
		local Name = Arg1.Name
		if Name:find(" Sign", 1, true) or table.find(T21, Name) then
			return
		end
		if Arg1:FindFirstChild("AMain") then
			if Arg1:WaitForChild("Menu", 3) then
				return
			end
		else
			Arg1.Parent = nil
		end
		V8 = {1, Name, Arg1.ClassName}
	end
	local function Fn42(Instance2)
		local Name = Instance2.Name
		if (Name == "Atmosphere" or Name == "Sky" or Name == "Blur" or Name == "Bloom" or Name == "ColorCorrection" or Name == "SunRays" or Name == "NVG" or Name == "WaterBlur" or Name == "WaterColorCorrection" or Name == "VRFade") and not Instance2.Archivable then
			return
		end
		V45 = {
			{math.sqrt(121)},
			Name,
			Instance2.ClassName,
		}
		task.spawn(Fn18, Instance2)
	end
	local function Fn43(Arg1)
		local Name = Arg1.Name
		if Name == "ExplorerPart" or Name == "VRBlurPart" or (Name == "AudioListener" or Name == "RecoilParts") or (string.match(Name, "^Buildv4") or string.match(Name, "UIGroup")) then
			return
		end
		local V, V2 = Fn7(Arg1)
		if V2 ~= "Model" or Arg1:GetAttribute("_") ~= true then
			task.spawn(Fn18, Arg1)
			return {12}, Name, V2
		end
	end
	local function Fn44(Instance2)
		local Name = Instance2.Name
		if Name == "Clouds" or Name == "CelestialOrientation" or Name == "SoundAttachment" then
			return
		end
		V45 = table.pack(table.pack(13), Name, Instance2.ClassName)
		task.spawn(Fn18, Instance2)
	end
	local function Fn45()
		local GuiService = game:GetService("GuiService")
		local MarketplaceService = game:GetService("MarketplaceService")
		local ContentProvider = game:GetService("ContentProvider")
		local CoreGui = game:GetService("CoreGui")
		local T = {}
		local T2 = {1, 16681869, 15680821, 25548179, 363101315, 174212818, 1063692972, 89117302, 19618897, 17199995, 1997079896, 35601765, 77554513, 2576490103}
		local V = 0
		local function Fn(Arg1, _)
			local V2 = Arg1:gsub("%D", "")
			if not V2 then
				return
			end
			local Number = tonumber(V2)
			if not Number then
				return
			end
			if Number == 10670510697 then
				V = V + 1
				return
			end
			if Number == 10066921516 or (T[Number] or (not Arg1:find("^rbxassetid://") or (Arg1:find("textures") or GuiService.MenuIsOpen))) then
				return
			end
			T[Number] = true
			local V3, V4 = pcall(MarketplaceService.GetProductInfo, MarketplaceService, Number)
			if not (V3 and V4) then
				return
			end
			local AssetTypeId = V4.AssetTypeId
			local Name = V4.Name
			if AssetTypeId ~= 1 and (AssetTypeId ~= 3 and (AssetTypeId ~= 5 and (AssetTypeId ~= 9 and (AssetTypeId ~= 13 and AssetTypeId ~= 38)))) or (V4.IsForSale or (V4.IsPublicDomain or (V4.IsLimited or (Name == "Image" or (Name == "Texture" or Name:find("^Images/")))))) then
				return
			end
			local Creator = V4.Creator
			if type(Creator) ~= "table" then
				return
			end
			if Creator.HasVerifiedBadge or (Creator.CreatorType == "Group" or table.find(T2, Creator.CreatorTargetId)) then
				return
			end
			V8 = {7, Number}
		end
		return function()
			V = 0
			local V2, V3 = pcall(ContentProvider.PreloadAsync, ContentProvider, {MarketplaceService, "rbxassetid://10670510697", CoreGui}, Fn)
			return V2, V3, V
		end
	end
	Fn45()
	local V59 = getmetatable(V41)
	local V60 = nil
	local function Fn46()
		local T = {
			{36},
		}
		local V = T
		local V2 = false
		for Index = 1, 5 do
			local V3 = debug.traceback("", Index):split("\n")
			local Count = 0
			for Key, Value in V3 do
				if Key == 1 or Key == #V3 then
					if Value ~= "" then
						T[2] = 1
						T[3] = Index
						T[4] = Value
						V2 = true
						break
					else
						Count = Count + 1
					end
				else
					local V4 = string.match(Value, "^(.+):%d+ ?[%a ]*$")
					if not V4 then
						T[2] = 1
						T[3] = Index
						T[4] = Value
						V2 = true
						break
					else
						local V5, V6 = Fn25(V4)
						if V5 == true then
							continue
						end
						T[2] = 1
						T[3] = Index
						T[4] = Value
						V2 = true
						break
					end
				end
			end
			if V2 then
				break
			end
			if Count == 2 then
				local V7, V8 = pcall(getfenv, Index)
				if (not V7 or not (type(V8) ~= "table" or (V8.writefile or V8.newcclosure))) and (V7 or ("%*"):format(V8) == V8 and string.match(V8, "^invalid argument #1 to 'getfenv' %(invalid level%)$")) then
					local V9, V10, V11, V12, V13, V14 = debug.info(Index, "sflna\0")
					local V15 = nil
					local V16, V17
					if Index == 1 or Index == 5 then
						if V9 ~= "ReplicatedStorage.Modules.AssetContainer" then
							V = 16
						else
							if Index == 5 then
								V = 16
							else
								V = V60
								if V10 == V60 and not (V12 ~= "" or V13 ~= 0 or V14 ~= true) then
									continue
								end
								if not (Index ~= 2 or V9 ~= "[C]" or (V10 ~= tostring or (V11 ~= -1 or V12 ~= "tostring" or (V13 ~= 0 or not V14)))) then
									continue
								end
								if Index ~= 3 or V9 ~= "[C]" or V11 ~= -1 or not (V12 == "FireServer" or V12 == "InvokeServer") or V13 ~= 0 or not V14 then
									if not (Index ~= 4 or V9 ~= "ReplicatedStorage.Modules.AssetContainer" or V10 ~= FireServer or V12 ~= "" or (V13 ~= 0 or not V14)) then
										continue
									end
									T[2] = 4
									T[3] = Index
									T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
									break
								else
									V16, V17 = pcall(V10, Workspace)
									if V16 ~= false then
										V15 = V17
										T[2] = 4
										T[3] = Index
										T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
										break
									else
										V = "%*"
										if V:format(V17) == V17 and string.match(V17, "^Expected ':' not '%.' calling member function [IF][ni][vr][oe]k?e?Server$") then
											continue
										end
										V15 = V17
										T[2] = 4
										T[3] = Index
										T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
										break
									end
								end
								continue
							end
							if not (V12 ~= "" or V13 ~= 0 or V14 ~= true) then
								continue
							end
						end
					else
						V = 16
					end
					if not (Index ~= 2 or V9 ~= "[C]" or (V10 ~= tostring or (V11 ~= -1 or V12 ~= "tostring" or (V13 ~= 0 or not V14)))) then
						continue
					end
					if Index ~= 3 or V9 ~= "[C]" or V11 ~= -1 or not (V12 == "FireServer" or V12 == "InvokeServer") or V13 ~= 0 or not V14 then
						if not (Index ~= 4 or V9 ~= "ReplicatedStorage.Modules.AssetContainer" or V10 ~= FireServer or V12 ~= "" or (V13 ~= 0 or not V14)) then
							continue
						end
						T[2] = 4
						T[3] = Index
						T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
						break
					else
						V16, V17 = pcall(V10, Workspace)
						if V16 ~= false then
							V15 = V17
							T[2] = 4
							T[3] = Index
							T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
							break
						else
							V = "%*"
							if V:format(V17) == V17 and string.match(V17, "^Expected ':' not '%.' calling member function [IF][ni][vr][oe]k?e?Server$") then
								continue
							end
							V15 = V17
							T[2] = 4
							T[3] = Index
							T[4] = ("%*/%*/%*/%*/%*/%*/%*"):format(V9, V10, V11, V12, V13, V14, V15)
							break
						end
					end
				else
					T[2] = 3
					T[3] = Index
					T[4] = ("%*/%*"):format(V7, V8)
					break
				end
			else
				T[2] = 2
				T[3] = Index
				T[4] = Count
				break
			end
		end
		if #T ~= 1 then
			V45 = T
		else
			table.clear(T[1])
			table.clear(T)
		end
		return ""
	end
	V60 = Fn46
	V59.__tostring = V60
	Fn32(LogService, "MessageOut", nil, false, false, false, V55)
	local function Fn47(Arg1, Arg2, Arg3)
		local T = {}
		local V = nil
		local function Fn()
			V = Arg3:GetFullName()
			return Arg3.Name
		end
		local V2, V3 = Fn29("002", Fn)
		if V then
			local V4, V5 = Fn25(V, V3)
			if V4 ~= true then
				local Insert = table.insert
				local V6 = ("%*/NAME3"):format(V5)
				Insert(T, V6)
			end
		end
		if Arg3 == Script or Arg3 == V14 then
			local Insert2 = table.insert
			local V7 = "%*/NAME4"
			local Format = V7.format
			local V8
			if Arg3 ~= Script then
				V8 = 1
			else
				V8 = 0
			end
			local V9 = Format(V7, V8)
			Insert2(T, V9)
		elseif not ((not V2 or not (not Arg3 or (not V3 or not V))) and (V2 or V == nil)) then
			local Insert3 = table.insert
			local V10 = "%*/INVALID1"
			local Format2 = V10.format
			local V11
			if not V2 then
				V11 = 0
			else
				V11 = 1
			end
			local V12 = Format2(V10, V11)
			Insert3(T, V12)
		end
		local Parts = string.split(Arg2 or "", "\n")
		table.insert(Parts, 1, Arg1)
		local V13 = 0
		local V15 = Enum["MessageType\0skibidi"]["MessageInfo\0toilet"]
		for Key, Part in Parts do
			local V16 = Key == 1
			local V17, V18, V19, V20, V21, V22
			if not V16 then
				if Part == "" and Key == #Parts then
					continue
				end
				local V23, V24, V25 = string.match(Part, "^(.-), line (%d+)(.*)")
				if V23 == nil or V24 == nil then
					local Insert4 = table.insert
					local V26 = ("%*/INVALID2"):format(Key)
					Insert4(T, V26)
				else
					V17 = ("Script '%*', Line %*%*"):format(V23, V24, V25)
					V18 = {}
					V19 = V55
					V20 = V17
					if not V16 then
						V21 = V15
					else
						V21 = V28
					end
					do
						local packed = table.pack(V19(V20, V21, nil, true))
						table.move(packed, 1, packed.n, 1, V18)
					end
					V22 = V18[1]
					if V22 ~= true then
						if V22 then
							table.insert(T, V18[4])
						end
					elseif not V16 then
						V13 = 2
					else
						V13 = 1
					end
				end
			else
				V17 = Part
				V18 = {}
				V19 = V55
				V20 = V17
				if not V16 then
					V21 = V15
				else
					V21 = V28
				end
				do
					local packed = table.pack(V19(V20, V21, nil, true))
					table.move(packed, 1, packed.n, 1, V18)
				end
				V22 = V18[1]
				if V22 ~= true then
					if V22 then
						table.insert(T, V18[4])
					end
				elseif not V16 then
					V13 = 2
				else
					V13 = 1
				end
			end
		end
		local V27 = not (V2 and V)
		local V29, V30, V31 = Fn33(V27, V13, Arg2)
		if V29 or V30 or V31 then
			local Insert5 = table.insert
			local V32 = "%*%*%*%*%*/INVALID3"
			local Format3 = V32.format
			local V33
			if not V29 then
				V33 = 0
			else
				V33 = 1
			end
			local V34
			if not V30 then
				V34 = 0
			else
				V34 = 1
			end
			local V35
			if not V31 then
				V35 = 0
			else
				V35 = 1
			end
			local V36
			if not V27 then
				V36 = 0
			else
				V36 = 1
			end
			local V37 = Format3(V32, V33, V34, V35, V36, V13)
			Insert5(T, V37)
		end
		if table.maxn(T) ~= 0 or (#T ~= 0 or T[1]) then
			return {4}, Arg1, Arg2, V, table.concat(T, ", ")
		end
	end
	Fn32(ScriptContext, "Error", nil, false, false, false, Fn47)
	local function Fn48(Arg1)
		if Arg1 == "GlobalWind" then
			return
		end
		local V = Workspace[Arg1]
		if Arg1 == "Gravity" then
			if V ~= 160 then
				Workspace.Gravity = 160
				return {5}, Arg1, V
			end
			return
		end
		return {5}, Arg1, V
	end
	Fn32(Workspace, "Changed", nil, false, true, false, Fn48)
	local PropertyChangedSignal = V9:GetPropertyChangedSignal("FieldOfView")
	local function Fn49()
		if V36 then
			return
		end
		V36 = true
		for Index = 1, 2 do
			local FieldOfView = V9.FieldOfView
			if 105 ~= math.random(98, 98) + math.random(7, 7) then
				return {105}, 2, 105
			end
			if 0 < FieldOfView and FieldOfView <= 105 then
				break
			end
			if Index == 2 then
				V36 = false
				return table.pack(7), FieldOfView
			end
			task.wait(4)
		end
		V36 = false
	end
	Fn32(V9, "FieldOfViewChanged", PropertyChangedSignal, false, false, false, Fn49)
	local T22 = {8}
	local function Fn50(Arg1)
		return {T22}, Arg1, TestService[Arg1]
	end
	local V61 = Fn50
	Fn32(TestService, "Changed", nil, false, false, false, V61)
	Fn32(PointsService, "ChildAdded", nil, true, false, false, Fn40)
	Fn32(V17, "ChildAdded", nil, false, false, false, Fn41)
	Fn32(Lighting, "ChildAdded", nil, false, false, false, Fn42)
	Fn32(V9, "ChildAdded", nil, false, false, false, Fn43)
	for _, Value in T do
		V61 = false
		T7 = false
		T8 = Fn38
		Fn32(Value, "DescendantAdded", nil, false, V61, T7, T8)
	end
	for _, Child in PointsService:GetChildren() do
		Fn40(Child)
	end
	for _, Child2 in V17:GetChildren() do
		task.spawn(Fn41, Child2)
	end
	for _, Child3 in Lighting:GetChildren() do
		Fn42(Child3)
	end
	for _, Child4 in V9:GetChildren() do
		local T23 = {Fn43(Child4)}
		if T23[1] == nil then
			continue
		end
		V45 = T23
		break
	end
	local Spawn = task.spawn
	local function Fn51()
		while true do
			V23 = Workspace:FindFirstChildOfClass("Terrain")
			if V23 then
				break
			end
			task.wait()
		end
		local V = V23
		local function Fn(Arg1)
			if Arg1 == "WaterTransparency" then
				return
			end
			local T = {6}
			local V = Arg1
			local V2
			if Arg1 ~= "Decoration" then
				V2 = Workspace.Terrain[Arg1]
			else
				V2 = false
			end
			return T, V, V2
		end
		Fn32(V, "Changed", nil, false, false, false, Fn)
		Fn32(V23, "ChildAdded", nil, false, false, false, Fn44)
		for _, Child in V23:GetChildren() do
			Fn44(Child)
		end
		if V5 ~= 895631756 then
			V2 = V2 - 596
			V5 = 620136465
			V4 = 962939715
			V3 = 320262443
		end
	end
	Spawn(Fn51)
	local function Fn52()
		local V = ("1%*5"):format(0)
		local function Fn()
			local V2 = Random.new()
			local V3 = 0
			local V4 = false
			local V5 = false
			while not V39 do
				local T = {}
				local T2 = {}
				local V7 = false
				local V9
				for _, Child in Workspace:GetChildren() do
					if Child.ClassName ~= "Model" then
						continue
					end
					local V10 = Fn8(Child, "Humanoid")
					if not V10 then
						continue
					end
					V9 = "Arms"
					if Fn8(Child, V9) then
						continue
					end
					local Name2 = Child.Name
					local V11, OnIterate, V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22
					if LocalPlayer.Character == Child then
						V4 = true
						if V32 ~= Child then
							V11 = setmetatable
							V9 = {}
							OnIterate = function(Arg1)
								V8 = {16, 1}
								return next, Arg1
							end
							V11(V9, {__iter = OnIterate})
							V9 = true
							V32 = Child
							Fn32(Child, "DescendantAdded", nil, false, false, true, V58)
							V12 = V10:GetPropertyChangedSignal("WalkSpeed")
							V13 = function()
								local WalkSpeed = V10.WalkSpeed
								V9 = nil
								if WalkSpeed >= 0 and WalkSpeed <= 19.01 then
									return
								end
								V8 = {11, WalkSpeed}
								V10.WalkSpeed = math.clamp(WalkSpeed, 0, 18)
							end
							Fn32(V10, "WalkSpeedChanged", V12, false, false, true, V13)
							V14 = V10:GetPropertyChangedSignal("JumpHeight")
							V15 = function()
								local JumpHeight = V10.JumpHeight
								if not (0 <= JumpHeight) or not (JumpHeight <= 3.26) then
									V10.JumpHeight = math.clamp(JumpHeight, 0, 3.25)
									return 16, 0, JumpHeight
								end
							end
							Fn32(V10, "JumpHeightChanged", V14, false, false, true, V15)
							V16 = V10:GetPropertyChangedSignal("HipHeight")
							V17 = function()
								local HipHeight = V10.HipHeight
								if HipHeight >= -0.01 and HipHeight <= 3 then
									return
								end
								if V5 then
									V8 = {3, 1, HipHeight}
									V10.HipHeight = 1.6
								else
									V5 = true
								end
							end
							Fn32(V10, "HipHeightChanged", V16, false, false, true, V17)
							V18 = V10:GetPropertyChangedSignal("UseJumpPower")
							V19 = function()
								V10.UseJumpPower = false
								return 16, 2, true
							end
							Fn32(V10, "UseJumpPowerChanged", V18, false, false, true, V19)
							V20 = V10:GetPropertyChangedSignal("PlatformStand")
							V21 = function()
								V10.PlatformStand = false
								return 16, 3, true
							end
							Fn32(V10, "PlatformStandChanged", V20, false, false, true, V21)
							V22 = function()
								local V2 = true
								local T = {}
								local V3 = 0
								local V4 = nil
								local WalkSpeed = V10.WalkSpeed
								local StartTime = nil
								local LowerTorso = Child:FindFirstChild("LowerTorso")
								local StartTime2 = os.clock()
								while V32 == Child do
									local Parent = V10.Parent
									if not Child.Parent or Parent == Child then
										local WalkSpeed2 = V10.WalkSpeed
										if WalkSpeed2 < 0 or 18.01 <= WalkSpeed2 then
											V10.WalkSpeed = math.clamp(WalkSpeed2, 0, 18)
											V4 = {"74", WalkSpeed2}
											break
										else
											if not (WalkSpeed2 == WalkSpeed or StartTime ~= nil) then
												StartTime = os.clock()
											end
											local Roll = math.random(19, 19)
											local ToNumber = tonumber
											V7 = 9
											local V11 = (".%*9"):format(V7)
											if 18.01 == Roll - ToNumber(V11) then
												if StartTime then
													if V9 ~= nil then
														os.clock()
													else
														StartTime = false
													end
												end
											else
												V4 = {V, 1, 18.01}
											end
											local JumpHeight = V10.JumpHeight
											if JumpHeight < 0 or 3.26 <= JumpHeight then
												V10.JumpHeight = math.clamp(JumpHeight, 0, 3.25)
												V4 = {16, 0, JumpHeight}
												break
											else
												local HipHeight = V10.HipHeight
												local V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22, V23, V24, V25, V26, V27, AttributeChanged, V28, V29, V30, V31, V33, V34, V35, V36, V37, V38, V39, V40, V41
												if HipHeight < -0.01 or 3 < HipHeight then
													if V5 then
														V10.HipHeight = 1.6
														V4 = {16, 1, HipHeight}
														break
													else
														V5 = true
														if V10.UseJumpPower == false then
															V12 = V10.MaxSlopeAngle
															if V12 < 0 or 80.01 <= V12 then
																V10.MaxSlopeAngle = math.clamp(V12, 0, 80)
																V4 = {16, 4, V12}
																break
															else
																V13 = V10.Name
																if V13 == "Humanoid" then
																	V14 = V10.TargetPoint
																	if V14 ~= Vector3.new() then
																		V6 = {17, 0, V14}
																	end
																	V15 = V10.WalkToPart
																	if V15 ~= nil then
																		V16 = {}
																		V7 = V15
																		do
																			local packed = table.pack(17, 1, tostring(V7))
																			table.move(packed, 1, packed.n, 1, V16)
																		end
																		V6 = V16
																	end
																	V17 = V10.WalkToPoint
																	if V17 ~= Vector3.new() then
																		V6 = {17, 2, V17}
																	end
																	if LowerTorso and LowerTorso.Parent then
																		V18 = LowerTorso:FindFirstChild("Weld")
																		if V18 then
																			V7 = 0.65
																			if V18.C0 == CFrame.new(0, V7, 0) then
																				V6 = {"109", 2}
																			end
																		end
																	end
																	if Lighting:GetAttribute("ignoreme") then
																		Lighting:SetAttribute("ignoreme", nil)
																		V6 = {"109", 3}
																	end
																	if Fn8(Child, "ignoreme") then
																		V6 = {"109", 4}
																	end
																	if ReplicatedStorage:GetAttribute("ignoreme") then
																		ReplicatedStorage:SetAttribute("ignoreme", nil)
																		V6 = {"109", 7}
																	end
																	if Child:FindFirstChildWhichIsA("Accessory") then
																		V6 = {"109", 8}
																	end
																	V3 = V3 - 1
																	if V3 <= 0 then
																		V3 = 20
																		V19, V20, V21 = Child:GetDescendants()
																		for _, Value in V19, V20, V21 do
																			V7 = Value
																			V58(V7, true)
																		end
																		if not V2 then
																			V22 = math.random(1, 19)
																			V23 = 0
																			V24, V25, V7 = Child:GetChildren()
																			for _, V7 in V24, V25, V7 do
																				V26 = V7.Name
																				if V7.ClassName ~= "LocalScript" or V26 == "CameraController" or V26 == "Animate" then
																					continue
																				end
																				V23 = V23 + 1
																				if V23 ~= V22 then
																					continue
																				end
																				if V26 ~= "ViewmodelController" then
																					V27 = "LocalAmmo"
																					AttributeChanged = nil
																					V28 = V7.AttributeChanged
																					V29 = function(Arg1)
																						if Arg1 ~= V27 then
																							return
																						end
																						if V7:GetAttribute(Arg1) == V22 then
																							StartTime2 = os.clock()
																						end
																						V7:SetAttribute(V27, nil)
																						AttributeChanged:Disconnect()
																					end
																					AttributeChanged = V28:Connect(V29)
																					V7:SetAttribute(V27, V22)
																					break
																				else
																					V27 = "Animate"
																					AttributeChanged = nil
																					V28 = V7.AttributeChanged
																					V29 = function(Arg1)
																						if Arg1 ~= V27 then
																							return
																						end
																						if V7:GetAttribute(Arg1) == V22 then
																							StartTime2 = os.clock()
																						end
																						V7:SetAttribute(V27, nil)
																						AttributeChanged:Disconnect()
																					end
																					AttributeChanged = V28:Connect(V29)
																					V7:SetAttribute(V27, V22)
																					break
																				end
																			end
																		end
																	end
																	task.wait(1)
																	if not V2 then
																		if #T <= 0 or table.maxn(T) <= 0 then
																			V4 = {19, 0}
																			break
																		elseif not (not Child.Parent or (not V10.Parent or not (0 < V10.Health))) then
																			for Key, Value2 in T do
																				V7 = Value2
																				if typeof(V7) ~= "RBXScriptConnection" then
																					V7 = 19
																					AttributeChanged = Key
																					V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																					break
																				else
																					V7 = Value2.Connected
																					if V7 then
																						continue
																					end
																					V7 = 19
																					AttributeChanged = Key
																					V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																					break
																				end
																			end
																			if V4 then
																				break
																			end
																		end
																	else
																		V30, V31, V33 = Child:GetChildren()
																		for _, Value3 in V30, V31, V33 do
																			V34 = Value3.Name
																			V7 = Value3.ClassName
																			if V7 ~= "LocalScript" or (V34 == "CameraController" or V34 == "Animate") then
																				continue
																			end
																			V7 = nil
																			V35 = function(Arg1)
																				local Attribute = Value3:GetAttribute(Arg1)
																				if not Arg1:find("Debug") and (not Arg1:find("Color") and (not Arg1:find("Distance") and (Arg1 ~= "Equipped" or not (Attribute < 0) and (not (Attribute > 6) and Attribute % 1 == 0)))) and (Arg1 ~= "LocalAmmo" or (Attribute == nil or not (Attribute < 0) and Attribute % 1 == 0)) then
																					return V7
																				end
																				V8 = {4, V34, Arg1, Attribute}
																				return V7
																			end
																			V7 = V35
																			V36 = table.insert
																			AttributeChanged = Value3.AttributeChanged
																			V37 = AttributeChanged
																			AttributeChanged = V37.Connect
																			V36(T, AttributeChanged(V37, V7))
																			V38 = V7
																			if V34 ~= "ViewmodelController" then
																				V39 = ""
																			else
																				V39 = "LocalAmmo"
																			end
																			V40 = V38(V39)
																			if V40 ~= V7 then
																				AttributeChanged = 106
																				V4 = {AttributeChanged, 1, V40}
																			end
																		end
																		V2 = #T == 0
																	end
																	V41 = os.clock() - StartTime2
																	if not (300 <= V41) or V3 ~= 20 then
																		continue
																	end
																	V7 = V41
																	V4 = {106, 6, V7}
																	break
																else
																	V10.Name = "Humanoid"
																	V4 = {16, 5, V13}
																	break
																end
															end
														else
															V10.UseJumpPower = false
															V4 = {16, 2, true}
															break
														end
													end
												elseif V10.UseJumpPower == false then
													V12 = V10.MaxSlopeAngle
													if V12 < 0 or 80.01 <= V12 then
														V10.MaxSlopeAngle = math.clamp(V12, 0, 80)
														V4 = {16, 4, V12}
														break
													else
														V13 = V10.Name
														if V13 == "Humanoid" then
															V14 = V10.TargetPoint
															if V14 ~= Vector3.new() then
																V6 = {17, 0, V14}
															end
															V15 = V10.WalkToPart
															if V15 ~= nil then
																V16 = {}
																V7 = V15
																do
																	local packed = table.pack(17, 1, tostring(V7))
																	table.move(packed, 1, packed.n, 1, V16)
																end
																V6 = V16
															end
															V17 = V10.WalkToPoint
															if V17 ~= Vector3.new() then
																V6 = {17, 2, V17}
															end
															if LowerTorso and LowerTorso.Parent then
																V18 = LowerTorso:FindFirstChild("Weld")
																if V18 then
																	V7 = 0.65
																	if V18.C0 == CFrame.new(0, V7, 0) then
																		V6 = {"109", 2}
																	end
																end
															end
															if Lighting:GetAttribute("ignoreme") then
																Lighting:SetAttribute("ignoreme", nil)
																V6 = {"109", 3}
															end
															if Fn8(Child, "ignoreme") then
																V6 = {"109", 4}
															end
															if ReplicatedStorage:GetAttribute("ignoreme") then
																ReplicatedStorage:SetAttribute("ignoreme", nil)
																V6 = {"109", 7}
															end
															if Child:FindFirstChildWhichIsA("Accessory") then
																V6 = {"109", 8}
															end
															V3 = V3 - 1
															if V3 <= 0 then
																V3 = 20
																V19, V20, V21 = Child:GetDescendants()
																for _, Value in V19, V20, V21 do
																	V7 = Value
																	V58(V7, true)
																end
																if not V2 then
																	V22 = math.random(1, 19)
																	V23 = 0
																	V24, V25, V7 = Child:GetChildren()
																	for _, V7 in V24, V25, V7 do
																		V26 = V7.Name
																		if V7.ClassName ~= "LocalScript" or V26 == "CameraController" or V26 == "Animate" then
																			continue
																		end
																		V23 = V23 + 1
																		if V23 ~= V22 then
																			continue
																		end
																		if V26 ~= "ViewmodelController" then
																			V27 = "LocalAmmo"
																			AttributeChanged = nil
																			V28 = V7.AttributeChanged
																			V29 = function(Arg1)
																				if Arg1 ~= V27 then
																					return
																				end
																				if V7:GetAttribute(Arg1) == V22 then
																					StartTime2 = os.clock()
																				end
																				V7:SetAttribute(V27, nil)
																				AttributeChanged:Disconnect()
																			end
																			AttributeChanged = V28:Connect(V29)
																			V7:SetAttribute(V27, V22)
																			break
																		else
																			V27 = "Animate"
																			AttributeChanged = nil
																			V28 = V7.AttributeChanged
																			V29 = function(Arg1)
																				if Arg1 ~= V27 then
																					return
																				end
																				if V7:GetAttribute(Arg1) == V22 then
																					StartTime2 = os.clock()
																				end
																				V7:SetAttribute(V27, nil)
																				AttributeChanged:Disconnect()
																			end
																			AttributeChanged = V28:Connect(V29)
																			V7:SetAttribute(V27, V22)
																			break
																		end
																	end
																end
															end
															task.wait(1)
															if not V2 then
																if #T <= 0 or table.maxn(T) <= 0 then
																	V4 = {19, 0}
																	break
																elseif not (not Child.Parent or (not V10.Parent or not (0 < V10.Health))) then
																	for Key, Value2 in T do
																		V7 = Value2
																		if typeof(V7) ~= "RBXScriptConnection" then
																			V7 = 19
																			AttributeChanged = Key
																			V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																			break
																		else
																			V7 = Value2.Connected
																			if V7 then
																				continue
																			end
																			V7 = 19
																			AttributeChanged = Key
																			V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																			break
																		end
																	end
																	if V4 then
																		break
																	end
																end
															else
																V30, V31, V33 = Child:GetChildren()
																for _, Value3 in V30, V31, V33 do
																	V34 = Value3.Name
																	V7 = Value3.ClassName
																	if V7 ~= "LocalScript" or (V34 == "CameraController" or V34 == "Animate") then
																		continue
																	end
																	V7 = nil
																	V35 = function(Arg1)
																		local Attribute = Value3:GetAttribute(Arg1)
																		if not Arg1:find("Debug") and (not Arg1:find("Color") and (not Arg1:find("Distance") and (Arg1 ~= "Equipped" or not (Attribute < 0) and (not (Attribute > 6) and Attribute % 1 == 0)))) and (Arg1 ~= "LocalAmmo" or (Attribute == nil or not (Attribute < 0) and Attribute % 1 == 0)) then
																			return V7
																		end
																		V8 = {4, V34, Arg1, Attribute}
																		return V7
																	end
																	V7 = V35
																	V36 = table.insert
																	AttributeChanged = Value3.AttributeChanged
																	V37 = AttributeChanged
																	AttributeChanged = V37.Connect
																	V36(T, AttributeChanged(V37, V7))
																	V38 = V7
																	if V34 ~= "ViewmodelController" then
																		V39 = ""
																	else
																		V39 = "LocalAmmo"
																	end
																	V40 = V38(V39)
																	if V40 ~= V7 then
																		AttributeChanged = 106
																		V4 = {AttributeChanged, 1, V40}
																	end
																end
																V2 = #T == 0
															end
															V41 = os.clock() - StartTime2
															if not (300 <= V41) or V3 ~= 20 then
																continue
															end
															V7 = V41
															V4 = {106, 6, V7}
															break
														else
															V10.Name = "Humanoid"
															V4 = {16, 5, V13}
															break
														end
													end
												else
													V10.UseJumpPower = false
													V4 = {16, 2, true}
													break
												end
											end
										end
									else
										V4 = {16, 6, Parent}
										break
									end
								end
								if V4 ~= nil then
									V6 = V4
								end
							end
							Fn30(2, nil, V22)
						end
					else
						V9 = Name
						if Name2 == V9 then
							V4 = true
							if V32 ~= Child then
								V11 = setmetatable
								V9 = {}
								OnIterate = function(Arg1)
									V8 = {16, 1}
									return next, Arg1
								end
								V11(V9, {__iter = OnIterate})
								V9 = true
								V32 = Child
								Fn32(Child, "DescendantAdded", nil, false, false, true, V58)
								V12 = V10:GetPropertyChangedSignal("WalkSpeed")
								V13 = function()
									local WalkSpeed = V10.WalkSpeed
									V9 = nil
									if WalkSpeed >= 0 and WalkSpeed <= 19.01 then
										return
									end
									V8 = {11, WalkSpeed}
									V10.WalkSpeed = math.clamp(WalkSpeed, 0, 18)
								end
								Fn32(V10, "WalkSpeedChanged", V12, false, false, true, V13)
								V14 = V10:GetPropertyChangedSignal("JumpHeight")
								V15 = function()
									local JumpHeight = V10.JumpHeight
									if not (0 <= JumpHeight) or not (JumpHeight <= 3.26) then
										V10.JumpHeight = math.clamp(JumpHeight, 0, 3.25)
										return 16, 0, JumpHeight
									end
								end
								Fn32(V10, "JumpHeightChanged", V14, false, false, true, V15)
								V16 = V10:GetPropertyChangedSignal("HipHeight")
								V17 = function()
									local HipHeight = V10.HipHeight
									if HipHeight >= -0.01 and HipHeight <= 3 then
										return
									end
									if V5 then
										V8 = {3, 1, HipHeight}
										V10.HipHeight = 1.6
									else
										V5 = true
									end
								end
								Fn32(V10, "HipHeightChanged", V16, false, false, true, V17)
								V18 = V10:GetPropertyChangedSignal("UseJumpPower")
								V19 = function()
									V10.UseJumpPower = false
									return 16, 2, true
								end
								Fn32(V10, "UseJumpPowerChanged", V18, false, false, true, V19)
								V20 = V10:GetPropertyChangedSignal("PlatformStand")
								V21 = function()
									V10.PlatformStand = false
									return 16, 3, true
								end
								Fn32(V10, "PlatformStandChanged", V20, false, false, true, V21)
								V22 = function()
									local V2 = true
									local T = {}
									local V3 = 0
									local V4 = nil
									local WalkSpeed = V10.WalkSpeed
									local StartTime = nil
									local LowerTorso = Child:FindFirstChild("LowerTorso")
									local StartTime2 = os.clock()
									while V32 == Child do
										local Parent = V10.Parent
										if not Child.Parent or Parent == Child then
											local WalkSpeed2 = V10.WalkSpeed
											if WalkSpeed2 < 0 or 18.01 <= WalkSpeed2 then
												V10.WalkSpeed = math.clamp(WalkSpeed2, 0, 18)
												V4 = {"74", WalkSpeed2}
												break
											else
												if not (WalkSpeed2 == WalkSpeed or StartTime ~= nil) then
													StartTime = os.clock()
												end
												local Roll = math.random(19, 19)
												local ToNumber = tonumber
												V7 = 9
												local V11 = (".%*9"):format(V7)
												if 18.01 == Roll - ToNumber(V11) then
													if StartTime then
														if V9 ~= nil then
															os.clock()
														else
															StartTime = false
														end
													end
												else
													V4 = {V, 1, 18.01}
												end
												local JumpHeight = V10.JumpHeight
												if JumpHeight < 0 or 3.26 <= JumpHeight then
													V10.JumpHeight = math.clamp(JumpHeight, 0, 3.25)
													V4 = {16, 0, JumpHeight}
													break
												else
													local HipHeight = V10.HipHeight
													local V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22, V23, V24, V25, V26, V27, AttributeChanged, V28, V29, V30, V31, V33, V34, V35, V36, V37, V38, V39, V40, V41
													if HipHeight < -0.01 or 3 < HipHeight then
														if V5 then
															V10.HipHeight = 1.6
															V4 = {16, 1, HipHeight}
															break
														else
															V5 = true
															if V10.UseJumpPower == false then
																V12 = V10.MaxSlopeAngle
																if V12 < 0 or 80.01 <= V12 then
																	V10.MaxSlopeAngle = math.clamp(V12, 0, 80)
																	V4 = {16, 4, V12}
																	break
																else
																	V13 = V10.Name
																	if V13 == "Humanoid" then
																		V14 = V10.TargetPoint
																		if V14 ~= Vector3.new() then
																			V6 = {17, 0, V14}
																		end
																		V15 = V10.WalkToPart
																		if V15 ~= nil then
																			V16 = {}
																			V7 = V15
																			do
																				local packed = table.pack(17, 1, tostring(V7))
																				table.move(packed, 1, packed.n, 1, V16)
																			end
																			V6 = V16
																		end
																		V17 = V10.WalkToPoint
																		if V17 ~= Vector3.new() then
																			V6 = {17, 2, V17}
																		end
																		if LowerTorso and LowerTorso.Parent then
																			V18 = LowerTorso:FindFirstChild("Weld")
																			if V18 then
																				V7 = 0.65
																				if V18.C0 == CFrame.new(0, V7, 0) then
																					V6 = {"109", 2}
																				end
																			end
																		end
																		if Lighting:GetAttribute("ignoreme") then
																			Lighting:SetAttribute("ignoreme", nil)
																			V6 = {"109", 3}
																		end
																		if Fn8(Child, "ignoreme") then
																			V6 = {"109", 4}
																		end
																		if ReplicatedStorage:GetAttribute("ignoreme") then
																			ReplicatedStorage:SetAttribute("ignoreme", nil)
																			V6 = {"109", 7}
																		end
																		if Child:FindFirstChildWhichIsA("Accessory") then
																			V6 = {"109", 8}
																		end
																		V3 = V3 - 1
																		if V3 <= 0 then
																			V3 = 20
																			V19, V20, V21 = Child:GetDescendants()
																			for _, Value in V19, V20, V21 do
																				V7 = Value
																				V58(V7, true)
																			end
																			if not V2 then
																				V22 = math.random(1, 19)
																				V23 = 0
																				V24, V25, V7 = Child:GetChildren()
																				for _, V7 in V24, V25, V7 do
																					V26 = V7.Name
																					if V7.ClassName ~= "LocalScript" or V26 == "CameraController" or V26 == "Animate" then
																						continue
																					end
																					V23 = V23 + 1
																					if V23 ~= V22 then
																						continue
																					end
																					if V26 ~= "ViewmodelController" then
																						V27 = "LocalAmmo"
																						AttributeChanged = nil
																						V28 = V7.AttributeChanged
																						V29 = function(Arg1)
																							if Arg1 ~= V27 then
																								return
																							end
																							if V7:GetAttribute(Arg1) == V22 then
																								StartTime2 = os.clock()
																							end
																							V7:SetAttribute(V27, nil)
																							AttributeChanged:Disconnect()
																						end
																						AttributeChanged = V28:Connect(V29)
																						V7:SetAttribute(V27, V22)
																						break
																					else
																						V27 = "Animate"
																						AttributeChanged = nil
																						V28 = V7.AttributeChanged
																						V29 = function(Arg1)
																							if Arg1 ~= V27 then
																								return
																							end
																							if V7:GetAttribute(Arg1) == V22 then
																								StartTime2 = os.clock()
																							end
																							V7:SetAttribute(V27, nil)
																							AttributeChanged:Disconnect()
																						end
																						AttributeChanged = V28:Connect(V29)
																						V7:SetAttribute(V27, V22)
																						break
																					end
																				end
																			end
																		end
																		task.wait(1)
																		if not V2 then
																			if #T <= 0 or table.maxn(T) <= 0 then
																				V4 = {19, 0}
																				break
																			elseif not (not Child.Parent or (not V10.Parent or not (0 < V10.Health))) then
																				for Key, Value2 in T do
																					V7 = Value2
																					if typeof(V7) ~= "RBXScriptConnection" then
																						V7 = 19
																						AttributeChanged = Key
																						V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																						break
																					else
																						V7 = Value2.Connected
																						if V7 then
																							continue
																						end
																						V7 = 19
																						AttributeChanged = Key
																						V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																						break
																					end
																				end
																				if V4 then
																					break
																				end
																			end
																		else
																			V30, V31, V33 = Child:GetChildren()
																			for _, Value3 in V30, V31, V33 do
																				V34 = Value3.Name
																				V7 = Value3.ClassName
																				if V7 ~= "LocalScript" or (V34 == "CameraController" or V34 == "Animate") then
																					continue
																				end
																				V7 = nil
																				V35 = function(Arg1)
																					local Attribute = Value3:GetAttribute(Arg1)
																					if not Arg1:find("Debug") and (not Arg1:find("Color") and (not Arg1:find("Distance") and (Arg1 ~= "Equipped" or not (Attribute < 0) and (not (Attribute > 6) and Attribute % 1 == 0)))) and (Arg1 ~= "LocalAmmo" or (Attribute == nil or not (Attribute < 0) and Attribute % 1 == 0)) then
																						return V7
																					end
																					V8 = {4, V34, Arg1, Attribute}
																					return V7
																				end
																				V7 = V35
																				V36 = table.insert
																				AttributeChanged = Value3.AttributeChanged
																				V37 = AttributeChanged
																				AttributeChanged = V37.Connect
																				V36(T, AttributeChanged(V37, V7))
																				V38 = V7
																				if V34 ~= "ViewmodelController" then
																					V39 = ""
																				else
																					V39 = "LocalAmmo"
																				end
																				V40 = V38(V39)
																				if V40 ~= V7 then
																					AttributeChanged = 106
																					V4 = {AttributeChanged, 1, V40}
																				end
																			end
																			V2 = #T == 0
																		end
																		V41 = os.clock() - StartTime2
																		if not (300 <= V41) or V3 ~= 20 then
																			continue
																		end
																		V7 = V41
																		V4 = {106, 6, V7}
																		break
																	else
																		V10.Name = "Humanoid"
																		V4 = {16, 5, V13}
																		break
																	end
																end
															else
																V10.UseJumpPower = false
																V4 = {16, 2, true}
																break
															end
														end
													elseif V10.UseJumpPower == false then
														V12 = V10.MaxSlopeAngle
														if V12 < 0 or 80.01 <= V12 then
															V10.MaxSlopeAngle = math.clamp(V12, 0, 80)
															V4 = {16, 4, V12}
															break
														else
															V13 = V10.Name
															if V13 == "Humanoid" then
																V14 = V10.TargetPoint
																if V14 ~= Vector3.new() then
																	V6 = {17, 0, V14}
																end
																V15 = V10.WalkToPart
																if V15 ~= nil then
																	V16 = {}
																	V7 = V15
																	do
																		local packed = table.pack(17, 1, tostring(V7))
																		table.move(packed, 1, packed.n, 1, V16)
																	end
																	V6 = V16
																end
																V17 = V10.WalkToPoint
																if V17 ~= Vector3.new() then
																	V6 = {17, 2, V17}
																end
																if LowerTorso and LowerTorso.Parent then
																	V18 = LowerTorso:FindFirstChild("Weld")
																	if V18 then
																		V7 = 0.65
																		if V18.C0 == CFrame.new(0, V7, 0) then
																			V6 = {"109", 2}
																		end
																	end
																end
																if Lighting:GetAttribute("ignoreme") then
																	Lighting:SetAttribute("ignoreme", nil)
																	V6 = {"109", 3}
																end
																if Fn8(Child, "ignoreme") then
																	V6 = {"109", 4}
																end
																if ReplicatedStorage:GetAttribute("ignoreme") then
																	ReplicatedStorage:SetAttribute("ignoreme", nil)
																	V6 = {"109", 7}
																end
																if Child:FindFirstChildWhichIsA("Accessory") then
																	V6 = {"109", 8}
																end
																V3 = V3 - 1
																if V3 <= 0 then
																	V3 = 20
																	V19, V20, V21 = Child:GetDescendants()
																	for _, Value in V19, V20, V21 do
																		V7 = Value
																		V58(V7, true)
																	end
																	if not V2 then
																		V22 = math.random(1, 19)
																		V23 = 0
																		V24, V25, V7 = Child:GetChildren()
																		for _, V7 in V24, V25, V7 do
																			V26 = V7.Name
																			if V7.ClassName ~= "LocalScript" or V26 == "CameraController" or V26 == "Animate" then
																				continue
																			end
																			V23 = V23 + 1
																			if V23 ~= V22 then
																				continue
																			end
																			if V26 ~= "ViewmodelController" then
																				V27 = "LocalAmmo"
																				AttributeChanged = nil
																				V28 = V7.AttributeChanged
																				V29 = function(Arg1)
																					if Arg1 ~= V27 then
																						return
																					end
																					if V7:GetAttribute(Arg1) == V22 then
																						StartTime2 = os.clock()
																					end
																					V7:SetAttribute(V27, nil)
																					AttributeChanged:Disconnect()
																				end
																				AttributeChanged = V28:Connect(V29)
																				V7:SetAttribute(V27, V22)
																				break
																			else
																				V27 = "Animate"
																				AttributeChanged = nil
																				V28 = V7.AttributeChanged
																				V29 = function(Arg1)
																					if Arg1 ~= V27 then
																						return
																					end
																					if V7:GetAttribute(Arg1) == V22 then
																						StartTime2 = os.clock()
																					end
																					V7:SetAttribute(V27, nil)
																					AttributeChanged:Disconnect()
																				end
																				AttributeChanged = V28:Connect(V29)
																				V7:SetAttribute(V27, V22)
																				break
																			end
																		end
																	end
																end
																task.wait(1)
																if not V2 then
																	if #T <= 0 or table.maxn(T) <= 0 then
																		V4 = {19, 0}
																		break
																	elseif not (not Child.Parent or (not V10.Parent or not (0 < V10.Health))) then
																		for Key, Value2 in T do
																			V7 = Value2
																			if typeof(V7) ~= "RBXScriptConnection" then
																				V7 = 19
																				AttributeChanged = Key
																				V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																				break
																			else
																				V7 = Value2.Connected
																				if V7 then
																					continue
																				end
																				V7 = 19
																				AttributeChanged = Key
																				V4 = {V7, ("%*%*"):format(AttributeChanged, typeof(Value2)), Value2.Connected}
																				break
																			end
																		end
																		if V4 then
																			break
																		end
																	end
																else
																	V30, V31, V33 = Child:GetChildren()
																	for _, Value3 in V30, V31, V33 do
																		V34 = Value3.Name
																		V7 = Value3.ClassName
																		if V7 ~= "LocalScript" or (V34 == "CameraController" or V34 == "Animate") then
																			continue
																		end
																		V7 = nil
																		V35 = function(Arg1)
																			local Attribute = Value3:GetAttribute(Arg1)
																			if not Arg1:find("Debug") and (not Arg1:find("Color") and (not Arg1:find("Distance") and (Arg1 ~= "Equipped" or not (Attribute < 0) and (not (Attribute > 6) and Attribute % 1 == 0)))) and (Arg1 ~= "LocalAmmo" or (Attribute == nil or not (Attribute < 0) and Attribute % 1 == 0)) then
																				return V7
																			end
																			V8 = {4, V34, Arg1, Attribute}
																			return V7
																		end
																		V7 = V35
																		V36 = table.insert
																		AttributeChanged = Value3.AttributeChanged
																		V37 = AttributeChanged
																		AttributeChanged = V37.Connect
																		V36(T, AttributeChanged(V37, V7))
																		V38 = V7
																		if V34 ~= "ViewmodelController" then
																			V39 = ""
																		else
																			V39 = "LocalAmmo"
																		end
																		V40 = V38(V39)
																		if V40 ~= V7 then
																			AttributeChanged = 106
																			V4 = {AttributeChanged, 1, V40}
																		end
																	end
																	V2 = #T == 0
																end
																V41 = os.clock() - StartTime2
																if not (300 <= V41) or V3 ~= 20 then
																	continue
																end
																V7 = V41
																V4 = {106, 6, V7}
																break
															else
																V10.Name = "Humanoid"
																V4 = {16, 5, V13}
																break
															end
														end
													else
														V10.UseJumpPower = false
														V4 = {16, 2, true}
														break
													end
												end
											end
										else
											V4 = {16, 6, Parent}
											break
										end
									end
									if V4 ~= nil then
										V6 = V4
									end
								end
								Fn30(2, nil, V22)
							end
						end
					end
					V9 = T
					table.insert(V9, Child)
					V9 = Child
					T2[Name2] = {V9, V10}
					V7 = true
				end
				table.clear(T14)
				table.clear(T15)
				T14 = T
				T15 = T2
				if V7 then
					local V23 = V2:NextInteger(1, #T14)
					local V24 = T14[V23]
					local Descendants = V24:GetDescendants()
					local V25 = nil
					for _, Descendant in Descendants do
						V9 = Descendant.Name
						if V9 ~= "HumanoidRootPart" then
							if Descendant.ClassName == "MeshPart" and Descendant.Parent == V24 then
								local Size = Descendant.Size
								if 2.01 <= Size.X or (15 <= Size.Y or 1.2 <= Size.Z) then
									V25 = {V9, 0, Size}
									break
								end
							end
						else
							local Size2 = Descendant.Size
							local Transparency = Descendant.Transparency
							if 2.01 <= Size2.X or (3.01 <= Size2.Y or 2.01 <= Size2.Z) then
								V25 = {V9, 0, Size2}
								break
							elseif Transparency ~= 1 then
								V25 = {V9, 1, Transparency}
								break
							end
						end
						Fn38(Descendant, true)
					end
					table.clear(Descendants)
					if V25 ~= nil then
						V9 = "37"
						table.insert(V25, 1, V9)
						V6 = V25
					end
				end
				local Wait = task.wait
				local V26
				if not V4 then
					V26 = 0.5
				else
					V26 = 6
				end
				Wait(V26)
				if Fn36() then
					V3 = 0
					V46 = V34
				else
					V46 = nil
					local Character = LocalPlayer.Character
					local V27 = Character and Fn8(Character, "Humanoid")
					if not V27 then
						local V28 = Fn8(Workspace, Name)
						V27 = V28 and Fn8(V28, "Humanoid")
					end
					if not V27 then
						V3 = 0
					else
						V3 = V3 + 1
						if V3 == 20 then
							V3 = 0
							V6 = table.pack("38")
						end
					end
				end
				V47[1] = os.clock()
			end
			V40 = true
		end
		local V7, V9 = Fn29("004", Fn)
		if V2 == V4 then
			V2 = V2 - 2009
			V5 = 37645617
			V3 = 874750437
			V4 = V4 + 712
			Upvalue298 = nil
			Upvalue287[287] = REG
		else
			V6 = {21, 3, V7, V9}
		end
	end
	Fn30(1, 1, Fn52)
	local function Fn53()
		local VFX = workspace:WaitForChild("VFX", 1)
		local VMs = nil
		if VFX then
			VMs = VFX:WaitForChild("VMs", 1)
		end
		local V = ("%*%*"):format(8, 5)
		local T = {V}
		local function Fn()
			local V, V2, V3, V4, V5, V9, V10, V11, V12, V13, V14, V15, V16, V18, V19, V20, V21, V24 = nil
			local V25 = Random.new()
			local Count = 0
			local V26 = ""
			V34 = Fn19()
			local T3 = {"WalkSpeed", "JumpHeight", "HipHeight", "MaxSlopeAngle"}
			local V27 = 0
			local V31 = nil
			local V32 = nil
			local V33 = nil
			local V36 = nil
			local V38 = nil
			local function Fn()
				return Game.InvokeServer
			end
			local function Fn3(Arg1)
				local Pcall = pcall
				local function Fn()
					return Arg1()
				end
				local V, V2 = Pcall(Fn)
				if V ~= false or (("%*"):format(V2) ~= V2 or not string.match(V2, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #1 %(Instance expected%)$")) then
					V32 = {0, V, V2}
				end
				local Pcall2 = pcall
				local function Fn2()
					return Arg1(Game)
				end
				local V3, V4 = Pcall2(Fn2)
				if V3 ~= false or (("%*"):format(V4) ~= V4 or not string.match(V4, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #2 %(string expected%)$")) then
					V32 = {1, V3, V4}
				end
				local Pcall3 = pcall
				local function Fn3()
					return Arg1(V34, "GetChildren")
				end
				local V5, V7 = Pcall3(Fn3)
				if V5 ~= false or (("%*"):format(V7) ~= V7 or not string.match(V7, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 %(Instance expected, got userdata%)$")) then
					V32 = {2, V5, V7}
				end
				local Pcall4 = pcall
				local function Fn4()
					return Arg1(Game, V34)
				end
				local V8, V9 = Pcall4(Fn4)
				if V8 ~= false or (("%*"):format(V9) ~= V9 or not string.match(V9, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$")) then
					V32 = {3, V8, V9}
				end
				local V10 = T3[Count % 4 + 1]
				local ModelModel = Instance.new("Model\0Model")
				ModelModel.Name = "Humanoid"
				ModelModel.Parent = workspace
				local Pcall5 = pcall
				local function Fn6()
					return Arg1(ModelModel, V10)
				end
				local V11, V12 = Pcall5(Fn6)
				if V11 ~= false or V12 ~= ("%* is not a valid member of Model \"Workspace .Humanoid\""):format(V10) then
					V32 = {4, V11, V12}
				end
				ModelModel:Destroy()
				ModelModel = Instance.new("RemoteFunction\0\1\2")
				ModelModel.Name = "RemoteEvent"
				ModelModel.Parent = ReplicatedStorage
				local Pcall6 = pcall
				local function Fn7()
					return Arg1(ModelModel, "FireServer")
				end
				local V13, V14 = Pcall6(Fn7)
				if V13 ~= false or V14 ~= "FireServer is not a valid member of RemoteFunction \"ReplicatedStorage.RemoteEvent\"" then
					V32 = {5, V13, V14}
				end
				local Pcall7 = pcall
				local function Fn8()
					return Arg1(ModelModel, "InvokeServer")
				end
				local V15, V16 = Pcall7(Fn8)
				if V31 == nil then
					V31 = V16
				end
				if V15 ~= true or Fn5(V16) ~= "function" or V16 ~= V31 then
					V32 = {6, V15, V16}
				end
				ModelModel:Destroy()
				local V17, V18 = pcall(Arg1, Game, V34)
				if V17 ~= false or V18 ~= "invalid argument #2 (string expected, got userdata)" then
					V32 = {7, V17, V18}
				end
				local V19, V20 = Fn36()
				if V20 then
					local Pcall8 = pcall
					local function Fn9()
						return Arg1(V20, V34)
					end
					local V21, V22 = Pcall8(Fn9)
					if V21 ~= false or (("%*"):format(V22) ~= V22 or not string.match(V22, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$")) then
						V32 = {8, V21, V22}
					end
					local Pcall9 = pcall
					local function Fn10()
						return Arg1(V20, V10)
					end
					local V23, V24 = Pcall9(Fn10)
					if V23 ~= true or Fn5(V24) ~= "number" then
						V32 = {9, V23, V24}
					end
				end
				if V27 == 1 then
					local V25 = V56(Arg1, -1, Workspace, "Name")
					if V25 then
						V6 = table.pack("43", 0, V25)
					end
				end
				return V27
			end
			local T4 = {
				{Fn, Fn3, "^0InvokeServer is not a valid member of DataModel \".+\"$"},
			}
			local function Fn6()
				Game.FireServer = 0
			end
			local function Fn7(Arg1)
				local Pcall = pcall
				local function Fn()
					Arg1()
				end
				local V, V2 = Pcall(Fn)
				if V ~= false or (("%*"):format(V2) ~= V2 or not string.match(V2, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #1 %(Instance expected%)$")) then
					V33 = {0, V, V2}
				end
				local Pcall2 = pcall
				local function Fn2()
					Arg1(Game)
				end
				local V3, V4 = Pcall2(Fn2)
				if V3 ~= false or (("%*"):format(V4) ~= V4 or not string.match(V4, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #2 %(string expected%)$")) then
					V33 = {1, V3, V4}
				end
				local Pcall3 = pcall
				local function Fn3()
					Arg1(V34, "FireServer", nil)
				end
				local V5, V7 = Pcall3(Fn3)
				if V5 ~= false or ("%*"):format(V7) ~= V7 or not string.match(V7, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 %(Instance expected, got userdata%)$") then
					V33 = {2, V5, V7}
				end
				local Pcall4 = pcall
				local function Fn4()
					Arg1(Game, V34, 0)
				end
				local V8, V9 = Pcall4(Fn4)
				if V8 ~= false or ("%*"):format(V9) ~= V9 or not string.match(V9, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$") then
					V33 = {3, V8, V9}
				end
				local Pcall5 = pcall
				local function Fn5()
					Arg1(Game, "Name", V34)
				end
				local V10, V11 = Pcall5(Fn5)
				if V10 ~= false or V11 ~= "Unable to assign property Name. string expected, got userdata" then
					V33 = {4, V10, V11}
				end
				local Pcall6 = pcall
				local function Fn6()
					return Arg1(Workspace, "Camera", nil)
				end
				local V12, V13 = Pcall6(Fn6)
				if V12 ~= false or V13 ~= "Camera is not a valid member of Workspace \"Workspace \"" then
					V33 = {5, V12, V13}
				end
				local V14 = T3[Count % 4 + 1]
				local Decalgg = Instance.new("Decal\0gg")
				Decalgg.Name = "Humanoid"
				local Pcall7 = pcall
				local function Fn7()
					Arg1(Decalgg, "Parent", Workspace)
					Arg1(Decalgg, V14, 0)
				end
				local V15, V16 = Pcall7(Fn7)
				if V15 ~= false or V16 ~= ("%* is not a valid member of Decal \"Workspace .Humanoid\""):format(V14) then
					V33 = {6, V15, V16}
				end
				Decalgg:Destroy()
				Decalgg = Instance.new("RemoteEvent\0=D")
				local Pcall8 = pcall
				local function Fn8()
					Arg1(Decalgg, "Parent", ReplicatedStorage)
					return Arg1(Decalgg, "FireServer", nil)
				end
				local V17, V18 = Pcall8(Fn8)
				if V17 ~= false or V18 ~= "FireServer is not a valid member of RemoteEvent \"ReplicatedStorage.RemoteEvent\"" then
					V33 = {7, V17, V18}
				end
				local Pcall9 = pcall
				local function Fn9()
					Arg1(Decalgg, "ClassName", "RemoteFunction")
				end
				local V19, V20 = Pcall9(Fn9)
				if V19 ~= false or V20 ~= "Unable to assign property ClassName. Property is read only" then
					V33 = {8, V19, V20}
				end
				local Pcall10 = pcall
				local function Fn10()
					Arg1(Decalgg, "RobloxLocked", true)
				end
				local V21, V22 = Pcall10(Fn10)
				if V21 ~= false or V22 ~= "The current thread cannot write 'RobloxLocked' (lacking capability Plugin)" then
					V33 = {9, V21, V22}
				end
				Decalgg:Destroy()
				local V23, V24 = pcall(Arg1, Game, V34, 0)
				if V23 ~= false or V24 ~= "invalid argument #2 (string expected, got userdata)" then
					V33 = {10, V23, V24}
				end
				local V25, V26 = Fn36()
				if V26 then
					local Pcall11 = pcall
					local function Fn11()
						return Arg1(V26, V34, 0)
					end
					local V28, V29 = Pcall11(Fn11)
					if V28 ~= false or ("%*"):format(V29) ~= V29 or not string.match(V29, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$") then
						V33 = {11, V28, V29}
					end
					local Pcall12 = pcall
					local function Fn12()
						Arg1(V26, "Archivable", V34)
						return true
					end
					local V30, V31 = Pcall12(Fn12)
					if V30 ~= true or V31 ~= true then
						V33 = {12, V30, V31}
					end
				end
				if V27 == 2 then
					local V32 = V56(Arg1, -1, Workspace, "Name", "Workspace ")
					if V32 then
						V6 = table.pack("43", 1, V32)
					end
				end
				return V27
			end
			T4[2] = {Fn6, Fn7, "^0FireServer is not a valid member of DataModel \".+\"$"}
			local function FireServer2()
				Game:FireServer()
			end
			local function Fn10(Arg1)
				local Pcall = pcall
				local function Fn()
					Arg1()
				end
				local V, V2 = Pcall(Fn)
				if V ~= false or (("%*"):format(V2) ~= V2 or not string.match(V2, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #1 %(Instance expected%)$")) then
					V36 = {0, V, V2}
				end
				local Pcall2 = pcall
				local function Fn2()
					Arg1(V34, "GetChildren")
				end
				local V3, V4 = Pcall2(Fn2)
				if V3 ~= false or ("%*"):format(V4) ~= V4 or not string.match(V4, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 %(Instance expected, got userdata%)$") then
					V36 = {1, V3, V4}
				end
				local Pcall3 = pcall
				local function Fn3()
					Arg1(Workspace, V34)
				end
				local V5, V7 = Pcall3(Fn3)
				if V5 ~= false or ("%*"):format(V7) ~= V7 or not string.match(V7, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$") then
					V36 = {2, V5, V7}
				end
				local V8, V9 = pcall(Arg1, V34, "GetChildren")
				if V8 ~= false or V9 ~= "invalid argument #1 (Instance expected, got userdata)" then
					V36 = {3, V8, V9}
				end
				local Folder = Instance.new("Folder\0$")
				Folder.Name = "RemoteEvent"
				Folder.Parent = ReplicatedStorage
				local Pcall4 = pcall
				local function Fn4()
					return Arg1(Folder, "FireServer")
				end
				local V10, V11 = Pcall4(Fn4)
				if V10 ~= false or V11 ~= "FireServer is not a valid member of Folder \"ReplicatedStorage.RemoteEvent\"" then
					V36 = {4, V10, V11}
				end
				Folder:Destroy()
				Folder = Instance.new("RemoteEvent\0hjrtsme4g")
				Folder.Parent = ReplicatedStorage
				local Pcall5 = pcall
				local function Fn5()
					return Arg1(Folder, V34)
				end
				local V12, V13 = Pcall5(Fn5)
				if V12 ~= false or (("%*"):format(V13) ~= V13 or not string.match(V13, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$")) then
					V36 = {5, V12, V13}
				end
				local Pcall6 = pcall
				local function Fn6()
					Arg1(Folder, "FireServer", V34)
					return true
				end
				local V14, V15 = Pcall6(Fn6)
				if V14 ~= true or V15 ~= true then
					V36 = {6, V14, V15}
				end
				if V27 == 3 then
					local V16 = V56(Arg1, -1, Folder, "FireServer")
					if V16 then
						V6 = table.pack("43", 2, V16)
					end
				end
				Folder:Destroy()
				return V27
			end
			T4[3] = {FireServer2, Fn10, "^0FireServer is not a valid member of DataModel \".+\"$"}
			local function Fn13()
				return Enum["DeveloperMemoryTag\0chicken"].FireServer
			end
			local function Fn14(Arg1)
				local Pcall = pcall
				local function Fn()
					return Arg1()
				end
				local V, V2 = Pcall(Fn)
				if V ~= false or ("%*"):format(V2) ~= V2 or not string.match(V2, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #1 %(Enum expected%)$") then
					V38 = {0, V, V2}
				end
				local Pcall2 = pcall
				local function Fn2()
					return Arg1(V34, "Script")
				end
				local V3, V4 = Pcall2(Fn2)
				if V3 ~= false or (("%*"):format(V4) ~= V4 or not string.match(V4, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 %(Enum expected, got userdata%)$")) then
					V38 = {1, V3, V4}
				end
				local V5 = Enum["DeveloperMemoryTag\0nlkadsf"]
				local Pcall3 = pcall
				local function Fn3()
					return Arg1(V5)
				end
				local V7, V8 = Pcall3(Fn3)
				if V7 ~= false or ("%*"):format(V8) ~= V8 or not string.match(V8, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: missing argument #2 %(string expected%)$") then
					V38 = {2, V7, V8}
				end
				local Pcall4 = pcall
				local function Fn4()
					return Arg1(V5, V34)
				end
				local V9, V10 = Pcall4(Fn4)
				if V9 ~= false or (("%*"):format(V10) ~= V10 or not string.match(V10, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #2 %(string expected, got userdata%)$")) then
					V38 = {3, V9, V10}
				end
				local V11, V12 = pcall(Arg1, Enum["MessageType\0z46k"], V34)
				if V11 ~= false or V12 ~= "invalid argument #2 (string expected, got userdata)" then
					V38 = {4, V11, V12}
				end
				local Pcall5 = pcall
				local function Fn6()
					return Arg1(V5, "Script\0mmm")
				end
				local V13, V14 = Pcall5(Fn6)
				if V13 ~= true or (Fn5(V14) ~= "EnumItem" or V14.Name ~= "Script" or V14.Value ~= 5 or V14.EnumType ~= V5) then
					V38 = {5, V13, V14}
				end
				if V27 == 4 then
					local V15 = V56(Arg1, -1, V5, "LuaHeap")
					if V15 then
						V6 = table.pack("43", 3, V15)
					end
				end
				return V27
			end
			T4[4] = {Fn13, Fn14, "^0FireServer is not a valid member of \"Enum.DeveloperMemoryTag\"$"}
			local function Nop()
			end
			local function Nop2()
			end
			local V40 = coroutine.create(Nop2)
			coroutine.resume(V40)
			local function Nop3()
			end
			local V41 = task.spawn(Nop3)
			local V42 = buffer.create(1)
			local V43 = table.freeze({})
			local V44 = setmetatable({}, {__metatable = "The metatable is locked"})
			local T5 = {}
			T5[1] = T5
			local SetMetatable = setmetatable
			local T6 = {}
			local function OnToString(_)
				local V, V2, V3 = Fn34(5, {4, 5})
				if V or (V2 or V3) then
					V45 = {T, V, V2, V3}
					return
				end
			end
			local V46 = SetMetatable(T6, {__tostring = OnToString})
			local T7 = {
				{
					setfenv,
					V34,
					{},
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'setfenv' %(number expected, got userdata%)$",
				},
				{
					setfenv,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'setfenv' %(table expected%)$",
				},
				{
					setfenv,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'setfenv' %(table expected, got userdata%)$",
				},
				{
					setfenv,
					os.clock,
					{},
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): 'setfenv' cannot change environment of given object$",
				},
				{
					getfenv,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'getfenv' %(number expected, got userdata%)$",
				},
				{
					getfenv,
					-1,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'getfenv' %(level must be non%-negative%)$",
				},
				{
					collectgarbage,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'collectgarbage' %(string expected%)$",
				},
				{
					collectgarbage,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'collectgarbage' %(string expected, got nil%)$",
				},
				{
					collectgarbage,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'collectgarbage' %(string expected, got userdata%)$",
				},
				{
					collectgarbage,
					"\0count",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): collectgarbage must be called with 'count'; use gcinfo%(%) instead$",
				},
				{
					debug.info,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'info' %(function or level expected%)$",
				},
				{
					debug.info,
					-1,
					"f",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'info' %(level can't be negative%)$",
				},
				{
					debug.info,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'info' %(string expected%)$",
				},
				{
					debug.info,
					os.clock,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'info' %(string expected, got nil%)$",
				},
				{
					debug.info,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'info' %(string expected, got userdata%)$",
				},
				{
					debug.info,
					0,
					"slfnam",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'info' %(invalid option%)$",
				},
				{
					debug.info,
					V41,
					os.clock,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'info' %(function or level expected%)$",
				},
				{
					debug.info,
					V41,
					-1,
					"f",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'info' %(level can't be negative%)$",
				},
				{
					debug.info,
					V41,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #3 to 'info' %(string expected%)$",
				},
				{
					debug.info,
					V41,
					0,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'info' %(string expected, got nil%)$",
				},
				{
					debug.info,
					V41,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'info' %(string expected, got userdata%)$",
				},
				{
					coroutine.create,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'create' %(function expected%)$",
				},
				{
					coroutine.create,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'create' %(function expected, got nil%)$",
				},
				{
					coroutine.create,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'create' %(function expected, got userdata%)$",
				},
				{
					coroutine.resume,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'resume' %(thread expected%)$",
				},
				{
					coroutine.resume,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'resume' %(thread expected, got nil%)$",
				},
				{
					coroutine.resume,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'resume' %(thread expected, got userdata%)$",
				},
				{
					string.match,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'match' %(string expected%)$",
				},
				{
					string.match,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'match' %(string expected, got nil%)$",
				},
				{
					string.match,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'match' %(string expected, got userdata%)$",
				},
				{
					string.match,
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'match' %(string expected%)$",
				},
				{
					string.match,
					"",
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'match' %(string expected, got nil%)$",
				},
				{
					string.match,
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'match' %(string expected, got userdata%)$",
				},
				{
					string.match,
					"",
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'match' %(number expected, got userdata%)$",
				},
				{string.match, "", "(", "^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): unfinished capture$"},
				{
					string.match,
					"",
					"[",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): malformed pattern %(missing '%]'%)$",
				},
				{
					string.match,
					"",
					"%1",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid capture index %%1$",
				},
				{
					string.match,
					"",
					"%ba",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): malformed pattern %(missing arguments to '%%b'%)$",
				},
				{
					xpcall,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'xpcall' %(function expected%)$",
				},
				{
					xpcall,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'xpcall' %(function expected, got userdata%)$",
				},
				{
					setmetatable,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'setmetatable' %(table expected%)$",
				},
				{
					setmetatable,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'setmetatable' %(table expected, got nil%)$",
				},
				{
					setmetatable,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'setmetatable' %(table expected, got userdata%)$",
				},
				{
					setmetatable,
					{},
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'setmetatable' %(nil or table expected%)$",
				},
				{
					setmetatable,
					{},
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'setmetatable' %(nil or table expected, got userdata%)$",
				},
				{
					setmetatable,
					V44,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): cannot change a protected metatable$",
				},
				{tonumber, "^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1$"},
				{
					tonumber,
					nil,
					-10,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'tonumber' %(string expected, got nil%)$",
				},
				{
					tonumber,
					nil,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'tonumber' %(number expected, got userdata%)$",
				},
				{
					tonumber,
					1,
					(0/0),
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'tonumber' %(base out of range%)$",
				},
				{tostring, "^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1$"},
				{
					tostring,
					V46,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): '__tostring' must return a string$",
				},
				{
					math.random,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'random' %(number expected, got nil%)$",
				},
				{
					math.random,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'random' %(number expected, got userdata%)$",
				},
				{
					math.random,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'random' %(interval is empty%)$",
				},
				{
					math.random,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'random' %(number expected, got userdata%)$",
				},
				{
					math.random,
					1,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'random' %(interval is empty%)$",
				},
				{
					table.insert,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'insert' %(table expected%)$",
				},
				{
					table.insert,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'insert' %(table expected, got nil%)$",
				},
				{
					table.insert,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'insert' %(table expected, got userdata%)$",
				},
				{
					table.insert,
					{},
					nil,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'insert' %(number expected, got nil%)$",
				},
				{
					table.insert,
					{},
					V34,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'insert' %(number expected, got userdata%)$",
				},
				{
					table.insert,
					{},
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): wrong number of arguments to 'insert'$",
				},
				{
					table.maxn,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'maxn' %(table expected%)$",
				},
				{
					table.maxn,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'maxn' %(table expected, got userdata%)$",
				},
				{
					string.lower,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'lower' %(string expected%)$",
				},
				{
					string.lower,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'lower' %(string expected, got userdata%)$",
				},
				{
					string.gsub,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'gsub' %(string expected%)$",
				},
				{
					string.gsub,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'gsub' %(string expected, got userdata%)$",
				},
				{
					string.gsub,
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'gsub' %(string expected%)$",
				},
				{
					string.gsub,
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'gsub' %(string expected, got userdata%)$",
				},
				{
					string.gsub,
					"",
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #3 to 'gsub' %(string/function/table expected%)$",
				},
				{
					string.gsub,
					"",
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'gsub' %(string/function/table expected, got userdata%)$",
				},
				{
					string.gsub,
					"",
					"",
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #4 to 'gsub' %(number expected, got userdata%)$",
				},
				{
					string.gsub,
					"a",
					".",
					{a = V34},
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid replacement value %(a userdata%)$",
				},
				{
					string.gsub,
					"a",
					"[",
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): malformed pattern %(missing '%]'%)$",
				},
				{
					string.gsub,
					"a",
					"%1",
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid capture index %%1$",
				},
				{
					string.gsub,
					"a",
					"%ba",
					"",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): malformed pattern %(missing arguments to '%%b'%)$",
				},
				{
					buffer.fromstring,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'fromstring' %(string expected%)$",
				},
				{
					buffer.fromstring,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'fromstring' %(string expected, got userdata%)$",
				},
				{
					buffer.writeu8,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'writeu8' %(buffer expected%)$",
				},
				{
					buffer.writeu8,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'writeu8' %(buffer expected, got nil%)$",
				},
				{
					buffer.writeu8,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'writeu8' %(buffer expected, got userdata%)$",
				},
				{
					buffer.writeu8,
					V42,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'writeu8' %(number expected%)$",
				},
				{
					buffer.writeu8,
					V42,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'writeu8' %(number expected, got userdata%)$",
				},
				{
					buffer.writeu8,
					V42,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #3 to 'writeu8' %(number expected%)$",
				},
				{
					buffer.writeu8,
					V42,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'writeu8' %(number expected, got userdata%)$",
				},
				{
					buffer.writeu8,
					V42,
					0,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'writeu8' %(number expected, got nil%)$",
				},
				{
					buffer.writeu8,
					V42,
					1,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): buffer access out of bounds$",
				},
				{
					buffer.writestring,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'writestring' %(buffer expected%)$",
				},
				{
					buffer.writestring,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'writestring' %(buffer expected, got userdata%)$",
				},
				{
					buffer.writestring,
					V42,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'writestring' %(number expected%)$",
				},
				{
					buffer.writestring,
					V42,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'writestring' %(number expected, got userdata%)$",
				},
				{
					buffer.writestring,
					V42,
					0,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #3 to 'writestring' %(string expected%)$",
				},
				{
					buffer.writestring,
					V42,
					0,
					nil,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'writestring' %(string expected, got nil%)$",
				},
				{
					buffer.writestring,
					V42,
					0,
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #3 to 'writestring' %(string expected, got userdata%)$",
				},
				{
					buffer.writestring,
					V42,
					0,
					"",
					V34,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #4 to 'writestring' %(number expected, got userdata%)$",
				},
				{
					buffer.writestring,
					V42,
					0,
					"a",
					-1,
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #4 to 'writestring' %(count%)$",
				},
				{
					buffer.writestring,
					V42,
					1,
					"a",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): buffer access out of bounds$",
				},
				{
					buffer.writestring,
					V42,
					0,
					"  ",
					"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): buffer access out of bounds$",
				},
			}
			local T8 = {
				buffer.writestring,
				V42,
				0,
				"a",
				2,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): string length overflow$",
			}
			local T10 = {
				buffer.readu8,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1 to 'readu8' %(buffer expected%)$",
			}
			local T11 = {
				buffer.readu8,
				nil,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'readu8' %(buffer expected, got nil%)$",
			}
			local T13 = {
				buffer.readu8,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'readu8' %(buffer expected, got userdata%)$",
			}
			local T14 = {
				buffer.readu8,
				V42,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #2 to 'readu8' %(number expected%)$",
			}
			local T15 = {
				buffer.readu8,
				V42,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #2 to 'readu8' %(number expected, got userdata%)$",
			}
			local T16 = {
				buffer.readu8,
				V42,
				1,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): buffer access out of bounds$",
			}
			local T17 = {
				task.spawn,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'spawn' %(function or thread expected%)$",
			}
			local T18 = {
				LogService.MessageOut,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): attempt to call a RBXScriptSignal value$",
			}
			local T19 = {
				task.wait,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'wait' %(number expected, got userdata%)$",
			}
			local T20 = {getmetatable, "^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): missing argument #1$"}
			local T21 = {
				newproxy,
				V34,
				"^ReplicatedStorage%.Modules%.AssetContainer:()(%d+): invalid argument #1 to 'newproxy' %(nil or boolean expected, got userdata%)$",
			}
			local T22 = {
				ScriptContext.AddCoreScriptLocal,
				ScriptContext,
				"",
				V17,
				"^The current thread cannot call 'AddCoreScriptLocal' %(lacking capability RobloxScript%)$",
			}
			local T23 = {
				Game:GetService("HttpRbxApiService").PostAsync,
				Game:GetService("HttpRbxApiService"),
				"https://economy.roblox.com/v1/user/currency",
				"",
				Enum.ThrottlingPriority.Default,
				Enum.HttpContentType.TextPlain,
				Enum.HttpRequestType.Default,
				"^The current thread cannot call 'PostAsync' %(lacking capability RobloxScript%)$",
			}
			local T24 = {
				Game:GetService("HttpRbxApiService").PostAsyncFullUrl,
				Game:GetService("HttpRbxApiService"),
				"https://economy.roblox.com/v1/user/currency",
				"",
				Enum.ThrottlingPriority.Default,
				Enum.HttpContentType.TextPlain,
				Enum.HttpRequestType.Default,
				"^The current thread cannot call 'PostAsyncFullUrl' %(lacking capability RobloxScript%)$",
			}
			local T25 = {
				Game:GetService("HttpRbxApiService").GetAsync,
				Game:GetService("HttpRbxApiService"),
				"https://economy.roblox.com/v1/user/currency",
				Enum.ThrottlingPriority.Default,
				Enum.HttpRequestType.Default,
				"^The current thread cannot call 'GetAsync' %(lacking capability RobloxScript%)$",
			}
			local T26 = {
				Game:GetService("HttpRbxApiService").GetAsyncFullUrl,
				Game:GetService("HttpRbxApiService"),
				"https://economy.roblox.com/v1/user/currency",
				Enum.ThrottlingPriority.Default,
				Enum.HttpRequestType.Default,
				"^The current thread cannot call 'GetAsyncFullUrl' %(lacking capability RobloxScript%)$",
			}
			local T27 = {
				Game:GetService("HttpRbxApiService").RequestAsync,
				Game:GetService("HttpRbxApiService"),
				{Url = "https://economy.roblox.com/v1/user/currency"},
				Enum.ThrottlingPriority.Default,
				Enum.HttpContentType.TextPlain,
				Enum.HttpRequestType.Default,
				"^The current thread cannot call 'RequestAsync' %(lacking capability RobloxScript%)$",
			}
			local T28 = {
				Game.Load,
				Game,
				"https://economy.roblox.com/v1/user/currency",
				"^The current thread cannot call 'Load' %(lacking capability LocalUser%)$",
			}
			local T29 = {
				Game.OpenScreenshotsFolder,
				Game,
				"^The current thread cannot call 'OpenScreenshotsFolder' %(lacking capability RobloxScript%)$",
			}
			local T30 = {
				GuiService.OpenBrowserWindow,
				GuiService,
				"https://www.google.com/",
				"^The current thread cannot call 'OpenBrowserWindow' %(lacking capability RobloxScript%)$",
			}
			local T31 = {
				GuiService.OpenNativeOverlay,
				GuiService,
				"",
				"https://www.google.com/",
				"^The current thread cannot call 'OpenNativeOverlay' %(lacking capability RobloxScript%)$",
			}
			local T32 = {
				MarketplaceService.PromptRobloxPurchase,
				MarketplaceService,
				1,
				false,
				"^The current thread cannot call 'PromptRobloxPurchase' %(lacking capability RobloxScript%)$",
			}
			local T33 = {
				MarketplaceService.PerformPurchase,
				MarketplaceService,
				"^The current thread cannot call 'PerformPurchase' %(lacking capability RobloxScript%)$",
			}
			local T34 = {
				MarketplaceService.SignalClientPurchaseSuccess,
				MarketplaceService,
				"",
				1,
				1,
				"^The current thread cannot call 'SignalClientPurchaseSuccess' %(lacking capability RobloxScript%)$",
			}
			local T35 = {
				MarketplaceService.GetRobuxBalance,
				MarketplaceService,
				"^The current thread cannot call 'GetRobuxBalance' %(lacking capability RobloxScript%)$",
			}
			local T36 = {
				MarketplaceService.PerformBulkPurchase,
				MarketplaceService,
				{},
				{},
				"^The current thread cannot call 'PerformBulkPurchase' %(lacking capability RobloxScript%)$",
			}
			local T37 = {
				MarketplaceService.PerformPurchaseV2,
				MarketplaceService,
				Enum.InfoType.Asset,
				1,
				1,
				"",
				true,
				{},
				"^The current thread cannot call 'PerformPurchaseV2' %(lacking capability RobloxScript%)$",
			}
			local T38 = {MarketplaceService.PromptPurchase, MarketplaceService, "^Argument [12] missing or nil$"}
			local function Fn15()
				task.wait()
			end
			local T39 = {string.gsub, "a", ".", Fn15, "^thread is not yieldable$"}
			local function Fn16()
				Game.Destroying:Wait()
			end
			local T40 = {string.gsub, "a", ".", Fn16, "^thread cannot be yielded to Wait$"}
			local ToString = tostring
			local SetMetatable2 = setmetatable
			local T41 = {}
			local function OnToString2()
				task.wait()
			end
			local T42 = {ToString, SetMetatable2(T41, {__tostring = OnToString2}), "^thread is not yieldable$"}
			local ToString2 = tostring
			local SetMetatable3 = setmetatable
			local T43 = {}
			local function OnToString3()
				Game.Destroying:Wait()
			end
			local T44 = {ToString2, SetMetatable3(T43, {__tostring = OnToString3}), "^thread cannot be yielded to Wait$"}
			local T45 = {setmetatable, V43, nil, "^attempt to modify a readonly table$"}
			local T46 = {table.insert, V43, 0, "^attempt to modify a readonly table$"}
			local T47 = {ContentProvider.PreloadAsync, ContentProvider, V34, Nop, "^Unable to cast n?u?l?l? ?to Array$"}
			local T48 = {
				Players.ReportAbuseV3,
				Players,
				LocalPlayer,
				"",
				"^The current thread cannot call 'ReportAbuseV3' %(lacking capability RobloxScript%)$",
			}
			local T49 = {
				HttpService.RequestInternal,
				HttpService,
				{},
				"^The current thread cannot call 'RequestInternal' %(lacking capability RobloxScript%)$",
			}
			local T50 = {
				Game:GetService("OpenCloudService").HttpRequestAsync,
				Game:GetService("OpenCloudService"),
				{},
				"^The current thread cannot call 'HttpRequestAsync' %(lacking capability RobloxScript%)$",
			}
			local T51 = {
				Game:GetService("CaptureService").DeleteCapture,
				Game:GetService("CaptureService"),
				"",
				"^The current thread cannot call 'DeleteCapture' %(lacking capability RobloxScript%)$",
			}
			local T52 = {HttpService.JSONEncode, HttpService, T5, "^tables cannot be cyclic$"}
			T7[101] = T8
			T7[102] = T10
			T7[103] = T11
			T7[104] = T13
			T7[105] = T14
			T7[106] = T15
			T7[107] = T16
			T7[108] = T17
			T7[109] = T18
			T7[110] = T19
			T7[111] = T20
			T7[112] = T21
			T7[113] = T22
			T7[114] = T23
			T7[115] = T24
			T7[116] = T25
			T7[117] = T26
			T7[118] = T27
			T7[119] = T28
			T7[120] = T29
			T7[121] = T30
			T7[122] = T31
			T7[123] = T32
			T7[124] = T33
			T7[125] = T34
			T7[126] = T35
			T7[127] = T36
			T7[128] = T37
			T7[129] = T38
			T7[130] = T39
			T7[131] = T40
			T7[132] = T42
			T7[133] = T44
			T7[134] = T45
			T7[135] = T46
			T7[136] = T47
			T7[137] = T48
			T7[138] = T49
			T7[139] = T50
			T7[140] = T51
			T7[141] = T52
			local T53 = {}
			local T54 = {[3] = nil, [4] = nil, [5] = nil, [1] = nil}
			local V48 = T54
			for Index = 1, math.random(1, 10) do
				local Insert = table.insert
				local V49 = ("%*"):format(math.random(0, 1))
				Insert(T53, V49)
			end
			local V50 = ("%*%*"):format(string.rep("-", math.random(0, 10)), math.random(0, 9))
			local V51 = ""
			for Index2 = 1, 10 do
				V51 = V51 .. Fn11(math.random(42, 255))
			end
			local V52 = V25:NextInteger(1, 10000000)
			local V53 = V25:NextInteger(1, 10000000)
			local V54 = V25:NextInteger(1, 10000000)
			local V58 = V25:NextInteger(3, 100)
			local V59 = V25:NextInteger(0, 255)
			local V60 = HttpService:GenerateGUID(false)
			local function Fn17()
				return V60
			end
			local T55 = {}
			local function Fn18(Arg1)
				return if type(Arg1) == "number" and (Arg1 % 1 == 0 and Arg1 >= 1) then Arg1 <= V53 else false
			end
			local T56 = {math.random, Fn18, 1, V53}
			local T57 = {math.random, V52, V52, V52}
			local T58 = {tonumber, nil, "\0-0.1"}
			local T59 = {tonumber, 255, "0xFF", 16}
			local ToNumber = tonumber
			local V61 = ("%*\0a"):format(V54)
			local T60 = {ToNumber, V54, V61}
			local T61 = {buffer.writeu8, nil, buffer.create(math.random(100, 255)), math.random(0, 60), math.random(0, 255)}
			local T62 = {buffer.writeu8, nil, V42, 0, V59}
			local T63 = {
				buffer.writestring,
				nil,
				buffer.create(math.random(100, 255)),
				math.random(0, 60),
				HttpService:GenerateGUID(false):gsub("-", ""),
				32,
			}
			local T64 = {buffer.readu8, V59, V42, 0}
			local T65 = {table.insert, nil, {}, 0}
			local T66 = {
				table.maxn,
				V58,
				{0, 1, [V58] = 2},
			}
			local T67 = {
				string.lower,
				"replicatedstorage.modules.assetcontainer:3: attempt to call a nil value",
				"ReplicatedStorage.Modules.AssetContainer:3: attempt to call a nil value",
			}
			local function Fn20(_, _)
				return "Script 'ReplicatedFirst.Preload', Line 3"
			end
			local T68 = {
				string.gsub,
				"Script 'ReplicatedFirst.Preload', Line 3",
				"Script 'ReplicatedStorage.Modules.AssetContainer', Line 3",
				"Script '(.-)', Line (%d+)",
				Fn20,
			}
			local T69 = {}
			local V62 = ("%*)%*("):format(V50, V51)
			local V63 = "%*%* %*)%*(%*%*)%*("
			local Format = V63.format
			local V64 = string.rep(Fn11(math.random(32, 255)), math.random(0, 2))
			local V65
			if math.random(1, 2) ~= 1 then
				V65 = ""
			else
				V65 = " "
			end
			local V66 = Format(V63, V64, V65, V50, V51, table.concat(T53), Fn11(math.random(97, 122)), V51)
			T69[1] = string.match
			T69[2] = V62
			T69[3] = V66
			T69[4] = "^.- ? (%-*[^%D](%b)())[0-1]+%l%2$"
			local function Fn21(Arg1)
				return if type(Arg1) == "number" then Arg1 > 0 else false
			end
			local T70 = {task.wait, Fn21}
			local T71 = {ContentProvider.PreloadAsync, nil, ContentProvider, T12, Nop}
			local Collectgarbage = collectgarbage
			local function Fn22(Arg1)
				return if type(Arg1) == "number" and Arg1 >= 0 then Arg1 % 1 == 0 else false
			end
			local T72 = {Collectgarbage, Fn22, "count\0"}
			local V67
			local function Fn23(Arg1)
				V67 = V67 or Arg1
				return if type(Arg1) == "function" then V67 == Arg1 else false
			end
			local T73 = {debug.info, Fn23, 10, "f\0\1"}
			local function Fn24(Arg1)
				return if type(Arg1) == "thread" then coroutine.status(Arg1) == "suspended" else false
			end
			local T74 = {coroutine.create, Fn24, Nop, V34}
			local New = Random.new
			local function Fn25(Arg1)
				return if tostring(Arg1) == "Random" then if type(Arg1.NextInteger) == "function" then typeof(Arg1) == "Random" else false else false
			end
			T55[1] = T56
			T55[2] = T57
			T55[3] = T58
			T55[4] = T59
			T55[5] = T60
			T55[6] = T61
			T55[7] = T62
			T55[8] = T63
			T55[9] = T64
			T55[10] = T65
			T55[11] = T66
			T55[12] = T67
			T55[13] = T68
			T55[14] = T69
			T55[15] = T70
			T55[16] = T71
			T55[17] = T72
			T55[18] = T73
			T55[19] = T74
			T55[20] = {New, Fn25}
			local V68 = true
			local V69 = nil
			local V70 = false
			local V71 = Fn9(SoundService, "Hit")
			local V72 = Fn9(SoundService, "HitHead")
			local BillboardGui = Instance.new("BillboardGui")
			local V73 = 0
			local Count2 = 0
			local V74 = false
			local V75 = false
			local V76 = false
			local V77 = false
			local V78 = false
			local V79 = false
			while not V70 do
				Count2 = Count2 + 1
				V35 = 0
				V35 = 1
				Script2 = {}
				local V80 = Fn19(Script2)
				getfenv(0).script = Script2
				V35 = 2
				if _VERSION ~= "Luau" or version() ~= Version() then
					local V81 = ("ALOOP1.%*.%*.%*"):format(_VERSION, version(), Version())
					Fn12(V81)
				end
				_G = nil
				if _G then
					Fn12("ALOOP2")
				end
				V2, V3, V = shared, nil, nil
				if type(V2) == "table" then
					V2, V3, V = next, V2, nil
				end
				while true do
					local V82, V83, V84 = (nil)()
					if not V82 then
						break
					end
					local V85 = ("ALOOP5.%*.%*"):format(V83, V84)
					Fn12(V85)
				end
				local V86 = V48[1]
				local V87 = V48[3]
				V35 = 3
				V5, V9, V4 = {"ErrorCount", "TestCount", "WarnCount", "Timeout"}, nil, nil
				if type(V5) == "table" then
					V5, V9, V4 = next, V5, nil
				end
				V48 = {[3] = V87, [4] = V48[4], [5] = V48[5], [1] = V86}
				local V88, V89, V90 = (nil)()
				if V88 then
					V6 = {"8", V90, TestService[V90]}
				end
				V35 = 4
				if Fn8(SoundService, "HitHead") == V72 then
					if V72.SoundId == "rbxassetid://988593556" then
						if not (0.603 <= V72.TimeLength) then
							if 0.001 <= V72.Volume - 0.8 then
								V6 = {77, 0, 3, V72.Volume}
							end
						else
							V6 = {77, 0, 2, V72.TimeLength}
						end
					else
						V6 = {77, 0, 1, V72.SoundId}
					end
				else
					V6 = {77, 0, 0, V72.Parent}
				end
				if Fn8(SoundService, "Hit") == V71 then
					if V71.SoundId == "rbxassetid://160432334" then
						if not (0.768 <= V71.TimeLength) then
							if 0.001 <= V71.Volume - 0.6 then
								V6 = {77, 1, 3, V71.Volume}
							end
						else
							V6 = {77, 1, 2, V71.TimeLength}
						end
					else
						V6 = {77, 1, 1, V71.SoundId}
					end
				else
					V6 = {77, 1, 0, V71.Parent}
				end
				V35 = 5
				local V91 = nil
				local V92 = nil
				local V93 = nil
				local V94 = nil
				local V95 = nil
				local V96 = false
				V11, V12, V10 = T7, nil, nil
				if type(V11) == "table" then
					V11, V12, V10 = next, V11, nil
				end
				local V97, V98, V99 = (nil)()
				local V100, V101, V102, V103
				if V97 then
					local V104 = #V99
					V100 = pcall
					local function Fn26()
						return V99[1](unpack(V99, 2, V104 - 1))
					end
					V101 = Fn26
					V100, V101 = V100(V101)
					if V100 ~= false then
						V91 = 0
						V92 = V98
						V93 = 1
						V94 = V100
						V95 = V101
						V96 = nil
					else
						V102 = "%*"
						local V105 = V102
						V102 = V105.format
						V103 = V101
						V102 = V102(V105, V103)
						if V102 == V101 then
							V102 = string
							V102 = V102.match
							V103 = V99[V104]
							local V106
							V102, V106 = V102(V101, V103)
							if not V69 then
								V69 = V106
							end
							if not (113 <= V98) then
								V91 = 0
								V92 = V98
								V93 = 3
								V94 = V100
								V95 = V101
								V96 = nil
							else
								V91 = 0
								V92 = V98
								V93 = 2
								V94 = V100
								V95 = V101
								V96 = nil
							end
						else
							V91 = 0
							V92 = V98
							V93 = 1
							V94 = V100
							V95 = V101
							V96 = nil
						end
					end
				end
				if V96 == false or getmetatable(T7) ~= nil then
					Fn12("ALOOP10")
				end
				V35 = 6
				local function Fn27()
					return coroutine.resume(V40, V34)
				end
				local V107, V108, V109, V110 = Fn29("006", Fn27)
				local V111, V112
				if V107 ~= true or (V108 ~= false or V109 ~= "cannot resume dead coroutine" or V110 ~= nil) then
					V100 = Fn12
					V101 = "ALOOP3.%*.%*.%*.%*"
					local V113 = V101
					V102 = V113
					V101 = V113.format
					V103 = V108
					V111 = V109
					V112 = V110
					V101 = V101(V102, V107, V103, V111, V112)
					V100(V101)
				end
				V35 = 7
				local V114 = false
				V100 = T55
				V101 = nil
				V102 = nil
				V14, V15, V13 = V100, V101, V102
				if type(V14) == "table" then
					V14, V15, V13 = next, V14, nil
				end
				local V115, V116, V117 = (nil)()
				if V115 then
					V101 = V116
					V102 = V117
					V103 = "007"
					local function Fn28()
						local V = V102[1]
						v9 = MRES_4_1
						return V(unpack(V102, 3))
					end
					V111 = Fn28
					local Spill = {}
					Spill.V118, V103 = Fn29(V103, V111)
					V111 = V102[2]
					if Spill.V118 == true then
						V112 = Fn5
						V112 = V112(V111)
						if V112 == "function" then
							V111(V103)
						end
					end
					V91 = 1
					V92 = V101
					V93 = Spill.V118
					V94 = V108
					V114 = nil
				end
				if V114 == false then
					V100 = Fn12
					V101 = "ALOOP11"
					V100(V101)
				else
					V100 = getmetatable
					V101 = T55
					V100 = V100(V101)
					if V100 ~= nil then
						V100 = Fn12
						V101 = "ALOOP11"
						V100(V101)
					end
				end
				V35 = 8
				if not (4 <= V27) then
					V27 = V27 + 1
				else
					V27 = 1
				end
				V100 = 0
				local function Fn30(Arg1, Arg2, ...)
					local T = {...}
					local V = 0
					local function Fn(Arg1_2)
						if 19990 + Arg2 <= Arg1_2 then
							Arg1(unpack(T))
							V = V + 1
						elseif Arg1_2 % 500 == 0 then
							task.wait()
						end
						Fn(Arg1_2 + 1)
					end
					local V2, V3 = pcall(Fn, 1)
					if V == 1 and (V2 == false and (type(V3) == "string" and string.match(V3, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: stack overflow$"))) then
						local V4 = V100[3]
						local V5 = V100[2]
						V4[V5] = V4[V5] + 1
						return
					end
					return if V3 == "not enough memory" then nil else V3 or "N/A"
				end
				V101 = Fn30
				V56 = V101
				V101 = Fn5
				V102 = T4
				V101 = V101(V102)
				local Spill2 = {}
				if V101 ~= "table" then
					V101 = error
					V102 = "ALOOP9"
					V101(V102)
				else
					V102 = #T4
					if V102 ~= 4 then
						V101 = error
						V102 = "ALOOP9"
						V101(V102)
					else
						V103 = T4[1]
						if Fn5(V103) ~= "table" then
							V101 = error
							V102 = "ALOOP9"
							V101(V102)
						else
							V103 = T4[1]
							V103 = V103[3]
							if V103 ~= "^0InvokeServer is not a valid member of DataModel \".+\"$" then
								V101 = error
								V102 = "ALOOP9"
								V101(V102)
							else
								V111 = Fn5
								V112 = T4[1]
								V112 = V112[2]
								V111 = V111(V112)
								if V111 ~= "function" then
									V101 = error
									V102 = "ALOOP9"
									V101(V102)
								else
									V112 = Fn5
									V112 = V112(T4[2])
									if V112 ~= "table" or T4[2][3] ~= "^0FireServer is not a valid member of DataModel \".+\"$" or Fn5(T4[2][2]) ~= "function" or (Fn5(T4[3]) ~= "table" or T4[3][3] ~= "^0FireServer is not a valid member of DataModel \".+\"$") then
										V101 = error
										V102 = "ALOOP9"
										V101(V102)
									else
										Spill2.V119 = Fn5
										Spill2.V120 = T4[3]
										Spill2.V120 = Spill2.V120[2]
										Spill2.V119 = Spill2.V119(Spill2.V120)
										if Spill2.V119 ~= "function" then
											V101 = error
											V102 = "ALOOP9"
											V101(V102)
										end
									end
								end
							end
						end
					end
				end
				V101 = T4
				V102 = nil
				V18, V19, V16 = V101, V102, nil
				if type(V18) == "table" then
					V18, V19, V16 = next, V18, nil
				end
				Spill2.V121, Spill2.V122, Spill2.V123 = (nil)()
				if Spill2.V121 then
					V102 = Spill2.V122
					V103 = nil
					V111 = nil
					V112 = nil
					Spill2.V128 = xpcall
					Spill2.V129 = Spill2.V123[1]
					Spill2.V130 = function(Arg1)
						local V, V2, V3 = Fn34(V102, 2)
						if V or V2 or V3 then
							V111 = V2
							V112 = V3
							return V
						end
						V103 = debug.info(2, "f\0f")
						local V4, V5, V6, V7, V8, V9 = debug.info(V103, "sflna")
						local V10
						if V4 ~= "[C]" or (V5 ~= V103 or (V6 ~= -1 or V7 ~= "" or V8 ~= 0 or V9 ~= true)) then
							V10 = "."
						else
							V10 = "0" .. Arg1
						end
						return V10
					end
					Spill2.V131, Spill2.V132, Spill2.V133 = Spill2.V128(Spill2.V129, Spill2.V130)
					if Spill2.V131 ~= false or Spill2.V133 ~= nil or V111 ~= nil or V112 ~= nil then
						Spill2.V119 = 44
						Spill2.V120 = V102
						Spill2.V124 = Spill2.V131
						Spill2.V125 = Spill2.V132
						Spill2.V126 = "INDEX: %*\nDEC: %*"
						Spill2.V134 = Spill2.V126
						Spill2.V126 = Spill2.V134.format
						Spill2.V127 = V111
						Spill2.V126 = Spill2.V126(Spill2.V134, Spill2.V127, V112)
						V6 = {Spill2.V119, Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126}
					else
						Spill2.V135 = "%*"
						Spill2.V119 = Spill2.V135
						Spill2.V120 = Spill2.V132
						if Spill2.V135.format(Spill2.V119, Spill2.V120) ~= Spill2.V132 then
							Spill2.V119 = 44
							Spill2.V120 = V102
							Spill2.V124 = Spill2.V131
							Spill2.V125 = Spill2.V132
							Spill2.V126 = "INDEX: %*\nDEC: %*"
							Spill2.V134 = Spill2.V126
							Spill2.V126 = Spill2.V134.format
							Spill2.V127 = V111
							Spill2.V126 = Spill2.V126(Spill2.V134, Spill2.V127, V112)
							V6 = {Spill2.V119, Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126}
						else
							Spill2.V119 = string
							Spill2.V119 = Spill2.V119.match
							Spill2.V120 = Spill2.V132
							Spill2.V124 = Spill2.V123[3]
							Spill2.V119 = Spill2.V119(Spill2.V120, Spill2.V124)
							if not Spill2.V119 then
								Spill2.V119 = 44
								Spill2.V120 = V102
								Spill2.V124 = Spill2.V131
								Spill2.V125 = Spill2.V132
								Spill2.V126 = "INDEX: %*\nDEC: %*"
								Spill2.V134 = Spill2.V126
								Spill2.V126 = Spill2.V134.format
								Spill2.V127 = V111
								Spill2.V126 = Spill2.V126(Spill2.V134, Spill2.V127, V112)
								V6 = {Spill2.V119, Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126}
							else
								Spill2.V119 = V57
								Spill2.V120 = V102
								Spill2.V124 = V103
								Spill2.V119 = Spill2.V119(Spill2.V120, Spill2.V124)
								if Spill2.V119 == true then
									Spill2.V119 = V103
									Spill2.V136 = Spill2.V123[2](Spill2.V119)
									if not V32 then
										if not V33 then
											if not V36 then
												if not V38 then
													Spill2.V124 = 45
													Spill2.V120 = {Spill2.V124}
													Spill2.V124 = V102
													Spill2.V125 = Spill2.V136
													Spill2.V119 = {Spill2.V120, Spill2.V124, Spill2.V125}
													V45 = Spill2.V119
												else
													Spill2.V119 = table
													Spill2.V119 = Spill2.V119.insert
													Spill2.V120 = V38
													Spill2.V124 = 1
													Spill2.V126 = "39" + 3
													Spill2.V125 = {Spill2.V126}
													Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125)
													V45 = V38
													V38 = nil
												end
											else
												Spill2.V119 = table
												Spill2.V119 = Spill2.V119.insert
												Spill2.V120 = V36
												Spill2.V124 = 1
												Spill2.V126 = "39" + 2
												Spill2.V125 = {Spill2.V126}
												Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125)
												V45 = V36
												V36 = nil
											end
										else
											Spill2.V119 = table
											Spill2.V119 = Spill2.V119.insert
											Spill2.V120 = V33
											Spill2.V124 = 1
											Spill2.V126 = "39" + 1
											Spill2.V125 = {Spill2.V126}
											Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125)
											V45 = V33
											V33 = nil
										end
									else
										Spill2.V119 = table
										Spill2.V119 = Spill2.V119.insert
										Spill2.V120 = V32
										Spill2.V124 = 1
										Spill2.V126 = "39"
										Spill2.V125 = {Spill2.V126}
										Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125)
										V45 = V32
										V32 = nil
									end
								else
									Spill2.V119 = 44
									Spill2.V120 = V102
									Spill2.V124 = Spill2.V131
									Spill2.V125 = Spill2.V132
									Spill2.V126 = "INDEX: %*\nDEC: %*"
									Spill2.V134 = Spill2.V126
									Spill2.V126 = Spill2.V134.format
									Spill2.V127 = V111
									Spill2.V126 = Spill2.V126(Spill2.V134, Spill2.V127, V112)
									V6 = {Spill2.V119, Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126}
								end
							end
						end
					end
				end
				V101 = V45
				if not V101 then
					V101 = V27
					V27 = 0
					V102 = HttpService
					Spill2.V137 = V102
					V102 = Spill2.V137.GenerateGUID
					V103 = false
					V102 = V102(Spill2.V137, V103)
					Spill2.V138 = {}
					V103 = setmetatable
					V111 = {}
					Spill2.V139 = function(...)
						local V, V2 = VM_pack(...)
						local V3 = V2[1]
						local T = {}
						local V4 = V + -2
						if V4 < 0 then
							table.insert(Spill2.V138, T)
						else
							local Count = 0
							for Index = 6, 6 + V4 do
								REG[i_84] = V2[2 + Count]
								Count = Count + 1
							end
							table.move(REG, 6, 6 + V4, 1, T)
							table.insert(Spill2.V138, T)
						end
						for Index2 = 2, 11 do
							local V5, V6, V7, V8 = debug.info(Index2, "slnf")
							if not (Index2 ~= 11 or V5) then
								continue
							end
							if (V5 ~= "[C]" or V6 ~= -1 or V7 ~= "pcall" or V8 ~= Pcall) and (V5 ~= "ReplicatedStorage.Modules.AssetContainer" or V7 ~= "" or V6 ~= 3) then
								local V9 = ("0/%*/%*/%*"):format(V5, V6, V7)
								return V9
							end
							if getfenv(Index2).getconnections then
								return "1"
							end
						end
						return V102
					end
					V112 = {__call = Spill2.V139}
					V103 = V103(V111, V112)
					if V101 ~= 1 then
						if V101 ~= 2 then
							if V101 == 3 then
								V111 = pcall
								V112 = T4[3]
								V112 = V112[2]
								V111, V112 = V111(V112, V103)
								if V111 ~= true or V112 ~= 0 or Fn5(V36) ~= "table" or V36[1] ~= 5 or V36[2] ~= true or V36[3] ~= V102 then
									Spill2.V140 = typeof(V36)
									if Spill2.V140 ~= "table" then
										V95 = Spill2.V140
									else
										Spill2.V141 = V36[1]
										Spill2.V119 = V36[2]
										Spill2.V120 = V36[3]
										V95 = ("%*/%*/%*"):format(Spill2.V141, Spill2.V119, Spill2.V120)
									end
									V91 = 22
									V92 = 2
									V93 = V111
									V94 = V112
								elseif Spill2.V138[1][1] or type(Spill2.V138[2][1]) ~= "userdata" or (Spill2.V138[2][2] ~= "GetChildren" or Spill2.V138[2][3] or Spill2.V138[3][1] ~= Workspace) then
									V91 = 23
									V92 = 2
									V93 = HttpService:JSONEncode(Spill2.V138)
								else
									Spill2.V119 = type
									Spill2.V120 = Spill2.V138[3]
									Spill2.V120 = Spill2.V120[2]
									Spill2.V119 = Spill2.V119(Spill2.V120)
									if Spill2.V119 ~= "userdata" then
										V91 = 23
										V92 = 2
										V93 = HttpService:JSONEncode(Spill2.V138)
									else
										Spill2.V120 = Spill2.V138[3]
										Spill2.V120 = Spill2.V120[3]
										if Spill2.V120 then
											V91 = 23
											V92 = 2
											V93 = HttpService:JSONEncode(Spill2.V138)
										else
											Spill2.V120 = type
											Spill2.V124 = Spill2.V138[4]
											Spill2.V124 = Spill2.V124[1]
											Spill2.V120 = Spill2.V120(Spill2.V124)
											if Spill2.V120 ~= "userdata" then
												V91 = 23
												V92 = 2
												V93 = HttpService:JSONEncode(Spill2.V138)
											else
												Spill2.V124 = Spill2.V138[4]
												Spill2.V124 = Spill2.V124[2]
												if Spill2.V124 ~= "GetChildren" then
													V91 = 23
													V92 = 2
													V93 = HttpService:JSONEncode(Spill2.V138)
												else
													Spill2.V125 = Spill2.V138[4]
													Spill2.V125 = Spill2.V125[3]
													if Spill2.V125 then
														V91 = 23
														V92 = 2
														V93 = HttpService:JSONEncode(Spill2.V138)
													else
														Spill2.V125 = typeof
														Spill2.V126 = Spill2.V138[5]
														Spill2.V126 = Spill2.V126[1]
														Spill2.V125 = Spill2.V125(Spill2.V126)
														if Spill2.V125 ~= "Instance" then
															V91 = 23
															V92 = 2
															V93 = HttpService:JSONEncode(Spill2.V138)
														else
															Spill2.V126 = Spill2.V138[5]
															Spill2.V126 = Spill2.V126[1]
															Spill2.V126 = Spill2.V126.ClassName
															if Spill2.V126 ~= "Folder" or Spill2.V138[5][2] ~= "FireServer" then
																V91 = 23
																V92 = 2
																V93 = HttpService:JSONEncode(Spill2.V138)
															else
																Spill2.V127 = Spill2.V138[5]
																Spill2.V127 = Spill2.V127[3]
																if Spill2.V127 then
																	V91 = 23
																	V92 = 2
																	V93 = HttpService:JSONEncode(Spill2.V138)
																else
																	Spill2.V127 = typeof
																	Spill2.V127 = Spill2.V127(Spill2.V138[6][1])
																	if Spill2.V127 ~= "Instance" or (Spill2.V138[6][1].ClassName ~= "RemoteEvent" or type(Spill2.V138[6][2]) ~= "userdata" or Spill2.V138[6][3] or Spill2.V138[7][1] ~= Spill2.V138[6][1] or (Spill2.V138[7][2] ~= "FireServer" or type(Spill2.V138[7][3]) ~= "userdata" or Spill2.V138[7][4])) then
																		V91 = 23
																		V92 = 2
																		V93 = HttpService:JSONEncode(Spill2.V138)
																	end
																end
															end
														end
													end
												end
											end
										end
									end
								end
								V36 = nil
							end
						else
							V111 = pcall
							V112 = T4[2]
							V112 = V112[2]
							V111, V112 = V111(V112, V103)
							if V111 ~= true or V112 ~= 0 or (Fn5(V33) ~= "table" or not ((V33[1] == 10 or V33[1] == 11) and V33[2] == true)) then
								Spill2.V142 = typeof(V33)
								if Spill2.V142 ~= "table" then
									V95 = Spill2.V142
								else
									Spill2.V143 = V33[1]
									Spill2.V119 = V33[2]
									Spill2.V120 = V33[3]
									V95 = ("%*/%*/%*"):format(Spill2.V143, Spill2.V119, Spill2.V120)
								end
								V91 = 22
								V92 = 1
								V93 = V111
								V94 = V112
							else
								Spill2.V119 = V33[3]
								if Spill2.V119 == V102 then
									if Spill2.V138[1][1] or (Spill2.V138[2][1] ~= Game or Spill2.V138[2][2] or type(Spill2.V138[3][1]) ~= "userdata" or Spill2.V138[3][2] ~= "FireServer") then
										V91 = 23
										V92 = 1
										V93 = HttpService:JSONEncode(Spill2.V138)
									else
										Spill2.V119 = Spill2.V138[3]
										Spill2.V119 = Spill2.V119[3]
										if Spill2.V119 then
											V91 = 23
											V92 = 1
											V93 = HttpService:JSONEncode(Spill2.V138)
										else
											Spill2.V119 = Spill2.V138[4]
											Spill2.V119 = Spill2.V119[1]
											Spill2.V120 = Game
											if Spill2.V119 ~= Spill2.V120 then
												V91 = 23
												V92 = 1
												V93 = HttpService:JSONEncode(Spill2.V138)
											else
												Spill2.V124 = type
												Spill2.V125 = Spill2.V138[4]
												Spill2.V125 = Spill2.V125[2]
												Spill2.V124 = Spill2.V124(Spill2.V125)
												if Spill2.V124 ~= "userdata" then
													V91 = 23
													V92 = 1
													V93 = HttpService:JSONEncode(Spill2.V138)
												else
													Spill2.V125 = Spill2.V138[4]
													Spill2.V125 = Spill2.V125[3]
													if Spill2.V125 ~= 0 then
														V91 = 23
														V92 = 1
														V93 = HttpService:JSONEncode(Spill2.V138)
													else
														Spill2.V126 = Spill2.V138[4]
														Spill2.V126 = Spill2.V126[4]
														if Spill2.V126 then
															V91 = 23
															V92 = 1
															V93 = HttpService:JSONEncode(Spill2.V138)
														else
															Spill2.V126 = Spill2.V138[5]
															Spill2.V126 = Spill2.V126[1]
															if Spill2.V126 ~= Game then
																V91 = 23
																V92 = 1
																V93 = HttpService:JSONEncode(Spill2.V138)
															else
																Spill2.V127 = Spill2.V138[5]
																Spill2.V127 = Spill2.V127[2]
																if Spill2.V127 ~= "Name" or (type(Spill2.V138[5][3]) ~= "userdata" or (Spill2.V138[5][4] or Spill2.V138[6][1] ~= Workspace or Spill2.V138[6][2] ~= "Camera" or (Spill2.V138[6][3] or typeof(Spill2.V138[7][1]) ~= "Instance" or Spill2.V138[7][1].ClassName ~= "Decal" or Spill2.V138[7][2] ~= "Parent" or Spill2.V138[7][3] ~= Workspace or Spill2.V138[7][4] or Spill2.V138[8][1] ~= Spill2.V138[7][1] or not table.find(T3, Spill2.V138[8][2]) or Spill2.V138[8][3] ~= 0 or Spill2.V138[8][4] or typeof(Spill2.V138[9][1]) ~= "Instance" or Spill2.V138[9][1].ClassName ~= "RemoteEvent" or Spill2.V138[9][2] ~= "Parent" or Spill2.V138[9][3] ~= ReplicatedStorage or Spill2.V138[9][4] or Spill2.V138[10][1] ~= Spill2.V138[9][1] or Spill2.V138[10][2] ~= "FireServer" or Spill2.V138[10][3] or Spill2.V138[11][1] ~= Spill2.V138[9][1] or Spill2.V138[11][2] ~= "ClassName" or Spill2.V138[11][3] ~= "RemoteFunction" or (Spill2.V138[11][4] or Spill2.V138[12][1] ~= Spill2.V138[9][1] or Spill2.V138[12][2] ~= "RobloxLocked" or Spill2.V138[12][3] ~= true or Spill2.V138[12][4] or Spill2.V138[13][1] ~= Game or type(Spill2.V138[13][2]) ~= "userdata" or Spill2.V138[13][3] ~= 0 or Spill2.V138[13][4])))) then
																	V91 = 23
																	V92 = 1
																	V93 = HttpService:JSONEncode(Spill2.V138)
																end
															end
														end
													end
												end
											end
										end
									end
								else
									Spill2.V142 = typeof(V33)
									if Spill2.V142 ~= "table" then
										V95 = Spill2.V142
									else
										Spill2.V143 = V33[1]
										Spill2.V119 = V33[2]
										Spill2.V120 = V33[3]
										V95 = ("%*/%*/%*"):format(Spill2.V143, Spill2.V119, Spill2.V120)
									end
									V91 = 22
									V92 = 1
									V93 = V111
									V94 = V112
								end
							end
							V33 = nil
						end
					else
						V111 = pcall
						V112 = T4[1]
						V112 = V112[2]
						V111, V112 = V111(V112, V103)
						if V111 ~= true or V112 ~= 0 or Fn5(V32) ~= "table" or not (V32[1] == 7 or V32[1] == 9) or V32[2] ~= true then
							Spill2.V144 = typeof(V32)
							if Spill2.V144 ~= "table" then
								V95 = Spill2.V144
							else
								Spill2.V145 = V32[1]
								Spill2.V119 = V32[2]
								Spill2.V120 = V32[3]
								V95 = ("%*/%*/%*"):format(Spill2.V145, Spill2.V119, Spill2.V120)
							end
							V91 = 22
							V92 = 0
							V93 = V111
							V94 = V112
						else
							Spill2.V119 = V32[3]
							if Spill2.V119 == V102 then
								if Spill2.V138[1][1] or Spill2.V138[2][1] ~= Game or Spill2.V138[2][2] or type(Spill2.V138[3][1]) ~= "userdata" or Spill2.V138[3][2] ~= "GetChildren" then
									V91 = 23
									V92 = 0
									V93 = HttpService:JSONEncode(Spill2.V138)
								else
									Spill2.V119 = Spill2.V138[3]
									Spill2.V119 = Spill2.V119[3]
									if Spill2.V119 then
										V91 = 23
										V92 = 0
										V93 = HttpService:JSONEncode(Spill2.V138)
									else
										Spill2.V119 = Spill2.V138[4]
										Spill2.V119 = Spill2.V119[1]
										Spill2.V120 = Game
										if Spill2.V119 ~= Spill2.V120 then
											V91 = 23
											V92 = 0
											V93 = HttpService:JSONEncode(Spill2.V138)
										else
											Spill2.V124 = type
											Spill2.V125 = Spill2.V138[4]
											Spill2.V125 = Spill2.V125[2]
											Spill2.V124 = Spill2.V124(Spill2.V125)
											if Spill2.V124 ~= "userdata" then
												V91 = 23
												V92 = 0
												V93 = HttpService:JSONEncode(Spill2.V138)
											else
												Spill2.V125 = Spill2.V138[4]
												Spill2.V125 = Spill2.V125[3]
												if Spill2.V125 then
													V91 = 23
													V92 = 0
													V93 = HttpService:JSONEncode(Spill2.V138)
												else
													Spill2.V125 = typeof
													Spill2.V126 = Spill2.V138[5]
													Spill2.V126 = Spill2.V126[1]
													Spill2.V125 = Spill2.V125(Spill2.V126)
													if Spill2.V125 ~= "Instance" then
														V91 = 23
														V92 = 0
														V93 = HttpService:JSONEncode(Spill2.V138)
													else
														Spill2.V126 = Spill2.V138[5]
														Spill2.V126 = Spill2.V126[1]
														Spill2.V126 = Spill2.V126.ClassName
														if Spill2.V126 ~= "Model" then
															V91 = 23
															V92 = 0
															V93 = HttpService:JSONEncode(Spill2.V138)
														else
															Spill2.V127 = T3
															if not table.find(Spill2.V127, Spill2.V138[5][2]) or Spill2.V138[5][3] then
																V91 = 23
																V92 = 0
																V93 = HttpService:JSONEncode(Spill2.V138)
															else
																Spill2.V127 = Spill2.V138[6]
																Spill2.V127 = Spill2.V127[1]
																if typeof(Spill2.V127) ~= "Instance" then
																	V91 = 23
																	V92 = 0
																	V93 = HttpService:JSONEncode(Spill2.V138)
																else
																	Spill2.V127 = Spill2.V138[6]
																	Spill2.V127 = Spill2.V127[1]
																	Spill2.V127 = Spill2.V127.ClassName
																	if Spill2.V127 ~= "RemoteFunction" or (Spill2.V138[6][2] ~= "FireServer" or Spill2.V138[6][3] or Spill2.V138[7][1] ~= Spill2.V138[6][1] or Spill2.V138[7][2] ~= "InvokeServer" or Spill2.V138[7][3] or Spill2.V138[8][1] ~= Game or type(Spill2.V138[8][2]) ~= "userdata" or Spill2.V138[8][3]) then
																		V91 = 23
																		V92 = 0
																		V93 = HttpService:JSONEncode(Spill2.V138)
																	end
																end
															end
														end
													end
												end
											end
										end
									end
								end
							else
								Spill2.V144 = typeof(V32)
								if Spill2.V144 ~= "table" then
									V95 = Spill2.V144
								else
									Spill2.V145 = V32[1]
									Spill2.V119 = V32[2]
									Spill2.V120 = V32[3]
									V95 = ("%*/%*/%*"):format(Spill2.V145, Spill2.V119, Spill2.V120)
								end
								V91 = 22
								V92 = 0
								V93 = V111
								V94 = V112
							end
						end
						V32 = nil
					end
					V111 = table
					V111 = V111.clear
					V112 = Spill2.V138
					V111(V112)
					V27 = V101
				end
				V35 = 9
				V101 = Count2 % 60
				if V101 == 1 then
					V101 = 0
					V102 = nil
					Spill2.V146 = function()
						local V = V101[3]
						local V2 = V101[2]
						V[V2] = V[V2] + 1
						local V3, V4
						if V101 % 1000 ~= 0 then
							V3, V4 = pcall(V102)
							return V4, V3
						end
						task.wait()
						V3, V4 = pcall(V102)
						return V4, V3
					end
					V102 = Spill2.V146
					Spill2.V147, V103 = V102()
					Spill2.V148 = V103
					if Spill2.V148 ~= true then
						V91 = 2
						V92 = V101
						V93 = Spill2.V148
						V94 = Spill2.V147
					else
						V103 = Spill2.V147
						V111 = "^ReplicatedStorage%.Modules%.AssetContainer:%d+: stack overflow$"
						if not string.match(V103, V111) or V101 ~= 9997 then
							V91 = 2
							V92 = V101
							V93 = Spill2.V148
							V94 = Spill2.V147
						end
					end
				end
				V35 = 10
				V101 = xpcall
				V102 = error
				Spill2.V149 = function(Arg1)
					if Arg1 == nil then
						Fn12("bypass ", Enum.MessageType.MessageWarning, {})
						return
					end
					return 0
				end
				V101, V102 = V101(V102, Spill2.V149)
				Spill2.V150 = V101
				Spill2.V151 = V102
				if Spill2.V150 ~= false or Spill2.V151 ~= "error in error handling" then
					V91 = 3
					V92 = Spill2.V150
					V93 = Spill2.V151
				end
				V35 = 11
				V101 = Fn11
				V102 = math
				V102 = V102.random
				V103 = 255
				V101 = V101(V102(1, V103))
				V26 = V26 .. V101
				V102 = #V26
				Spill2.V152 = nil
				if V102 ~= 1 then
					if V102 ~= 2 then
						if V102 ~= 3 then
							if V102 ~= 4 then
								if V102 ~= 5 then
									if V102 ~= 6 then
										if V102 ~= 7 then
											if V102 ~= 8 then
												if V102 ~= 9 then
													if V102 ~= 10 then
														if V102 ~= 11 then
															if V102 ~= 12 then
																if V102 ~= 13 then
																	if V102 ~= 14 then
																		if V102 ~= 15 then
																			if V102 ~= 16 then
																				V103 = "%*"
																				Spill2.V153 = V103
																				V111 = Spill2.V153
																				V103 = Spill2.V153.format
																				V112 = V26
																				V103 = V103(V111, V112)
																				if V103 ~= V26 or (V102 <= 0 or 17 < V102) then
																					V103 = Fn12
																					V111 = "ALOOP4.%*"
																					Spill2.V154 = V111
																					V112 = Spill2.V154
																					V111 = Spill2.V154.format
																					V111 = V111(V112, V26)
																					V103(V111)
																				else
																					V111 = V102 % 1
																					if V111 == 0 then
																						V26 = ""
																					else
																						V103 = Fn12
																						V111 = "ALOOP4.%*"
																						Spill2.V154 = V111
																						V112 = Spill2.V154
																						V111 = Spill2.V154.format
																						V111 = V111(V112, V26)
																						V103(V111)
																					end
																				end
																			else
																				V103 = nil
																				V111 = HttpService
																				Spill2.V155 = V111
																				V112 = Spill2.V155
																				V111 = Spill2.V155.GenerateGUID
																				V111 = V111(V112, false)
																				Spill2.V156 = V111
																				V112 = Spill2.V156
																				V111 = Spill2.V156.upper
																				V111 = V111(V112)
																				Spill2.V157 = V111
																				V112 = Spill2.V157
																				V111 = Spill2.V157.gsub
																				V111 = V111(V112, "%-", "")
																				V112 = pcall
																				Spill2.V158 = function()
																					local V = V56
																					local function Fn(Arg1)
																						V103 = type(Arg1) == "table" and "table"
																						local Error = error
																						local V = ("%*\0"):format(V111)
																						Error(V)
																					end
																					return V(Fn, -3, T12)
																				end
																				V112, Spill2.V159 = V112(Spill2.V158)
																				if V112 ~= true or type(Spill2.V159) ~= "string" then
																					Spill2.V119 = V103
																					V92 = ("DEC2/%*/%*"):format(V112, Spill2.V119)
																					V91 = 5
																					V93 = Spill2.V159
																				else
																					Spill2.V119 = "^ReplicatedStorage%%.Modules%%.AssetContainer:%%d+: %*\0$"
																					Spill2.V160 = Spill2.V119
																					Spill2.V120 = Spill2.V160
																					Spill2.V119 = Spill2.V160.format
																					Spill2.V124 = V111
																					Spill2.V119 = Spill2.V119(Spill2.V120, Spill2.V124)
																					if not string.match(Spill2.V159, Spill2.V119) or V103 ~= "table" then
																						Spill2.V119 = V103
																						V92 = ("DEC2/%*/%*"):format(V112, Spill2.V119)
																						V91 = 5
																						V93 = Spill2.V159
																					end
																				end
																			end
																		else
																			V103 = 0
																			V111 = V56
																			V112 = task
																			V112 = V112.wait
																			V111 = V111(V112)
																			V112 = V56
																			Spill2.V161 = function()
																				V103 = nil
																			end
																			Spill2.V119 = Spill2.V161
																			V112 = V112(string.gsub, 0, " ", ".", Spill2.V119)
																			if not string.match(V111, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: attempt to perform arithmetic %(add%) on n%l+[rl] and n%l+[rl]$") or V112 ~= "stack overflow" or V103 ~= 0 then
																				V92 = ("DEC1/%*/%*"):format(V112, V103)
																				V91 = 5
																				V93 = V111
																			end
																		end
																	else
																		V103 = V56
																		V111 = os
																		V111 = V111.clock
																		V112 = 0
																		V103 = V103(V111, V112)
																		Spill2.V152 = V103
																	end
																else
																	V103 = V56
																	V111 = pcall
																	V112 = -1
																	V103 = V103(V111, V112, error, "")
																	if V103 ~= "error in error handling" then
																		V91 = 4
																		V92 = V103
																	end
																end
															else
																V103 = V56
																V111 = V55
																V112 = -2
																V103 = V103(V111, V112, "", V28, {})
																Spill2.V152 = V103
															end
														else
															V103 = V56
															V111 = setmetatable
															V112 = 0
															V103 = V103(V111, V112, {}, {})
															Spill2.V152 = V103
														end
													else
														V103 = V56
														V111 = collectgarbage
														V112 = 0
														V103 = V103(V111, V112, "count\0")
														Spill2.V152 = V103
													end
												else
													V103 = V56
													V111 = string
													V111 = V111.match
													V112 = 0
													V103 = V103(V111, V112, "", "")
													Spill2.V152 = V103
												end
											else
												V103 = V56
												V111 = coroutine
												V111 = V111.create
												V112 = 0
												Spill2.V162 = function()
													Fn2()
												end
												V103 = V103(V111, V112, Spill2.V162)
												Spill2.V152 = V103
											end
										else
											V103 = V56
											V111 = table
											V111 = V111.maxn
											V112 = 0
											V103 = V103(V111, V112, V43)
											Spill2.V152 = V103
										end
									else
										V103 = V56
										V111 = table
										V111 = V111.insert
										V112 = 0
										V103 = V103(V111, V112, {}, 0)
										Spill2.V152 = V103
									end
								else
									V103 = V56
									V111 = buffer
									V111 = V111.writestring
									V112 = 0
									V103 = V103(V111, V112, V42, 0, V101)
									Spill2.V152 = V103
								end
							else
								V103 = V56
								V111 = debug
								V111 = V111.info
								V112 = 0
								Spill2.V119 = 2
								if V25:NextInteger(1, Spill2.V119) ~= 1 then
									Spill2.V163 = "f"
								else
									Spill2.V163 = "slfna"
								end
								V103 = V103(V111, V112, 2, Spill2.V163)
								Spill2.V152 = V103
							end
						else
							V103 = V56
							V111 = getfenv
							V112 = 0
							V103 = V103(V111, V112)
							Spill2.V152 = V103
						end
					else
						V103 = V56
						V111 = Fn17
						V112 = -1
						V103 = V103(V111, V112)
						Spill2.V152 = V103
					end
				else
					V103 = V56
					V111 = task
					V111 = V111.wait
					V112 = 0
					V103 = V103(V111, V112)
					Spill2.V152 = V103
				end
				if Spill2.V152 then
					V92 = #V26
					V91 = 6
					V93 = Spill2.V152
				end
				V35 = 12
				if 10 <= Count then
					V103 = pcall
					V111 = MarketplaceService.PromptThirdPartyPurchase
					V112 = MarketplaceService
					V103, V111 = V103(V111, V112, LocalPlayer, "")
					if V103 ~= false or V111 ~= "The current thread cannot call 'PromptThirdPartyPurchase' (lacking capability LocalUser)" then
						V112 = Fn12
						Spill2.V164 = ("ALOOP7.%*.%*"):format(V103, V111)
						V112(Spill2.V164)
					end
				end
				V111 = pcall
				V112 = V55
				V103 = {V111(V112, "bypass ", Enum.MessageType.MessageWarning, {})}
				V111 = type
				V112 = V103
				V111 = V111(V112)
				if V111 ~= "table" then
					V111 = Fn12
					V112 = "ALOOP8.%*.%*.%*.%*.%*.%*"
					Spill2.V165 = V112
					V112 = Spill2.V165.format
					Spill2.V166 = V103[1]
					Spill2.V167 = V103[2]
					Spill2.V168 = V103[3]
					Spill2.V119 = V103[4]
					Spill2.V120 = V103[5]
					Spill2.V124 = V103[6]
					V112 = V112(Spill2.V165, Spill2.V166, Spill2.V167, Spill2.V168, Spill2.V119, Spill2.V120, Spill2.V124)
					V111(V112)
				else
					V112 = V103[1]
					if V112 ~= true or type(V103[2]) ~= "table" or V103[3] ~= "bypass " or V103[4] ~= "MessageWarning" or V103[5] ~= "116" then
						V111 = Fn12
						V112 = "ALOOP8.%*.%*.%*.%*.%*.%*"
						Spill2.V165 = V112
						V112 = Spill2.V165.format
						Spill2.V166 = V103[1]
						Spill2.V167 = V103[2]
						Spill2.V168 = V103[3]
						Spill2.V119 = V103[4]
						Spill2.V120 = V103[5]
						Spill2.V124 = V103[6]
						V112 = V112(Spill2.V165, Spill2.V166, Spill2.V167, Spill2.V168, Spill2.V119, Spill2.V120, Spill2.V124)
						V111(V112)
					else
						Spill2.V119 = V103[6]
						if Spill2.V119 ~= 0 then
							V111 = Fn12
							V112 = "ALOOP8.%*.%*.%*.%*.%*.%*"
							Spill2.V165 = V112
							V112 = Spill2.V165.format
							Spill2.V166 = V103[1]
							Spill2.V167 = V103[2]
							Spill2.V168 = V103[3]
							Spill2.V119 = V103[4]
							Spill2.V120 = V103[5]
							Spill2.V124 = V103[6]
							V112 = V112(Spill2.V165, Spill2.V166, Spill2.V167, Spill2.V168, Spill2.V119, Spill2.V120, Spill2.V124)
							V111(V112)
						end
					end
				end
				V111 = table
				V111 = V111.clear
				V112 = V103
				V111(V112)
				V35 = 13
				V111 = V22
				if not V111 then
					V111 = task
					V111 = V111.delay
					V112 = 3
					Spill2.V169 = function()
						if not V39 then
							Fn2()
						else
							V70 = true
						end
					end
					V111(V112, Spill2.V169)
				else
					V111 = V22.Parent
					V112 = NetworkClient
					if V111 ~= V112 or not NetworkClient:FindFirstChildWhichIsA("ClientReplicator") or not table.find(NetworkClient:GetChildren(), V22) or V22:GetPlayer() ~= LocalPlayer then
						V111 = task
						V111 = V111.delay
						V112 = 3
						Spill2.V169 = function()
							if not V39 then
								Fn2()
							else
								V70 = true
							end
						end
						V111(V112, Spill2.V169)
					end
				end
				V35 = 14
				V111 = os
				V111 = V111.clock
				V111 = V111()
				V112 = 1
				for Index3 = V112, 6 do
					Spill2.V119 = V111 - V47[Index3]
					if not (Spill2.V119 < 600) then
						Spill2.V120 = math
						Spill2.V120 = Spill2.V120.ceil
						Spill2.V124 = Spill2.V119
						Spill2.V120 = Spill2.V120(Spill2.V124)
						V91 = 17
						V92 = Index3
						V93 = Spill2.V120
					end
				end
				if V91 ~= nil then
					V112 = {78 + V91}
					V111 = {V112, V92, V93, V94, V95}
					V45 = V111
				end
				V35 = 15
				V111 = V37
				if V111 then
					V111 = Game
					Spill2.V170 = V111
					V112 = Spill2.V170
					V111 = Spill2.V170.FindService
					V111 = V111(V112, "AppUpdateService\0")
					if not V111 then
						V111 = Game
						Spill2.V171 = V111
						V112 = Spill2.V171
						V111 = Spill2.V171.FindService
						V111 = V111(V112, "AccountService\0")
						if not V111 then
							V111 = Game
							Spill2.V172 = V111
							V112 = Spill2.V172
							V111 = Spill2.V172.FindService
							V111 = V111(V112, "DataModelPatchService\0")
							if not V111 then
								V111 = Game
								Spill2.V173 = V111
								V112 = Spill2.V173
								V111 = Spill2.V173.FindService
								V111 = V111(V112, "OmniRecommendationsService\0")
								if not V111 then
									V111 = Game
									Spill2.V174 = V111
									V112 = Spill2.V174
									V111 = Spill2.V174.FindService
									V111 = V111(V112, "UGCValidationService\0")
									if not V111 then
										V111 = Game
										Spill2.V175 = V111
										V112 = Spill2.V175
										V111 = Spill2.V175.FindService
										V111 = V111(V112, "HttpService\0")
										if not V111 then
											V112 = "%*%*"
											Spill2.V176 = V112
											V112 = Spill2.V176.format
											V112 = V112(Spill2.V176, 9, 9)
											V111 = {V112, 5}
											V6 = V111
										end
									else
										V112 = "%*%*"
										Spill2.V177 = V112
										V112 = Spill2.V177.format
										V112 = V112(Spill2.V177, 9, 9)
										V111 = {V112, 4}
										V6 = V111
									end
								else
									V112 = "%*%*"
									Spill2.V178 = V112
									V112 = Spill2.V178.format
									V112 = V112(Spill2.V178, 9, 9)
									V111 = {V112, 3}
									V6 = V111
								end
							else
								V112 = "%*%*"
								Spill2.V179 = V112
								V112 = Spill2.V179.format
								V112 = V112(Spill2.V179, 9, 9)
								V111 = {V112, 2}
								V6 = V111
							end
						else
							V112 = "%*%*"
							Spill2.V180 = V112
							V112 = Spill2.V180.format
							V112 = V112(Spill2.V180, 9, 9)
							V111 = {V112, 1}
							V6 = V111
						end
					else
						V112 = "%*%*"
						Spill2.V181 = V112
						V112 = Spill2.V181.format
						V112 = V112(Spill2.V181, 9, 9)
						V111 = {V112, 0}
						V6 = V111
					end
				end
				V35 = 16
				V111 = math
				V111 = V111.random
				V112 = 1
				V111 = V111(V112, 100)
				V112 = type
				V112 = V112(T9[V111])
				if V112 ~= "table" or (T9[V111] == T9[V111 + 1] or T9._ ~= nil) then
					V112 = {103, 4}
					V6 = V112
				end
				V112 = V8
				if not V112 then
					V112 = Fn38
					V112 = V112(BillboardGui, false)
					Spill2.V182 = type(V8)
					if V112 ~= nil or Spill2.V182 ~= "table" or V8[1] ~= 2 or V8[2] ~= "BillboardGui" then
						Spill2.V119 = Spill2.V182
						V6 = {106, 2, Spill2.V119}
					else
						Spill2.V183 = V8[3]
						Spill2.V119 = V8[2]
						if Spill2.V183 ~= Spill2.V119 then
							Spill2.V119 = Spill2.V182
							V6 = {106, 2, Spill2.V119}
						else
							Spill2.V120 = V8[4]
							if Spill2.V120 ~= false then
								Spill2.V119 = Spill2.V182
								V6 = {106, 2, Spill2.V119}
							end
						end
					end
					table.clear(V8)
					V8 = nil
				end
				V112 = V8
				if not V112 then
					V112 = Fn38
					V112 = V112(Workspace, true)
					if V112 ~= nil or V8 ~= nil then
						Spill2.V184 = {}
						Spill2.V119 = V8
						do
							local packed = table.pack(106, 3, type(Spill2.V119))
							table.move(packed, 1, packed.n, 1, Spill2.V184)
						end
						V6 = Spill2.V184
					end
					V8 = nil
				end
				V112 = false
				Spill2.V185 = pcall
				Spill2.V186 = setmetatable
				Spill2.V187 = {}
				Spill2.V188 = function()
					V112 = nil
					_[1] = true
				end
				Spill2.V120 = Spill2.V188
				Spill2.V119 = {__index = Spill2.V120}
				Spill2.V189, Spill2.V190 = Spill2.V185(Fn38, Spill2.V186(Spill2.V187, Spill2.V119), true)
				if V112 ~= nil or Spill2.V189 ~= false then
					Spill2.V119 = 4
					Spill2.V120 = Spill2.V190
					V6 = {106, Spill2.V119, Spill2.V120}
				else
					Spill2.V119 = "^ReplicatedStorage%.Modules%.AssetContainer:%d+: attempt to index nil with number$"
					if not string.match(Spill2.V190, Spill2.V119) then
						Spill2.V119 = 4
						Spill2.V120 = Spill2.V190
						V6 = {106, Spill2.V119, Spill2.V120}
					end
				end
				if not V8 then
					Spill2.V119 = 2
					Spill2.V191 = {Spill2.V119}
					V8 = Spill2.V191
					Spill2.V119 = V8
					if Spill2.V119 ~= Spill2.V191 then
						Spill2.V119 = FireServer
						Spill2.V120 = V29
						Spill2.V124 = V30
						Spill2.V125 = nil
						Spill2.V126 = 1
						Spill2.V127 = 1
						Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
					else
						Spill2.V120 = type
						Spill2.V124 = V8
						Spill2.V120 = Spill2.V120(Spill2.V124)
						if Spill2.V120 ~= "table" then
							Spill2.V119 = FireServer
							Spill2.V120 = V29
							Spill2.V124 = V30
							Spill2.V125 = nil
							Spill2.V126 = 1
							Spill2.V127 = 1
							Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
						else
							Spill2.V124 = V8[1]
							if Spill2.V124 ~= 2 then
								Spill2.V119 = FireServer
								Spill2.V120 = V29
								Spill2.V124 = V30
								Spill2.V125 = nil
								Spill2.V126 = 1
								Spill2.V127 = 1
								Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
							end
						end
					end
					Spill2.V119 = {}
					Spill2.V192 = Spill2.V119
					V8 = Spill2.V192
					Spill2.V119 = V8
					if Spill2.V119 ~= Spill2.V192 then
						Spill2.V119 = FireServer
						Spill2.V120 = V29
						Spill2.V124 = V30
						Spill2.V125 = nil
						Spill2.V126 = 1
						Spill2.V127 = 2
						Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
					else
						Spill2.V120 = V8
						Spill2.V120 = #Spill2.V120
						if Spill2.V120 ~= 0 then
							Spill2.V119 = FireServer
							Spill2.V120 = V29
							Spill2.V124 = V30
							Spill2.V125 = nil
							Spill2.V126 = 1
							Spill2.V127 = 2
							Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
						end
					end
					Spill2.V120 = math
					Spill2.V120 = Spill2.V120.random
					Spill2.V124 = 1
					Spill2.V125 = 10
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125)
					Spill2.V124 = Random
					Spill2.V124 = Spill2.V124.new
					Spill2.V124 = Spill2.V124()
					Spill2.V193 = Spill2.V124
					Spill2.V125 = Spill2.V193
					Spill2.V124 = Spill2.V193.NextNumber
					Spill2.V126 = 0
					Spill2.V119 = {Spill2.V120, Spill2.V124(Spill2.V125, Spill2.V126, 10)}
					Spill2.V120 = math
					Spill2.V120 = Spill2.V120.random
					Spill2.V124 = 1
					Spill2.V125 = 20
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125)
					if Spill2.V120 == 1 then
						Spill2.V120 = table
						Spill2.V120 = Spill2.V120.insert
						Spill2.V124 = Spill2.V119
						Spill2.V125 = math
						Spill2.V125 = Spill2.V125.random
						Spill2.V126 = 6
						Spill2.V120(Spill2.V124, Spill2.V125(Spill2.V126, 7))
					end
					Spill2.V120 = setmetatable
					Spill2.V124 = Spill2.V119
					Spill2.V194 = function(Arg1)
						V74 = true
						return rawlen(Arg1)
					end
					Spill2.V126 = Spill2.V194
					Spill2.V125 = {__len = Spill2.V126}
					Spill2.V195 = function(Arg1, Arg2)
						V74 = true
						return rawget(Arg1, Arg2)
					end
					Spill2.V126 = Spill2.V195
					Spill2.V125.__index = Spill2.V126
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125)
					V8 = Spill2.V120
					Spill2.V124 = setmetatable
					Spill2.V125 = Spill2.V119
					Spill2.V196 = function(Arg1)
						V75 = true
						return next, Arg1
					end
					Spill2.V126 = {__iter = Spill2.V196}
					Spill2.V124 = Spill2.V124(Spill2.V125, Spill2.V126)
					V8 = Spill2.V124
					Spill2.V126 = {7, n = 1}
					Spill2.V197 = Random.new()
					Spill2.V127 = Spill2.V197
					Spill2.V125 = {Spill2.V126, Spill2.V197.NextNumber(Spill2.V127, 100, 120.2)}
					V8 = Spill2.V125
					Spill2.V126 = type
					Spill2.V126 = Spill2.V126(V8)
					V76 = if Spill2.V126 ~= "table" or V8 ~= Spill2.V125 then true else V76
					Spill2.V126 = {V34}
					V8 = Spill2.V126
					V8 = nil
				end
				if not V45 then
					Spill2.V119 = 1
					Spill2.V120 = 255
					Spill2.V198 = math.random(Spill2.V119, Spill2.V120)
					Spill2.V120 = {}
					Spill2.V124 = math
					Spill2.V124 = Spill2.V124.random
					Spill2.V125 = 1
					Spill2.V126 = 100
					do
						local packed = table.pack(Spill2.V124(Spill2.V125, Spill2.V126))
						table.move(packed, 1, packed.n, 1, Spill2.V120)
					end
					Spill2.V124 = "%*"
					Spill2.V199 = Spill2.V124
					Spill2.V125 = Spill2.V199
					Spill2.V124 = Spill2.V199.format
					Spill2.V126 = Spill2.V198 + 1
					Spill2.V124 = Spill2.V124(Spill2.V125, Spill2.V126)
					Spill2.V119 = {Spill2.V120, Spill2.V124}
					V45 = Spill2.V119
					Spill2.V120 = V45
					if Spill2.V120 ~= Spill2.V119 then
						Spill2.V120 = FireServer
						Spill2.V124 = V29
						Spill2.V125 = V30
						Spill2.V126 = nil
						Spill2.V127 = 6
						Spill2.V120(Spill2.V124, Spill2.V125, Spill2.V126, 1, Spill2.V127, 3)
					else
						Spill2.V124 = type
						Spill2.V125 = V45
						Spill2.V124 = Spill2.V124(Spill2.V125)
						if Spill2.V124 ~= "table" then
							Spill2.V120 = FireServer
							Spill2.V124 = V29
							Spill2.V125 = V30
							Spill2.V126 = nil
							Spill2.V127 = 6
							Spill2.V120(Spill2.V124, Spill2.V125, Spill2.V126, 1, Spill2.V127, 3)
						else
							Spill2.V125 = type
							Spill2.V126 = V45[1]
							Spill2.V125 = Spill2.V125(Spill2.V126)
							if Spill2.V125 ~= "table" then
								Spill2.V120 = FireServer
								Spill2.V124 = V29
								Spill2.V125 = V30
								Spill2.V126 = nil
								Spill2.V127 = 6
								Spill2.V120(Spill2.V124, Spill2.V125, Spill2.V126, 1, Spill2.V127, 3)
							else
								Spill2.V126 = V45[2]
								Spill2.V200 = "%*"
								Spill2.V127 = Spill2.V200
								if Spill2.V126 ~= Spill2.V200.format(Spill2.V127, Spill2.V198 + 1) then
									Spill2.V120 = FireServer
									Spill2.V124 = V29
									Spill2.V125 = V30
									Spill2.V126 = nil
									Spill2.V127 = 6
									Spill2.V120(Spill2.V124, Spill2.V125, Spill2.V126, 1, Spill2.V127, 3)
								end
							end
						end
					end
					V45 = nil
				end
				if V68 then
					Spill2.V119 = V6
					if Spill2.V119 ~= false then
						Spill2.V120 = type
						Spill2.V124 = V6
						Spill2.V120 = Spill2.V120(Spill2.V124)
						if Spill2.V120 ~= "table" then
							Spill2.V124 = V7
						end
					end
				end
				Spill2.V119 = V6
				if not Spill2.V119 then
					Spill2.V120 = "%*"
					Spill2.V201 = Spill2.V120
					Spill2.V124 = Spill2.V201
					Spill2.V120 = Spill2.V201.format
					Spill2.V125 = math
					Spill2.V125 = Spill2.V125.random
					Spill2.V126 = 1
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125(Spill2.V126, 99))
					Spill2.V124 = 7
					Spill2.V119 = {Spill2.V120, Spill2.V124}
					Spill2.V120 = math
					Spill2.V120 = Spill2.V120.random
					Spill2.V124 = 1
					Spill2.V125 = 20
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125)
					if Spill2.V120 == 1 then
						Spill2.V120 = table
						Spill2.V120 = Spill2.V120.insert
						Spill2.V124 = Spill2.V119
						Spill2.V125 = true
						Spill2.V120(Spill2.V124, Spill2.V125)
					end
					Spill2.V120 = setmetatable
					Spill2.V124 = Spill2.V119
					Spill2.V202 = function(Arg1)
						V77 = true
						return rawlen(Arg1)
					end
					Spill2.V126 = Spill2.V202
					Spill2.V125 = {__len = Spill2.V126}
					Spill2.V203 = function(Arg1, Arg2)
						V77 = true
						return rawget(Arg1, Arg2)
					end
					Spill2.V126 = Spill2.V203
					Spill2.V125.__index = Spill2.V126
					Spill2.V120 = Spill2.V120(Spill2.V124, Spill2.V125)
					V6 = Spill2.V120
					Spill2.V124 = setmetatable
					Spill2.V125 = Spill2.V119
					Spill2.V204 = function(_)
					end
					Spill2.V126 = {__iter = Spill2.V204}
					Spill2.V124 = Spill2.V124(Spill2.V125, Spill2.V126)
					V6 = Spill2.V124
					Spill2.V126 = {7, n = 1}
					Spill2.V205 = Random.new()
					Spill2.V127 = Spill2.V205
					Spill2.V125 = {Spill2.V126, Spill2.V205.NextNumber(Spill2.V127, 100, 120.2)}
					V6 = Spill2.V125
					Spill2.V126 = type
					Spill2.V126 = Spill2.V126(V6)
					V76 = if Spill2.V126 ~= "table" or V6 ~= Spill2.V125 then true else V76
					Spill2.V126 = {V34}
					V6 = Spill2.V126
					Spill2.V206 = ""
					Spill2.V127 = 1
					for Index4 = Spill2.V127, math.random(1, 100) do
						Spill2.V206 = Spill2.V206 .. string.char(math.random(1, 255))
					end
					Spill2.V127 = {"2", Spill2.V206}
					V6 = Spill2.V127
					if V6 ~= Spill2.V127 or type(V6) ~= "table" or V6[1] ~= "2" or V6[2] ~= Spill2.V206 then
						FireServer(V29, V30, nil, 1, 6, 4)
					end
					V6 = false
					if V6 ~= false then
						FireServer(V29, V30, nil, 1, 6, 5)
					end
					V6 = nil
				end
				if not V74 then
					if not V75 then
						if not V76 then
							if not V77 then
								if not V78 then
									if V79 then
										Spill2.V119 = FireServer
										Spill2.V120 = V29
										Spill2.V124 = V30
										Spill2.V125 = nil
										Spill2.V126 = 1
										Spill2.V127 = 15
										Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
									end
								else
									Spill2.V119 = FireServer
									Spill2.V120 = V29
									Spill2.V124 = V30
									Spill2.V125 = nil
									Spill2.V126 = 1
									Spill2.V127 = 14
									Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
								end
							else
								Spill2.V119 = FireServer
								Spill2.V120 = V29
								Spill2.V124 = V30
								Spill2.V125 = nil
								Spill2.V126 = 1
								Spill2.V127 = 13
								Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
							end
						else
							Spill2.V119 = FireServer
							Spill2.V120 = V29
							Spill2.V124 = V30
							Spill2.V125 = nil
							Spill2.V126 = 1
							Spill2.V127 = 12
							Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
						end
					else
						Spill2.V119 = FireServer
						Spill2.V120 = V29
						Spill2.V124 = V30
						Spill2.V125 = nil
						Spill2.V126 = 1
						Spill2.V127 = 11
						Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
					end
				else
					Spill2.V119 = FireServer
					Spill2.V120 = V29
					Spill2.V124 = V30
					Spill2.V125 = nil
					Spill2.V126 = 1
					Spill2.V127 = 10
					Spill2.V119(Spill2.V120, Spill2.V124, Spill2.V125, Spill2.V126, 6, Spill2.V127)
				end
				Spill2.V119 = V45
				Spill2.V119 = nil
				Spill2.V120 = false
				Spill2.V124 = nil
				Spill2.V125 = false
				Spill2.V126 = false
				Spill2.V207 = {}
				Spill2.V127 = nil
				Spill2.V208 = function(Arg1, Arg2)
					if not rawequal(Arg1, Spill2.V127) or Arg2 ~= 3 or Spill2.V119 ~= nil then
						Spill2.V119 = true
						return rawget(Arg1, Arg2)
					end
					Spill2.V119 = false
					return 0
				end
				Spill2.V209 = {__index = Spill2.V208}
				Spill2.V210 = function(Arg1, Arg2, Arg3)
					Spill2.V120 = true
					rawset(Arg1, Arg2, Arg3)
				end
				Spill2.V209.__newindex = Spill2.V210
				Spill2.V211 = function()
					if Spill2.V124 ~= nil then
						Spill2.V124 = true
					else
						Spill2.V124 = false
					end
					return rawlen(Spill2.V127)
				end
				Spill2.V209.__len = Spill2.V211
				Spill2.V212 = function()
					Spill2.V125 = true
					return tostring(Spill2.V207)
				end
				Spill2.V209.__tostring = Spill2.V212
				Spill2.V213 = function(Arg1)
					Spill2.V126 = true
					return next, Arg1
				end
				Spill2.V209.__iter = Spill2.V213
				Spill2.V214 = {2}
				Spill2.V127 = setmetatable({Spill2.V214, 0}, Spill2.V209)
				V45 = Spill2.V127
				if V45 ~= Spill2.V127 or (#V45 ~= 2 or V45[3] ~= 0) then
					FireServer(V29, V30, nil, 1, 6, 6)
				end
				Spill2.V215 = getmetatable(V45)
				if Spill2.V215 ~= Spill2.V209 or Spill2.V215.__index ~= Spill2.V208 then
					FireServer(V29, V30, nil, 1, 6, 7)
				end
				setmetatable(V45, nil)
				table.clear(Spill2.V215)
				if V45[2] ~= 0 or V45[3] ~= nil or #V45 ~= 2 or getmetatable(V45) ~= nil or Spill2.V214[1] ~= 2 then
					FireServer(V29, V30, nil, 1, 6, 8)
				end
				Spill2.V216 = "%*%*%*%*%*"
				Spill2.V217 = Spill2.V216.format
				if Spill2.V119 ~= false then
					Spill2.V218 = 1
				else
					Spill2.V218 = 0
				end
				if Spill2.V120 ~= false then
					Spill2.V219 = 1
				else
					Spill2.V219 = 0
				end
				if Spill2.V124 ~= false then
					Spill2.V220 = 1
				else
					Spill2.V220 = 0
				end
				if Spill2.V125 ~= false then
					Spill2.V221 = 1
				else
					Spill2.V221 = 0
				end
				if Spill2.V126 ~= false then
					Spill2.V222 = 1
				else
					Spill2.V222 = 0
				end
				Spill2.V223 = Spill2.V217(Spill2.V216, Spill2.V218, Spill2.V219, Spill2.V220, Spill2.V221, Spill2.V222)
				if Spill2.V223 ~= "00000" then
					FireServer(V29, V30, nil, 1, 6, 9, Spill2.V223)
				end
				Spill2.V224 = ("%*"):format(math.random(6, 8))
				Spill2.V225 = {
					{Spill2.V224},
					false,
				}
				Spill2.V226 = setmetatable
				Spill2.V227 = function(Arg1)
					V79 = true
					return rawlen(Arg1)
				end
				Spill2.V228 = {__len = Spill2.V227}
				Spill2.V229 = function(Arg1, Arg2)
					V79 = true
					return rawget(Arg1, Arg2)
				end
				Spill2.V228.__index = Spill2.V229
				V45 = Spill2.V226(Spill2.V225, Spill2.V228)
				Spill2.V230 = setmetatable
				Spill2.V231 = function(Arg1)
					V78 = true
					return next, Arg1
				end
				V45 = Spill2.V230(Spill2.V225, {__iter = Spill2.V231})
				Spill2.V232 = {
					{7, n = 1},
					Random.new():NextNumber(100, 120.2),
				}
				V45 = Spill2.V232
				if type(V45) ~= "table" or V45 ~= Spill2.V232 then
					V76 = true
				end
				V45 = {Fn19({3})}
				V45 = nil
				V35 = 17
				Spill2.V119 = Workspace
				Spill2.V233 = Spill2.V119
				Spill2.V120 = Spill2.V233
				Spill2.V119 = Spill2.V233.FindFirstChildOfClass
				Spill2.V124 = "Terrain"
				Spill2.V119 = Spill2.V119(Spill2.V120, Spill2.V124)
				if not Spill2.V119 then
					V73 = 0
				else
					Spill2.V119 = V23
					if Spill2.V119 then
						V73 = 0
					else
						V73 = V73 + 1
						if 5 <= V73 then
							V73 = 0
							Spill2.V119 = Fn12
							Spill2.V120 = "ALOOP9"
							Spill2.V119(Spill2.V120)
						end
					end
				end
				Spill2.V119 = VMs
				Spill2.V119 = workspace
				Spill2.V234 = Spill2.V119
				Spill2.V120 = Spill2.V234
				Spill2.V119 = Spill2.V234.GetChildren
				Spill2.V119, Spill2.V120, Spill2.V124 = Spill2.V119(Spill2.V120)
				V21, V24, V20 = Spill2.V119, Spill2.V120, Spill2.V124
				if type(V21) == "table" then
					V21, V24, V20 = next, V21, nil
				end
				Spill2.V235, Spill2.V236, Spill2.V237 = (nil)()
				if Spill2.V235 then
					Spill2.V120 = Spill2.V236
					Spill2.V124 = Spill2.V237
					Spill2.V125 = Spill2.V124.Name
					if Spill2.V125 ~= "Model" then
						Spill2.V238 = Spill2.V124
						Spill2.V126 = Spill2.V238.IsA
						Spill2.V127 = "Beam"
						Spill2.V126 = Spill2.V126(Spill2.V238, Spill2.V127)
						if not Spill2.V126 then
							Spill2.V126 = Spill2.V124.ClassName
							if Spill2.V126 ~= "Part" then
								if Spill2.V124.Name ~= "TracerModel" or not Spill2.V124:FindFirstChildWhichIsA("Beam") then
									Spill2.V239 = Spill2.V124.Name
									Spill2.V124:FindFirstChildWhichIsA("Attachment")
								end
							elseif Spill2.V124.Name ~= "Anchor" then
								Spill2.V127 = Spill2.V124.Name
								if Spill2.V127 ~= "purple" and (Spill2.V124.Name ~= "TracerModel" or not Spill2.V124:FindFirstChildWhichIsA("Beam")) then
									Spill2.V239 = Spill2.V124.Name
									Spill2.V124:FindFirstChildWhichIsA("Attachment")
								end
							end
						end
					else
						Spill2.V240 = Spill2.V124
						Spill2.V126 = Spill2.V240.FindFirstChildWhichIsA
						Spill2.V127 = "Attachment"
						Spill2.V126 = Spill2.V126(Spill2.V240, Spill2.V127)
						if not Spill2.V126 then
							Spill2.V238 = Spill2.V124
							Spill2.V126 = Spill2.V238.IsA
							Spill2.V127 = "Beam"
							Spill2.V126 = Spill2.V126(Spill2.V238, Spill2.V127)
							if not Spill2.V126 then
								Spill2.V126 = Spill2.V124.ClassName
								if Spill2.V126 ~= "Part" then
									if Spill2.V124.Name ~= "TracerModel" or not Spill2.V124:FindFirstChildWhichIsA("Beam") then
										Spill2.V239 = Spill2.V124.Name
										Spill2.V124:FindFirstChildWhichIsA("Attachment")
									end
								elseif Spill2.V124.Name ~= "Anchor" then
									Spill2.V127 = Spill2.V124.Name
									if Spill2.V127 ~= "purple" and (Spill2.V124.Name ~= "TracerModel" or not Spill2.V124:FindFirstChildWhichIsA("Beam")) then
										Spill2.V239 = Spill2.V124.Name
										Spill2.V124:FindFirstChildWhichIsA("Attachment")
									end
								end
							end
						end
					end
					Spill2.V125 = FireServer
					Spill2.V126 = V29
					Spill2.V127 = nil
					Spill2.V125(Spill2.V126, V30, Spill2.V127, 1, 7, 5)
				end
				Spill2.V119 = ReplicatedStorage.ClientSignals
				Spill2.V241 = Spill2.V119
				Spill2.V120 = Spill2.V241
				Spill2.V119 = Spill2.V241.GetChildren
				Spill2.V119, Spill2.V120, Spill2.V124 = Spill2.V119(Spill2.V120)
				V21, V24, V20 = Spill2.V119, Spill2.V120, Spill2.V124
				if type(V21) == "table" then
					V21, V24, V20 = next, V21, nil
				end
				while true do
					Spill2.V242, Spill2.V243, Spill2.V244 = (nil)()
					if not Spill2.V242 then
						break
					end
					Spill2.V120 = Spill2.V243
					Spill2.V124 = Spill2.V244
					Spill2.V245 = Spill2.V124
					Spill2.V126 = Spill2.V245
					Spill2.V125 = Spill2.V245.IsA
					Spill2.V125 = Spill2.V125(Spill2.V126, "RemoteEvent")
					if Spill2.V125 then
						continue
					end
					Spill2.V246 = Spill2.V124
					Spill2.V126 = Spill2.V246
					Spill2.V125 = Spill2.V246.IsA
					Spill2.V125 = Spill2.V125(Spill2.V126, "UnreliableRemoteEvent")
					if not Spill2.V125 then
						Spill2.V125 = FireServer
						Spill2.V126 = V29
						Spill2.V127 = nil
						Spill2.V125(Spill2.V126, V30, Spill2.V127, 1, 7, 6)
					end
				end
				Spill2.V119 = Fn4
				Spill2.V120 = Count + 1
				Spill2.V119 = Spill2.V119(Spill2.V120)
				if Spill2.V119 ~= "" then
					Spill2.V120 = Fn12
					Spill2.V124 = "ALOOP12.%*"
					Spill2.V247 = Spill2.V124
					Spill2.V125 = Spill2.V247
					Spill2.V124 = Spill2.V247.format
					Spill2.V126 = type
					Spill2.V124 = Spill2.V124(Spill2.V125, Spill2.V126(Spill2.V119))
					Spill2.V120(Spill2.V124)
				end
				Spill2.V120 = Fn17
				Spill2.V120 = Spill2.V120()
				if Spill2.V120 ~= V60 then
					Spill2.V124 = Fn12
					Spill2.V125 = "ALOOP12.%*"
					Spill2.V248 = Spill2.V125
					Spill2.V126 = Spill2.V248
					Spill2.V125 = Spill2.V248.format
					Spill2.V125 = Spill2.V125(Spill2.V126, Spill2.V120)
					Spill2.V124(Spill2.V125)
				end
				V35 = 18
				Spill2.V120 = FireServer
				Spill2.V124 = V29
				Spill2.V125 = V30
				Spill2.V126 = nil
				Spill2.V120(Spill2.V124, Spill2.V125, Spill2.V126, os.clock())
				V35 = 19
				Count = Count + 1
				Spill2.V120 = task
				Spill2.V120 = Spill2.V120.wait
				Spill2.V124 = 10
				Spill2.V120(Spill2.V124)
				V35 = 20
				Spill2.V120 = Script2
				Spill2.V120 = -Spill2.V120
				Spill2.V124 = rawequal
				Spill2.V125 = getfenv
				Spill2.V126 = 0
				Spill2.V125 = Spill2.V125(Spill2.V126)
				Spill2.V125 = Spill2.V125.script
				Spill2.V126 = Script2
				Spill2.V124 = Spill2.V124(Spill2.V125, Spill2.V126)
				Spill2.V125 = getmetatable
				Spill2.V126 = Script2
				Spill2.V125 = Spill2.V125(Spill2.V126)
				Spill2.V126 = rawequal
				Spill2.V127 = V80
				Spill2.V126 = Spill2.V126(Script2, Spill2.V127)
				if not Spill2.V126 then
					Spill2.V126 = Fn12
					Spill2.V249 = "ALOOP6.%*.%*.%*.%*.%*"
					Spill2.V127 = Spill2.V249
					Spill2.V250 = Spill2.V249.format(Spill2.V127, typeof(Script2), Spill2.V124, Spill2.V120, T2, Spill2.V125)
					Spill2.V126(Spill2.V250)
				else
					Spill2.V126 = Fn5
					Spill2.V126 = Spill2.V126(Script2)
					if Spill2.V126 ~= "table" or (not Spill2.V124 or Spill2.V125 ~= "The metatable is locked") then
						Spill2.V126 = Fn12
						Spill2.V249 = "ALOOP6.%*.%*.%*.%*.%*"
						Spill2.V127 = Spill2.V249
						Spill2.V250 = Spill2.V249.format(Spill2.V127, typeof(Script2), Spill2.V124, Spill2.V120, T2, Spill2.V125)
						Spill2.V126(Spill2.V250)
					else
						Spill2.V251 = "%*"
						Spill2.V127 = Spill2.V251
						if Spill2.V120 ~= Spill2.V251.format(Spill2.V127, T2) then
							Spill2.V126 = Fn12
							Spill2.V249 = "ALOOP6.%*.%*.%*.%*.%*"
							Spill2.V127 = Spill2.V249
							Spill2.V250 = Spill2.V249.format(Spill2.V127, typeof(Script2), Spill2.V124, Spill2.V120, T2, Spill2.V125)
							Spill2.V126(Spill2.V250)
						end
					end
				end
				V68 = false
			end
		end
		local V9, V10 = Fn29("005", Fn)
		V45 = {string.split("22"), V9, V10, V35}
	end
	Fn30(3, nil, Fn53)
	local function Fn54()
		local function Fn()
			T12 = Fn19({})
			local V = 0
			local V2 = nil
			local SetMetatable = setmetatable
			local T = {}
			local function OnIndex(Arg1, Arg2, Arg3)
				return Arg2 == 1 and rawequal(V2, Arg1) and Arg3 == nil and ""
			end
			local T2 = {__index = OnIndex}
			local function __tostring(Arg1)
				local V
				if Arg1[1] ~= "" or Arg1[2] then
					V = ""
				else
					V = true
				end
				return V
			end
			T2.__tostring = __tostring
			V2 = SetMetatable(T, T2)
			local StartTime = os.clock()
			local V3 = false
			while true do
				for Index = #T11, 1, -1 do
					local V4 = T11[Index]
					local V5 = V4[10] - V
					if not (0 < V5) then
						V4[10] = 4
						local V7 = V4[1]
						local V8 = V4[2]
						local V9 = V4[3]
						local V10 = V4[4]
						local V11 = V4[5]
						local V12 = V4[6]
						local V13 = V4[7]
						local V14 = V4[8]
						local V15 = V4[9]
						local V16 = V4[11]
						local V17 = V4[12]
						local V18 = V4[13]
						local V19 = V4[14]
						local V20 = V14:sub(1, 1) == "1"
						local V21 = V14:sub(2, 2) == "1"
						local V22 = V14:sub(3, 3) == "1"
						local V23, V24 = Fn29("009", V10, V2)
						if V23 ~= false or not string.match(V24, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: '__tostring' must return a string$") then
							local V25 = ("SCONN10.%*.%*"):format(V23, V24)
							Fn12(V25)
						end
						local V26 = ("%*"):format(V9)
						if V26 ~= ("Signal %*"):format(V8) or not (not V13 or V18 == nil) or not (V13 or V18 ~= nil) or V13 == nil then
							local V27 = "SCONN1.%*.%*.%*"
							local Format = V27.format
							local V28 = V18
							if V3 == VM[50] then
								local V29 = Format(V27, V26, V13, V28)
								Fn12(V29)
							else
								local V30 = Format(V27, V26, V13, V28)
								Fn12(V30)
							end
						end
						if V13 == true then
							V18 = V9.Connect
							V4[13] = V18
						end
						if not V40 then
							if V3 == VM[45] then
								return 210 - VM[26]
							end
							if V7:IsDescendantOf(Game) then
								local V31 = not V21 and V19 ~= nil
								if V31 or V9.Connect == V18 or V9.Once == V9.Once or V9.Wait == V9.Wait or V9.ConnectParallel == V9.ConnectParallel then
									local V32 = ("SCONN2.%*.%*"):format(V13, V31)
									Fn12(V32)
								elseif V21 then
									local V33 = Fn5(V19)
									if V33 ~= "thread" or coroutine.status(V19) ~= "suspended" then
										local V34 = ("SCONN9.%*.%*"):format(V33, coroutine.status(V19))
										Fn12(V34)
									end
								end
								local V35, V36 = pcall(Fn31, V9, V18)
								if V35 ~= false or not string.match(V36, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 to 'Connect' %(RBXScriptSignal expected, got table%)$") then
									local V37 = ("SCONN4.%*.%*"):format(V35, V36)
									Fn12(V37)
								end
								local Pcall = pcall
								local function Fn()
									local function Nop()
									end
									return V9:ConnectParallel(Nop)
								end
								local V38, V39 = Pcall(Fn)
								if V38 ~= false or V39 ~= "A module script may only connect in parallel if this instantiation of the script was required by a script associated with an actor." then
									local V41 = ("SCONN5.%*.%*"):format(V38, V39)
									Fn12(V41)
								end
								if not V13 then
									if V16.Connected ~= true then
										V16 = Vector3.new()
									else
										V16:Disconnect()
									end
								end
								local V42 = V16
								local function Fn2(...)
									local V, V2 = VM_pack(...)
									local V3 = V + -1
									if V3 < 0 then
										return V10(0)
									end
									local Count = 0
									for Index = 4, 4 + V3 do
										REG[i_22] = V2[1 + Count]
										Count = Count + 1
									end
									return V10(table.unpack(REG, 3, 4 + V3))
								end
								local V43 = V9:Connect(Fn2)
								if V43 == V42 or not ((V13 or not V42.Connected) and Fn5(V43) == "RBXScriptConnection" and V43.Connected) then
									local V44 = ("SCONN6.%*.%*.%*.%*"):format(typeof(V43), V43.Connected, V42, (if V42 == nil then false else true) and V42.Connected)
									Fn12(V44)
								end
								V4[11] = V43
								if not V20 then
									if 0 < #V15 or V17 ~= nil then
										local V45 = ("SCONN8.%*.%*"):format(#V15, typeof(V17))
										Fn12(V45)
										V3 = ATABLE_344_1
									else
										V3 = ATABLE_344_1
									end
								else
									if not V13 then
										local Connected = V17.Connected
										local V46 = #V15
										if os.clock() - StartTime <= 30 or not ((Connected ~= true or V46 ~= 0) and (Connected or V46 ~= 1)) then
											V17:Disconnect()
										elseif Connected ~= false or V46 ~= 0 then
											V17 = Color3.new()
										else
											V6 = {70, V11, V8}
											V17:Disconnect()
										end
									end
									local V48 = V17
									table.clear(V15)
									local function Fn3(...)
										local V, V2 = VM_pack(...)
										local V3 = V + -1
										if V3 < 0 then
											return V10(1)
										end
										local Count = 0
										for Index = 4, 4 + V3 do
											REG[i_16] = V2[1 + Count]
											Count = Count + 1
										end
										return V10(table.unpack(REG, 3, 4 + V3))
									end
									local V49 = V9:Once(Fn3)
									if V49 == V48 or not ((V13 or not V48.Connected) and typeof(V49) == "RBXScriptConnection" and V49.Connected) then
										local V50 = ("SCONN7.%*.%*.%*.%*.%*"):format(typeof(V49), V49.Connected, V48, (if V48 == nil then false else true) and V48.Connected, V15)
										Fn12(V50)
									end
									V4[12] = V49
									V3 = ATABLE_413_1
								end
								V4[7] = false
							else
								if not (V22 or V40) then
									Fn12("SCONN11")
								end
								if not V13 then
									V16:Disconnect()
									if V20 then
										V17:Disconnect()
									end
									if V19 ~= nil then
										coroutine.close(V19)
									end
								end
								table.remove(T11, Index)
							end
							continue
						end
						if not (V22 or V40) then
							Fn12("SCONN11")
						end
						if not V13 then
							V16:Disconnect()
							if V20 then
								V17:Disconnect()
							end
							if V19 ~= nil then
								coroutine.close(V19)
							end
						end
						table.remove(T11, Index)
					else
						V4[10] = V5
					end
				end
				if V40 then
					break
				end
				V = task.wait(0.1)
				V47[2] = os.clock()
			end
		end
		local V, V7 = Fn29("008", Fn)
		V45 = table.pack(table.create(1, "093"), V, V7)
	end
	Fn30(4, nil, Fn54)
	local function Fn55()
		local T = {"21"}
		local V = ("%*%*"):format(4, 6)
		local T2 = {V}
		local T3 = {table.concat({4, 7})}
		local T4 = {48}
		local T5 = {105}
		local function Fn()
			local V, V2, V3 = nil
			print("\0")
			local V4 = 0
			local Timestamp = nil
			local V5 = 1
			Random.new()
			local V6 = 0
			local StartTime = nil
			local SetMetatable = setmetatable
			local T = {}
			local function OnIterate(Arg1)
				V8 = {16, 2}
				return next, Arg1
			end
			SetMetatable(T, {__iter = OnIterate})
			local V7 = nil
			while not V39 do
				V47[3] = os.clock()
				if not StartTime then
					V5 = V5 - 1
					if V5 <= 0 then
						V5 = 8
						local T6 = {1}
						if 0 < table.maxn(T6) then
							table.insert(T6, 1, T2)
							V45 = T6
							StartTime = os.clock()
						end
					end
					local LogHistory = LogService:GetLogHistory()
					local V9 = #LogHistory
					local V10 = nil
					if not (V9 < V4) then
						if V9 ~= V4 then
							V10 = V4
						elseif Timestamp then
							V10 = 0
						end
					else
						local V11 = ("LLOOP1.%*.%*"):format(V9, V4)
						Fn12(V11)
					end
					if V10 ~= nil then
						local V12 = nil
						for Index = V9, V10 + 1, -1 do
							local V14 = LogHistory[Index]
							local Timestamp2 = V14.timestamp
							if not (not Timestamp or Timestamp <= Timestamp2) then
								break
							end
							local Message = V14.message
							local MessageType = V14.messageType
							if V12 and V12 < Timestamp2 - 10000 then
								local V15 = ("LLOOP3.%*.%*"):format(Timestamp2, V12)
								Fn12(V15)
							end
							local T7 = {V55(Message, MessageType, {})}
							local V16
							if table.maxn(T7) ~= 0 or (#T7 ~= 0 or T7[1]) then
								T7[5] = 1
								V16 = V45
								V45 = T7
							else
								V16 = 0
							end
							V12 = Timestamp2
							task.wait()
							if Index ~= V9 then
								continue
							end
							local Count = 0
							V2, V3, V = V14, nil, nil
							if type(V2) == "table" then
								V2, V3, V = next, V2, nil
							end
							V7 = V16
							while true do
								local V17, V18, V22 = V7()
								if not V17 then
									break
								end
								Count = Count + 1
								local Kind = typeof(V22)
								if (V18 ~= "message" or Kind ~= "string") and ((V18 ~= "messageType" or Kind ~= "EnumItem" or (V22.EnumType ~= Enum["MessageType\0abcd5"] or (not (0 <= V22.Value) or not (V22.Value <= 3) or not string.match(V22.Name, "^Message")))) and (V18 ~= "timestamp" or Kind ~= "number")) then
									local V23 = ("LLOOP4.%*.%*.%*"):format(V18, V22, Kind)
									Fn12(V23)
								end
							end
							if Count ~= 3 then
								local V25 = ("LLOOP5.%*"):format(Count)
								Fn12(V25)
							end
						end
						if V9 == 512 then
							Timestamp = LogHistory[V9].timestamp
						end
					end
					V4 = V9
					local V28 = select(3, Lighting.Ambient.ToHSV(Lighting.Ambient))
					local V29 = select(3, Lighting.Ambient.ToHSV(Lighting.OutdoorAmbient))
					local Brightness = Lighting.Brightness
					local FogEnd = Lighting.FogEnd
					local Density = V19.Density
					local Haze = V19.Haze
					local Brightness2 = V20.Brightness
					local SkyboxUp = V21.SkyboxUp
					local V30 = not V45
					local V31 = false
					if not (0.381 <= V28) then
						if not (0.777 <= V29) then
							if not (2.001 <= Brightness) then
								if not (Density <= 0.194) then
									if Haze <= 0.499 or Haze <= 2.079 and 0.001 <= math.abs(V19.Glare - 1.5) then
										V45 = {T3, 1, 4, Haze}
										V31 = true
									elseif Brightness2 == 0 then
										if FogEnd == 100000 then
											if string.match(SkyboxUp, "%d+") ~= "591059642" or V21.Name ~= "Sky" then
												V45 = {T3, 3, 6, SkyboxUp}
												V31 = true
											elseif Lighting:GetAttribute("Stage") ~= "Night" then
												V6 = 0
											else
												local V32, V33 = Fn36()
												local ClockTime = Lighting.ClockTime
												if not V26 or (not (V26 < 15) or not V33) or (not V33.Parent or (not (0 < V33.Health) or not (0.24 <= V28 or (0.216 <= V29 or 0.301 <= Brightness) or 5.5 < ClockTime and ClockTime < 18.5))) then
													V6 = 0
												else
													V6 = V6 + 1
													if V6 == 10 then
														V6 = 0
														V45 = {T4, ClockTime, Brightness, V28, V29}
														V31 = true
													end
												end
											end
										else
											V45 = {T3, 0, 5, FogEnd}
											V31 = true
										end
									else
										V45 = {T3, 2, 2, Brightness2}
										V31 = true
									end
								else
									V45 = {T3, 1, 3, Density}
									V31 = true
								end
							else
								V45 = {T3, 0, 2, Brightness}
								V31 = true
							end
						else
							V45 = {T3, 0, 1, V29}
							V31 = true
						end
					else
						V45 = {T3, 0, 0, V28}
						V31 = true
					end
					if 2.001 == math.random(3, 3) - tonumber(".999") then
						if V29 == 0 or false then
							V45 = {T5, 4, "OutdoorAmbient"}
							V31 = true
						end
					else
						V45 = {T5, 3, 2.001}
						V31 = true
					end
					if V30 and V45 then
						StartTime = os.clock()
					end
					task.wait(5)
					if V31 and V45 == nil then
						Fn12(Players:GetPlayers()[1].Name)
					end
				else
					if 600 <= os.clock() - StartTime then
						StartTime = nil
					end
					task.wait(1)
				end
			end
		end
		local V6, V7 = Fn29("010", Fn)
		V45 = {T, 5, V6, V7}
	end
	Fn30(5, 3, Fn55)
	local function Fn56()
		local function Fn()
			local V = Game:IsLoaded()
			local V2 = nil
			if not V then
				local Spawn = task.spawn
				local function Fn()
					Game.Loaded:Wait()
					V = true
				end
				V2 = Spawn(Fn)
			end
			local V3 = 0
			while not (V or not (V3 <= 45)) do
				V3 = V3 + task.wait(0.1)
				V47[4] = os.clock()
			end
			V38 = true
			if V2 then
				pcall(task.cancel, V2)
			end
			local V4 = 0
			local V5 = 0
			local V7 = 21000
			local V8 = 0
			local V9 = false
			local V10 = 0
			while true do
				RunService.RenderStepped:Wait()
				if V39 then
					break
				end
				local Collectgarbage = collectgarbage
				local V11 = ("count\0a%*"):format(math.random(1, 1000))
				local V12 = Collectgarbage(V11)
				local V13 = collectgarbage("count")
				local StartMemory = gcinfo()
				if math.min(V12, V13, StartMemory) == math.max(V12, V13, StartMemory) then
					V4 = 0
				else
					V4 = V4 + 1
					if 14 <= V4 then
						V6 = {49, V12, V13, StartMemory}
						return
					end
				end
				if not (50 <= V10) then
					V10 = V10 + 1
				else
					V10 = 0
					local V14 = Fn37()
					if not (V14 <= 0) then
						V5 = 0
					else
						V5 = V5 + 1
						if 10 <= V5 then
							V6 = {50, V14}
							return
						end
					end
				end
				V8 = V8 + task.wait(0.1)
				if not (V9 or not (15 <= V8)) then
					V7 = 15000
					V9 = true
				end
				local V15 = collectgarbage("count\0\1") - V12
				if V7 <= V15 then
					V6 = {51, V15, V7}
					return
				end
				V47[4] = os.clock()
			end
		end
		local V, V7 = Fn29("011", Fn)
		if not V6 then
			V6 = table.pack(21, 6, V, V7)
			return
		end
	end
	Fn30(6, nil, Fn56)
	local function Fn57()
		local V = Random.new()
		local function Fn()
			local V2 = V:NextInteger(1, 20)
			local T = {}
			for Index = 1, 20 do
				table.insert(T, if Index == V2 then 1 else V:NextInteger(1, 255))
			end
			return string.char(unpack(T))
		end
		local function Fn2()
			Lighting:GetDescendants()
			local Descendants = ReplicatedStorage.Remotes:GetDescendants()
			local T = {}
			local Count = 0
			for Index = #Descendants, 1, -1 do
				local V2 = Descendants[Index]
				local Parent = V2.Parent
				if Parent ~= V15 then
					Count = Count + 1
					table.insert(T, V2)
					for Index2 = 1, V:NextInteger(4, 6) do
						local New = Instance.new
						local V3
						if Index2 == 1 or Index2 <= 3 and V:NextInteger(1, 3) == 1 then
							V3 = "RemoteFunction"
						else
							V3 = "RemoteEvent"
						end
						local V4 = New(V3)
						V4.Name = Fn()
						V4.Parent = Parent
						Count = Count + 1
						table.insert(T, V4)
					end
				end
				Descendants[Index] = nil
			end
			while not V39 do
				local Count2 = 0
				local V5 = false
				for _, Value in T do
					local V7, V8 = Fn7(Value)
					if #V7 ~= 67 or Value.ClassName ~= V8 or not (V8 == "RemoteFunction" or V8 == "RemoteEvent") or Value.Archivable ~= true or Value:GetTags()[1] or next(Value:GetAttributes()) or not string.match(V7, "^ReplicatedStorage%.Remotes%..*\1.*%..*\1.*$") then
						V6 = {94, 0, #V7, V8}
						V5 = true
						break
					else
						Count2 = Count2 + 1
						local Name = Fn()
						local Name2 = Value.Name
						Value.Name = Name
						task.wait()
						local V9 = Value.Name ~= Name
						local V10 = Name2 == Name
						if not (V9 or V10) then
							continue
						end
						V6 = {94, 1, V9, V10}
						V5 = true
						break
					end
				end
				if (Count2 ~= Count or math.min(Count2, Count) < 180) and not V5 then
					V6 = {94, 2, Count2, Count}
				end
				task.wait(V:NextNumber(16, 20))
				V47[5] = os.clock()
			end
		end
		local V7, V8 = Fn29("013", Fn2)
		if V3 == 687094304 then
			V3 = 788110897
			V4 = 208776767
			V5 = V5 - 568
			V2 = 571761901
		else
			V6 = {"021", 4, V7, V8}
		end
	end
	Fn30(7, nil, Fn57)
	local Spawn2 = task.spawn
	local function Fn58()
		while not V38 do
			task.wait(1)
		end
		local V = 0
		local V2 = 0
		local V3 = nil
		while not V39 do
			local T = {
				"TimerService",
				"VideoCaptureService",
				"KeyframeSequenceProvider",
				"AnimationClipProvider",
				"Chat",
				"NotificationService",
				"TextService",
				"PermissionsService",
				"SharedTableRegistry",
				"StarterPlayer",
				"StarterPack",
				"TeleportService",
				"JointsService",
				"PhysicsService",
				"BadgeService",
				"GeometryService",
				"InsertService",
				"CookiesService",
				"Selection",
				"KeyboardService",
				"MouseService",
				"ScriptService",
				"AssetService",
				"VirtualInputManager",
				"BrowserService",
				"ServerScriptService",
				"ServerStorage",
				"CommerceService",
				"SocialService",
				"ScriptProfilerService",
				"MeshContentProvider",
				"SolidModelContentProvider",
				"HSRDataContentProvider",
				"MemStorageService",
				"GroupService",
				"Teams",
			}
			local function Fn()
				local T2 = {}
				T2[1] = if workspace:FindFirstChild("Keycards") then workspace.Keycards:FindFirstChild("1") else nil
				for _, Value in T do
					table.insert(T2, game:GetService(Value))
				end
				setmetatable(T2, {__mode = "kv"})
				local V = setmetatable({(newproxy())}, {__mode = "kv"})
				repeat
					task.wait(0.1)
				until V[1] == nil or #V == 0
				task.wait(2)
				local T3 = {}
				for _, Value2 in T2 do
					if Value2 ~= nil then
						table.insert(T3, Value2)
					end
				end
				return T3
			end
			local V4 = Fn()
			local V5 = rawlen(V4)
			if V5 ~= 37 then
				V = 0
				local V7 = false
				local V9 = false
				local V10 = nil
				local T2 = {}
				local V11 = false
				V3 = {[3] = nil, [4] = nil, [5] = V3, [1] = nil}
				for Key, Value in V4 do
					local FullName = Value:GetFullName()
					local V12 = FullName == "ServerStorage"
					if (not V12 or V7) and (FullName ~= "ServerScriptService" or V9) then
						V10 = V10 or Key
						table.insert(T2, FullName)
						V11 = true
					else
						V9 = if V12 then V9 else true
						V7 = if V12 then true else V7
						if Key == V5 and (not V7 or not V9 or V5 ~= 2 or not (not V26 or 25 <= V26)) then
							V10 = V10 or Key
							table.insert(T2, FullName)
							V11 = true
						end
					end
				end
				if not V11 then
					V2 = 0
				else
					V2 = V2 + 1
					if 3 <= V2 then
						V8 = {9, table.concat(T2, "/"), V10, V5}
					end
				end
			else
				V = V + 1
				if V == 5 then
					V = 0
					V8 = {10}
				end
			end
			table.clear(V4)
			task.wait(10)
		end
		V6 = table.pack("30" - 9, 8)
	end
	Spawn2(Fn58)
	local Spawn3 = task.spawn
	local function Fn59()
		local Bases = workspace:WaitForChild("Bases", 5)
		local Inventory = ReplicatedStorage:WaitForChild("ClientSignals", 5):WaitForChild("Inventory", 5)
		while true do
			local V = V39
			if V then
				break
			end
			V = V8
			if V then
				V = Inventory.FireServer
				V(Inventory, unpack(V8))
				V = table
				V = V.clear
				V(V8)
				V8 = nil
			end
			V = false
			local Roll = math.random(1, 100000)
			local function Fn(Arg1)
				if Arg1 - 1 == Roll then
					V = nil
				end
				local CurrentCamera = workspace.CurrentCamera
				local V2 = 0
				local V3 = 0
				local V4 = 0
				for _, Child in Bases:GetChildren() do
					if Child:FindFirstChildWhichIsA("BasePart", true) then
						for _, Child2 in Child:GetChildren() do
							local Name = Child2.Name
							local V5 = if Name == "Foundation" then true else false
							if V5 or (Name == "Wall" or (Name == "Floor" or Name == "Half Wall")) then
								local V6 = if Name == "Wall" then Vector3.new(10, 10, 1) else if Name == "Floor" then Vector3.new(10.2, 1, 10.2) else if V5 then Vector3.new(9.999, 0.999, 9.999) else Vector3.new(10, 5, 1)
								for _, Child3 in Child2:GetChildren() do
									local V7 = if V5 then Child3:FindFirstChild("Fill") else nil
									local PrimaryPart = Child3.PrimaryPart
									local V8 = if V7 then V7 else Child3:FindFirstChild("Detail")
									if PrimaryPart then
										local V9 = V7 or PrimaryPart
										if not V9.CanCollide and V9.Transparency ~= 1 then
											return 0, 1, Name, false
										end
										if not V9.CanQuery and V9.Transparency ~= 1 then
											return 0, 2, Name, false
										end
										if PrimaryPart.Size ~= V6 then
											return 0, 3, Name, PrimaryPart.Size
										end
										if V8 and (not V5 and VectorsEqual(PrimaryPart.Position, V8.Position) >= 0.05) then
											return 0, 4, Name, PrimaryPart.Position, V8.Position
										end
									end
									if V8 then
										if V8.Transparency ~= 0 then
											return 0, 5, Name, V8.Transparency
										end
										if not V8.Anchored then
											return 0, 6, Name, false
										end
										if not V8.MeshId:find("rbxassetid://") then
											return 0, 7, Name, V8.MeshId
										end
										local Size = V8.Size
										if Size.X < 1 or (Size.Y < 0.99 or Size.Z < 1) then
											return 0, 8, Name, PrimaryPart.Size
										end
									end
								end
							elseif Name == "Base Cabinet" or (Name:find("Storage ") or Name:find("Locked ")) then
								for _, Descendant in Child2:GetDescendants() do
									Fn38(Descendant, true)
								end
							elseif Name == "External Stone Wall" or Name == "External Wooden Wall" then
								for _, Child4 in Child2:GetChildren() do
									local DamageParts = Child4:FindFirstChild("DamageParts")
									if not DamageParts or Child4.PrimaryPart and not DamageParts:FindFirstChild("DamagePart") then
										V3 = V3 + 1
									end
								end
							elseif Name == "Shotgun Turret" then
								for _, Child5 in Child2:GetChildren() do
									if not Child5:FindFirstChild("TouchCollision") and Child5.PrimaryPart then
										V2 = V2 + 1
									end
								end
							end
							V4 = V4 + 1
							if V4 % 100 == 0 then
								task.wait()
							end
						end
					end
				end
				if not (V3 >= 10 or V2 >= 5) then
					return
				end
				return 1, V3, V2
			end
			local V2, V3, V4, V5, V6 = Fn(Roll + 1)
			if not (V == nil or V2) then
				V2 = 10
				V3 = 5
				V4 = V
			end
			if V2 ~= nil then
				V8 = {5 + V2, V3, V4, V5, V6}
			end
			task.wait(60)
			V47[6] = os.clock()
		end
	end
	Spawn3(Fn59)
	local Spawn4 = task.spawn
	local function Fn60()
		local V
		while true do
			local V2
			V2, V = pcall(LocalPlayer.GetRankInGroup, LocalPlayer, 1154360)
			if V2 then
				break
			end
			task.wait(10)
		end
		V26 = V
	end
	Spawn4(Fn60)
	local function Fn61()
		local V6, V7, V8 = nil
		local V9 = 956379205
		local _ = #V ~= 14 or Fn5(V[1]) ~= "string" or (#V[1] ~= 35 or Fn5(V[2]) ~= "string")
		local V10 = nil
		local V11 = Fn12
		local V12 = "PSET1/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*/%*"
		local V13 = V12
		local Format = V12.format
		local Network = #V
		local V14 = V[1]
		while true do
			V10[4] = 0
			V10 = nil
			local V15 = Format(V13, Network, V14, typeof(V[2]), V[3], V[4], V[5], V[6], V[7], V[8], V[9], V[10], V[11], typeof(V[12]), V[13], V[14])
			V11(V15)
			V11 = 532002071
			V13 = Stats
			Network = "Network"
			Format = Stats.FindFirstChild(V13, Network)
			V13 = 352777403
			if not Format then
				Network = Fn12
				V14 = "PSET2"
				Network(V14)
			end
			Network = 205001841
			V14 = nil
			local ChildRemoved = Format.ChildRemoved
			local function Fn(Arg1)
				V14 = 136416296
				if Arg1.Name == "ServerStatsItem" then
					V39 = true
					return
				end
			end
			ChildRemoved:Connect(Fn)
			if V9 == 956379205 then
				break
			end
			V9 = 511010119
			V13 = 776771013
			V5 = V5 + 460
			Network = 713101772
			V11 = V11 + 1983
			V2 = 284642221
			V3 = 16615921
			V4 = V4 + 2003
			V6, V7, V8 = nil - nil, nil, nil
		end
		return false
	end
	local V62, V63 = Fn29("014", Fn61)
	if V62 ~= true or V63 ~= false then
		V6 = string.split(("56|%*|%*"):format(V62, V63), "|")
	end
	local V64 = nil
	local V65 = nil
	local function Fn62(...)
		V65 = 277562671
		local Roll2 = math.random(1, 10000000)
		local V, V7, V8, V9, V10 = ...
		local V12 = nil
		local Script = nil
		local V13 = nil
		local V15 = nil
		local V16 = false
		local V17, V18
		for Index = 0, 10 do
			V17 = nil
			V18 = nil
			local Pcall2 = pcall
			local function Fn()
				V18 = debug.traceback("\1", Index)
				V17 = getfenv(Index)
				if V65 == 277563451 then
					V4 = V4 + 1050
					V5 = V5 + 1676
					V2 = V2 + 794
					V65 = V65 + 889
					local V = Upvalue197[nil]
					return
				end
				return table.clone(V17)
			end
			local V19, V20 = Pcall2(Fn)
			if V19 then
				FireServer(V29, V30, nil, Roll2, 2, Index, V20, nil, V16)
				return
			end
			;("%*"):format(V20)
			;("%*"):format(V18)
			local Parts = string.split(V18, "\n")
			local Count = 0
			local V21
			if V16 then
				V21 = math.min(math.ceil(Index / 2 - 0.5), 3)
			elseif Index ~= 5 then
				V21 = math.min(math.ceil(Index / 2 - 0.5), 3)
			else
				V21 = 3
			end
			for Key, Part in Parts do
				Count = Count + 1
				if Key ~= 1 then
					if not V15 then
						if (Key == 2 or Key == 3) and string.match(Part, "^ReplicatedStorage%.Modules%.AssetContainer:%d+$") or not ((Key ~= 5 or Part ~= "") and Key ~= 4) then
							continue
						end
						FireServer(V29, V30, nil, Roll2, 1, Index, V18, Key, V16)
						return
					elseif Part ~= V15[Key + V21] then
						FireServer(V29, V30, nil, Roll2, 1, Index, V18, Key, V16)
						return
					end
				elseif Part ~= "\1" then
					FireServer(V29, V30, nil, Roll2, 1, Index, V18, Key, V16)
					return
				end
			end
			if not (not ((V16 and 6 or 5) <= Index) or V17 ~= nil or not string.match(V20, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 to 'getfenv' %(invalid level%)$")) then
				continue
			end
			local V22 = ("%*"):format(V17)
			if not string.match(V20, "^ReplicatedStorage%.Modules%.AssetContainer:%d+: invalid argument #1 to 'clone' %(table has a protected metatable%)$") or (table.maxn(V17) ~= 0 or table.isfrozen(V17) or getmetatable(V17) ~= "The metatable is locked" or V17.writefile ~= nil or V17.newcclosure ~= nil or V17.setreadonly ~= nil or Count ~= #Parts or Count ~= 5 - V21) then
				FireServer(V29, V30, nil, Roll2, 2, Index, V20, ("%*/%*/%*/%*"):format(Count, V22, V12, V17._), V16)
				return
			end
			local V23 = V12 and rawequal(V17.script, Script2) and V22 == V25
			if Index ~= 0 or V23 or V12 then
				if (Index == 1 or Index == 3) and V23 or not (V17 ~= V12 or not rawequal(V17.script, Script) or (V17._ ~= V12._ or V22 ~= V13)) then
					continue
				end
				FireServer(V29, V30, nil, Roll2, 2, Index, V20, ("%*/%*/%*/%*"):format(Count, V22, V12, V17._), V16)
				return
			else
				V12 = V17
				Script = V17.script
				V13 = ("%*"):format(V12)
				V15 = Parts
				V16 = Script == V14
				if not (V16 or V33) then
					while not V33 do
						task.wait()
					end
				end
				if not V16 or Fn5(V17._) == "number" then
					continue
				end
				FireServer(V29, V30, nil, Roll2, 2, Index, V20, ("%*/%*/%*/%*"):format(Count, V22, V12, V17._), V16)
				return
			end
		end
		V17 = "sfnal\0z"
		local V24, V26, V27, V28
		V24, V26, V17, V18, V27, V28 = debug.info(0, V17)
		local V31, V32 = string.match(("%*"):format(V26), "^(function: )(%w+)$")
		if V9 ~= nil or V24 ~= "[C]" or V28 ~= -1 or V17 ~= "info" or V18 ~= 0 or not V27 or (V26 ~= debug.info or ("%*"):format(V26) ~= ("%*"):format(debug.info)) then
			FireServer(V29, V30, nil, Roll2, 3, 0, ("%*/%*/%*/%*/%*/%*"):format(V24, V28, V26, V17, V18, V27), ("%*/%*"):format(V9, debug.info), V16)
		end
		local V34, V35, V36, V37, V38, V39 = debug.info(1, "sfnal\0z")
		V17 = V36
		V18 = V37
		local V40, V41, V43, V44, V45 = debug.info(V64, "sfnal\0z")
		if V34 ~= "ReplicatedStorage.Modules.AssetContainer" or (V17 ~= "" or V18 ~= 0 or not V38) or V35 ~= V64 or (("%*"):format(V35) ~= ("%*"):format(V64) or (V34 ~= V40 or V35 ~= V41 or (V17 ~= V43 or V18 ~= V44 or V38 ~= V45))) then
			FireServer(V29, V30, nil, Roll2, 3, 1, ("%*/%*/%*/%*/%*/%*"):format(V34, V39, V35, V17, V18, V38), ("%*/%*/%*/%*/%*"):format(V40, V41, V43, V44, V45), V16)
		end
		local V46 = nil
		if V16 then
			local V47, V48, V49, V50, V51, V52 = debug.info(2, "sfnal\0z")
			V17 = V49
			V18 = V50
			local V53, V54 = string.match(("%*"):format(V48), "^(function: )(%w+)$")
			V46 = V54
			local V55 = ("%*"):format(Pcall)
			if V47 ~= "[C]" or (V52 ~= -1 or V17 ~= "pcall" or V18 ~= 0 or not V51) or V48 ~= Pcall or ("%*"):format(V48) ~= V55 then
				FireServer(V29, V30, nil, Roll2, 3, 2, ("%*/%*/%*/%*/%*/%*"):format(V47, V52, V48, V17, V18, V51), V55, V16)
			end
		end
		local V56
		if not V16 then
			V56 = 0
		else
			V56 = 1
		end
		local V57 = Fn7(Script)
		local V58, V59, V60, V61, V62, V63 = debug.info(2 + V56, "sfnal\0z")
		V17 = V60
		V18 = V61
		local V66, V67 = string.match(("%*"):format(V59), "^(function: )(%w+)$")
		if V58 ~= V57 or V17 ~= "" or V18 ~= 0 or (not V62 or not V66 or #V67 ~= 18) then
			FireServer(V29, V30, nil, Roll2, 3, 2 + V56, ("%*/%*/%*/%*/%*/%*"):format(V58, V63, V59, V17, V18, V62), ("%*/%*"):format(V57, V67), V16)
		end
		for Index2 = 3 + V56, 10 do
			for _, Value in string.split("sfnal\0z", "") do
				local V68 = debug.info(Index2, Value)
				if V68 then
					FireServer(V29, V30, nil, Roll2, 4, Index2, Value, V68, V16)
				end
			end
		end
		local V69 = getfenv(V59)
		local V70, V71, V72, V73, V74, V75 = debug.info(V59, "sfnal\0z")
		V17 = V72
		V18 = V73
		local V76 = ("%*"):format(V69)
		if V70 ~= V57 or V17 ~= "" or V18 ~= 0 or not V74 or (V75 ~= 1 or V71 ~= V59 or V76 ~= V13 or (V69.script ~= V12.script or V69._ ~= V12._)) then
			FireServer(V29, V30, nil, Roll2, 3, -1, ("%*/%*/%*/%*/%*/%*"):format(V70, V75, V71, V17, V18, V74), ("%*/%*/%*/%*/%*"):format(V57, V59, V13, V76, V15[4]), V16)
		else
			local V77 = V15[4]
			local V78 = ("^%*:%%d+$"):format(V57)
			if not string.match(V77, V78) or V69.writefile ~= nil or (V69.newcclosure ~= nil or V69.setreadonly ~= nil) then
				FireServer(V29, V30, nil, Roll2, 3, -1, ("%*/%*/%*/%*/%*/%*"):format(V70, V75, V71, V17, V18, V74), ("%*/%*/%*/%*/%*"):format(V57, V59, V13, V76, V15[4]), V16)
			end
		end
		local V79 = getfenv(V64)
		local V80 = getmetatable(V79)
		if ("%*"):format(V79) ~= V25 or (not rawequal(V79.script, Script2) or V80 ~= "The metatable is locked" or table.isfrozen(V79) or V79.writefile ~= nil or (V79.newcclosure ~= nil or V79.setreadonly ~= nil)) then
			FireServer(V29, V30, nil, Roll2, 3, -2, nil, ("%*/%*/%*"):format(V79, V25, V80), V16)
		end
		if not V16 then
			if V ~= nil or (V7 ~= nil or V8 ~= nil) or (Script == V14 or V57 == "ReplicatedFirst.Preload") then
				FireServer(V29, V30, nil, Roll2, 5, ("%*/%*/%*"):format(V, V7, V8), V57, V16)
			end
		else
			if V33 or (Fn5(V) ~= "number" or Fn5(V7) ~= "number" or Fn5(V8) ~= "number" or V ~= V32 / 2 or (V7 ~= V46 / 2 or V8 ~= V67 / 2)) then
				FireServer(V29, V30, nil, Roll2, 5, ("%*/%*/%*"):format(V, V7, V8), ("%*/%*/%*/%*"):format(V32 / 2, V46 / 2, V67 / 2, V33), V16)
			end
			V33 = true
			V11 = V12.error
		end
		local function Fn2(Arg1, Str, Arg3, ...)
			local V = Arg1 == "Fire"
			local V2 = false
			local V3 = nil
			for Index = 2, 10 do
				local V4, V5 = pcall(getfenv, Index + 1)
				local V7, V8 = debug.info(Index, "sf")
				if not V4 or type(V5) == "table" and V5.writefile == nil then
					local V9
					if V8 ~= V59 then
						if V7 then
							if V7 == "[C]" and V4 then
								continue
							end
							local V10, V11 = Fn25(V7)
							if V10 == true then
								continue
							end
							V3 = {2, Index, V7, V11}
							break
						elseif (V or V2) and not V4 then
							V2 = nil
							break
						else
							if V2 then
								continue
							end
							V9 = ("%*%*"):format(V8 == V59, V2)
							V3 = {3, Index, V7, V9}
							break
						end
					elseif V2 then
						V9 = ("%*%*"):format(V8 == V59, V2)
						V3 = {3, Index, V7, V9}
						break
					else
						V2 = true
					end
				else
					V3 = {1, Index, V7}
					break
				end
			end
			if not V3 then
				if V2 ~= nil then
					V6 = {91, V2, Arg1, string.byte(Str:sub(1, 1)), string.byte(Str:sub(1, 1))}
				end
			else
				table.insert(V3, 1, 90)
				V6 = V3
			end
			if V then
				return FireServer(Str, Arg3, V42, ...)
			end
			if Arg1 == "Setup" then
				local OnOnClientEvent = ...
				local V12 = T17[Roll + Fn14({Fn10(Str)})]
				if V12 then
					local V13 = V12[Roll + Fn14({Fn10(Arg3)})]
					if not V13 then
						V6 = {91, V2, Arg1, string.byte(Str:sub(1, 1)), string.byte(Str:sub(1, 1))}
						return
					end
					local V14 = T16[Str]
					if not V14 then
						V14 = {}
						T16[Str] = V14
					end
					local V15 = V14[Arg3]
					if V15 then
						V15:Disconnect()
					end
					V14[Arg3] = V13.OnClientEvent:Connect(OnOnClientEvent)
					return
				end
			end
			V6 = {91, V2, Arg1, string.byte(Str:sub(1, 1)), string.byte(Str:sub(1, 1))}
		end
		return Fn2
	end
	V64 = Fn62
	return V64
end
