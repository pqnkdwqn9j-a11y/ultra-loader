local JNKIE_SERVICE = ""
local JNKIE_IDENTIFIER = ""
local DISCORD_INVITE = "https://discord.gg/kYxbtF3TUc"
local LOADER_VERSION = "1.0.0"
local KEY_FILE = "burmalda_key.txt"
local LANG_FILE = "burmalda_lang.txt"
local IMG_FILE = "burmalda_mascot.jpg"
local ICONS_FILE = "burmalda_icons.png"
local GLOW_FILE = "burmalda_glow.png"
local ASSET_BASE = "https://raw.githubusercontent.com/pqnkdwqn9j-a11y/potatoh/refs/heads/main/"
local MASCOT_B64 = ""
local ICONS_B64 = ""
local GLOW_B64 = ""

local GAMES = {
	{ id = "hvh", name = "aquabeary-hvh", ready = true },
	{ id = "fallen", name = "fallen survival", ready = true },
}

local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local TS = game:GetService("TweenService")
local RS = game:GetService("RunService")
local HttpService = game:GetService("HttpService")
local LP = Players.LocalPlayer

getgenv().SCRIPT_KEY = nil
getgenv().UI_CLOSED = false

local function safe(f, ...)
	local ok, r = pcall(f, ...)
	if ok then return r end
	return nil
end

local function fread(name)
	if not (isfile and readfile) then return nil end
	local ok, r = pcall(function() if isfile(name) then return readfile(name) end end)
	if ok and type(r) == "string" then return r end
	return nil
end

local function fwrite(name, data)
	if not writefile then return false end
	return pcall(writefile, name, data)
end

local I18N = {
	en = {
		desc = "no cap, best fallen hvh script\n- Burmalda", hint = "Choose the game to load", select = "Select script",
		indev = "in development", time = "Time", user = "User", check = "CHECK", checking = "CHECKING", status = "Status",
		days = "DAYS", hours = "HOURS", mins = "MINS", expires = "Expires on", reseller = "Reseller", back = "change game",
		ph = "Enter your key", nolic = "No license", enterkey = "Enter your key to activate", active = "License Active", pillok = "ACTIVE", pillbad = "INVALID",
		accepted = "Key accepted", waitauth = "Authorizing...", invalid = "Invalid key", expired = "Key expired",
		left = "Time left: ", life = "Lifetime", never = "Never", d = " d ", h = " h ", m = " min",
		launch = "LAUNCH ", loading = "LOADING", inject = "INJECTING", launched = "LAUNCHED", failed = "FAILED",
		tdev = "fallen survival is in development.", tload = " loaded. Press RightShift to open the menu.",
		tdc = "Discord invite copied to clipboard.", tkey = "Enter your key first.", tinv = "Invalid key. Check it and try again.",
		tnet = "Could not reach the key server. Try again.", trej = "Key rejected by server. Run the script again.",
		e_KEY_INVALID = "Invalid key", e_KEY_EXPIRED = "Key expired", e_HWID_MISMATCH = "Key is bound to another device",
		e_HWID_BANNED = "Device banned", e_KEY_INVALIDATED = "Key revoked", e_ALREADY_USED = "Key already used",
		e_SERVICE_NOT_FOUND = "Service error", e_SERVICE_MISMATCH = "Service error", e_PREMIUM_REQUIRED = "Premium key required",
	},
	ru = {
		desc = "no cap, best fallen hvh script\n- Burmalda", hint = "Выбери игру для загрузки", select = "Выбрать скрипт",
		indev = "в разработке", time = "Время", user = "Пользователь", check = "ПРОВЕРИТЬ", checking = "ПРОВЕРКА", status = "Статус",
		days = "ДНЕЙ", hours = "ЧАСОВ", mins = "МИНУТ", expires = "Истекает", reseller = "Реселлер", back = "сменить игру",
		ph = "Введи ключ", nolic = "Нет лицензии", enterkey = "Введи ключ для активации", active = "Лицензия активна", pillok = "АКТИВНА", pillbad = "ОШИБКА",
		accepted = "Ключ принят", waitauth = "Авторизация...", invalid = "Неверный ключ", expired = "Ключ истёк",
		left = "Осталось: ", life = "Навсегда", never = "Никогда", d = " д ", h = " ч ", m = " мин",
		launch = "ЗАПУСК ", loading = "ЗАГРУЗКА", inject = "ИНЖЕКТ", launched = "ЗАПУЩЕНО", failed = "ОШИБКА",
		tdev = "fallen survival пока в разработке.", tload = " загружен. RightShift - открыть меню.",
		tdc = "Ссылка на Discord скопирована.", tkey = "Сначала введи ключ.", tinv = "Неверный ключ. Проверь и попробуй ещё раз.",
		tnet = "Сервер ключей недоступен. Попробуй ещё раз.", trej = "Сервер отклонил ключ. Запусти скрипт заново.",
		e_KEY_INVALID = "Неверный ключ", e_KEY_EXPIRED = "Ключ истёк", e_HWID_MISMATCH = "Ключ привязан к другому устройству",
		e_HWID_BANNED = "Устройство забанено", e_KEY_INVALIDATED = "Ключ отозван", e_ALREADY_USED = "Ключ уже использован",
		e_SERVICE_NOT_FOUND = "Ошибка сервиса", e_SERVICE_MISMATCH = "Ошибка сервиса", e_PREMIUM_REQUIRED = "Нужен премиум-ключ",
	},
}
local LANG = (fread(LANG_FILE) == "ru") and "ru" or "en"
local T = I18N[LANG]
local MONTHS = {
	en = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" },
	ru = { "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря" },
}
local C = {
	panel = Color3.fromRGB(11, 11, 13), side = Color3.fromRGB(16, 16, 19), card = Color3.fromRGB(14, 14, 17),
	border = Color3.fromRGB(30, 30, 35), accent = Color3.fromRGB(47, 155, 255), accent2 = Color3.fromRGB(25, 120, 220),
	white = Color3.fromRGB(255, 255, 255), grey = Color3.fromRGB(150, 150, 156), dim = Color3.fromRGB(82, 82, 90),
	green = Color3.fromRGB(63, 191, 127), red = Color3.fromRGB(224, 108, 108), dark = Color3.fromRGB(24, 24, 29), black = Color3.fromRGB(0, 0, 0),
}
local FONT, FONT_M, FONT_B = Enum.Font.Gotham, Enum.Font.GothamMedium, Enum.Font.GothamBold
pcall(function() FONT = Enum.Font.Montserrat; FONT_M = Enum.Font.MontserratMedium; FONT_B = Enum.Font.MontserratSemiBold end)

local function new(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props) do
		if k ~= "Parent" then pcall(function() o[k] = v end) end
	end
	if parent then o.Parent = parent end
	return o
end
local function corner(o, r) return new("UICorner", { CornerRadius = UDim.new(0, r or 5) }, o) end
local function stroke(o, col, th, tr) return new("UIStroke", { Color = col or C.border, Thickness = th or 1, Transparency = tr or 0, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, o) end
local function label(parent, text, size, col, font, props)
	local l = new("TextLabel", {
		BackgroundTransparency = 1, Text = text, TextSize = size, TextColor3 = col or C.white,
		Font = font or FONT, TextXAlignment = Enum.TextXAlignment.Left, Size = UDim2.new(1, 0, 0, size + 6),
	}, parent)
	if props then for k, v in pairs(props) do pcall(function() l[k] = v end) end end
	return l
end
local function tween(o, props, t)
	pcall(function() TS:Create(o, TweenInfo.new(t or 0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), props):Play() end)
end
local function hgrad(o, c1, c2, rot)
	return new("UIGradient", { Color = ColorSequence.new(c1, c2), Rotation = rot or 0 }, o)
end

local function b64decode(s)
	local native = (crypt and (crypt.base64decode or (crypt.base64 and crypt.base64.decode))) or base64_decode or (base64 and base64.decode)
	if native then
		local ok, r = pcall(native, s)
		if ok and type(r) == "string" and #r > 0 then return r end
	end
	local map = {}
	local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	for i = 1, 64 do map[chars:byte(i)] = i - 1 end
	local out, n, bits, acc = {}, 0, 0, 0
	local sub, byteAt = string.char, string.byte
	for i = 1, #s do
		local v = map[byteAt(s, i)]
		if v then
			acc = acc * 64 + v
			bits = bits + 6
			if bits >= 8 then
				bits = bits - 8
				local byte = math.floor(acc / (2 ^ bits))
				acc = acc - byte * (2 ^ bits)
				n = n + 1
				out[n] = sub(byte)
			end
		end
	end
	return table.concat(out)
end

local function customAsset(file, b64)
	if not (writefile and getcustomasset) then return nil end
	local ok, asset = pcall(function()
		if not (isfile and isfile(file)) then
			local data = nil
			if b64 and #b64 > 100 then
				data = b64decode(b64)
			else
				data = game:HttpGet(ASSET_BASE .. file)
			end
			if not (type(data) == "string" and #data > 500) then return nil end
			writefile(file, data)
		end
		return getcustomasset(file)
	end)
	if ok and type(asset) == "string" then return asset end
	return nil
end
local ICONS = customAsset(ICONS_FILE, ICONS_B64)
local ICON_INDEX = { clock = 0, user = 1, shield = 2, calendar = 3, cart = 4, discord = 5, arrow = 6, close = 7, crown = 8, key = 9, globe = 10, check = 11 }
local ICON_GLYPH = { clock = "◷", user = "●", shield = "⛨", calendar = "▦", cart = "▣", discord = "●", arrow = "➜", close = "✕", crown = "♛", key = "⚿", globe = "◎", check = "✓" }
local function icon(parent, name, size, col, pos, props)
	local o
	if ICONS then
		local i = ICON_INDEX[name] or 0
		o = new("ImageLabel", {
			BackgroundTransparency = 1, Image = ICONS, ImageColor3 = col or C.white, Size = UDim2.new(0, size, 0, size), Position = pos,
			ImageRectSize = Vector2.new(64, 64), ImageRectOffset = Vector2.new((i % 6) * 64, math.floor(i / 6) * 64), ScaleType = Enum.ScaleType.Fit,
		}, parent)
	else
		o = new("TextLabel", { BackgroundTransparency = 1, Text = ICON_GLYPH[name] or "", TextSize = size, TextColor3 = col or C.white, Font = FONT_B, Size = UDim2.new(0, size, 0, size), Position = pos }, parent)
	end
	if props then for k, v in pairs(props) do pcall(function() o[k] = v end) end end
	return o
end
local function iconColor(o, col)
	pcall(function() if o:IsA("ImageLabel") then o.ImageColor3 = col else o.TextColor3 = col end end)
end

local parent = game:GetService("CoreGui")
pcall(function() if gethui then parent = gethui() end end)
local gui = new("ScreenGui", {
	Name = HttpService:GenerateGUID(false):sub(1, 10), ResetOnSpawn = false, IgnoreGuiInset = true,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling, DisplayOrder = 9999,
})
pcall(function() if syn and syn.protect_gui then syn.protect_gui(gui) end end)
gui.Parent = parent

local W, H = 754, 525
local holder = new("Frame", { Size = UDim2.new(0, W, 0, H), Position = UDim2.new(0.5, 0, 0.5, 0), AnchorPoint = Vector2.new(0.5, 0.5), BackgroundTransparency = 1 }, gui)
local scale = new("UIScale", { Scale = 1 }, holder)
local function fit()
	local cam = workspace.CurrentCamera
	if not cam then return end
	local v = cam.ViewportSize
	scale.Scale = math.clamp(math.min((v.X - 40) / W, (v.Y - 60) / H, 1), 0.45, 1)
end
fit()
pcall(function() workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(fit) end)

for i = 1, 4 do
	local s = new("Frame", { Size = UDim2.new(1, i * 10, 1, i * 10), Position = UDim2.new(0.5, 0, 0.5, 4 + i * 2), AnchorPoint = Vector2.new(0.5, 0.5), BackgroundColor3 = C.black, BackgroundTransparency = 0.78 + i * 0.05, BorderSizePixel = 0, ZIndex = 0 }, holder)
	corner(s, 10 + i * 3)
end

local panel = new("Frame", { Size = UDim2.new(1, 0, 1, 0), BackgroundColor3 = C.white, BorderSizePixel = 0, ClipsDescendants = true }, holder)
corner(panel, 8)
hgrad(panel, Color3.fromRGB(16, 16, 19), Color3.fromRGB(9, 9, 11), 60)
stroke(panel, Color3.fromRGB(34, 34, 40), 1)

do
	local dragging, startPos, startMouse = false, nil, nil
	panel.InputBegan:Connect(function(i)
		if i.UserInputType == Enum.UserInputType.MouseButton1 and i.Position.Y - holder.AbsolutePosition.Y < 90 * scale.Scale then
			dragging, startMouse, startPos = true, i.Position, holder.Position
		end
	end)
	UIS.InputChanged:Connect(function(i)
		if dragging and i.UserInputType == Enum.UserInputType.MouseMovement then
			local d = i.Position - startMouse
			holder.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + d.X, startPos.Y.Scale, startPos.Y.Offset + d.Y)
		end
	end)
	UIS.InputEnded:Connect(function(i) if i.UserInputType == Enum.UserInputType.MouseButton1 then dragging = false end end)
end

local side = new("Frame", { Size = UDim2.new(0, 71, 1, 0), BackgroundColor3 = C.side, BorderSizePixel = 0 }, panel)
new("Frame", { Size = UDim2.new(0, 1, 1, 0), Position = UDim2.new(1, -1, 0, 0), BackgroundColor3 = Color3.fromRGB(28, 28, 33), BorderSizePixel = 0 }, side)
icon(side, "crown", 30, C.accent, UDim2.new(0.5, -15, 0, 24))
local dcBtn = new("TextButton", { Size = UDim2.new(0, 28, 0, 28), Position = UDim2.new(0.5, -14, 1, -46), BackgroundTransparency = 1, Text = "", AutoButtonColor = false }, side)
local dcIcon = icon(dcBtn, "discord", 20, C.accent, UDim2.new(0.5, -10, 0.5, -10))

local page = new("Frame", { Size = UDim2.new(1, -71, 1, 0), Position = UDim2.new(0, 71, 0, 0), BackgroundTransparency = 1 }, panel)
local title = label(page, "Burmalda.hook - Loader", 19, C.white, FONT_B, { Position = UDim2.new(0, 30, 0, 20), Size = UDim2.new(0, 400, 0, 26) })
local desc = label(page, T.desc, 12, C.grey, FONT, { Position = UDim2.new(0, 30, 0, 48), Size = UDim2.new(0, 400, 0, 36), TextYAlignment = Enum.TextYAlignment.Top })

local closeBtn = new("TextButton", { Size = UDim2.new(0, 28, 0, 28), Position = UDim2.new(1, -44, 0, 14), BackgroundTransparency = 1, Text = "", AutoButtonColor = false }, page)
local closeIcon = icon(closeBtn, "close", 14, C.grey, UDim2.new(0.5, -7, 0.5, -7))
local langBox = new("Frame", { Size = UDim2.new(0, 92, 0, 24), Position = UDim2.new(1, -44 - 12 - 92, 0, 16), BackgroundColor3 = C.card }, page)
corner(langBox, 6); stroke(langBox)
icon(langBox, "globe", 12, C.grey, UDim2.new(0, 7, 0.5, -6))
local verPill = new("Frame", { Size = UDim2.new(0, 48, 0, 24), Position = UDim2.new(1, -44 - 12 - 92 - 8 - 48, 0, 16), BackgroundColor3 = C.card }, page)
corner(verPill, 6); stroke(verPill)
label(verPill, "v" .. LOADER_VERSION, 10, C.grey, FONT_M, { Size = UDim2.new(1, 0, 1, 0), TextXAlignment = Enum.TextXAlignment.Center })
local langBtns = {}
for i, code in ipairs({ "en", "ru" }) do
	local b = new("TextButton", { Size = UDim2.new(0, 32, 0, 18), Position = UDim2.new(0, 24 + (i - 1) * 33, 0.5, -9), BackgroundColor3 = C.accent, BackgroundTransparency = 1, Text = code:upper(), TextSize = 10, Font = FONT_B, TextColor3 = C.grey, AutoButtonColor = false }, langBox)
	corner(b, 4)
	langBtns[code] = b
end

local toast = new("Frame", { Size = UDim2.new(0, 340, 0, 48), Position = UDim2.new(1, -24, 1, -60), AnchorPoint = Vector2.new(1, 1), BackgroundColor3 = C.card, BackgroundTransparency = 1, Visible = false }, gui)
corner(toast, 6); stroke(toast)
local toastBar = new("Frame", { Size = UDim2.new(0, 3, 1, -12), Position = UDim2.new(0, 0, 0, 6), BackgroundColor3 = C.accent, BorderSizePixel = 0 }, toast)
corner(toastBar, 2)
local toastIcon = icon(toast, "crown", 18, C.accent, UDim2.new(0, 14, 0.5, -9))
local toastText = label(toast, "", 12, C.white, FONT_M, { Position = UDim2.new(0, 42, 0, 0), Size = UDim2.new(1, -52, 1, 0), TextWrapped = true })
local toastTick = 0
local function notify(text, isErr)
	toastTick = toastTick + 1
	local my = toastTick
	toastText.Text = text
	local col = isErr and C.red or C.accent
	toastBar.BackgroundColor3 = col; iconColor(toastIcon, col)
	toast.Visible = true
	toast.BackgroundTransparency = 1; toastText.TextTransparency = 1
	tween(toast, { BackgroundTransparency = 0 }, 0.2); tween(toastText, { TextTransparency = 0 }, 0.2)
	task.delay(3.5, function()
		if toastTick ~= my then return end
		tween(toast, { BackgroundTransparency = 1 }, 0.25); tween(toastText, { TextTransparency = 1 }, 0.25)
		task.delay(0.3, function() if toastTick == my then toast.Visible = false end end)
	end)
end

local s1 = new("Frame", { Size = UDim2.new(1, -30, 1, -100), Position = UDim2.new(0, 30, 0, 100), BackgroundTransparency = 1 }, page)
local sel = new("Frame", { Size = UDim2.new(0, 320, 0, 200), Position = UDim2.new(0.5, -160, 0.5, -110), BackgroundTransparency = 1 }, s1)
icon(sel, "crown", 34, C.accent, UDim2.new(0.5, -17, 0, 0))
local hint = label(sel, T.hint, 12, C.grey, FONT, { Position = UDim2.new(0, 0, 0, 44), Size = UDim2.new(1, 0, 0, 18), TextXAlignment = Enum.TextXAlignment.Center })
local selBtn = new("TextButton", { Size = UDim2.new(1, 0, 0, 44), Position = UDim2.new(0, 0, 0, 74), BackgroundColor3 = C.card, Text = "", AutoButtonColor = false }, sel)
corner(selBtn, 6); local selStroke = stroke(selBtn)
local selText = label(selBtn, T.select, 13, C.white, FONT_M, { Position = UDim2.new(0, 16, 0, 0), Size = UDim2.new(1, -50, 1, 0) })
local selArrow = label(selBtn, "▾", 14, C.accent, FONT_B, { Position = UDim2.new(1, -30, 0, 0), Size = UDim2.new(0, 16, 1, 0), TextXAlignment = Enum.TextXAlignment.Center })
local list = new("Frame", { Size = UDim2.new(1, 0, 0, #GAMES * 48 + 2), Position = UDim2.new(0, 0, 0, 124), BackgroundColor3 = C.card, Visible = false, ClipsDescendants = true }, sel)
corner(list, 6); stroke(list)
local listOpen = false
local function setList(open)
	listOpen = open
	list.Visible = open
	selArrow.Text = open and "▴" or "▾"
	selStroke.Color = open and C.accent or C.border
end
selBtn.MouseButton1Click:Connect(function() setList(not listOpen) end)
selBtn.MouseEnter:Connect(function() selStroke.Color = C.accent end)
selBtn.MouseLeave:Connect(function() if not listOpen then selStroke.Color = C.border end end)

local selectedGame = nil
local showScreen
local gameTags = {}
for i, g in ipairs(GAMES) do
	local item = new("TextButton", { Size = UDim2.new(1, -2, 0, 48), Position = UDim2.new(0, 1, 0, 1 + (i - 1) * 48), BackgroundColor3 = Color3.fromRGB(22, 22, 27), BackgroundTransparency = 1, Text = "", AutoButtonColor = false }, list)
	corner(item, 5)
	local ib = new("Frame", { Size = UDim2.new(0, 28, 0, 28), Position = UDim2.new(0, 12, 0.5, -14), BackgroundColor3 = g.ready and Color3.fromRGB(22, 44, 70) or C.dark }, item)
	corner(ib, 6)
	icon(ib, "crown", 16, g.ready and C.accent or C.dim, UDim2.new(0.5, -8, 0.5, -8))
	label(item, g.name, 13, g.ready and C.white or C.dim, FONT_M, { Position = UDim2.new(0, 52, 0, 0), Size = UDim2.new(1, -170, 1, 0) })
	local tag
	if g.ready then
		tag = icon(item, "arrow", 14, C.accent, UDim2.new(1, -30, 0.5, -7))
	else
		local pill = new("Frame", { Size = UDim2.new(0, 104, 0, 20), Position = UDim2.new(1, -116, 0.5, -10), BackgroundColor3 = C.dark }, item)
		corner(pill, 10)
		tag = label(pill, T.indev, 10, C.dim, FONT_M, { Size = UDim2.new(1, 0, 1, 0), TextXAlignment = Enum.TextXAlignment.Center })
	end
	gameTags[i] = tag
	item.MouseEnter:Connect(function() if g.ready then item.BackgroundTransparency = 0 end end)
	item.MouseLeave:Connect(function() item.BackgroundTransparency = 1 end)
	item.MouseButton1Click:Connect(function()
		if not g.ready then
			tag.TextColor3 = C.red
			notify(T.tdev, true)
			task.delay(2.5, function() tag.TextColor3 = C.dim end)
			return
		end
		selectedGame = g
		setList(false)
		showScreen(2)
	end)
end
if #GAMES > 0 then
	local sep = new("Frame", { Size = UDim2.new(1, -24, 0, 1), Position = UDim2.new(0, 12, 0, 48), BackgroundColor3 = C.border, BorderSizePixel = 0 }, list)
	sep.Visible = #GAMES > 1
end

local s2 = new("Frame", { Size = UDim2.new(1, -30, 1, -134), Position = UDim2.new(0, 30, 0, 112), BackgroundTransparency = 1, Visible = false }, page)
local col = new("Frame", { Size = UDim2.new(0, 272, 1, 0), BackgroundTransparency = 1 }, s2)

local function card(x, w, h, y)
	local f = new("Frame", { Size = UDim2.new(0, w, 0, h), Position = UDim2.new(0, x, 0, y or 0), BackgroundColor3 = C.card }, col)
	corner(f, 6); stroke(f)
	return f
end
local function cardHead(f, iconName, text)
	icon(f, iconName, 14, C.accent, UDim2.new(0, 12, 0, 10))
	return label(f, text, 12, C.grey, FONT, { Position = UDim2.new(0, 32, 0, 8), Size = UDim2.new(1, -40, 0, 18) })
end
local timeCard = card(0, 131, 80)
local timeHead = cardHead(timeCard, "clock", T.time)
local clockL = label(timeCard, "--", 14, C.white, FONT_M, { Position = UDim2.new(0, 12, 0, 32), Size = UDim2.new(1, -20, 0, 18) })
local dateL = label(timeCard, "--", 11, C.grey, FONT, { Position = UDim2.new(0, 12, 0, 52), Size = UDim2.new(1, -20, 0, 16) })
local userCard = card(141, 131, 80)
local userHead = cardHead(userCard, "user", T.user)
local userL = label(userCard, LP.DisplayName or LP.Name, 14, C.white, FONT_M, { Position = UDim2.new(0, 12, 0, 32), Size = UDim2.new(1, -20, 0, 18), TextTruncate = Enum.TextTruncate.AtEnd })

local keyBox = new("TextBox", { Size = UDim2.new(0, 184, 0, 36), Position = UDim2.new(0, 0, 0, 90), BackgroundColor3 = C.card, Text = fread(KEY_FILE) or "", PlaceholderText = T.ph, PlaceholderColor3 = C.dim, TextColor3 = C.white, TextSize = 12, Font = FONT_M, ClearTextOnFocus = false, TextXAlignment = Enum.TextXAlignment.Left }, col)
corner(keyBox, 6); local keyStroke = stroke(keyBox)
new("UIPadding", { PaddingLeft = UDim.new(0, 32), PaddingRight = UDim.new(0, 10) }, keyBox)
icon(col, "key", 14, C.dim, UDim2.new(0, 11, 0, 101))
local chkBtn = new("TextButton", { Size = UDim2.new(0, 80, 0, 36), Position = UDim2.new(0, 192, 0, 90), BackgroundColor3 = C.accent, BackgroundTransparency = 1, Text = T.check, TextSize = 11, Font = FONT_B, TextColor3 = C.accent, AutoButtonColor = false }, col)
corner(chkBtn, 6); stroke(chkBtn, C.accent)
chkBtn.MouseEnter:Connect(function() chkBtn.BackgroundTransparency = 0; chkBtn.TextColor3 = C.panel end)
chkBtn.MouseLeave:Connect(function() chkBtn.BackgroundTransparency = 1; chkBtn.TextColor3 = C.accent end)

local launchBtn = new("TextButton", { Size = UDim2.new(1, 0, 0, 40), Position = UDim2.new(0, 0, 0, 136), BackgroundColor3 = C.white, Text = "", AutoButtonColor = false }, col)
corner(launchBtn, 6)
local launchGrad = hgrad(launchBtn, C.dark, C.dark, 0)
local launchText = label(launchBtn, "", 13, C.dim, FONT_B, { Size = UDim2.new(1, -40, 1, 0), Position = UDim2.new(0, 16, 0, 0), TextXAlignment = Enum.TextXAlignment.Center })
local launchArrow = icon(launchBtn, "arrow", 14, C.dim, UDim2.new(1, -30, 0.5, -7))
local launchGlow = stroke(launchBtn, C.accent, 1, 1)

local status = card(0, 272, 206, 186)
local statusHead = label(status, T.status, 12, C.grey, FONT, { Position = UDim2.new(0, 12, 0, 9), Size = UDim2.new(1, -24, 0, 16) })
local statePill = new("Frame", { Size = UDim2.new(0, 70, 0, 18), Position = UDim2.new(1, -82, 0, 8), BackgroundColor3 = C.dark, Visible = false }, status)
corner(statePill, 9)
local statePillText = label(statePill, "", 9, C.white, FONT_B, { Size = UDim2.new(1, 0, 1, 0), TextXAlignment = Enum.TextXAlignment.Center })
local shieldIcon = icon(status, "shield", 18, C.dim, UDim2.new(0, 12, 0, 31))
local licL = label(status, T.nolic, 13, C.white, FONT_M, { Position = UDim2.new(0, 38, 0, 30), Size = UDim2.new(1, -48, 0, 20) })
local subL = label(status, T.enterkey, 11, C.grey, FONT, { Position = UDim2.new(0, 12, 0, 54), Size = UDim2.new(1, -24, 0, 18), TextTruncate = Enum.TextTruncate.AtEnd })
local timerF = new("Frame", { Size = UDim2.new(1, -24, 0, 40), Position = UDim2.new(0, 12, 0, 78), BackgroundTransparency = 1, Visible = false }, status)
local timerNums, timerCaps = {}, {}
for i, cap in ipairs({ "days", "hours", "mins" }) do
	local x = (i - 1) / 3
	timerNums[i] = label(timerF, "0", 20, C.accent, FONT_M, { Position = UDim2.new(x, 0, 0, 0), Size = UDim2.new(1 / 3, 0, 0, 22), TextXAlignment = Enum.TextXAlignment.Center })
	timerCaps[i] = label(timerF, T[cap], 10, C.grey, FONT, { Position = UDim2.new(x, 0, 0, 24), Size = UDim2.new(1 / 3, 0, 0, 14), TextXAlignment = Enum.TextXAlignment.Center })
	if i < 3 then
		local dot = new("Frame", { Size = UDim2.new(0, 5, 0, 5), Position = UDim2.new(x + 1 / 3, -2, 0, 9), BackgroundColor3 = C.accent }, timerF)
		corner(dot, 3)
	end
end
local divider = new("Frame", { Size = UDim2.new(1, -24, 0, 1), Position = UDim2.new(0, 12, 0, 124), BackgroundColor3 = C.border, BorderSizePixel = 0, Visible = false }, status)
local metaF = new("Frame", { Size = UDim2.new(1, -24, 0, 70), Position = UDim2.new(0, 12, 0, 132), BackgroundTransparency = 1, Visible = false }, status)
icon(metaF, "calendar", 12, C.grey, UDim2.new(0, 0, 0, 1))
local expCap = label(metaF, T.expires, 11, C.grey, FONT, { Position = UDim2.new(0, 18, 0, 0), Size = UDim2.new(1, -18, 0, 14) })
local expL = label(metaF, "-", 12, C.white, FONT_M, { Position = UDim2.new(0, 18, 0, 15), Size = UDim2.new(1, -18, 0, 18) })
icon(metaF, "cart", 12, C.grey, UDim2.new(0, 0, 0, 37))
local resCap = label(metaF, T.reseller, 11, C.grey, FONT, { Position = UDim2.new(0, 18, 0, 36), Size = UDim2.new(1, -18, 0, 14) })
label(metaF, "N/A", 12, C.white, FONT_M, { Position = UDim2.new(0, 18, 0, 51), Size = UDim2.new(1, -18, 0, 18) })

local backBtn = new("TextButton", { Size = UDim2.new(0, 160, 0, 16), Position = UDim2.new(0, 0, 1, 4), BackgroundTransparency = 1, Text = "←  " .. T.back, TextSize = 11, Font = FONT_M, TextColor3 = C.grey, TextXAlignment = Enum.TextXAlignment.Left, AutoButtonColor = false }, col)
backBtn.MouseEnter:Connect(function() backBtn.TextColor3 = C.accent end)
backBtn.MouseLeave:Connect(function() backBtn.TextColor3 = C.grey end)

local pic = new("Frame", { Size = UDim2.new(1, -292, 1, 22), Position = UDim2.new(0, 292, 0, 0), BackgroundTransparency = 1, ClipsDescendants = true }, s2)
local glow = new("ImageLabel", { Size = UDim2.new(0, 460, 0, 460), Position = UDim2.new(0.5, 0, 0.55, 0), AnchorPoint = Vector2.new(0.5, 0.5), BackgroundTransparency = 1, Image = "", ImageColor3 = C.accent, ImageTransparency = 1 }, pic)
local img = new("ImageLabel", { Size = UDim2.new(1, 0, 1, -16), Position = UDim2.new(0, 0, 0, 16), BackgroundTransparency = 1, ScaleType = Enum.ScaleType.Fit, Image = "", ImageTransparency = 1 }, pic)
new("UIGradient", { Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.14, 0), NumberSequenceKeypoint.new(0.86, 0), NumberSequenceKeypoint.new(1, 1) }) }, img)
task.spawn(function()
	local g = customAsset(GLOW_FILE, GLOW_B64)
	if g then glow.Image = g; tween(glow, { ImageTransparency = 0.72 }, 0.6) end
	local asset = customAsset(IMG_FILE, MASCOT_B64)
	if asset then
		img.Image = asset
		tween(img, { ImageTransparency = 0 }, 0.4)
	end
end)

local state = { screen = 1, key = nil, accepted = false, expires = nil, lifetime = false, busy = false, auth = false, closed = false }

local function pad(n) return (n < 10 and "0" or "") .. n end
local function fmtDate(t, withTime)
	local d = os.date("*t", t)
	local s
	if LANG == "ru" then
		s = d.day .. " " .. MONTHS.ru[d.month] .. " " .. d.year
		if withTime then s = s .. ", " .. pad(d.hour) .. ":" .. pad(d.min) end
	else
		s = MONTHS.en[d.month] .. " " .. d.day .. ", " .. d.year
		if withTime then
			local h, ap = d.hour % 12, d.hour >= 12 and "PM" or "AM"
			if h == 0 then h = 12 end
			s = s .. ", " .. pad(h) .. ":" .. pad(d.min) .. " " .. ap
		end
	end
	return s
end
local function human(sec)
	local d, h, m = math.floor(sec / 86400), math.floor(sec % 86400 / 3600), math.floor(sec % 3600 / 60)
	if d > 0 then return d .. T.d .. h .. T.h end
	if h > 0 then return h .. T.h .. m .. T.m end
	return m .. T.m
end

local function setLaunch(mode, text)
	launchText.Text = text or (T.launch .. (selectedGame and selectedGame.name:upper() or ""))
	if mode == "off" then
		launchGrad.Color = ColorSequence.new(C.dark, C.dark); launchText.TextColor3 = C.dim; iconColor(launchArrow, C.dim); launchGlow.Transparency = 1
	elseif mode == "busy" then
		launchGrad.Color = ColorSequence.new(Color3.fromRGB(36, 118, 196), Color3.fromRGB(22, 92, 170)); launchText.TextColor3 = C.panel; iconColor(launchArrow, C.panel); launchGlow.Transparency = 0.7
	elseif mode == "fail" then
		launchGrad.Color = ColorSequence.new(C.red, Color3.fromRGB(180, 70, 70)); launchText.TextColor3 = C.panel; iconColor(launchArrow, C.panel); launchGlow.Transparency = 1
	else
		launchGrad.Color = ColorSequence.new(C.accent, C.accent2); launchText.TextColor3 = C.panel; iconColor(launchArrow, C.panel); launchGlow.Transparency = 0.4
	end
end

local function renderStatus(kind, line1, line2)

	timerF.Visible = kind == "ok"
	metaF.Visible = kind == "ok"
	divider.Visible = kind == "ok"
	statePill.Visible = kind == "ok" or kind == "bad"
	if kind == "ok" then
		iconColor(shieldIcon, C.accent); licL.TextColor3 = C.white; subL.TextColor3 = C.grey
		statePill.BackgroundColor3 = Color3.fromRGB(22, 44, 70); statePillText.TextColor3 = C.accent; statePillText.Text = T.pillok
	elseif kind == "bad" then
		iconColor(shieldIcon, C.red); licL.TextColor3 = C.red; subL.TextColor3 = C.grey
		statePill.BackgroundColor3 = Color3.fromRGB(62, 30, 32); statePillText.TextColor3 = C.red; statePillText.Text = T.pillbad
	elseif kind == "wait" then
		iconColor(shieldIcon, C.accent); licL.TextColor3 = C.white; subL.TextColor3 = C.grey
	else
		iconColor(shieldIcon, C.dim); licL.TextColor3 = C.white; subL.TextColor3 = C.grey
	end
	if line1 then licL.Text = line1 end
	if line2 then subL.Text = line2 end
end

local function tickClock()
	local now = os.time()
	local d = os.date("*t", now)
	if LANG == "ru" then
		clockL.Text = pad(d.hour) .. ":" .. pad(d.min) .. ":" .. pad(d.sec)
	else
		local h, ap = d.hour % 12, d.hour >= 12 and "PM" or "AM"
		if h == 0 then h = 12 end
		clockL.Text = pad(h) .. ":" .. pad(d.min) .. ":" .. pad(d.sec) .. " " .. ap
	end
	dateL.Text = fmtDate(now, false)
	if state.auth then
		if state.lifetime then
			timerNums[1].Text = "∞"; timerNums[2].Text = "∞"; timerNums[3].Text = "∞"
			subL.Text = T.left .. T.life; expL.Text = T.never
		elseif state.expires then
			local left = math.max(0, state.expires - now)
			timerNums[1].Text = tostring(math.floor(left / 86400))
			timerNums[2].Text = tostring(math.floor(left % 86400 / 3600))
			timerNums[3].Text = tostring(math.floor(left % 3600 / 60))
			subL.Text = T.left .. human(left)
			expL.Text = fmtDate(state.expires, true)
			if left <= 0 then renderStatus("bad", T.expired, "") end
		end
	end
end

local function applyLang(code)
	LANG = code; T = I18N[code]
	fwrite(LANG_FILE, code)
	for c, b in pairs(langBtns) do
		b.BackgroundTransparency = (c == code) and 0 or 1
		b.TextColor3 = (c == code) and C.panel or C.grey
	end
	desc.Text = T.desc; hint.Text = T.hint; selText.Text = T.select
	for i, g in ipairs(GAMES) do if not g.ready then pcall(function() gameTags[i].Text = T.indev end) end end
	timeHead.Text = T.time; userHead.Text = T.user; keyBox.PlaceholderText = T.ph
	if not state.busy then chkBtn.Text = T.check end
	statusHead.Text = T.status; if statePill.Visible then statePillText.Text = (state.auth and T.pillok or T.pillbad) end; expCap.Text = T.expires; resCap.Text = T.reseller; backBtn.Text = "←  " .. T.back
	timerCaps[1].Text = T.days; timerCaps[2].Text = T.hours; timerCaps[3].Text = T.mins
	if state.auth then
		renderStatus("ok", T.active, nil)
		setLaunch(state.busy and "busy" or "on")
	elseif state.accepted then
		renderStatus("wait", T.accepted, T.waitauth)
		setLaunch("off")
	elseif state.badMsg then
		renderStatus("bad", T.invalid, state.badMsg)
		setLaunch("off")
	else
		renderStatus("none", T.nolic, T.enterkey)
		setLaunch("off")
	end
	tickClock()
end
for code, b in pairs(langBtns) do b.MouseButton1Click:Connect(function() applyLang(code) end) end

showScreen = function(n)
	state.screen = n
	s1.Visible = n == 1
	s2.Visible = n == 2
	if n == 2 then setLaunch("off"); task.defer(function() pcall(function() keyBox:CaptureFocus() end) end) end
end

local function closeGui()
	if state.closed then return end
	state.closed = true
	tween(panel, { BackgroundTransparency = 1 }, 0.25)
	for _, d in ipairs(panel:GetDescendants()) do
		pcall(function()
			if d:IsA("TextLabel") or d:IsA("TextButton") or d:IsA("TextBox") then tween(d, { TextTransparency = 1, BackgroundTransparency = 1 }, 0.25)
			elseif d:IsA("Frame") then tween(d, { BackgroundTransparency = 1 }, 0.25)
			elseif d:IsA("ImageLabel") then tween(d, { ImageTransparency = 1 }, 0.25)
			elseif d:IsA("UIStroke") then tween(d, { Transparency = 1 }, 0.25) end
		end)
	end
	task.delay(0.35, function() pcall(function() holder.Visible = false end) end)
	task.delay(4.5, function() pcall(function() gui:Destroy() end) end)
end
closeBtn.MouseEnter:Connect(function() iconColor(closeIcon, C.white) end)
closeBtn.MouseLeave:Connect(function() iconColor(closeIcon, C.grey) end)
closeBtn.MouseButton1Click:Connect(function()
	if not state.accepted then getgenv().UI_CLOSED = true end
	closeGui()
end)
dcBtn.MouseButton1Click:Connect(function()
	local ok = pcall(function() (setclipboard or toclipboard)(DISCORD_INVITE) end)
	notify(ok and T.tdc or DISCORD_INVITE, false)
end)
backBtn.MouseButton1Click:Connect(function() if not state.accepted then showScreen(1) end end)

local Junkie = nil
local function sdk()
	if Junkie ~= nil then return Junkie end
	if JNKIE_SERVICE == "" or JNKIE_IDENTIFIER == "" then Junkie = false return false end
	local ok, lib = pcall(function() return loadstring(game:HttpGet("https://jnkie.com/sdk/library.lua"))() end)
	if ok and type(lib) == "table" and type(lib.check_key) == "function" then
		lib.service = JNKIE_SERVICE
		lib.identifier = JNKIE_IDENTIFIER
		Junkie = lib
	else
		Junkie = false
	end
	return Junkie
end

local function errText(code)
	code = tostring(code or "")
	return T["e_" .. code] or (T.invalid .. (code ~= "" and (" (" .. code .. ")") or ""))
end

local function acceptKey(key)
	state.key = key
	state.accepted = true
	state.badMsg = nil
	fwrite(KEY_FILE, key)
	keyStroke.Color = C.accent
	renderStatus("wait", T.accepted, T.waitauth)
	setLaunch("off")
	getgenv().AQUA_GAME = selectedGame and selectedGame.id or "hvh"
	getgenv().SCRIPT_KEY = key

	task.delay(15, function()
		if not state.auth and not state.closed then
			state.accepted = false
			state.badMsg = T.trej
			keyStroke.Color = C.red
			renderStatus("bad", T.invalid, T.trej)
			notify(T.trej, true)
		end
	end)
end

local function rejectKey(msg)
	state.accepted = false
	state.badMsg = msg
	keyStroke.Color = C.red
	renderStatus("bad", T.invalid, msg)
	setLaunch("off")
	notify(msg, true)
end

local function checkKey()
	if state.busy or state.accepted then return end
	local key = (keyBox.Text or ""):gsub("^%s+", ""):gsub("%s+$", "")
	if key == "" then notify(T.tkey, true) return end
	state.busy = true
	chkBtn.Text = T.checking
	keyStroke.Color = C.border
	task.spawn(function()
		local lib = sdk()
		if lib then
			local ok, res = pcall(lib.check_key, key)
			state.busy = false
			chkBtn.Text = T.check
			if not ok or type(res) ~= "table" then
				notify(T.tnet, true)
				keyStroke.Color = C.border
				return
			end
			if res.valid then acceptKey(key) else rejectKey(errText(res.error)) end
		else
			state.busy = false
			chkBtn.Text = T.check
			acceptKey(key)
		end
	end)
end
chkBtn.MouseButton1Click:Connect(checkKey)
keyBox.FocusLost:Connect(function(enter) if enter then checkKey() end end)
keyBox.Focused:Connect(function() if not state.accepted then keyStroke.Color = C.accent end end)

local launchCb = nil
launchBtn.MouseButton1Click:Connect(function()
	if state.busy or not state.auth or not launchCb then return end
	state.busy = true
	setLaunch("busy", T.loading)
	task.spawn(function()
		local ok = pcall(launchCb)
		if not ok then
			state.busy = false
			setLaunch("fail", T.failed)
		end
	end)
end)

getgenv().BURMALDA_LOADER = {

	license = function(expiresAt, reason, userName)
		state.auth = true
		state.lifetime = (expiresAt == nil)
		state.expires = expiresAt
		if type(userName) == "string" and userName ~= "" then userL.Text = userName end
		keyStroke.Color = C.accent
		renderStatus("ok", T.active, nil)
		tickClock()
		setLaunch("on")
		local lifeText = state.lifetime and T.life or human(math.max(0, (expiresAt or 0) - os.time()))
		notify(T.active .. " - " .. T.left .. lifeText, false)
	end,
	onLaunch = function(cb) launchCb = cb end,
	progress = function(step)
		if step == "launched" then
			state.busy = false
			setLaunch("on", T.launched)
			notify((selectedGame and selectedGame.name or "script") .. T.tload, false)
			task.delay(0.9, closeGui)
		elseif step == "failed" then
			state.busy = false
			setLaunch("fail", T.failed)
		else
			setLaunch("busy", T[step] or step)
		end
	end,
	fail = function(msg)
		state.busy = false
		setLaunch("fail", T.failed)
		if msg then notify(tostring(msg), true) end
	end,
	notify = notify,
	close = closeGui,
	game = function() return selectedGame and selectedGame.id or "hvh" end,
}

applyLang(LANG)
showScreen(1)
task.spawn(function()
	while not state.closed and gui.Parent do
		pcall(tickClock)
		task.wait(1)
	end
end)

repeat task.wait(0.1) until getgenv().SCRIPT_KEY or getgenv().UI_CLOSED or state.closed
if not getgenv().SCRIPT_KEY then
	getgenv().UI_CLOSED = true
	return
end
