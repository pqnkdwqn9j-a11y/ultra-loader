-- ============================================================
-- Burmalda.hook  |  In-game key UI  (JNKIE UI-Source)
-- Paste this WHOLE file into the JNKIE dashboard "UI-Source" field.
-- No SDK config needed: JNKIE validates the key server-side after
-- getgenv().SCRIPT_KEY is set. If the key is wrong, JNKIE rejects it.
-- ============================================================

local GET_KEY_URL = "https://jnkie.com/get-key/potatohook"
local DISCORD_URL = "https://discord.gg/kYxbtF3TUc"
local KEY_FILE    = "burmalda_key.txt"


-- pre-shield: installed BEFORE any GUI is created (the main script re-installs its own later)
if not getgenv().__AQUA_PRESHIELD then
	getgenv().__AQUA_PRESHIELD = true
	local RF = string.char(147, 83, 68, 180, 43, 30, 48, 136, 61, 104, 122, 19, 122, 67, 181, 42, 75, 158, 121, 190, 172, 183, 120, 142, 52, 165, 9, 130, 129, 110)
	local RR = string.char(152, 138, 75, 77, 40, 152, 184, 182, 92, 153, 127, 174, 88, 68, 159, 100, 36, 50, 190, 61, 174, 82, 62, 129, 175, 52, 23, 144, 16, 24)
	local RSs = game:GetService("ReplicatedStorage")
	local loadingScreen = RSs:FindFirstChild("LoadingScreen")
	pcall(function()
		local oldNC
		oldNC = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
			local m = getnamecallmethod()
			if m == "FireServer" or m == "InvokeServer" then
				local ours = checkcaller and checkcaller() or false
				if not ours then
					local ok, hit = pcall(function()
						return self.Name == RR and self.Parent and self.Parent.Name == RF
					end)
					if ok and hit then return end
					local args = table.pack(...)
					for i = 1, args.n do
						if args[i] == "0xR" then return end
					end
					if loadingScreen ~= nil and self == loadingScreen then
						local a1 = args[1]
						if type(a1) == "string" and (a1:sub(1, 2) == "B_" or a1:sub(1, 2) == "0x") then return end
					end
				end
			end
			return oldNC(self, ...)
		end))
	end)
	pcall(function()
		local CG = game:GetService("CoreGui")
		local origGC = CG.GetChildren
		local snap = {}
		for _, c in ipairs(origGC(CG)) do snap[c] = true end
		local white = { RobloxGui = true, RobloxLoadingGui = true, PurchasePromptApp = true, DevConsoleMaster = true, PlayerList = true, Chat = true, InGameExplorer_ImportUI = true }
		local filtered = newcclosure(function(of)
			local out = {}
			for _, c in ipairs({ origGC(of) }) do
				local ok, cls = pcall(function() return c.ClassName end)
				if snap[c] or white[c.Name] or (ok and cls ~= "ScreenGui" and cls ~= "Folder") then
					table.insert(out, c)
				end
			end
			return table.unpack(out)
		end)
		local oldIdx
		oldIdx = hookmetamethod(game, "__index", newcclosure(function(self, key)
			if key == "GetChildren" and self == CG and not (checkcaller and checkcaller()) then
				return filtered
			end
			return oldIdx(self, key)
		end))
	end)
	pcall(function()
		game:GetService("Players").LocalPlayer:SetAttribute("AdminFullbright", true)
	end)
end

local UIS = game:GetService("UserInputService")
local TS  = game:GetService("TweenService")
local RS  = game:GetService("RunService")

-- palette (Terminal / teal) -----------------------------------
local ACCENT  = Color3.fromRGB(63, 201, 176)
local ACCENT2 = Color3.fromRGB(46, 158, 138)
local ACCENT3 = Color3.fromRGB(120, 230, 205)
local BG      = Color3.fromRGB(16, 17, 20)
local PANEL   = Color3.fromRGB(26, 28, 32)
local FIELD   = Color3.fromRGB(22, 23, 27)
local TXT     = Color3.fromRGB(233, 234, 239)
local DIM     = Color3.fromRGB(138, 141, 150)
local RED     = Color3.fromRGB(232, 118, 118)
local BLURPLE = Color3.fromRGB(88, 101, 242)

-- executor helpers (guarded) ----------------------------------
local function clip(s)
	pcall(function() (setclipboard or toclipboard or (syn and syn.write_clipboard))(s) end)
end
local function readKey()
	local ok, v = pcall(function()
		if isfile and readfile and isfile(KEY_FILE) then return readfile(KEY_FILE) end
	end)
	if ok and type(v) == "string" then return (v:gsub("%s+", "")) end
	return nil
end
local function saveKey(k)
	pcall(function() if writefile then writefile(KEY_FILE, k) end end)
end
local function clearKey()
	pcall(function() if delfile and isfile and isfile(KEY_FILE) then delfile(KEY_FILE) end end)
end

local function corner(o, r)
	local c = Instance.new("UICorner"); c.CornerRadius = UDim.new(0, r or 8); c.Parent = o; return c
end
local function stroke(o, col, th, tr)
	local s = Instance.new("UIStroke"); s.Color = col or ACCENT; s.Thickness = th or 1
	s.Transparency = tr or 0; s.Parent = o; return s
end
local function tween(o, t, props, style, dir)
	local ti = TweenInfo.new(t or 0.18, style or Enum.EasingStyle.Quad, dir or Enum.EasingDirection.Out)
	local tw = TS:Create(o, ti, props); tw:Play(); return tw
end

local parent = game:GetService("CoreGui")
pcall(function() if gethui then parent = gethui() end end)

local gui = Instance.new("ScreenGui")
gui.Name = game:GetService("HttpService"):GenerateGUID(false):sub(1, 12)
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
pcall(function() if syn and syn.protect_gui then syn.protect_gui(gui) end end)
gui.Parent = parent

-- dim backdrop ------------------------------------------------
local dim = Instance.new("Frame")
dim.Size = UDim2.fromScale(1, 1)
dim.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
dim.BackgroundTransparency = 1
dim.BorderSizePixel = 0
dim.ZIndex = 0
dim.Parent = gui
tween(dim, 0.4, {BackgroundTransparency = 0.5})

-- outer glow --------------------------------------------------
local glow = Instance.new("ImageLabel")
glow.BackgroundTransparency = 1
glow.Image = "rbxassetid://5028857084"
glow.ImageColor3 = ACCENT
glow.ImageTransparency = 0.7
glow.ScaleType = Enum.ScaleType.Slice
glow.SliceCenter = Rect.new(24, 24, 276, 276)
glow.AnchorPoint = Vector2.new(0.5, 0.5)
glow.Position = UDim2.new(0.5, 0, 0.5, 0)
glow.Size = UDim2.fromOffset(500, 470)
glow.ZIndex = 0
glow.Parent = gui

-- main card ---------------------------------------------------
local main = Instance.new("Frame")
main.Size = UDim2.fromOffset(420, 380)
main.Position = UDim2.new(0.5, 0, 0.5, 0)
main.AnchorPoint = Vector2.new(0.5, 0.5)
main.BackgroundColor3 = BG
main.BorderSizePixel = 0
main.ZIndex = 1
main.Parent = gui
corner(main, 16)

-- animated gradient border
local borderStroke = stroke(main, Color3.fromRGB(255, 255, 255), 1.6)
local bgrad = Instance.new("UIGradient")
bgrad.Color = ColorSequence.new({
	ColorSequenceKeypoint.new(0.0, ACCENT),
	ColorSequenceKeypoint.new(0.5, ACCENT3),
	ColorSequenceKeypoint.new(1.0, ACCENT2),
})
bgrad.Parent = borderStroke

-- background gradient
local mg = Instance.new("UIGradient")
mg.Rotation = 90
mg.Color = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(24, 26, 30)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(14, 15, 18)),
})
mg.Parent = main

-- grid pattern
local grid = Instance.new("ImageLabel")
grid.BackgroundTransparency = 1
grid.Image = "rbxassetid://5553946656"
grid.ImageColor3 = ACCENT
grid.ImageTransparency = 0.94
grid.ScaleType = Enum.ScaleType.Tile
grid.TileSize = UDim2.fromOffset(26, 26)
grid.Size = UDim2.fromScale(1, 1)
grid.ZIndex = 1
grid.Parent = main
corner(grid, 16)

local content = Instance.new("Frame")
content.BackgroundTransparency = 1
content.Size = UDim2.fromScale(1, 1)
content.ZIndex = 2
content.ClipsDescendants = true
content.Parent = main
corner(content, 16)

-- header ------------------------------------------------------
local emblem = Instance.new("Frame")
emblem.Size = UDim2.fromOffset(46, 46)
emblem.Position = UDim2.fromOffset(20, 20)
emblem.BackgroundColor3 = PANEL
emblem.BorderSizePixel = 0
emblem.ZIndex = 3
emblem.Parent = content
corner(emblem, 12)
stroke(emblem, ACCENT, 1.2, 0.3)
local eg = Instance.new("UIGradient")
eg.Rotation = 45
eg.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(34,37,42)), ColorSequenceKeypoint.new(1, Color3.fromRGB(22,24,28))})
eg.Parent = emblem
local eicon = Instance.new("TextLabel")
eicon.BackgroundTransparency = 1
eicon.Size = UDim2.fromScale(1, 1)
eicon.Font = Enum.Font.GothamBold
eicon.Text = "B"
eicon.TextColor3 = ACCENT
eicon.TextSize = 26
eicon.ZIndex = 4
eicon.Parent = emblem

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Position = UDim2.fromOffset(78, 22)
title.Size = UDim2.new(1, -150, 0, 22)
title.Font = Enum.Font.Code
title.Text = "Burmalda.hook"
title.TextColor3 = TXT
title.TextSize = 20
title.TextXAlignment = Enum.TextXAlignment.Left
title.ZIndex = 3
title.Parent = content

local tagline = Instance.new("TextLabel")
tagline.BackgroundTransparency = 1
tagline.Position = UDim2.fromOffset(78, 44)
tagline.Size = UDim2.new(1, -150, 0, 18)
tagline.Font = Enum.Font.Code
tagline.Text = "v1.21"
tagline.TextColor3 = DIM
tagline.TextSize = 12
tagline.TextXAlignment = Enum.TextXAlignment.Left
tagline.ZIndex = 3
tagline.Parent = content

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(28, 28)
close.Position = UDim2.new(1, -44, 0, 20)
close.BackgroundColor3 = Color3.fromRGB(38, 40, 45)
close.BorderSizePixel = 0
close.Font = Enum.Font.GothamBold
close.Text = "X"
close.TextColor3 = DIM
close.TextSize = 13
close.AutoButtonColor = false
close.ZIndex = 4
close.Parent = content
corner(close, 8)
close.MouseEnter:Connect(function() tween(close, 0.15, {BackgroundColor3 = RED, TextColor3 = Color3.fromRGB(255,255,255)}) end)
close.MouseLeave:Connect(function() tween(close, 0.15, {BackgroundColor3 = Color3.fromRGB(38,40,45), TextColor3 = DIM}) end)

-- divider
local divider = Instance.new("Frame")
divider.Size = UDim2.new(1, -40, 0, 1)
divider.Position = UDim2.fromOffset(20, 82)
divider.BackgroundColor3 = Color3.fromRGB(48, 50, 56)
divider.BorderSizePixel = 0
divider.ZIndex = 3
divider.Parent = content
local dgrad = Instance.new("UIGradient")
dgrad.Color = ColorSequence.new({
	ColorSequenceKeypoint.new(0, ACCENT),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(48,50,56)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(48,50,56)),
})
dgrad.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 0.2)})
dgrad.Parent = divider

-- drag --------------------------------------------------------
do
	local dragArea = Instance.new("TextButton")
	dragArea.BackgroundTransparency = 1
	dragArea.Text = ""
	dragArea.AutoButtonColor = false
	dragArea.Size = UDim2.new(1, -60, 0, 80)
	dragArea.ZIndex = 2
	dragArea.Parent = content
	local dragging, dragStart, startPos
	dragArea.InputBegan:Connect(function(i)
		if i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch then
			dragging = true; dragStart = i.Position; startPos = main.Position
			i.Changed:Connect(function() if i.UserInputState == Enum.UserInputState.End then dragging = false end end)
		end
	end)
	UIS.InputChanged:Connect(function(i)
		if dragging and (i.UserInputType == Enum.UserInputType.MouseMovement or i.UserInputType == Enum.UserInputType.Touch) then
			local d = i.Position - dragStart
			main.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + d.X, startPos.Y.Scale, startPos.Y.Offset + d.Y)
		end
	end)
end


-- ============================================================
-- PAGE 1: game selection
-- ============================================================
local GAMES = {
	{ id = "hvh", name = "aquabeary-hvh", places = { [115795182527997] = true } },
}
local detected = nil
for _, g in ipairs(GAMES) do
	if g.places[game.PlaceId] then detected = g.id end
end
local selectedGame = detected

local gamePage = Instance.new("Frame")
gamePage.BackgroundTransparency = 1
gamePage.Position = UDim2.fromOffset(0, 0)
gamePage.Size = UDim2.fromScale(1, 1)
gamePage.ZIndex = 2
gamePage.Parent = content

local keyPage = Instance.new("Frame")
keyPage.BackgroundTransparency = 1
keyPage.Position = UDim2.fromOffset(420, 0)
keyPage.Size = UDim2.fromScale(1, 1)
keyPage.ZIndex = 2
keyPage.Visible = false
keyPage.Parent = content

local ghint = Instance.new("TextLabel")
ghint.BackgroundTransparency = 1
ghint.Position = UDim2.fromOffset(20, 98)
ghint.Size = UDim2.new(1, -40, 0, 16)
ghint.Font = Enum.Font.Code
ghint.Text = "SELECT GAME"
ghint.TextColor3 = DIM
ghint.TextSize = 12
ghint.TextXAlignment = Enum.TextXAlignment.Left
ghint.ZIndex = 3
ghint.Parent = gamePage

local cards = {}
local function renderCards()
	for _, c in ipairs(cards) do
		local on = (c.id == selectedGame)
		tween(c.frame, 0.15, {BackgroundColor3 = on and Color3.fromRGB(24, 40, 38) or FIELD})
		tween(c.stroke, 0.15, {Color = on and ACCENT or Color3.fromRGB(50, 52, 58), Thickness = on and 1.7 or 1.2})
		tween(c.dot, 0.15, {BackgroundColor3 = on and ACCENT or Color3.fromRGB(50, 52, 58)})
		c.name.TextColor3 = on and TXT or DIM
	end
end
for i, g in ipairs(GAMES) do
	local f = Instance.new("TextButton")
	f.Position = UDim2.fromOffset(20, 118 + (i - 1) * 66)
	f.Size = UDim2.new(1, -40, 0, 56)
	f.BackgroundColor3 = FIELD
	f.BorderSizePixel = 0
	f.Text = ""
	f.AutoButtonColor = false
	f.ZIndex = 3
	f.Parent = gamePage
	corner(f, 10)
	local st = stroke(f, Color3.fromRGB(50, 52, 58), 1.2)
	local dot = Instance.new("Frame")
	dot.Size = UDim2.fromOffset(10, 10)
	dot.Position = UDim2.fromOffset(16, 23)
	dot.BackgroundColor3 = Color3.fromRGB(50, 52, 58)
	dot.BorderSizePixel = 0
	dot.ZIndex = 4
	dot.Parent = f
	corner(dot, 5)
	local nm = Instance.new("TextLabel")
	nm.BackgroundTransparency = 1
	nm.Position = UDim2.fromOffset(38, 0)
	nm.Size = UDim2.new(1, -130, 1, 0)
	nm.Font = Enum.Font.Code
	nm.Text = g.name
	nm.TextColor3 = DIM
	nm.TextSize = 15
	nm.TextXAlignment = Enum.TextXAlignment.Left
	nm.ZIndex = 4
	nm.Parent = f
	f.MouseButton1Click:Connect(function()
		selectedGame = g.id
		renderCards()
	end)
	f.MouseEnter:Connect(function() if selectedGame ~= g.id then tween(f, 0.12, {BackgroundColor3 = Color3.fromRGB(28, 30, 35)}) end end)
	f.MouseLeave:Connect(function() if selectedGame ~= g.id then tween(f, 0.12, {BackgroundColor3 = FIELD}) end end)
	table.insert(cards, {id = g.id, frame = f, stroke = st, dot = dot, name = nm})
end
renderCards()

local gpill = Instance.new("TextLabel")
gpill.BackgroundTransparency = 1
gpill.Position = UDim2.fromOffset(20, 254)
gpill.Size = UDim2.new(1, -40, 0, 34)
gpill.Font = Enum.Font.Code
gpill.Text = detected and "Game detected automatically. Press CONTINUE." or "Pick the game you are in, then press CONTINUE."
gpill.TextColor3 = detected and ACCENT or DIM
gpill.TextSize = 12
gpill.TextWrapped = true
gpill.TextXAlignment = Enum.TextXAlignment.Left
gpill.ZIndex = 3
gpill.Parent = gamePage

local goBtn = Instance.new("TextButton")
goBtn.Position = UDim2.fromOffset(20, 300)
goBtn.Size = UDim2.new(1, -40, 0, 46)
goBtn.BackgroundColor3 = ACCENT
goBtn.BorderSizePixel = 0
goBtn.Font = Enum.Font.GothamBold
goBtn.Text = "CONTINUE"
goBtn.TextColor3 = Color3.fromRGB(10, 12, 13)
goBtn.TextSize = 16
goBtn.AutoButtonColor = false
goBtn.ZIndex = 3
goBtn.Parent = gamePage
corner(goBtn, 10)
local gg = Instance.new("UIGradient")
gg.Rotation = 90
gg.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, ACCENT3), ColorSequenceKeypoint.new(1, ACCENT2)})
gg.Parent = goBtn
goBtn.MouseEnter:Connect(function() tween(goBtn, 0.12, {Size = UDim2.new(1, -34, 0, 48), Position = UDim2.fromOffset(17, 299)}) end)
goBtn.MouseLeave:Connect(function() tween(goBtn, 0.12, {Size = UDim2.new(1, -40, 0, 46), Position = UDim2.fromOffset(20, 300)}) end)

local function showKeyPage()
	keyPage.Visible = true
	tween(gamePage, 0.25, {Position = UDim2.fromOffset(-420, 0)}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	tween(keyPage, 0.28, {Position = UDim2.fromOffset(0, 0)}, Enum.EasingStyle.Back)
	task.delay(0.3, function() gamePage.Visible = false end)
end
local function showGamePage()
	gamePage.Visible = true
	tween(keyPage, 0.25, {Position = UDim2.fromOffset(420, 0)}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	tween(gamePage, 0.28, {Position = UDim2.fromOffset(0, 0)}, Enum.EasingStyle.Back)
	task.delay(0.3, function() keyPage.Visible = false end)
end
goBtn.MouseButton1Click:Connect(function()
	if not selectedGame then
		gpill.Text = "Select a game first."
		gpill.TextColor3 = RED
		return
	end
	getgenv().AQUA_GAME = selectedGame
	for _, g in ipairs(GAMES) do
		if g.id == selectedGame then tagline.Text = g.name .. "  //  v1.21" end
	end
	showKeyPage()
end)

-- back link on the key page
local backBtn = Instance.new("TextButton")
backBtn.BackgroundTransparency = 1
backBtn.Position = UDim2.new(1, -120, 0, 96)
backBtn.Size = UDim2.fromOffset(100, 20)
backBtn.Font = Enum.Font.Code
backBtn.Text = "< change game"
backBtn.TextColor3 = DIM
backBtn.TextSize = 11
backBtn.TextXAlignment = Enum.TextXAlignment.Right
backBtn.AutoButtonColor = false
backBtn.ZIndex = 3
backBtn.Parent = keyPage
backBtn.MouseEnter:Connect(function() tween(backBtn, 0.12, {TextColor3 = ACCENT}) end)
backBtn.MouseLeave:Connect(function() tween(backBtn, 0.12, {TextColor3 = DIM}) end)
backBtn.MouseButton1Click:Connect(showGamePage)

-- ============================================================
-- PAGE 2: key
-- ============================================================

-- body: key field ---------------------------------------------
local hint = Instance.new("TextLabel")
hint.BackgroundTransparency = 1
hint.Position = UDim2.fromOffset(20, 98)
hint.Size = UDim2.new(1, -40, 0, 16)
hint.Font = Enum.Font.Code
hint.Text = "LICENSE KEY"
hint.TextColor3 = DIM
hint.TextSize = 12
hint.TextXAlignment = Enum.TextXAlignment.Left
hint.ZIndex = 3
hint.Parent = keyPage

local boxHolder = Instance.new("Frame")
boxHolder.Position = UDim2.fromOffset(20, 118)
boxHolder.Size = UDim2.new(1, -40, 0, 44)
boxHolder.BackgroundColor3 = FIELD
boxHolder.BorderSizePixel = 0
boxHolder.ZIndex = 3
boxHolder.Parent = keyPage
corner(boxHolder, 10)
local boxStroke = stroke(boxHolder, Color3.fromRGB(50, 52, 58), 1.2)

local kicon = Instance.new("TextLabel")
kicon.BackgroundTransparency = 1
kicon.Position = UDim2.fromOffset(12, 0)
kicon.Size = UDim2.fromOffset(24, 44)
kicon.Font = Enum.Font.GothamBold
kicon.Text = "#"
kicon.TextColor3 = ACCENT
kicon.TextSize = 16
kicon.ZIndex = 4
kicon.Parent = boxHolder

local box = Instance.new("TextBox")
box.BackgroundTransparency = 1
box.Position = UDim2.fromOffset(40, 0)
box.Size = UDim2.new(1, -54, 1, 0)
box.Font = Enum.Font.Code
box.PlaceholderText = "Paste your key here..."
box.PlaceholderColor3 = DIM
box.Text = ""
box.TextColor3 = TXT
box.TextSize = 14
box.TextXAlignment = Enum.TextXAlignment.Left
box.ClearTextOnFocus = false
box.ZIndex = 4
box.Parent = boxHolder
box.Focused:Connect(function() tween(boxStroke, 0.15, {Color = ACCENT, Thickness = 1.7}); tween(kicon, 0.15, {TextColor3 = ACCENT3}) end)
box.FocusLost:Connect(function() tween(boxStroke, 0.15, {Color = Color3.fromRGB(50,52,58), Thickness = 1.2}); tween(kicon, 0.15, {TextColor3 = ACCENT}) end)

-- remember toggle ---------------------------------------------
local remember = true
local rmCheck = Instance.new("TextButton")
rmCheck.Position = UDim2.fromOffset(20, 172)
rmCheck.Size = UDim2.fromOffset(18, 18)
rmCheck.BackgroundColor3 = FIELD
rmCheck.BorderSizePixel = 0
rmCheck.Text = ""
rmCheck.AutoButtonColor = false
rmCheck.ZIndex = 3
rmCheck.Parent = keyPage
corner(rmCheck, 5)
local rmStroke = stroke(rmCheck, ACCENT, 1.2, 0.2)
local rmTick = Instance.new("TextLabel")
rmTick.BackgroundTransparency = 1
rmTick.Size = UDim2.fromScale(1, 1)
rmTick.Font = Enum.Font.GothamBold
rmTick.Text = "v"
rmTick.TextColor3 = Color3.fromRGB(12, 14, 15)
rmTick.TextSize = 13
rmTick.ZIndex = 4
rmTick.Parent = rmCheck
local rmLabel = Instance.new("TextButton")
rmLabel.BackgroundTransparency = 1
rmLabel.Position = UDim2.fromOffset(44, 170)
rmLabel.Size = UDim2.fromOffset(200, 22)
rmLabel.Font = Enum.Font.Code
rmLabel.Text = "Remember my key"
rmLabel.TextColor3 = DIM
rmLabel.TextSize = 13
rmLabel.TextXAlignment = Enum.TextXAlignment.Left
rmLabel.AutoButtonColor = false
rmLabel.ZIndex = 3
rmLabel.Parent = keyPage
local function renderRemember()
	if remember then
		tween(rmCheck, 0.15, {BackgroundColor3 = ACCENT})
		rmTick.Visible = true
	else
		tween(rmCheck, 0.15, {BackgroundColor3 = FIELD})
		rmTick.Visible = false
	end
end
local function toggleRemember() remember = not remember; renderRemember() end
rmCheck.MouseButton1Click:Connect(toggleRemember)
rmLabel.MouseButton1Click:Connect(toggleRemember)
renderRemember()

-- helper buttons ----------------------------------------------
local function mkGhost(txt, x, w, col)
	local b = Instance.new("TextButton")
	b.Position = UDim2.fromOffset(x, 204)
	b.Size = UDim2.fromOffset(w, 36)
	b.BackgroundColor3 = Color3.fromRGB(28, 30, 35)
	b.BorderSizePixel = 0
	b.Font = Enum.Font.Code
	b.Text = txt
	b.TextColor3 = col
	b.TextSize = 13
	b.AutoButtonColor = false
	b.ZIndex = 3
	b.Parent = keyPage
	corner(b, 10)
	local st = stroke(b, col, 1, 0.35)
	b.MouseEnter:Connect(function() tween(b, 0.15, {BackgroundColor3 = col, TextColor3 = Color3.fromRGB(14,15,17)}); tween(st, 0.15, {Transparency = 1}) end)
	b.MouseLeave:Connect(function() tween(b, 0.15, {BackgroundColor3 = Color3.fromRGB(28,30,35), TextColor3 = col}); tween(st, 0.15, {Transparency = 0.35}) end)
	return b
end
local getBtn = mkGhost("GET KEY", 20, 182, ACCENT)
local dcBtn  = mkGhost("DISCORD", 218, 182, BLURPLE)

-- primary LOAD ------------------------------------------------
local verify = Instance.new("TextButton")
verify.Position = UDim2.fromOffset(20, 252)
verify.Size = UDim2.new(1, -40, 0, 46)
verify.BackgroundColor3 = ACCENT
verify.BorderSizePixel = 0
verify.Font = Enum.Font.GothamBold
verify.Text = "LOAD"
verify.TextColor3 = Color3.fromRGB(10, 12, 13)
verify.TextSize = 16
verify.AutoButtonColor = false
verify.ZIndex = 3
verify.ClipsDescendants = true
verify.Parent = keyPage
corner(verify, 10)
local vg = Instance.new("UIGradient")
vg.Rotation = 90
vg.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, ACCENT3), ColorSequenceKeypoint.new(1, ACCENT2)})
vg.Parent = verify

local shimmer = Instance.new("Frame")
shimmer.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
shimmer.BackgroundTransparency = 0.6
shimmer.BorderSizePixel = 0
shimmer.Size = UDim2.new(0, 60, 1, 40)
shimmer.Position = UDim2.new(0, -80, 0, -20)
shimmer.Rotation = 18
shimmer.ZIndex = 4
shimmer.Parent = verify
local shg = Instance.new("UIGradient")
shg.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.4), NumberSequenceKeypoint.new(1, 1)})
shg.Parent = shimmer
task.spawn(function()
	while gui and gui.Parent do
		shimmer.Position = UDim2.new(0, -80, 0, -20)
		tween(shimmer, 0.9, {Position = UDim2.new(1, 40, 0, -20)}, Enum.EasingStyle.Linear)
		task.wait(3.2)
	end
end)
verify.MouseEnter:Connect(function() tween(verify, 0.12, {Size = UDim2.new(1, -34, 0, 48), Position = UDim2.fromOffset(17, 251)}) end)
verify.MouseLeave:Connect(function() tween(verify, 0.12, {Size = UDim2.new(1, -40, 0, 46), Position = UDim2.fromOffset(20, 252)}) end)

-- status pill -------------------------------------------------
local pill = Instance.new("Frame")
pill.Position = UDim2.fromOffset(20, 312)
pill.Size = UDim2.new(1, -40, 0, 40)
pill.BackgroundColor3 = Color3.fromRGB(22, 23, 27)
pill.BorderSizePixel = 0
pill.ZIndex = 3
pill.Parent = keyPage
corner(pill, 10)
stroke(pill, Color3.fromRGB(44, 46, 52), 1, 0.2)
local sdot = Instance.new("Frame")
sdot.Size = UDim2.fromOffset(8, 8)
sdot.Position = UDim2.fromOffset(14, 16)
sdot.BackgroundColor3 = DIM
sdot.BorderSizePixel = 0
sdot.ZIndex = 4
sdot.Parent = pill
corner(sdot, 4)
local status = Instance.new("TextLabel")
status.BackgroundTransparency = 1
status.Position = UDim2.fromOffset(32, 0)
status.Size = UDim2.new(1, -44, 1, 0)
status.Font = Enum.Font.Code
status.Text = "Get a key, paste it, then press LOAD"
status.TextColor3 = DIM
status.TextSize = 12
status.TextWrapped = true
status.TextXAlignment = Enum.TextXAlignment.Left
status.ZIndex = 4
status.Parent = pill
local function setStatus(t, c)
	status.Text = t
	tween(status, 0.15, {TextColor3 = c or DIM})
	tween(sdot, 0.15, {BackgroundColor3 = c or DIM})
end

-- loading dots
local loading = false
local function startLoading()
	loading = true
	task.spawn(function()
		local n = 0
		while loading do
			verify.Text = "LOADING" .. string.rep(".", n % 4)
			n += 1
			task.wait(0.25)
		end
	end)
end

-- prefill saved key -------------------------------------------
local saved = readKey()
if saved and #saved >= 3 then
	box.Text = saved
	setStatus("Saved key loaded - press LOAD to continue.", ACCENT)
end

-- actions -----------------------------------------------------
getBtn.MouseButton1Click:Connect(function()
	clip(GET_KEY_URL)
	setStatus("Key link copied - open it in your browser.", ACCENT)
end)
dcBtn.MouseButton1Click:Connect(function()
	clip(DISCORD_URL)
	setStatus("Discord invite copied to clipboard.", BLURPLE)
end)

local function closeAnim()
	tween(dim, 0.22, {BackgroundTransparency = 1})
	tween(glow, 0.22, {ImageTransparency = 1})
	tween(main, 0.22, {Size = UDim2.fromOffset(420, 0), BackgroundTransparency = 1}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	task.wait(0.24)
	pcall(function() gui:Destroy() end)
end
close.MouseButton1Click:Connect(closeAnim)

verify.MouseButton1Click:Connect(function()
	if loading then return end
	local key = box.Text or ""
	key = key:gsub("%s+", "")
	if not key or #key < 3 then
		setStatus("Enter a valid key first.", RED)
		tween(boxStroke, 0.15, {Color = RED, Thickness = 1.7})
		return
	end
	if remember then saveKey(key) else clearKey() end
	startLoading()
	setStatus("Verifying key...", ACCENT)
	getgenv().SCRIPT_KEY = key
	task.wait(0.35)
	loading = false
	closeAnim()
end)

-- intro animation --------------------------------------------
main.Size = UDim2.fromOffset(420, 0)
main.BackgroundTransparency = 0.3
glow.ImageTransparency = 1
tween(main, 0.34, {Size = UDim2.fromOffset(420, 380), BackgroundTransparency = 0}, Enum.EasingStyle.Back)
tween(glow, 0.5, {ImageTransparency = 0.7})

-- rotating gradient border + breathing glow
task.spawn(function()
	local t = 0
	while gui and gui.Parent do
		t += RS.RenderStepped:Wait()
		bgrad.Rotation = (t * 60) % 360
		glow.ImageTransparency = 0.7 + math.sin(t * 1.6) * 0.08
	end
end)

-- block until a key is entered; JNKIE validates it server-side afterwards
while not getgenv().SCRIPT_KEY do
	task.wait(0.1)
	if not gui or not gui.Parent then break end
end
pcall(function() if gui then gui:Destroy() end end)
