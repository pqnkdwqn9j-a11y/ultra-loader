local ok, err = pcall(function()
	local SRC = "ReplicatedStorage.Modules.AssetContainer"
	local info, getups, getconsts = debug.info, debug.getupvalues, debug.getconstants
	local out = {}
	local function w(s) out[#out + 1] = s end
	local function tn(x)
		local t = typeof(x)
		if t == "string" then return ("str(%d)"):format(#x) end
		if t == "number" or t == "boolean" then return tostring(x) end
		return t
	end
	local function tinfo(t)
		local n, nums, selfref, mt = 0, {}, false, nil
		pcall(function() mt = getmetatable(t) end)
		for k, v in next, t do
			n = n + 1
			if rawequal(v, t) then selfref = true end
			if type(k) == "number" and type(v) == "number" then nums[#nums + 1] = k .. "=" .. v end
			if n > 200 then break end
		end
		return ("tbl len=%d keys=%d self=%s mt=%s nums=[%s]"):format(rawlen(t), n, tostring(selfref), tn(mt), table.concat(nums, ","))
	end
	local seen, fns = {}, {}
	for _, f in getgc(false) do
		if type(f) == "function" and not seen[f] then
			seen[f] = true
			local s, l, n = info(f, "sln")
			if s == SRC then fns[#fns + 1] = {f = f, l = l, n = n or ""} end
		end
	end
	table.sort(fns, function(a, b) return a.l < b.l end)
	w(("functions: %d"):format(#fns))
	for _, e in fns do
		local f = e.f
		local strs, nc = {}, 0
		local okc, cs = pcall(getconsts, f)
		if okc then
			for _, c in next, cs do
				nc = nc + 1
				if type(c) == "string" and #strs < 12 then strs[#strs + 1] = c:sub(1, 24):gsub("[%c]", "?") end
			end
		end
		w(("\n[L%d] %s consts=%d {%s}"):format(e.l, e.n, nc, table.concat(strs, "|")))
		local oku, ups = pcall(getups, f)
		if oku then
			for i, u in next, ups do
				local d
				if type(u) == "table" then
					d = tinfo(u)
				elseif type(u) == "function" then
					local us, ul = info(u, "sl")
					d = ("fn %s:%s"):format(us == SRC and "AC" or tostring(us), tostring(ul))
				else
					d = tn(u)
				end
				w(("  up%d: %s"):format(i, d))
			end
		end
	end
	local path = "Burmalda_scan.txt"
	writefile(path, table.concat(out, "\n"))
	pcall(setclipboard, ("scan done: %d functions, saved %s"):format(#fns, path))
end)
if not ok then
	pcall(writefile, "Burmalda_scan_error.txt", tostring(err))
end
