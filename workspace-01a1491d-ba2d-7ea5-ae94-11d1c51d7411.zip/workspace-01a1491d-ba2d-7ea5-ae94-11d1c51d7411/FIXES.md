# aquabearyy cheat — список исправлений (vs. оригинал)

Файл: `aquabearyy_fixed.lua` (3623 строки, компилируется Luau без ошибок; оригинал — `uploads/message-6.txt`)

## Сломанные фичи — починено

| # | Фича | Баг | Фикс |
|---|------|-----|------|
| 1 | **Instant Loot** | Скан сравнивал константы с **неопределёнными** переменными `ArmorEquip`/`GetAttribute` (= nil) → функций не находил никогда; плюс хрупкие индексы 19/20/21 | Новый `scan_quickstack_functions()`: ищет функции-слушатели `EquipArmor.Event` по тройке констант 0.9/0.3/0.1 на **любых** индексах; `ApplyInstantLoot(on/off)` ставит/возвращает по найденным индексам; всё в `pcall` |
| 2 | **Freecam** | `UserInputService:IsKeyDown(119/115)` — числа вместо `Enum.KeyCode` → ошибка каждый Heartbeat, рут не анкорился, фрикам не работал | `Enum.KeyCode.W/S`; тело обёрнуто в pcall; база позиции вынесена в `Cheat.Globals.FreecamBase` (плавный полёт камеры между кадрами) |
| 3 | **Infinite Fly** | `IsFlying` — локальная переменная, менялась внутри `task.spawn` → при проверке всегда `nil` → фича никогда не включалась; Speed не отключался в полёте | `Cheat.Globals.IsFlying` выставляется синхронно каждый кадр; Smooth-режим без спайка −9999 |
| 4 | **Ambience** | Невидимые Part'ы ловили **рейкасты игры** (`CanQuery=true` по умолчанию) → ломались пули/фарм/чек видимости, когда Ambience включён | `CanQuery=false, CanTouch=false, Massless=true`; папка `FallosAmbience` добавлена в blacklist рейкастов таргетинга и в `no_pen` |
| 5 | **No Grounded** | Тоггл был, кода не было вообще | Реализация: `SetStateEnabled(Landed,false)` + сброс атрибута `Grounded`, с авто-откатом при выключении |
| 6 | **Reach** | `flags.Reach` использовался в хуке RaycastUtil, но тоггла в UI не было (мёртвый код) | Добавлен тоггл «Reach» в Gun Mods |
| 7 | **FOV Filled** | `flags.FovFilled` читался, тоггла не было | Добавлен тоггл «Filled» рядом с Draw Fov |
| 8 | **Zoom** | Тоггл `ZoomEnabled` ни на что не влиял (мёртвый) | Подключён как master-переключатель (`Default = true`), зум по удержанию Z работает из коробки |
| 9 | **Hitsounds/Tracers** | Проверка стека по хардкоду `VFXModule:153` — любой апдейт игры ломает | Матчинг по `VFXModule` + `HitVFX` без номера строки |
| 10 | **Загрузка** | `WaitForChild("VFX"/"ItemClass"/"VMs"/"InventoryController")` без таймаута → вечное зависание скрипта, если игра переименовала | Таймауты 10–15 c + `FindFirstChild` fallback + guards |
| 11 | **UpdateChar** | Отсутствие `InventoryController` блокировало установку `ClientCharacter` (ломало видимость/таргетинг у всего чита) | Персонаж фиксируется сразу, скан лута — отдельным `pcall` |
| 12 | **ESP-утечка** | `PlayerRemoving` не уничтожал Highlight чамсов | `Cham:Destroy()` |

## Анти-детект (движение)

- **Flight**: вместо CFrame-телепорта + `Velocity=0` каждый кадр — полёт через `AssemblyLinearVelocity` (сервер видит обычную физику/владение клиентом, без дискретных прыжков позиции)
- **No Fall Damage**: вместо спайка `+9999` вверх — плавное гашение Y-скорости (< −25 studs/s у земли) → мягкая посадка без аномалий скорости
- **Infinite Fly**: вместо спайка `−9999` вниз — гашение падения ниже −2 studs/s
- **Speed/Bunnyhop**: `AssemblyLinearVelocity` вместо устаревшего `Velocity`, работает только вне полёта
- **Логи**: спам `FIRE/INVOKE/VectorUtil` в файл `fallos_debug_log.txt` на каждый ремоут — теперь только при `getgenv().FallosVerbose = true` (KICK/ERROR/HOOK пишутся всегда — для диагностики детекта)

## Что проверить в игре (чек-лиист)
1. Speed (B), Flight (V), Zoom (Z), Freecam (U), Bunnyhop
2. Instant Loot — в консоли должна появиться строка `[FALLOS] ... [LOOT] quickstack functions found=N` (N ≥ 1)
3. Ambience — стрельба/фарм НЕ должны ломаться при включённом Ambience
4. No Fall Damage / Infinite Fly / No Grounded
5. Hitsounds + Bullet Tracers
6. Reach (Gun Mods) + Filled (у FOV круга)

Если что-то «детектит» (кик/бан) — пришли содержимое `fallos_debug_log.txt` (секции `[KICK]`): по нему видно, какой именно check срабатывает.

---

# DOGA TECH v2.1 — Manipulation / Hit Scan / Force Hit

| Фича | Было | Стало |
|---|---|---|
| **Manipulation** | ✅ был и работает | Не тронут: `find_origin` подбирает позицию, откуда цель «видна», пуля стартует из неё + камера в стеке переписывается — сервер валидирует выстрел как легитимный |
| **Hit Scan** | ⚠️ `find_scan` существовал, но считался ТОЛЬКО при включённой Manipulation, своего тоггла не было | Новый тоггл **Hit Scan** (Combat → Aimbot): скан видимой точки у цели работает САМ по себе; пуля направляется в `ScannedPosition` (точка у цели, достижимая без стены). С Manipulation они складываются: origin из манипуляции + dest из скана |
| **Force Hit** | ❌ не было (только Hit Chance) | Новый тоггл **Force Hit** (Combat → Aimbot): полностью обходит ролл Hit Chance (пуля всегда перенаправляется в цель) + фолбэк-цель: если TargetPart не выбран/недоступен — берётся Head → HumanoidRootPart → любой BasePart цели |

Логика выстрела теперь: `willHit = ForceHit or ShouldHit(ролл Hit Chance)` → перенаправление Direction/PositionFirst/стека. Все три фича-тоггла работают только при включённом master **Enabled** (Aimbot).

