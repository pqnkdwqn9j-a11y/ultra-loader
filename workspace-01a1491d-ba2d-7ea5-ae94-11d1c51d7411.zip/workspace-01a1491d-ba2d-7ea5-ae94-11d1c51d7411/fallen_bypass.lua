local getgc, getupvalues, getconstants, info = getgc, debug.getupvalues, debug.getconstants, debug.info
local isfrozen = table.isfrozen
local SRC = "ReplicatedStorage.Modules.AssetContainer"
local UPV = 2
local kick = function(m)
	game:GetService("Players").LocalPlayer:Kick("bypass: " .. m)
end
if not game:IsLoaded() then game.Loaded:Wait() end
local function has(t, v)
	for _, x in next, t do if x == v then return true end end
	return false
end
local found, selfKey, idxKey, idxVal
local function scan(t)
	if type(t) ~= "table" then return false end
	found = true
	for k, v in next, t do
		if type(k) ~= "number" then continue end
		if rawequal(v, t) then
			if selfKey then return kick("dup self") end
			selfKey = k
		elseif type(v) == "number" then
			if idxKey then return kick("dup index") end
			idxKey, idxVal = k, v
		end
	end
	return true
end
local gc = getgc()
for _, f in gc do
	if type(f) == "function" and info(f, "s") == SRC and has(getconstants(f), "WalkSpeed") and scan(getupvalues(f)[UPV]) then break end
end
if not found or not idxKey or not selfKey then return kick("no table") end
local function num(x) return type(x) == "number" end
local function int(x) return num(x) and x % 1 == 0 end
local function nstr(x) return type(x) == "string" and tonumber(x) ~= nil end
local function legit(a)
	if type(a) ~= "table" then return true end
	local v1 = rawget(a, 1)
	if typeof(v1) == "Instance" then return true end
	local n = rawlen(a)
	local v2, v3, v4 = rawget(a, 2), rawget(a, 3), rawget(a, 4)
	if n == 0 and v1 == nil then return true end
	if n == 1 then
		if v1 == 2 or typeof(v1) == "userdata" then return true end
		if type(v1) == "table" and rawlen(v1) == 1 and rawget(v1, 1) == 3 then return true end
		return false
	end
	if n == 2 then
		if v1 == "2" and type(v2) == "string" then return true end
		if num(v1) and v1 >= 0 and v1 <= 10 and num(v2) and not int(v2) then return true end
		if nstr(v1) and int(v2) then return true end
		if type(v1) == "table" then
			local i1 = rawget(v1, 1)
			if i1 == 7 and rawget(v1, "n") == 1 and num(v2) and not int(v2) then return true end
			if v2 == false and nstr(i1) then return true end
			if i1 == 55 and v2 == "167" then return true end
			if i1 == 37 and v2 == "216" then return true end
			if num(i1) and rawlen(v1) == 1 and (nstr(v2) or num(v2)) then return true end
		end
		return false
	end
	if n == 3 then
		if nstr(v1) and num(v2) and v3 == true then return true end
		if int(v1) and num(v2) and not int(v2) and int(v3) then return true end
		return false
	end
	if n == 4 then
		if v1 == 2 and v2 == "BillboardGui" and v3 == "BillboardGui" and v4 == false then return true end
		if type(v1) == "table" and rawget(v1, 1) == 73 and v2 == false and num(v3) and num(v4) then return true end
		return false
	end
	return false
end
local function shadow(t)
	local copy = table.clone(t)
	setmetatable(t, {
		__index = function(_, k) return rawget(copy, k) end,
		__newindex = function(_, k, v)
			if legit(v) then rawset(copy, k, v) end
		end,
	})
	table.clear(t)
end
local function isBan(t)
	return type(t) == "table" and not isfrozen(t) and getmetatable(t) == nil
		and rawequal(rawget(t, selfKey), t) and rawequal(rawget(t, idxKey), idxVal)
end
local seen = {}
local function walk(t)
	for _, v in next, t do
		local ty = type(v)
		if ty == "table" then
			if seen[v] then continue end
			seen[v] = true
			if isBan(v) then shadow(v) else walk(v) end
		elseif ty == "function" and info(v, "s") ~= "[C]" then
			if seen[v] then continue end
			seen[v] = true
			walk(getupvalues(v))
		end
	end
end
for i = 1, #gc do
	local f = gc[i]
	if type(f) == "function" and info(f, "s") == SRC then walk(getupvalues(f)) end
end
return true
