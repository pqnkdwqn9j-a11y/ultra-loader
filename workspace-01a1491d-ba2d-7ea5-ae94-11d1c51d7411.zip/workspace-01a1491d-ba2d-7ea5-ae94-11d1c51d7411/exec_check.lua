local names = {
	"getgc", "getgenv", "writefile", "readfile", "isfile", "makefolder", "isfolder", "setclipboard",
	"identifyexecutor", "checkcaller", "getrawmetatable", "setrawmetatable", "setreadonly", "newcclosure",
	"cloneref", "compareinstances", "getsenv", "getcallingscript", "hookfunction", "clonefunction",
	"debug.info", "debug.getupvalues", "debug.setupvalue", "debug.getconstants", "debug.setconstant",
	"debug.getstack", "debug.setstack", "debug.getprotos", "Drawing.new", "mousemoverel", "mouse1press",
}
local out = {}
local okx, ex = pcall(function() return identifyexecutor() end)
out[1] = "executor: " .. tostring(okx and ex or "?")
for _, n in names do
	local ok, v = pcall(function()
		local cur = getfenv(0)
		for part in n:gmatch("[^%.]+") do cur = cur[part] end
		return cur
	end)
	out[#out + 1] = n .. " = " .. (ok and v ~= nil and "OK" or "MISSING")
end
local s = table.concat(out, "\n")
pcall(setclipboard, s)
pcall(writefile, "exec_check.txt", s)
